import { MusicProvider, Track, SearchResults } from './MusicProvider';

const API_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:3000';

/**
 * Backed by Deezer's public catalog API (via our own backend, see
 * deezer-provider.service.ts) — the source that actually stuck, after
 * Spotify (Premium-only developer accounts) and Apple's iTunes Search
 * API (erratic, aggressive rate-limiting from shared cloud IPs) both
 * turned out not to work for this project. No key needed, previewUrl
 * is a reliable 30-second CDN clip present for most tracks. Plays
 * through a single reused <audio> element — same pattern every
 * provider tried here has used.
 */
export class DeezerProvider implements MusicProvider {
  private audio = new Audio();

  constructor() {
    this.audio.preload = 'auto';
  }

  async search(query: string): Promise<SearchResults> {
    const res = await fetch(`${API_URL}/music/search?q=${encodeURIComponent(query)}`, { credentials: 'include' });
    if (res.status === 429) {
      throw new Error('Музыкальный поиск временно ограничен — попробуйте через минуту.');
    }
    if (!res.ok) throw new Error(`Не удалось выполнить поиск (ошибка ${res.status}). Попробуйте ещё раз.`);
    const data = await res.json();
    return {
      artists: (data.artists ?? []).map((a: any) => ({ id: a.id, name: a.name, imageUrl: a.imageUrl, genres: a.genres ?? [] })),
      tracks: (data.tracks ?? []).map((t: any) => ({
        id: t.id, name: t.name, artist: t.artist, durationSec: t.durationSec, imageUrl: t.imageUrl, previewUrl: t.previewUrl,
      })),
      albums: (data.albums ?? []).map((al: any) => ({ id: al.id, name: al.name, artist: al.artist, imageUrl: al.imageUrl, releaseYear: al.releaseYear })),
    };
  }

  async getArtistTracks(artistId: string): Promise<Track[]> {
    const res = await fetch(`${API_URL}/music/artist/${artistId}/top-tracks`, { credentials: 'include' });
    if (!res.ok) throw new Error(`Artist top tracks failed: ${res.status}`);
    const data = await res.json();
    return (data ?? []).map((t: any) => ({
      id: t.id, name: t.name, artist: t.artist, durationSec: t.durationSec, imageUrl: t.imageUrl, previewUrl: t.previewUrl,
    }));
  }

  async load(track: Track): Promise<void> {
    if (!track.previewUrl) {
      throw new Error('Этот трек сейчас недоступен для воспроизведения — у Deezer нет превью для этой записи.');
    }
    this.audio.src = track.previewUrl;
    this.audio.currentTime = 0;
  }

  async play(): Promise<void> {
    await this.audio.play();
  }

  pause(): void {
    this.audio.pause();
  }

  async resume(): Promise<void> {
    await this.audio.play();
  }

  seek(seconds: number): void {
    this.audio.currentTime = seconds;
  }

  setVolume(volume: number): void {
    this.audio.volume = Math.max(0, Math.min(1, volume));
  }

  getCurrentTime(): number {
    return this.audio.currentTime || 0;
  }

  getDuration(): number {
    return this.audio.duration || 0;
  }

  onEnded(cb: () => void): void {
    this.audio.addEventListener('ended', cb);
  }

  onTimeUpdate(cb: (time: number) => void): void {
    this.audio.addEventListener('timeupdate', () => cb(this.audio.currentTime));
  }
}
