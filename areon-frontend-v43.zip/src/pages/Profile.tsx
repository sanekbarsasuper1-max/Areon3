import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, Me, MatchSummary, ProfileSummary, Hero } from '../api';

export function Profile() {
  const [me, setMe] = useState<Me | null>(null);
  const [summary, setSummary] = useState<ProfileSummary | null>(null);
  const [matches, setMatches] = useState<MatchSummary[]>([]);
  const [heroesById, setHeroesById] = useState<Record<number, Hero>>({});
  const [syncing, setSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);
  const [shardBalance, setShardBalance] = useState<number | null>(null);
  const [hofCount, setHofCount] = useState<number | null>(null);
  const [equipped, setEquipped] = useState<{ id: string; itemId: string; item: { name: string; iconEmoji: string; rarity: string; category: string } }[]>([]);

  useEffect(() => {
    api.shardBalance().then((r) => setShardBalance(r.balance));
    api.hallOfFameMine().then((entries) => setHofCount(entries.length));
    api.shopEquipped().then(setEquipped).catch(() => {});
  }, []);

  async function load() {
    const [meRes, summaryRes, matchesRes, heroesRes] = await Promise.all([
      api.me(),
      api.summary(),
      api.matches({}),
      api.heroes(),
    ]);
    setMe(meRes);
    setSummary(summaryRes);
    setMatches(matchesRes.slice(0, 6));
    setHeroesById(Object.fromEntries(heroesRes.map((h) => [h.id, h])));
  }

  useEffect(() => {
    load();
  }, []);

  async function sync() {
    setSyncing(true);
    setSyncMessage(null);
    try {
      const result = await api.syncMatches();
      await load();
      setSyncMessage(
        result.skipped > 0
          ? `Загружено матчей: ${result.synced}. Пропущено (неполные данные от OpenDota): ${result.skipped}.`
          : `Загружено матчей: ${result.synced}.`,
      );
    } catch {
      setSyncMessage('Не удалось связаться с OpenDota — попробуйте ещё раз позже.');
    } finally {
      setSyncing(false);
    }
  }

  if (!me || !summary) {
    return (
      <div style={{ minHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, color: 'var(--text-secondary)' }}>
        Загрузка…
      </div>
    );
  }

  return (
    <div className="page-shell-wide">
      {/* ---------- Header: avatar + name + rating ---------- */}
      <div style={{ display: 'flex', gap: 28, marginBottom: 32, alignItems: 'center', flexWrap: 'wrap' }}>
        <img
          src={me.avatarFull}
          alt=""
          style={{ width: 128, height: 128, borderRadius: 18, boxShadow: '0 12px 32px rgba(0,0,0,0.4)' }}
        />
        <div style={{ flex: 1, minWidth: 240 }}>
          <p style={{ fontSize: 34, fontWeight: 700, margin: '0 0 8px', letterSpacing: -0.5 }}>{me.personaName}</p>
          <p style={{ fontSize: 16, color: 'var(--text-secondary)', margin: 0 }}>
            {me.statsExposed ? 'Статистика доступна' : 'Статистика недоступна'}
          </p>
          <p style={{ fontSize: 14, color: 'var(--primary)', margin: '6px 0 0' }}>
            Site Rating: <strong>{me.siteRating}</strong>
            {'  ·  '}
            Drafter Rating: <strong>{me.draftRating}</strong>
          </p>
          {equipped.length > 0 && (
            <p style={{ fontSize: 13, margin: '8px 0 0' }}>
              {equipped.map((e) => (
                <span key={e.id} title={e.item.name} style={{ marginRight: 8 }}>{e.item.iconEmoji} {e.item.name}</span>
              ))}
            </p>
          )}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1fr) 320px', gap: 28, alignItems: 'flex-start' }}>
        {/* ---------- Main column ---------- */}
        <div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px,1fr))', gap: 16, marginBottom: 28 }}>
            <Stat label="Winrate" value={`${summary.winrate}%`} />
            <Stat label="Wins / Losses" value={`${summary.wins} / ${summary.losses}`} />
            <Stat label="KDA" value={summary.avgKda} />
            <Stat label="GPM / XPM" value={`${summary.avgGpm ?? '—'} / ${summary.avgXpm ?? '—'}`} />
          </div>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, flexWrap: 'wrap', gap: 10 }}>
            <p style={{ fontSize: 22, fontWeight: 600, margin: 0 }}>Последние матчи</p>
            <div style={{ display: 'flex', gap: 10 }}>
              <Link to="/matches" className="button-ghost" style={{ textDecoration: 'none' }}>
                Все матчи
              </Link>
              <button className="button-ghost" onClick={sync} disabled={syncing}>
                {syncing ? 'Синхронизация…' : 'Обновить из OpenDota'}
              </button>
            </div>
          </div>

          {syncMessage && (
            <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 12px' }}>{syncMessage}</p>
          )}

          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {matches.length === 0 && (
              <p style={{ fontSize: 16, color: 'var(--text-muted)' }}>
                Матчей пока нет — нажмите «Обновить из OpenDota».
              </p>
            )}
            {matches.map((m) => {
              const hero = heroesById[m.heroId];
              return (
                <Link
                  key={m.matchId}
                  to={`/matches/${m.id}`}
                  className="card"
                  style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', textDecoration: 'none', color: 'inherit' }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                    <span
                      style={{
                        width: 5, height: 30, borderRadius: 3,
                        background: m.won ? 'var(--accent)' : 'var(--danger)',
                      }}
                    />
                    {hero?.iconUrl && (
                      <img src={hero.iconUrl} alt="" style={{ width: 52, aspectRatio: '16/9', objectFit: 'cover', borderRadius: 6 }} />
                    )}
                    <span style={{ fontSize: 17, fontWeight: 500 }}>{hero?.localizedName ?? `Герой #${m.heroId}`}</span>
                  </div>
                  <span style={{ fontSize: 16, color: 'var(--text-secondary)' }}>
                    {m.kills}/{m.deaths}/{m.assists}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>

        {/* ---------- Side column: extra info ---------- */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {shardBalance != null && (
            <Link to="/trials" className="card" style={{ textDecoration: 'none', color: 'inherit', display: 'block' }}>
              <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '0 0 6px', letterSpacing: 1.5 }}>ORION PLUS</p>
              <p style={{ fontSize: 30, fontWeight: 700, margin: 0, color: 'var(--gold)' }}>{shardBalance}</p>
            </Link>
          )}

          {hofCount != null && hofCount > 0 && (
            <Link
              to="/hall-of-fame"
              className="card"
              style={{ textDecoration: 'none', color: 'inherit', display: 'block', border: '1px solid rgba(217,184,74,0.35)' }}
            >
              <p style={{ fontSize: 17, margin: '0 0 4px' }}>🏛️ Зал славы Areon</p>
              <p style={{ fontSize: 14, color: 'var(--text-muted)', margin: 0 }}>
                {hofCount} {hofCount === 1 ? 'историческое достижение' : hofCount < 5 ? 'исторических достижения' : 'исторических достижений'}
              </p>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="card">
      <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: '0 0 8px' }}>{label}</p>
      <p style={{ fontSize: 28, fontWeight: 700, margin: 0 }}>{value}</p>
    </div>
  );
}
