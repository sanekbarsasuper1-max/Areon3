import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './App';
import './theme.css';

// TEMPORARY DIAGNOSTIC MARKER — proves the JS bundle actually executed,
// independent of anything React does further down. Safe to remove once
// the blank-screen issue is confirmed fixed.
const marker = document.createElement('div');
marker.textContent = 'JS ЗАГРУЗИЛСЯ — VITE_API_URL: ' + (import.meta.env.VITE_API_URL ?? '(не задан!)');
marker.style.cssText = 'position:fixed;top:0;left:0;right:0;background:#ff0000;color:#fff;font-size:16px;font-weight:bold;padding:10px;z-index:999999;text-align:center;';
document.body.appendChild(marker);

try {
  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>,
  );
} catch (err) {
  const errorDiv = document.createElement('div');
  errorDiv.textContent = 'ОШИБКА РЕНДЕРА: ' + String(err);
  errorDiv.style.cssText = 'position:fixed;top:50px;left:0;right:0;background:#000;color:#0f0;font-size:14px;padding:10px;z-index:999999;white-space:pre-wrap;';
  document.body.appendChild(errorDiv);
}

window.addEventListener('error', (e) => {
  const errorDiv = document.createElement('div');
  errorDiv.textContent = 'ГЛОБАЛЬНАЯ ОШИБКА: ' + e.message + ' (' + e.filename + ':' + e.lineno + ')';
  errorDiv.style.cssText = 'position:fixed;top:50px;left:0;right:0;background:#000;color:#f00;font-size:14px;padding:10px;z-index:999999;white-space:pre-wrap;';
  document.body.appendChild(errorDiv);
});
