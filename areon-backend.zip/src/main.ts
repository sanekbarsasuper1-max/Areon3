import { NestFactory } from '@nestjs/core';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import { AppModule } from './app.module';

// Node's JSON.stringify has no idea how to serialize a BigInt (Prisma
// returns bigint for any PostgreSQL BIGINT column, e.g. Match.matchId
// and WheelChallenge.matchId), and it throws rather than silently
// dropping the field — a real production outage found in this
// project's own logs (TypeError: Do not know how to serialize a
// BigInt), not a hypothetical. Individual call sites already convert
// theirs with .toString() where the code is aware of it, but that's
// exactly the kind of thing one new endpoint away from forgetting
// again. This is the actual fix: teach every BigInt in the process how
// to serialize itself, once, so no future endpoint can reintroduce
// this same crash by accident.
(BigInt.prototype as any).toJSON = function () {
  return this.toString();
};

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.use(cookieParser());
  app.use(
    helmet({
      // This is a JSON API, not an HTML-serving app — no page here
      // ever renders untrusted content that a CSP would be defending
      // against. The frontend (a separate service) has its own CSP,
      // tailored to what it actually loads — see its nginx.conf.
      // Every other helmet default (X-Content-Type-Options,
      // X-Frame-Options, Strict-Transport-Security, etc.) still
      // applies and is genuinely useful for an API too.
      contentSecurityPolicy: false,
    }),
  );

  // Real, concrete failure mode this guards against: a trailing slash
  // (or any other stray character) in FRONTEND_URL makes this NOT
  // equal the browser's Origin header on a cross-site fetch — CORS
  // then silently rejects it. The cookie itself still gets set fine
  // right after Steam's redirect (that's a top-level navigation, not
  // subject to CORS at all), so login visually "worked", but the very
  // next call the SPA makes — GET /auth/me, to find out who's logged
  // in — fails, and the UI falls back to "not logged in". That exact
  // mismatch is the single most common cause of "Steam login redirects
  // back but I'm still logged out" in a setup with the frontend and
  // backend on two different origins, which this project's always
  // been. Trimmed here so a stray trailing slash in the Render env var
  // can't silently break every login.
  const rawFrontendUrl = process.env.FRONTEND_URL ?? '';
  const frontendOrigin = rawFrontendUrl.replace(/\/+$/, '');
  if (!frontendOrigin) {
    // eslint-disable-next-line no-console
    console.warn('[CORS] FRONTEND_URL is not set — cross-origin requests from the SPA will be rejected.');
  }
  app.enableCors({
    origin: (requestOrigin, callback) => {
      if (!requestOrigin || requestOrigin === frontendOrigin) {
        callback(null, true);
        return;
      }
      // Logged, not just silently rejected — the only way to actually
      // SEE a mismatch (a stale env var, an extra character, a scheme
      // difference) instead of guessing at it from a generic "it
      // doesn't work" report.
      // eslint-disable-next-line no-console
      console.warn(`[CORS] Rejected origin "${requestOrigin}" — expected "${frontendOrigin}" (from FRONTEND_URL="${rawFrontendUrl}")`);
      callback(null, false);
    },
    credentials: true,
  });
  await app.listen(3000);
}
bootstrap();
