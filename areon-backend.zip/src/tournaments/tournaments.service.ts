import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { TournamentStatus, MatchStatus, TeamRole } from '@prisma/client';
import { HallOfFameService } from '../hall-of-fame/hall-of-fame.service';

const VALID_FORMATS = ['BO1', 'BO3', 'BO5'];
const VALID_BRACKET_FORMATS = ['single_elimination', 'double_elimination', 'round_robin', 'swiss', 'group_stage'];

/** Order-independent key for a pair of team IDs — "played each other" doesn't care which was teamA. */
function pairKey(a: string, b: string): string {
  return [a, b].sort().join('|');
}

@Injectable()
export class TournamentsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly hallOfFame: HallOfFameService,
  ) {}

  async create(userId: string, input: {
    name: string;
    description?: string;
    teamSize?: number;
    matchFormat?: string;
    bracketFormat?: string;
    maxTeams: number;
    swissRounds?: number;
    groupCount?: number;
    advancingPerGroup?: number;
  }) {
    // requirement: tournament creation is admin-only by default —
    // admins can grant canCreateFreeTournaments to specific trusted
    // users. Areon does not run paid tournaments at all right now (no
    // legal basis yet for paid esports events in Kazakhstan), so this
    // is the only gate left — there is no separate "paid" tier of
    // permission to check.
    const creator = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    if (!creator.isAdmin && !creator.canCreateFreeTournaments) {
      throw new ForbiddenException('У вас нет прав на создание турниров — обратитесь к администратору');
    }

    const matchFormat = input.matchFormat ?? 'BO1';
    if (!VALID_FORMATS.includes(matchFormat)) {
      throw new BadRequestException(`matchFormat must be one of: ${VALID_FORMATS.join(', ')}`);
    }
    const bracketFormat = input.bracketFormat ?? 'single_elimination';
    if (!VALID_BRACKET_FORMATS.includes(bracketFormat)) {
      throw new BadRequestException(`bracketFormat must be one of: ${VALID_BRACKET_FORMATS.join(', ')}`);
    }
    if (input.maxTeams < 2) {
      throw new BadRequestException('A tournament needs at least 2 teams');
    }
    if (bracketFormat === 'double_elimination' && input.maxTeams < 4) {
      throw new BadRequestException('Double elimination needs at least 4 teams');
    }
    if (bracketFormat === 'group_stage') {
      if (!input.groupCount || input.groupCount < 1) {
        throw new BadRequestException('group_stage needs groupCount (at least 1)');
      }
      if (input.advancingPerGroup != null && input.advancingPerGroup < 1) {
        throw new BadRequestException('advancingPerGroup must be at least 1');
      }
    }

    // No single "correct" round count for every team count the way
    // single elimination's log2 is exact — ceil(log2(n)) + 1 is the
    // standard rule-of-thumb Swiss sizing (comfortably separates a
    // clear leader from an n-team field without playing more rounds
    // than the field needs), used here only as a sensible default an
    // organizer who leaves swissRounds unset gets, not a hard rule.
    const swissRounds = bracketFormat === 'swiss'
      ? (input.swissRounds ?? Math.max(1, Math.ceil(Math.log2(input.maxTeams)) + 1))
      : undefined;

    return this.prisma.tournament.create({
      data: {
        name: input.name,
        description: input.description,
        teamSize: input.teamSize ?? 5,
        matchFormat,
        bracketFormat,
        maxTeams: input.maxTeams,
        swissRounds,
        groupCount: input.groupCount,
        advancingPerGroup: input.advancingPerGroup ?? (bracketFormat === 'group_stage' ? 2 : undefined),
        createdByUserId: userId,
        status: TournamentStatus.REGISTRATION_OPEN,
      },
    });
  }

  async list() {
    return this.prisma.tournament.findMany({
      include: { registrations: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  async get(id: string) {
    const tournament = await this.prisma.tournament.findUnique({
      where: { id },
      include: {
        registrations: { include: { team: true } },
        matches: { orderBy: [{ bracket: 'asc' }, { round: 'asc' }, { position: 'asc' }] },
      },
    });
    if (!tournament) throw new NotFoundException('Tournament not found');
    return tournament;
  }

  /**
   * Registers a team. Only that team's OWNER/CAPTAIN can register it —
   * an arbitrary member shouldn't be able to commit the whole roster to
   * a tournament unilaterally.
   */
  async register(tournamentId: string, userId: string, teamId: string) {
    const tournament = await this.prisma.tournament.findUnique({ where: { id: tournamentId } });
    if (!tournament) throw new NotFoundException('Tournament not found');
    if (tournament.status !== TournamentStatus.REGISTRATION_OPEN) {
      throw new BadRequestException('Registration is not open for this tournament');
    }

    const membership = await this.prisma.teamMember.findUnique({
      where: { teamId_userId: { teamId, userId } },
    });
    if (!membership || (membership.role !== TeamRole.OWNER && membership.role !== TeamRole.CAPTAIN)) {
      throw new ForbiddenException('Only the team owner or a captain can register it');
    }

    // Real gap this closes: teamSize was only ever used to LABEL a
    // tournament ("1x1", "2x2", "5x5"), never enforced — a 5-person
    // team could register for a 1x1 bracket with nothing stopping it.
    // Checked here at registration time (not tournament creation),
    // since a team's actual roster size is a property of the TEAM,
    // not the tournament.
    const memberCount = await this.prisma.teamMember.count({ where: { teamId } });
    if (memberCount !== tournament.teamSize) {
      throw new BadRequestException(
        `This tournament is ${tournament.teamSize}x${tournament.teamSize} — your team has ${memberCount} member${memberCount === 1 ? '' : 's'}`,
      );
    }

    const currentCount = await this.prisma.tournamentRegistration.count({ where: { tournamentId } });
    if (currentCount >= tournament.maxTeams) {
      throw new BadRequestException('Tournament is full');
    }

    // Free registration only — Areon does not run paid tournaments in
    // any form right now (see the TournamentRegistration schema
    // comment for why), so there is nothing else to check or charge
    // here.
    return this.prisma.tournamentRegistration.create({ data: { tournamentId, teamId } });
  }

  async generateBracket(tournamentId: string, requestingUserId: string) {
    const tournament = await this.prisma.tournament.findUnique({
      where: { id: tournamentId },
      include: { registrations: true },
    });
    if (!tournament) throw new NotFoundException('Tournament not found');
    if (tournament.createdByUserId !== requestingUserId) {
      throw new ForbiddenException('Only the tournament creator can generate the bracket');
    }
    if (tournament.registrations.length < 2) {
      throw new BadRequestException('Need at least 2 registered teams to generate a bracket');
    }

    const teamIds = tournament.registrations.map((r) => r.teamId);

    if (tournament.bracketFormat === 'double_elimination') {
      await this.generateDoubleEliminationBracket(tournamentId, teamIds);
    } else if (tournament.bracketFormat === 'round_robin') {
      await this.generateRoundRobinBracket(tournamentId, teamIds);
    } else if (tournament.bracketFormat === 'swiss') {
      await this.generateSwissBracket(tournamentId, teamIds);
    } else if (tournament.bracketFormat === 'group_stage') {
      await this.generateGroupStageBracket(tournamentId, teamIds, tournament.groupCount ?? 2);
    } else {
      await this.generateSingleEliminationBracket(tournamentId, teamIds);
    }

    await this.prisma.tournament.update({
      where: { id: tournamentId },
      data: { status: TournamentStatus.IN_PROGRESS },
    });

    return this.get(tournamentId);
  }

  /**
   * Seeded purely by registration order — no skill-based seeding. Byes
   * go to whichever teams land in an incomplete pairing when the field
   * isn't a power of two; that's a registration-order artifact, not a
   * deliberate seeding decision, and should be called out as such to
   * organizers rather than presented as fair seeding.
   */
  /**
   * Standard "circle method": fix team 0, rotate everyone else one
   * position each round — n-1 rounds for an even team count, n rounds
   * for odd (one team sits out — a bye — each round, rotating through
   * every team exactly once). Every team plays every other team
   * exactly once, which single/double elimination deliberately don't
   * guarantee (a team can be knocked out after one loss).
   */
  private async generateRoundRobinBracket(tournamentId: string, teamIds: string[]) {
    const teams = teamIds.length % 2 === 0 ? [...teamIds] : [...teamIds, null]; // null = bye slot for odd counts
    const n = teams.length;
    const totalRounds = n - 1;
    const matches: { round: number; position: number; teamAId: string | null; teamBId: string | null }[] = [];

    for (let round = 0; round < totalRounds; round++) {
      for (let i = 0; i < n / 2; i++) {
        const a = teams[i];
        const b = teams[n - 1 - i];
        if (a != null && b != null) {
          matches.push({ round: round + 1, position: i, teamAId: a, teamBId: b });
        }
      }
      // Rotate: keep index 0 fixed, everyone else shifts one seat.
      teams.splice(1, 0, teams.pop()!);
    }

    await this.prisma.tournamentMatch.createMany({
      data: matches.map((m) => ({
        tournamentId, bracket: 'round_robin', round: m.round, position: m.position,
        teamAId: m.teamAId, teamBId: m.teamBId, status: MatchStatus.PENDING,
      })),
    });
  }

  /**
   * Round 1 only — Swiss pairing depends on standings that don't
   * exist yet before any match is played, so round 1 is just
   * registration-order pairing (same convention as round robin's
   * seeding). Every later round is generated by
   * maybeAdvanceSwissRound() once the previous one finishes.
   */
  private async generateSwissBracket(tournamentId: string, teamIds: string[]) {
    await this.createSwissRoundMatches(tournamentId, 1, [...teamIds]);
  }

  /**
   * Pairs teams for one Swiss round: sort by current win count
   * (score group), then walk down the sorted list pairing adjacent
   * teams, skipping ahead within the list to avoid a rematch where
   * possible. This is a real, working pairing — not full Swiss
   * tournament-theory optimality (proper Swiss pairing is its own
   * small research area), but every round is fair by current
   * standing and never repeats a pairing where an alternative exists.
   * An odd team count gives the lowest-standing unpaired team a bye
   * (an automatic win, no match created) rather than leaving them out.
   */
  private async createSwissRoundMatches(tournamentId: string, round: number, teamIds: string[]) {
    const wins = await this.computeWinCounts(tournamentId, 'swiss', teamIds);
    const playedPairs = await this.computePlayedPairs(tournamentId, 'swiss');

    const sorted = [...teamIds].sort((a, b) => (wins.get(b) ?? 0) - (wins.get(a) ?? 0));
    const pool = [...sorted];
    const pairs: [string, string][] = [];
    let byeTeamId: string | null = null;

    while (pool.length > 0) {
      const a = pool.shift()!;
      if (pool.length === 0) {
        byeTeamId = a; // odd one out — lowest remaining standing gets the bye
        break;
      }
      let opponentIdx = pool.findIndex((b) => !playedPairs.has(pairKey(a, b)));
      if (opponentIdx === -1) opponentIdx = 0; // everyone left has been played already — pair anyway rather than skip a round
      const [b] = pool.splice(opponentIdx, 1);
      pairs.push([a, b]);
    }

    await this.prisma.tournamentMatch.createMany({
      data: pairs.map(([teamAId, teamBId], i) => ({
        tournamentId, bracket: 'swiss', round, position: i, teamAId, teamBId, status: MatchStatus.PENDING,
      })),
    });

    if (byeTeamId) {
      // A bye is a genuine win for standings purposes, not a bracket
      // slot to fill later — recorded as an already-COMPLETED match
      // with only one side, same convention completeMatch expects
      // (isBye path) elsewhere in this file.
      await this.prisma.tournamentMatch.create({
        data: {
          tournamentId, bracket: 'swiss', round, position: pairs.length,
          teamAId: byeTeamId, teamBId: null, winnerTeamId: byeTeamId, status: MatchStatus.COMPLETED,
        },
      });
    }
  }

  private async maybeAdvanceSwissRound(tournamentId: string, completedRound: number) {
    const pending = await this.prisma.tournamentMatch.count({
      where: { tournamentId, bracket: 'swiss', round: completedRound, status: { not: MatchStatus.COMPLETED } },
    });
    if (pending > 0) return; // this round isn't actually fully done yet

    const tournament = await this.prisma.tournament.findUniqueOrThrow({ where: { id: tournamentId } });
    const totalRounds = tournament.swissRounds ?? 1;
    if (completedRound >= totalRounds) {
      const champion = await this.computeStandingsChampion(tournamentId, 'swiss');
      await this.prisma.tournament.update({ where: { id: tournamentId }, data: { status: TournamentStatus.COMPLETED } });
      if (champion) await this.recordChampion(tournamentId, champion);
      return;
    }

    const registrations = await this.prisma.tournamentRegistration.findMany({ where: { tournamentId } });
    await this.createSwissRoundMatches(tournamentId, completedRound + 1, registrations.map((r) => r.teamId));
  }

  /**
   * Splits teams into groupCount groups (simple sequential chunking
   * by registration order — same seeding convention as every other
   * format here), then generates a full round robin WITHIN each
   * group. Rounds are offset by group index (see the groupIndex field
   * comment on TournamentMatch) so groups never collide in the
   * (tournamentId, bracket, round, position) key each match is stored
   * under; groupIndex itself is stored too, purely so the group a
   * match belongs to can be read back directly instead of reverse-
   * engineered from the offset.
   */
  private async generateGroupStageBracket(tournamentId: string, teamIds: string[], groupCount: number) {
    const groups: string[][] = Array.from({ length: groupCount }, () => []);
    teamIds.forEach((id, i) => groups[i % groupCount].push(id));

    const ROUND_OFFSET = 100; // headroom well beyond any realistic round-robin round count per group
    for (let g = 0; g < groups.length; g++) {
      const group = groups[g];
      if (group.length < 2) continue; // a group this small can't play anyone — every team in it advances by default, nothing to schedule
      const teams = group.length % 2 === 0 ? [...group] : [...group, null];
      const n = teams.length;
      for (let round = 0; round < n - 1; round++) {
        const matches: { position: number; teamAId: string; teamBId: string }[] = [];
        for (let i = 0; i < n / 2; i++) {
          const a = teams[i];
          const b = teams[n - 1 - i];
          if (a != null && b != null) matches.push({ position: i, teamAId: a, teamBId: b });
        }
        await this.prisma.tournamentMatch.createMany({
          data: matches.map((m) => ({
            tournamentId, bracket: 'group_stage', groupIndex: g,
            round: g * ROUND_OFFSET + round + 1, position: m.position,
            teamAId: m.teamAId, teamBId: m.teamBId, status: MatchStatus.PENDING,
          })),
        });
        teams.splice(1, 0, teams.pop()!);
      }
    }
  }

  private async maybeAdvanceGroupStage(tournamentId: string) {
    const pending = await this.prisma.tournamentMatch.count({
      where: { tournamentId, bracket: 'group_stage', status: { not: MatchStatus.COMPLETED } },
    });
    if (pending > 0) return; // groups still in progress

    const tournament = await this.prisma.tournament.findUniqueOrThrow({ where: { id: tournamentId } });
    const groupCount = tournament.groupCount ?? 1;
    const advancingPerGroup = tournament.advancingPerGroup ?? 2;

    const matches = await this.prisma.tournamentMatch.findMany({ where: { tournamentId, bracket: 'group_stage' } });
    const advancers: string[] = [];
    for (let g = 0; g < groupCount; g++) {
      const groupMatches = matches.filter((m) => m.groupIndex === g);
      const groupTeamIds = [...new Set(groupMatches.flatMap((m) => [m.teamAId, m.teamBId].filter((x): x is string => !!x)))];
      const wins = await this.computeWinCounts(tournamentId, 'group_stage', groupTeamIds, g);
      const ranked = groupTeamIds.sort((a, b) => (wins.get(b) ?? 0) - (wins.get(a) ?? 0));
      advancers.push(...ranked.slice(0, advancingPerGroup));
    }

    if (advancers.length < 2) {
      // Not enough advancers to hold a playoff at all (e.g. every
      // group had under 2 teams) — the group stage itself decided the
      // outcome, so the standings leader is the champion outright.
      await this.prisma.tournament.update({ where: { id: tournamentId }, data: { status: TournamentStatus.COMPLETED } });
      if (advancers[0]) await this.recordChampion(tournamentId, advancers[0]);
      return;
    }
    // Reuses the exact same generator single elimination uses on its
    // own — a playoff bracket seeded from group standings is
    // structurally identical to a standalone single-elimination
    // tournament from here on, byes included.
    await this.generateSingleEliminationBracket(tournamentId, advancers);
  }

  /** Wins per team from COMPLETED matches in the given bracket (optionally scoped to one group). */
  private async computeWinCounts(tournamentId: string, bracket: string, teamIds: string[], groupIndex?: number) {
    const matches = await this.prisma.tournamentMatch.findMany({
      where: { tournamentId, bracket, status: MatchStatus.COMPLETED, ...(groupIndex != null ? { groupIndex } : {}) },
    });
    const wins = new Map<string, number>(teamIds.map((id) => [id, 0]));
    for (const m of matches) {
      if (m.winnerTeamId) wins.set(m.winnerTeamId, (wins.get(m.winnerTeamId) ?? 0) + 1);
    }
    return wins;
  }

  private async computeStandingsChampion(tournamentId: string, bracket: string): Promise<string | null> {
    const registrations = await this.prisma.tournamentRegistration.findMany({ where: { tournamentId } });
    const wins = await this.computeWinCounts(tournamentId, bracket, registrations.map((r) => r.teamId));
    let best: string | null = null;
    let bestWins = -1;
    for (const [teamId, w] of wins) {
      if (w > bestWins) { best = teamId; bestWins = w; }
    }
    return best;
  }

  /** Every pair that has already played each other in this bracket, for rematch avoidance. */
  private async computePlayedPairs(tournamentId: string, bracket: string): Promise<Set<string>> {
    const matches = await this.prisma.tournamentMatch.findMany({
      where: { tournamentId, bracket, teamAId: { not: null }, teamBId: { not: null } },
    });
    return new Set(matches.map((m) => pairKey(m.teamAId!, m.teamBId!)));
  }

  private async generateSingleEliminationBracket(tournamentId: string, teamIds: string[]) {
    const bracketSize = nextPowerOfTwo(teamIds.length);
    const totalRounds = Math.log2(bracketSize);

    // Byes go to the first `byeCount` registered teams, one bye per
    // match, spread across separate round-1 matches rather than
    // clustered at the end. Clustering (the original approach: pad the
    // team list with nulls and pair sequentially) can produce a match
    // with BOTH slots empty whenever more than one bye is needed (e.g.
    // 5 or 6 teams padded to a bracket of 8) — that match can never be
    // played, and nothing downstream of it can ever be filled in either.
    // Since bracketSize is always the *smallest* power of two >= the
    // team count, byeCount is mathematically guaranteed to be smaller
    // than the number of round-1 matches, so one-bye-per-match is
    // always achievable.
    const byeCount = bracketSize - teamIds.length;
    const round1Pairs: [string | null, string | null][] = [];
    for (let i = 0; i < byeCount; i++) {
      round1Pairs.push([teamIds[i], null]);
    }
    for (let i = byeCount; i < bracketSize / 2; i++) {
      const idx = byeCount + (i - byeCount) * 2;
      round1Pairs.push([teamIds[idx] ?? null, teamIds[idx + 1] ?? null]);
    }

    const created = await this.prisma.$transaction(async (tx) => {
      const matches = [];
      for (let round = 1; round <= totalRounds; round++) {
        const matchesInRound = bracketSize / Math.pow(2, round);
        for (let position = 0; position < matchesInRound; position++) {
          const [teamAId, teamBId] = round === 1 ? round1Pairs[position] : [null, null];
          matches.push(
            await tx.tournamentMatch.create({
              data: { tournamentId, bracket: 'winners', round, position, teamAId, teamBId },
            }),
          );
        }
      }
      return matches;
    });

    for (const match of created.filter((m) => m.round === 1)) {
      const hasBye = (match.teamAId && !match.teamBId) || (!match.teamAId && match.teamBId);
      if (hasBye) {
        const winnerTeamId = (match.teamAId ?? match.teamBId) as string;
        await this.completeMatch(match.id, winnerTeamId, null, null, /* isBye */ true);
      }
    }
  }

  /**
   * ============================================================================
   * DOUBLE ELIMINATION — only supported for an exact power-of-two team count
   * (4/8/16/32). Single elimination handles any count via byes (a lone
   * team in an incomplete pairing auto-advances); there's no equally
   * simple bye equivalent for double elimination, since a bye would need
   * to propagate through BOTH the winners and losers brackets
   * consistently, and getting that wrong silently produces an unfair or
   * broken bracket rather than a loud error. Rejecting non-power-of-two
   * counts outright is safer than guessing.
   *
   * Structure (k = log2(teamCount), so a WB with k rounds):
   *  - Winners bracket (WB): identical in shape to single elimination.
   *  - Losers bracket (LB): 2*(k-1) rounds, alternating:
   *      - "minor" rounds (odd LB round index) pair up LB survivors
   *        against each other, no new entrants.
   *      - "major" rounds (even LB round index) pair each LB survivor
   *        against a fresh loser dropping in from the winners bracket.
   *    LB round 1 is a special case of "minor": it has no prior LB
   *    survivors, so it's populated entirely from WB round 1's losers.
   *  - Grand final: WB champion (teamA) vs LB champion (teamB).
   *  - Bracket reset: only created if the LB-side team wins the grand
   *    final — at that point both finalists have exactly one loss, so a
   *    single decisive match is needed. If the WB-side team wins the
   *    grand final instead, the tournament ends there; no reset needed.
   *
   * This structure was derived by hand and cross-checked against the
   * well-known "double elimination needs 2N-2 (or 2N-1 with a reset)
   * total matches" formula for both N=4 and N=8 — it is NOT validated
   * against any specific external bracket-generator's exact seeding
   * convention (e.g. Challonge), the way single elimination's "byes go
   * to registration order" is at least a documented choice rather than
   * a guess. The overall shape (round counts, advancement logic) is
   * sound; which specific losers face each other first in a given LB
   * round is this implementation's own deterministic convention.
   * ============================================================================
   */
  private async generateDoubleEliminationBracket(tournamentId: string, teamIds: string[]) {
    if (Math.pow(2, Math.round(Math.log2(teamIds.length))) !== teamIds.length) {
      throw new BadRequestException(
        `Double elimination needs an exact power-of-two number of registered teams (4, 8, 16, 32...) — got ${teamIds.length}`,
      );
    }

    const n = teamIds.length;
    const k = Math.log2(n);
    const lbRounds = 2 * (k - 1);

    await this.prisma.$transaction(async (tx) => {
      // Winners bracket — same shape as single elimination, no byes needed.
      for (let round = 1; round <= k; round++) {
        const matchesInRound = n / Math.pow(2, round);
        for (let position = 0; position < matchesInRound; position++) {
          const [teamAId, teamBId] =
            round === 1 ? [teamIds[position * 2], teamIds[position * 2 + 1]] : [null, null];
          await tx.tournamentMatch.create({
            data: { tournamentId, bracket: 'winners', round, position, teamAId, teamBId },
          });
        }
      }

      // Losers bracket — empty shells now, populated via winner/loser
      // routing as WB and LB matches complete. See matchesInLbRound()
      // for the size derivation.
      for (let lbRound = 1; lbRound <= lbRounds; lbRound++) {
        const matchesInRound = matchesInLbRound(n, lbRound);
        for (let position = 0; position < matchesInRound; position++) {
          await tx.tournamentMatch.create({
            data: { tournamentId, bracket: 'losers', round: lbRound, position, teamAId: null, teamBId: null },
          });
        }
      }

      // Grand final — both slots filled later by advanceWinner as the
      // WB and LB finals complete.
      await tx.tournamentMatch.create({
        data: { tournamentId, bracket: 'grand_final', round: 1, position: 0, teamAId: null, teamBId: null },
      });
    });
  }

  async reportResult(
    tournamentId: string,
    matchId: string,
    requestingUserId: string,
    winnerTeamId: string,
    scoreA: number,
    scoreB: number,
  ) {
    const tournament = await this.prisma.tournament.findUnique({ where: { id: tournamentId } });
    if (!tournament) throw new NotFoundException('Tournament not found');
    if (tournament.createdByUserId !== requestingUserId) {
      throw new ForbiddenException('Only the tournament creator can report results');
    }

    return this.completeMatch(matchId, winnerTeamId, scoreA, scoreB, false);
  }

  /**
   * Support action: closes a tournament regardless of its current state
   * (stuck mid-bracket, organizer unresponsive, etc.), without touching
   * whatever matches were still pending — those stay exactly as they
   * were, just no longer reachable through the normal flow since the
   * tournament itself is CANCELLED.
   */
  async adminForceClose(tournamentId: string) {
    const tournament = await this.prisma.tournament.findUnique({ where: { id: tournamentId } });
    if (!tournament) throw new NotFoundException('Tournament not found');
    return this.prisma.tournament.update({
      where: { id: tournamentId },
      data: { status: TournamentStatus.CANCELLED },
    });
  }

  /**
   * Support action: forces a specific match's result the same way
   * reportResult does, but without requiring the caller to be the
   * tournament's organizer — for when an organizer is unreachable and a
   * bracket is stuck waiting on a result nobody can enter.
   */
  async adminForceResult(matchId: string, winnerTeamId: string, scoreA: number, scoreB: number) {
    return this.completeMatch(matchId, winnerTeamId, scoreA, scoreB, false);
  }

  private async completeMatch(
    matchId: string,
    winnerTeamId: string,
    scoreA: number | null,
    scoreB: number | null,
    isBye: boolean,
  ) {
    const match = await this.prisma.tournamentMatch.findUnique({ where: { id: matchId } });
    if (!match) throw new NotFoundException('Match not found');
    if (match.status === MatchStatus.COMPLETED) {
      throw new BadRequestException('This match already has a result');
    }
    if (!isBye && winnerTeamId !== match.teamAId && winnerTeamId !== match.teamBId) {
      throw new BadRequestException('winnerTeamId must be one of the two teams in this match');
    }
    const loserTeamId = winnerTeamId === match.teamAId ? match.teamBId : match.teamAId;

    const updated = await this.prisma.tournamentMatch.update({
      where: { id: matchId },
      data: { winnerTeamId, scoreA, scoreB, status: MatchStatus.COMPLETED },
    });

    if (match.bracket === 'bracket_reset') {
      // The one match that unconditionally ends the tournament — both
      // finalists already had one loss each going in, so this decides
      // the second and final one either way.
      await this.prisma.tournament.update({
        where: { id: match.tournamentId },
        data: { status: TournamentStatus.COMPLETED },
      });
      await this.recordChampion(match.tournamentId, winnerTeamId);
      return updated;
    }

    if (match.bracket === 'grand_final') {
      if (winnerTeamId === match.teamAId) {
        // The WB-side finalist (zero prior losses) won outright.
        await this.prisma.tournament.update({
          where: { id: match.tournamentId },
          data: { status: TournamentStatus.COMPLETED },
        });
        await this.recordChampion(match.tournamentId, winnerTeamId);
      } else {
        // The LB-side finalist won — both now have exactly one loss.
        // A single decisive bracket-reset match is required.
        await this.prisma.tournamentMatch.create({
          data: {
            tournamentId: match.tournamentId,
            bracket: 'bracket_reset',
            round: 1,
            position: 0,
            teamAId: match.teamAId,
            teamBId: match.teamBId,
          },
        });
      }
      return updated;
    }

    const tournament = await this.prisma.tournament.findUnique({ where: { id: match.tournamentId } });

    if (tournament?.bracketFormat === 'double_elimination') {
      await this.advanceDoubleElimination(match, winnerTeamId, loserTeamId);
    } else if (match.bracket === 'round_robin') {
      // No per-match "winner advances" concept here at all — every
      // team plays every round regardless of result. The real bug
      // this replaces: falling through to the single-elimination
      // branch below checked for a 'winners' bracket that round robin
      // never creates, so nextRoundCount was always 0 — completing
      // the very FIRST round-robin match immediately ended the whole
      // tournament and crowned whoever won that one match. Standings
      // (and, once the tournament's fully done, a champion) only ever
      // come from the complete set of results, once every match in
      // the format has one.
      const remaining = await this.prisma.tournamentMatch.count({
        where: { tournamentId: match.tournamentId, bracket: 'round_robin', status: { not: MatchStatus.COMPLETED } },
      });
      if (remaining === 0) {
        const champion = await this.computeStandingsChampion(match.tournamentId, 'round_robin');
        await this.prisma.tournament.update({ where: { id: match.tournamentId }, data: { status: TournamentStatus.COMPLETED } });
        if (champion) await this.recordChampion(match.tournamentId, champion);
      }
    } else if (tournament?.bracketFormat === 'swiss') {
      await this.maybeAdvanceSwissRound(match.tournamentId, match.round);
    } else if (tournament?.bracketFormat === 'group_stage' && match.bracket === 'group_stage') {
      // Group-stage matches never advance a winner into a next slot —
      // they only ever feed standings. Once every group's round robin
      // is fully played, generateGroupPlayoffs seeds a real single-
      // elimination bracket (bracket: 'winners') from those standings;
      // THAT bracket's own matches fall through to the plain
      // single-elimination branch below like any other, since
      // structurally they're identical once seeded.
      await this.maybeAdvanceGroupStage(match.tournamentId);
    } else {
      await this.advanceWinner(updated);
      const nextRoundCount = await this.prisma.tournamentMatch.count({
        where: { tournamentId: match.tournamentId, bracket: 'winners', round: match.round + 1 },
      });
      if (nextRoundCount === 0) {
        await this.prisma.tournament.update({
          where: { id: match.tournamentId },
          data: { status: TournamentStatus.COMPLETED },
        });
        await this.recordChampion(match.tournamentId, winnerTeamId);
      }
    }

    return updated;
  }

  private async recordChampion(tournamentId: string, winnerTeamId: string) {
    try {
      const [tournament, team] = await Promise.all([
        this.prisma.tournament.findUnique({ where: { id: tournamentId } }),
        this.prisma.team.findUnique({ where: { id: winnerTeamId } }),
      ]);
      await this.hallOfFame.recordEvent({
        key: 'tournament_champion',
        teamId: winnerTeamId,
        value: `Чемпион "${tournament?.name ?? 'турнира'}"`,
        description: team?.name,
        relatedTournamentId: tournamentId,
      });
    } catch (e: any) {
      // Fail soft — a Hall of Fame hiccup should never make a
      // tournament fail to actually complete.
      console.warn(`Hall of Fame check failed after a tournament completion: ${e.message}`);
    }
  }

  /** Single-elimination winner routing — unchanged logic, now bracket-scoped. */
  private async advanceWinner(match: {
    tournamentId: string;
    bracket: string;
    round: number;
    position: number;
    winnerTeamId: string | null;
  }) {
    const nextMatch = await this.prisma.tournamentMatch.findUnique({
      where: {
        tournamentId_bracket_round_position: {
          tournamentId: match.tournamentId,
          bracket: match.bracket,
          round: match.round + 1,
          position: Math.floor(match.position / 2),
        },
      },
    });
    if (!nextMatch) return;

    const slot = match.position % 2 === 0 ? 'teamAId' : 'teamBId';
    await this.prisma.tournamentMatch.update({ where: { id: nextMatch.id }, data: { [slot]: match.winnerTeamId } });
  }

  /**
   * Double-elimination routing for a just-completed match — sends the
   * winner (and, for winners-bracket matches, the loser too) to their
   * next slot. See the class-level comment on
   * generateDoubleEliminationBracket for the structural rules this
   * implements.
   */
  private async advanceDoubleElimination(
    match: { tournamentId: string; bracket: string; round: number; position: number },
    winnerTeamId: string,
    loserTeamId: string | null,
  ) {
    const tournament = await this.prisma.tournament.findUnique({ where: { id: match.tournamentId } });
    const totalTeams = tournament!.maxTeams; // registration is closed by the time a bracket exists
    const k = Math.log2(nextPowerOfTwo(totalTeams));
    const lbRounds = 2 * (k - 1);

    const setSlot = async (bracket: string, round: number, position: number, slot: 'teamAId' | 'teamBId', teamId: string | null) => {
      const target = await this.prisma.tournamentMatch.findUnique({
        where: { tournamentId_bracket_round_position: { tournamentId: match.tournamentId, bracket, round, position } },
      });
      if (!target) return;
      await this.prisma.tournamentMatch.update({ where: { id: target.id }, data: { [slot]: teamId } });
    };

    if (match.bracket === 'winners') {
      // Winner: normal WB advancement, or into the grand final if this
      // was the WB final.
      if (match.round === k) {
        await setSlot('grand_final', 1, 0, 'teamAId', winnerTeamId);
      } else {
        await setSlot('winners', match.round + 1, Math.floor(match.position / 2), match.position % 2 === 0 ? 'teamAId' : 'teamBId', winnerTeamId);
      }

      // Loser: drops into the losers bracket at the round this WB round
      // feeds — round 1 directly, later rounds into a "major" round.
      const targetLbRound = match.round === 1 ? 1 : 2 * (match.round - 1);
      if (match.round === 1) {
        await setSlot('losers', targetLbRound, Math.floor(match.position / 2), match.position % 2 === 0 ? 'teamAId' : 'teamBId', loserTeamId);
      } else {
        // Survivors occupy teamAId in a major round; the freshly-dropped
        // WB loser always fills teamBId, at the same position number
        // (major-round match counts equal the WB round's match count).
        await setSlot('losers', targetLbRound, match.position, 'teamBId', loserTeamId);
      }
      return;
    }

    // match.bracket === 'losers'
    const isLastLbRound = match.round === lbRounds;
    if (isLastLbRound) {
      await setSlot('grand_final', 1, 0, 'teamBId', winnerTeamId);
      return;
    }

    const isMinorRound = match.round % 2 === 1;
    if (isMinorRound) {
      // Minor round winner -> next (major) round, same position, teamAId.
      await setSlot('losers', match.round + 1, match.position, 'teamAId', winnerTeamId);
    } else {
      // Major round winner -> next (minor) round, halved position.
      await setSlot('losers', match.round + 1, Math.floor(match.position / 2), match.position % 2 === 0 ? 'teamAId' : 'teamBId', winnerTeamId);
    }
  }
}

function nextPowerOfTwo(n: number): number {
  return Math.pow(2, Math.ceil(Math.log2(n)));
}

/**
 * Match count for losers-bracket round `lbRound` out of a bracket for
 * `n` teams (n a power of two). See the derivation in the comment on
 * generateDoubleEliminationBracket — this walks the same
 * survivors/new-entrants tracking rather than a closed-form formula,
 * since the alternating minor/major halving pattern isn't a simple
 * single expression.
 */
function matchesInLbRound(n: number, lbRound: number): number {
  let survivors = n / 2; // WB round 1's loser count, used directly by LB round 1
  let wbLoserRoundIndex = 1;
  let matches = 0;

  for (let round = 1; round <= lbRound; round++) {
    const isMinor = round % 2 === 1;
    let participants: number;
    if (round === 1) {
      participants = survivors;
    } else if (isMinor) {
      participants = survivors;
    } else {
      wbLoserRoundIndex += 1;
      const newEntrants = n / Math.pow(2, wbLoserRoundIndex);
      participants = survivors + newEntrants;
    }
    matches = participants / 2;
    survivors = matches;
  }
  return matches;
}
