import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common';
import { TournamentsService } from './tournaments.service';

@Controller('tournaments')
export class TournamentsController {
  constructor(private readonly tournamentsService: TournamentsService) {}

  @Post()
  create(
    @Req() req: any,
    @Body() body: {
      name: string; description?: string; teamSize?: number; matchFormat?: string; bracketFormat?: string;
      maxTeams: number; entryFeeShards?: number; entryFeeTenge?: number; paymentInstructions?: string;
    },
  ) {
    return this.tournamentsService.create(req.user.sub, body);
  }

  @Get()
  list() {
    return this.tournamentsService.list();
  }

  @Get(':id')
  get(@Param('id') id: string) {
    return this.tournamentsService.get(id);
  }

  @Post(':id/register')
  register(@Req() req: any, @Param('id') id: string, @Body() body: { teamId: string; paymentNote?: string }) {
    return this.tournamentsService.registerWithPayment(id, req.user.sub, body.teamId, body.paymentNote);
  }

  // Organizer-only: the actual "I checked my Kaspi account, this
  // team's fee really arrived" confirmation — see
  // TournamentsService.confirmPayment for why this stays a human
  // decision rather than an automatic check.
  @Post(':id/registrations/:registrationId/confirm-payment')
  confirmPayment(
    @Req() req: any,
    @Param('id') id: string,
    @Param('registrationId') registrationId: string,
    @Body() body: { confirmed: boolean },
  ) {
    return this.tournamentsService.confirmPayment(id, req.user.sub, registrationId, body.confirmed);
  }

  @Post(':id/generate-bracket')
  generateBracket(@Req() req: any, @Param('id') id: string) {
    return this.tournamentsService.generateBracket(id, req.user.sub);
  }

  @Post(':id/matches/:matchId/result')
  reportResult(
    @Req() req: any,
    @Param('id') id: string,
    @Param('matchId') matchId: string,
    @Body() body: { winnerTeamId: string; scoreA: number; scoreB: number },
  ) {
    return this.tournamentsService.reportResult(
      id,
      matchId,
      req.user.sub,
      body.winnerTeamId,
      body.scoreA,
      body.scoreB,
    );
  }
}
