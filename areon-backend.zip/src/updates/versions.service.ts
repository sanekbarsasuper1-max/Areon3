import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

export interface VersionInput {
  version: string;
  added?: string[];
  fixed?: string[];
  improved?: string[];
  addressed?: string[];
  knownIssues?: string[];
}

@Injectable()
export class VersionsService {
  constructor(private readonly prisma: PrismaService) {}

  async listAll() {
    return this.prisma.areonVersion.findMany({ orderBy: { releasedAt: 'desc' } });
  }

  async getCurrent() {
    return this.prisma.areonVersion.findFirst({ where: { isCurrent: true } });
  }

  async getByVersion(version: string) {
    const row = await this.prisma.areonVersion.findUnique({ where: { version } });
    if (!row) throw new NotFoundException('Version not found');
    return row;
  }

  /**
   * Creates a new version and makes it current — atomically flips the
   * old current version's isCurrent to false in the same transaction,
   * so there is never a moment with zero or two current versions, even
   * under concurrent admin requests.
   */
  async createVersion(input: VersionInput) {
    return this.prisma.$transaction(async (tx) => {
      const previous = await tx.areonVersion.findFirst({ where: { isCurrent: true } });
      if (previous) {
        await tx.areonVersion.update({ where: { id: previous.id }, data: { isCurrent: false } });
      }
      return tx.areonVersion.create({
        data: {
          version: input.version,
          added: input.added ?? [],
          fixed: input.fixed ?? [],
          improved: input.improved ?? [],
          addressed: input.addressed ?? [],
          knownIssues: input.knownIssues ?? [],
          isCurrent: true,
        },
      });
    });
  }

  async updateVersion(id: string, input: Partial<VersionInput>) {
    return this.prisma.areonVersion.update({ where: { id }, data: input });
  }

  /** Admin can also re-flag an OLDER version as current, e.g. after
   * rolling back a broken release — same atomic guarantee. */
  async setCurrent(id: string) {
    return this.prisma.$transaction(async (tx) => {
      const previous = await tx.areonVersion.findFirst({ where: { isCurrent: true } });
      if (previous && previous.id !== id) {
        await tx.areonVersion.update({ where: { id: previous.id }, data: { isCurrent: false } });
      }
      return tx.areonVersion.update({ where: { id }, data: { isCurrent: true } });
    });
  }

  /** Links an already-implemented Suggestion to the version that
   * shipped it — requirement 7. */
  async linkSuggestion(versionId: string, suggestionId: string) {
    return this.prisma.suggestion.update({
      where: { id: suggestionId },
      data: { status: 'IMPLEMENTED', implementedInVersionId: versionId },
    });
  }

  /**
   * Idempotent — only runs if literally zero versions exist yet. Does
   * NOT fabricate a detailed changelog history (no invented past
   * entries) — just a real, honest baseline so the version display and
   * update-notification banner have something to show on a fresh
   * install, before an admin has written a real first changelog entry.
   */
  async seedInitialVersion() {
    const existing = await this.prisma.areonVersion.count();
    if (existing > 0) return { created: false };
    await this.createVersion({
      version: '1.0.0',
      added: ['Запуск платформы Areon'],
    });
    return { created: true };
  }

  /**
   * Idempotent (keyed on the version string, not "any versions
   * exist") — safe to run on every boot. Records the visual-redesign
   * release without needing an admin to type it in through a UI that
   * doesn't exist yet.
   */
  async ensureVersion2() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.0.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.0.0',
      improved: [
        'Интерфейс переработан на полноэкранный: боковая навигация вместо узкой верхней полосы',
        'Все страницы используют всю ширину экрана вместо маленького окна по центру',
        'Увеличен размер текста и элементов по всему сайту для читаемости',
        'Повышена контрастность вторичного и приглушённого текста',
        'Профиль и страница разбора матча переработаны с более крупными карточками и двухколоночной раскладкой',
        'Добавлена адаптивная раскладка для узких экранов (боковая панель сворачивается в верхнюю полосу)',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern as ensureVersion2 — keyed on version string. */
  async ensureVersion21() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.1.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.1.0',
      fixed: [
        'GPM/XPM в статистике матча больше не показывают 0 — запрос к OpenDota теперь явно запрашивает эти поля',
        'Графики золота по ходу игры: матч теперь автоматически отправляется на разбор Valve, если он ещё не распарсен, вместо пустого графика',
        'Исправлена ошибка в расчёте отклонения от медианы (сравнивались показатели в разных единицах — из-за этого могли появляться значения вроде «+6520%»)',
        'Вход через Steam стал заметно быстрее — проверка доступности статистики больше не блокирует вход при каждом заходе, используется сохранённое значение с фоновым обновлением',
      ],
      improved: [
        'Новая цветовая система: многослойный тёмный фон с мягкими индиго- и сине-фиолетовыми акцентами вместо плоского чёрного',
        'Карточки получили собственную поверхность, границу и мягкую тень для визуальной иерархии',
        'История обновлений и уведомление о новой версии теперь видны и гостям, не только вошедшим пользователям',
        'В меню появился индикатор NEW рядом с «Что нового», когда есть непросмотренное обновление',
        'На страницу разбора матча добавлены урон по башням, лечение и denies',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — third entry in the changelog history. */
  async ensureVersion22() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.2.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.2.0',
      added: [
        'Wheel of Fate полностью запущен: случайный герой и AI-сборка → принятие испытания → реальный матч → автоматическая проверка результата → Orion Plus и рейтинг',
      ],
      improved: [
        'ИИ в Draft Trainer теперь собирает состав по ролям (Carry/Support/Disabler/Durable/Nuker), а не только ищет контрпики',
        'Баны в Draft Trainer разделены по командам и визуально меньше пиков',
        'После завершения драфта — честная эвристическая оценка того, чей состав сильнее (не прогноз реальной победы)',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — fourth entry. */
  async ensureVersion23() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.3.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.3.0',
      added: [
        'Мониторинг пользователей в админ-панели: кто сейчас онлайн, история посещений, журнал значимых действий, карточка конкретного пользователя',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — fifth entry. */
  async ensureVersion24() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.4.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.4.0',
      added: [
        'Драфт-турниры 1v1: живая турнирная сетка, автоматическое продвижение победителя, блок «Мой матч», инструменты администратора (отмена/удаление турнира, исправление результата, удаление участника)',
      ],
      improved: [
        'Музыкальный поиск переведён на настоящий каталог Apple Music (бесплатный, без ключа) вместо Jamendo — теперь находит реальных исполнителей и треки, с разделением на Артисты/Треки/Альбомы',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — sixth entry. */
  async ensureVersion25() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.5.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.5.0',
      added: [
        'Drafter Rating: отдельный Elo-рейтинг за реальные драфты 1 на 1 (friend/matchmaking), с историей изменений',
        'Расстановка позиций после драфта и визуализация синергии героев (по реальным тегам ролей)',
      ],
      fixed: [
        'Победитель драфта теперь определяется всегда — убраны формулировки «примерно равны»',
        'Сравнение составов было заблокировано до завершения драфта — теперь работает и во время живого драфта',
        'Синхронизация OpenDota: явный запрос дополнительных полей случайно вытеснял базовые (герой, K/D/A, дата матча) — матчи с неполными данными больше не ломают всю синхронизацию',
      ],
      improved: [
        'Пики и баны в драфтере визуально различаются по размеру, у банов — яркий красный крестик, у каждой карточки — настоящий номер хода',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — seventh entry. */
  async ensureVersion26() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.6.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.6.0',
      added: [
        'Расстановка позиций после драфта — теперь перетаскиванием героев на стилизованную мини-карту вместо выпадающих списков',
        'Противостояние по позициям (Your Carry vs Enemy Offlane и т.д.) — по реальным данным контрпиков',
        'Пятиугольник синергии — визуализация связей между всеми пятью героями команды',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — eighth entry. */
  async ensureVersion27() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.7.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.7.0',
      added: [
        'Site Rating — единый внутриигровой рейтинг за активность на платформе (драфты, Wheel of Fate, Драфт-турниры, Techies: Сапёр), отдельно от Orion Plus/Points и от Elo Drafter Rating',
        'Единый Reward Engine с защитой от повторного начисления — новую игровую активность в будущем можно подключить одной строкой, не переписывая систему наград',
      ],
      fixed: [
        'Контрпики почти всегда показывали 0 — не баг в расчёте, а данные никогда не синхронизировались (требовалось запускать вручную по одному герою). Добавлена кнопка массовой синхронизации в админке',
        'Итоговый результат драфта (очки, победитель, пятиугольник) больше не считается и не показывается раньше времени — только после подтверждения позиций и нажатия «Завершить драфт»',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — ninth entry. */
  async ensureVersion28() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.8.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.8.0',
      added: [
        'Магазин Areon открыт — первые 5 косметических наград (Areon Veteran, Scourgeborn Emblem, Void Hunter, Areon Champion, Areon Aegis) за Arium Points, с защитой от двойной покупки',
        'Музыкальный поиск переведён на Deezer — более стабильный источник без агрессивного лимита запросов, который был у предыдущего варианта',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — tenth entry. */
  async ensureVersion29() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.9.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.9.0',
      added: [
        'AI Coach — три уровня разбора (SHORT бесплатно, FULL 300 и MAXIMUM 500 Arium Plus), с настоящими иконками способностей и предметов вместо текста, разбитый на отдельные разделы вместо одного большого текста',
        'Реальные иконки способностей — раньше их не было в базе вообще, только у героев и предметов',
      ],
      fixed: [
        'График золота по ходу матча стал интерактивным — подписи осей, подсказка при наведении с точным временем и значением',
        'На полностью новой базе данных герои/предметы/способности могли никогда не синхронизироваться, если угаданный стартовый патч случайно совпадал с реальным — теперь первая синхронизация всегда происходит явно',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — eleventh entry. */
  async ensureVersion30() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.10.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.10.0',
      added: [
        'Techies: Сапёр — визуальное обновление: объёмные клетки, анимация установки флажка, взрыв с частицами и лёгкой тряской поля вместо плоской серой таблицы',
        'Отдельная фоновая музыка для Сапёра (звуковые файлы подключаются владельцем — система уже поддерживает музыку и эффекты, громкость и вкл/выкл управляются в общих настройках звука)',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — twelfth entry. */
  async ensureVersion31() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.11.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.11.0',
      fixed: [
        'Вход через Steam всегда возвращал на /profile независимо от того, с какой страницы был начат вход — теперь возвращает именно туда, откуда вы зашли',
        'Музыкальный поиск отдавал 401 — запрос не отправлял cookie авторизации',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — thirteenth entry. */
  async ensureVersion32() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.12.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.12.0',
      added: [
        'Музыка переведена на YouTube — теперь звучат полные треки, а не 30-секундные превью (требует официальный плеер YouTube, небольшое видео в углу экрана)',
      ],
      fixed: [
        'Wheel of Fate временно убран из меню — упирался в дневной лимит бесплатного тарифа ИИ',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — fourteenth entry. */
  async ensureVersion33() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.13.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.13.0',
      added: [
        'Добавлена фоновая музыка сайта — играет после вступительного звука, автоматически приглушается в Draft Trainer и Сапёре и возвращается после',
      ],
      fixed: [
        'Передача эстафеты от вступительного звука к основной теме была только описана в документации, но никогда не была реализована в коде — теперь работает по-настоящему',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — fifteenth entry. */
  async ensureVersion34() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.14.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.14.0',
      added: [
        'Оценка драфта расширена с 3 до 5 категорий — добавлены синергия состава и совпадение по линиям (раньше эти данные считались для визуализации, но не входили в итоговый счёт)',
      ],
      fixed: [
        'Кнопка «Завершить драфт» могла отклоняться сервером в режиме практики против себя — рассинхронизация между тем, как фронтенд и бэкенд определяли, кому какие герои принадлежат',
        'Результат и очки драфта могли показываться до нажатия «Завершить» — последнее действие, завершающее драфт, не сбрасывало предыдущий предварительный расчёт',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — sixteenth entry. */
  async ensureVersion35() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.15.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.15.0',
      added: [
        'Раздел «Сообщество» — Discord и WhatsApp, плюс «Areon Voice» и «Поиск игроков»/«Пати» как ближайшие шаги',
        'Полноценная система друзей — заявки, принятие/отклонение, блокировка, поиск по нику или Areon ID',
        'Публичный профиль любого игрока — статистика, матчи, достижения, значки, с учётом настроек приватности',
        'Настройки приватности профиля — отдельно для статистики, истории матчей, достижений, рейтингов, списка друзей',
        'Уведомления — заявки в друзья и их принятие, с колокольчиком в шапке сайта',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — seventeenth entry. */
  async ensureVersion36() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.16.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.16.0',
      added: [
        'Разбор драфта стал намного подробнее — под каждой из 5 категорий теперь конкретные объяснения (кто с кем, почему, что можно было сделать иначе), а не просто цифра',
        'Рекомендации «кого стоило забанить» расширены до нескольких кандидатов, добавлен «альтернативный пик» с конкретным героем взамен рискованного',
        'Итоговый результат драфта теперь в самом низу страницы — сначала весь разбор, потом вердикт. Оценка состава и результат реальной игры чётко разделены',
        'Единый компонент для иконок героев — при сбое загрузки показывается аккуратная заглушка вместо сломанной картинки, ошибка видна в консоли',
      ],
      fixed: [
        '«Линии» в оценке драфта почти всегда показывали 0 — синхронизация контрпиков была подключена только к ручной кнопке в админке и, скорее всего, никогда не запускалась на этой базе. Теперь запускается автоматически вместе с остальными данными патча',
        'Контрпики могли дублироваться в списке («X контрит Y» дважды) — добавлена защита от повторного подсчёта одной и той же пары',
        'Пятиугольник синергии был почти весь зелёным — правил на «хорошо» было четыре и они широкие, а на «плохо» — всего одно узкое. Добавлены ещё два содержательных правила конфликта',
        'Фоновая музыка запускалась только после того, как пользователь трогал громкость — теперь при блокировке автовоспроизведения браузером повторная попытка происходит при первом клике/тапе в любом месте страницы',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — eighteenth entry. */
  async ensureVersion37() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.17.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.17.0',
      fixed: [
        'iBot в Draft Trainer больше не ходит мгновенно — теперь реально «думает» 5-15 секунд (зависит от сложности решения) перед каждым баном/пиком, с индикатором статуса анализа',
        'Баны iBot до первого пика были полностью случайными (buffer в самом коде так и было написано) — теперь бан ориентируется на то, насколько герой в принципе опасен, даже без собственного состава для защиты',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — nineteenth entry. */
  async ensureVersion38() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.18.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.18.0',
      added: [
        'Оценка драфта расширена с 5 до 10 категорий — добавлены Teamfight, Урон, Контроль/инициация, Scaling и Objectives/Tempo, каждая с реальными причинами по тегам ролей героев',
        'iBot теперь тоже использует эти новые параметры при выборе пика — закрывает не только роли, но и реальные пробелы состава (нет инициатора/контроля/магического урона/физического керри)',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — twentieth entry. */
  async ensureVersion39() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.19.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.19.0',
      added: [
        'iBot теперь объясняет свои решения — наведите на пик/бан бота в истории драфта, чтобы увидеть, почему он выбрал именно этого героя',
        'iBot меняет приоритеты по стадии драфта — в начале важнее гибкость и роли, к концу — конкретные контрпики против уже открытого состава',
        'iBot выбирает не всегда сильнейший вариант, а один из нескольких действительно сильных (в разумных пределах) — меньше предсказуемости при той же осмысленности',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — twenty-first entry. */
  async ensureVersion40() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.20.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.20.0',
      added: [
        'Глобальный клик — один звук на нажатие любой кнопки по всему сайту, без ручной прошивки каждой страницы',
        'Звук перехода между разделами сайта (там, где ещё не было своего специфичного)',
        'Звук покупки и ошибки в магазине, звук принятия заявки в друзья, звук нового уведомления (только когда оно реально новое, не при каждой проверке)',
        'Защита от наложения звуков — не больше 6 одновременно, важные (ошибка, результат, взрыв) не глушатся менее важными, повторный одинаковый звук не может сработать чаще раза в 80мс (защита от дублей из-за повторного рендера React)',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — twenty-second entry. */
  async ensureVersion41() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.21.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.21.0',
      added: [
        'Void Hunter, Areon Aegis, Inferno Wraps — теперь настоящие анимированные рамки аватара (искажение пространства, постоянное свечение, живой огонь), а не маленькие картинки. Фото профиля внутри остаётся чётким',
        'Титулы теперь реально отображаются под именем игрока, бейджи — статусной плашкой рядом с именем',
        'Areon Champion, Areon Veteran, Scourgeborn Emblem переведены в эксклюзивные — больше не продаются за Arium Points, выдаются только администратором',
        'Магазин разделён на вкладки «Купить» и «Эксклюзивные» — эксклюзивные предметы честно показывают «Не продаётся. Выдаётся администрацией.» вместо кнопки покупки',
        'Добавлено 5 новых предметов: Inferno Wraps (анимированная рамка), Radiant Pulse (эффект пульсирующей ауры профиля), Ancient Guardian (титул), Stormcaller Sigil (бейдж), Nightfall Crest (эмблема)',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — twenty-third entry. */
  async ensureVersion42() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.22.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.22.0',
      added: [
        '«Продолжить драфт» — заметный баннер в лобби Draft Trainer, если есть незавершённая сессия (данные всегда сохранялись в базе, просто не было пути назад без прямой ссылки)',
        'Контрпики героя теперь показываются прямо в панели предпросмотра во время драфта — не нужно уходить со страницы, чтобы их увидеть',
      ],
      fixed: [
        'Настоящая причина нестабильности контрпиков/линий: массовая синхронизация с OpenDota стучалась в 3 раза быстрее их лимита (60 запросов/минуту без API-ключа) — после первых ~50 героев всё остальное проваливалось с ошибкой на каждом запуске. Теперь синхронизация укладывается в лимит и делает настоящую паузу при столкновении с ним',
        'Ошибки синхронизации матчей показывали одну и ту же расплывчатую фразу независимо от причины (код буквально отбрасывал реальную ошибку) — теперь видно, что случилось на самом деле: лимит OpenDota, приватный профиль, их сервис недоступен, и т.д.',
        '«Назад» в Draft Trainer выкидывал из активного драфта — причина в том, что «Контрпики» на самом деле уводили на отдельную страницу, а не показывали данные на месте. Теперь это разворачиваемая панель без ухода со страницы',
        'Заглушка при сбое загрузки иконки героя была залита почти чёрным цветом на чёрном фоне кнопки — визуально неотличимо от «чёрного экрана». Теперь заглушка — заметный серый прямоугольник со знаком вопроса',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — twenty-fourth entry. */
  async ensureVersion43() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.23.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.23.0',
      fixed: [
        'Матч, ещё не проверенный на испытания (Orion Trials), мог быть удалён при обрезке до последних 20 матчей раньше, чем испытания успевали его увидеть — прогресс по заданию терялся безвозвратно. Проверка испытаний теперь всегда идёт раньше обрезки',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — twenty-fifth entry. */
  async ensureVersion44() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.24.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.24.0',
      fixed: [
        'Синхронизация матчей реально обрывалась по таймауту (подтверждено в логах: OpenDota отвечала дольше 10 секунд) — увеличен таймаут до 25 секунд и добавлена одна автоматическая повторная попытка при таймауте/обрыве сети',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — twenty-sixth entry. */
  async ensureVersion45() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.25.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.25.0',
      fixed: [
        'После починки таймаута обнаружилась следующая по цепочке ошибка: обрезка до 20 матчей падала с ошибкой внешнего ключа, если у вытесняемого матча уже был сохранён детальный разбор (AI Coach) или кэш анализа матча — база отказывалась его удалить. Добавлено каскадное удаление связанных записей',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — twenty-seventh entry. */
  async ensureVersion46() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.26.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.26.0',
      fixed: [
        '«Загружено матчей: 20» показывалось одинаково и когда матчи были реально новыми, и когда OpenDota просто повторно отдавала уже известные — теперь сообщение честно различает «новых матчей: N» и «новых нет, OpenDota ещё не обработала последнюю игру» (это задержка на их стороне, не то, что можно починить у себя)',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — twenty-eighth entry. */
  async ensureVersion47() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.27.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.27.0',
      fixed: [
        'Настоящая причина суточной задержки новых матчей: OpenDota не опрашивает Steam постоянно сама за каждого игрока — для этого у них есть отдельный метод «обновить прямо сейчас», и наш сайт им ни разу не пользовался, просто читал то, что у них уже было закешировано. Теперь синхронизация сначала явно просит OpenDota проверить Steam, и только потом запрашивает список матчей',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — twenty-ninth entry. */
  async ensureVersion48() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.28.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.28.0',
      added: [
        'Areon Voice — настоящие голосовые комнаты прямо на сайте: создание/удаление, публичные и приватные (по коду приглашения), микрофон/звук вкл-выкл, индикатор говорящего, исключение участника, приглашение из уведомлений. Работает через LiveKit — ждёт настройки ключа администратором',
      ],
    });
    return { created: true };
  }
}
