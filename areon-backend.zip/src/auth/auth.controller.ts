import { Controller, Get, Post, Req, Res, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ConfigService } from '@nestjs/config';
import { Response } from 'express';
import { AuthService } from './auth.service';
import { SteamProfile } from './steam.strategy';
import { PrismaService } from '../prisma.service';
import { Public } from './public.decorator';
import { isSafeRelativePath } from './capture-return-to.middleware';
import { SecurityLogService } from '../security/security-log.service';

@Controller('auth')
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly config: ConfigService,
    private readonly prisma: PrismaService,
    private readonly securityLog: SecurityLogService,
  ) {}

  // GET /auth/steam — kicks off the redirect to Steam's login page.
  // Passport handles the redirect itself; this handler body never runs.
  @Public()
  @Get('steam')
  @UseGuards(AuthGuard('steam'))
  steamLogin() {}

  // GET /auth/steam/return — Steam redirects back here after login.
  // Must be @Public(): there's no session cookie yet at this point —
  // that's exactly what this handler is about to create.
  @Public()
  @Get('steam/return')
  @UseGuards(AuthGuard('steam'))
  async steamReturn(@Req() req: { user: SteamProfile; ip: string }, @Res() res: Response) {
    const { accessToken, user } = await this.authService.loginOrCreate(req.user);
    // Same normalization as main.ts's CORS setup — a trailing slash in
    // the env var would otherwise double up right before the "#" below
    // (".../#/profile" becoming "..//#/profile"), which some browsers
    // tolerate and some don't. One source of truth for "this env var
    // might have a stray trailing slash" is safer than fixing it in
    // two places that could drift apart later.
    const frontendUrl = (this.config.get('FRONTEND_URL') as string | undefined)?.replace(/\/+$/, '');

    // A banned user never gets a working cookie at all — logging in
    // successfully and then hitting 403 on the very first request
    // would look like a bug, not an explained ban.
    if (user.isBanned) {
      this.securityLog.log('BANNED_ACCESS_ATTEMPT', { userId: user.id, ip: req.ip, metadata: { stage: 'steam_return' } });
      res.redirect(`${frontendUrl}/#/banned`);
      return;
    }

    // requirement 8: logins are a security-relevant event too — this
    // type existed in SecurityLogService already but nothing ever
    // actually called it for a successful login, only failures had a
    // (likewise unused) type defined. No secrets in the metadata, per
    // that service's own rule — just enough to spot something odd
    // later (a login from a new IP for an account, a sudden burst).
    this.securityLog.log('STEAM_LOGIN_SUCCESS', { userId: user.id, ip: req.ip });

    res.cookie('areon_token', accessToken, {
      httpOnly: true,
      // Frontend and backend live on two different origins (separate
      // subdomains), so this cookie must be sent on cross-site fetch
      // requests — SameSite=Lax blocks that (it only allows top-level
      // navigations cross-site). 'none' requires secure:true, which we
      // already compute below whenever the frontend is on https.
      sameSite: 'none',
      // Was a dead comment ("secure: true in production") for a while —
      // actually wired up now. Derived from APP_URL's protocol rather
      // than a separate NODE_ENV check, so it can't drift out of sync
      // with the URL Steam's OpenID return actually points at.
      secure: frontendUrl?.startsWith('https://') ?? false,
    });

    // Redirect to the FRONTEND's origin, not a relative path on this API —
    // the SPA and this backend are two separate apps on two separate
    // ports/domains, so a bare "/profile" would 404 against the API itself.
    // Requirement: return the person to wherever they actually started
    // — not always /profile. isSafeRelativePath was already checked
    // once when the cookie was set, but checked again here too, since
    // trusting a cookie value without re-validating it at the point
    // it's used as a redirect target is exactly how open-redirect bugs
    // creep back in during a later edit.
    const savedReturnTo = (req as any).cookies?.areon_return_to;
    res.clearCookie('areon_return_to', { path: '/auth/steam/return' });

    // Onboarding (the data-exposure consent step) still takes priority
    // for anyone who hasn't done it yet — a brand-new login isn't the
    // moment to skip that just because they started from some other
    // page. Once that's done, returning users go back to wherever they
    // actually started.
    const target = !user.statsExposed
      ? '/onboarding/expose-data'
      : typeof savedReturnTo === 'string' && isSafeRelativePath(savedReturnTo)
      ? savedReturnTo
      : '/profile';
    res.redirect(`${frontendUrl}/#${target}`);
  }

  // Lets the SPA ask "who am I / is my data exposed" on load without
  // re-running the Steam API check every time — that's what
  // /players/me/stats-status is for, triggered explicitly.
  @Get('me')
  async me(@Req() req: any) {
    const user = await this.prisma.user.findUnique({ where: { id: req.user.sub } });
    if (!user) return null;
    return {
      id: user.id,
      personaName: user.personaName,
      avatarFull: user.avatarFull,
      statsExposed: user.statsExposed,
      isAdmin: user.isAdmin,
      canCreateFreeTournaments: user.canCreateFreeTournaments,
      siteRating: user.siteRating,
      draftRating: user.draftRating,
    };
  }

  /**
   * A real logout, not just a client-side cookie clear: bumping
   * tokenVersion invalidates this token (and any other copy of it,
   * e.g. one an attacker had already stolen) immediately, server-side
   * — see JwtStrategy.validate()'s matching check. Clearing the cookie
   * on top of that is just good hygiene for the normal case.
   */
  @Post('logout')
  async logout(@Req() req: any, @Res() res: Response) {
    await this.prisma.user.update({
      where: { id: req.user.sub },
      data: { tokenVersion: { increment: 1 } },
    });
    res.clearCookie('areon_token');
    res.status(204).send();
  }
}

