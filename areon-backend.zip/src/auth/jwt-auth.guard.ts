import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { Reflector } from '@nestjs/core';
import { IS_PUBLIC_KEY } from './public.decorator';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  constructor(private readonly reflector: Reflector) {
    super();
  }

  canActivate(context: any) {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) return true;
    return super.canActivate(context);
  }

  // Diagnostic only — passport's default handleRequest just throws
  // UnauthorizedException on any failure with no detail. This is the
  // one place that can show WHICH of the three real possibilities is
  // actually happening after a Steam login: no cookie reaching this
  // request at all (req.cookies.areon_token is undefined — a CORS/
  // SameSite/domain problem), a cookie that's present but fails JWT
  // verification (a secret/expiry problem), or JwtStrategy.validate()
  // itself rejecting a structurally valid token (banned/tokenVersion
  // mismatch, logged separately in SecurityLogService). Without this,
  // every one of those looks identical from the frontend: just "not
  // logged in".
  handleRequest(err: any, user: any, info: any, context: any) {
    if (!user) {
      const req = context.switchToHttp().getRequest();
      // eslint-disable-next-line no-console
      console.log(
        `[auth] JWT check failed for ${req.method} ${req.url} — ` +
        `cookie present=${!!req.cookies?.areon_token}, err=${err?.message ?? 'none'}, info=${info?.message ?? info ?? 'none'}`,
      );
    }
    return super.handleRequest(err, user, info, context);
  }
}

/**
 * Diagnostic-only wrapper around AuthGuard('steam') — if Steam's own
 * OpenID verification fails (wrong realm, wrong returnURL, a lapsed
 * STEAM_API_KEY, Steam's own verification endpoint being unreachable
 * from this server), Passport's default handling can fail BEFORE
 * steamReturn()'s own console.log ever runs, since the guard runs
 * first. Without this, that failure mode would be invisible in the
 * logs the same way the whole login flow has been so far. Logged
 * here regardless of outcome — once, on the actual /auth/steam/return
 * hit — so there's always at least one line proving the request
 * reached this server at all, even in the worst case.
 */
@Injectable()
export class SteamAuthGuard extends AuthGuard('steam') {
  handleRequest(err: any, user: any, info: any, context: any) {
    const req = context.switchToHttp().getRequest();
    // eslint-disable-next-line no-console
    console.log(
      `[auth] Steam guard result for ${req.method} ${req.url} — ` +
      `success=${!!user}, err=${err?.message ?? 'none'}, info=${info?.message ?? info ?? 'none'}`,
    );
    return super.handleRequest(err, user, info, context);
  }
}
