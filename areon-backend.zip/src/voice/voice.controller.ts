import { Body, Controller, Delete, Get, Param, Post, Query, Req } from '@nestjs/common';
import { VoiceService } from './voice.service';

@Controller('voice')
export class VoiceController {
  constructor(private readonly voice: VoiceService) {}

  @Get('rooms')
  list(@Req() req: any) {
    return this.voice.listRooms(req.user.sub);
  }

  @Post('rooms')
  create(@Req() req: any, @Body() body: { name: string; isPrivate?: boolean; context?: string }) {
    return this.voice.createRoom(req.user.sub, body.name, !!body.isPrivate, body.context);
  }

  @Delete('rooms/:id')
  remove(@Req() req: any, @Param('id') id: string) {
    return this.voice.deleteRoom(req.user.sub, id);
  }

  @Get('rooms/:id/join')
  join(@Req() req: any, @Param('id') id: string, @Query('code') code?: string) {
    return this.voice.joinToken(req.user.sub, id, code);
  }

  @Post('rooms/:id/kick/:userId')
  kick(@Req() req: any, @Param('id') id: string, @Param('userId') userId: string, @Body() body: { ban?: boolean }) {
    return this.voice.kick(req.user.sub, id, userId, !!body?.ban);
  }

  @Post('rooms/:id/invite/:userId')
  invite(@Req() req: any, @Param('id') id: string, @Param('userId') userId: string) {
    return this.voice.inviteToRoom(req.user.sub, id, userId);
  }
}
