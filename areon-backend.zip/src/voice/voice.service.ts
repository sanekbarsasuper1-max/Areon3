import { BadRequestException, ForbiddenException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AccessToken, RoomServiceClient } from 'livekit-server-sdk';
import { randomBytes } from 'crypto';
import { PrismaService } from '../prisma.service';
import { NotificationsService } from '../notifications/notifications.service';

@Injectable()
export class VoiceService {
  private readonly logger = new Logger(VoiceService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly config: ConfigService,
    private readonly notifications: NotificationsService,
  ) {}

  /**
   * Areon's own DB never holds the LiveKit API key/secret in more
   * than one place, and never sends the secret to the browser —
   * every method below either mints a short-lived signed token
   * (AccessToken) or calls LiveKit's management API server-side
   * (RoomServiceClient), matching the architecture agreed on when
   * this was first planned: our backend owns rooms/auth/moderation,
   * LiveKit owns the actual WebRTC media.
   */
  private get credentials(): { url: string; apiKey: string; apiSecret: string } | null {
    const url = this.config.get<string>('LIVEKIT_URL');
    const apiKey = this.config.get<string>('LIVEKIT_API_KEY');
    const apiSecret = this.config.get<string>('LIVEKIT_API_SECRET');
    if (!url || !apiKey || !apiSecret) return null;
    return { url, apiKey, apiSecret };
  }

  private requireCredentials() {
    const creds = this.credentials;
    if (!creds) {
      throw new BadRequestException('Голосовой чат ещё не настроен администратором (нет ключей LiveKit).');
    }
    return creds;
  }

  private roomServiceClient(): RoomServiceClient {
    const { url, apiKey, apiSecret } = this.requireCredentials();
    // RoomServiceClient's constructor wants an https:// host, not the
    // wss:// one browsers connect with for media — LiveKit Cloud
    // issues one project URL that works for both, but sync it here
    // in case a self-hosted LIVEKIT_URL is ever wss:// only.
    const httpUrl = url.replace(/^wss:\/\//, 'https://').replace(/^ws:\/\//, 'http://');
    return new RoomServiceClient(httpUrl, apiKey, apiSecret);
  }

  async listRooms(userId: string) {
    const rooms = await this.prisma.voiceRoom.findMany({
      where: { closedAt: null, OR: [{ isPrivate: false }, { createdByUserId: userId }] },
      include: { createdBy: { select: { id: true, personaName: true } } },
      orderBy: { createdAt: 'desc' },
    });

    // Live participant counts come from LiveKit itself, not our DB —
    // best-effort: if LiveKit isn't configured yet or a single lookup
    // fails, the room list still renders, just without a live count.
    const creds = this.credentials;
    if (!creds) return rooms.map((r) => ({ ...r, participantCount: null as number | null }));

    const svc = this.roomServiceClient();
    const counts = await Promise.all(
      rooms.map(async (r) => {
        try {
          const participants = await svc.listParticipants(r.id);
          return participants.length;
        } catch {
          return null;
        }
      }),
    );
    return rooms.map((r, i) => ({ ...r, participantCount: counts[i] }));
  }

  async createRoom(userId: string, name: string, isPrivate: boolean, context?: string) {
    if (!name?.trim()) throw new BadRequestException('Укажите название комнаты');
    const inviteCode = isPrivate ? randomBytes(6).toString('hex') : null;

    const room = await this.prisma.voiceRoom.create({
      data: { name: name.trim(), createdByUserId: userId, isPrivate, inviteCode, context },
    });

    const creds = this.credentials;
    if (creds) {
      try {
        await this.roomServiceClient().createRoom({ name: room.id, emptyTimeout: 10 * 60, maxParticipants: 25 });
      } catch (e: any) {
        this.logger.warn(`LiveKit createRoom failed for ${room.id}: ${e.message}`);
      }
    }
    return room;
  }

  async deleteRoom(userId: string, roomId: string) {
    const room = await this.prisma.voiceRoom.findUnique({ where: { id: roomId } });
    if (!room) throw new NotFoundException('Комната не найдена');
    if (room.createdByUserId !== userId) throw new ForbiddenException('Удалить комнату может только её создатель');

    await this.prisma.voiceRoom.update({ where: { id: roomId }, data: { closedAt: new Date() } });
    const creds = this.credentials;
    if (creds) {
      try {
        await this.roomServiceClient().deleteRoom(roomId);
      } catch (e: any) {
        this.logger.warn(`LiveKit deleteRoom failed for ${roomId}: ${e.message}`);
      }
    }
    return { closed: true };
  }

  /**
   * requirement: joining a private room needs the invite code; a
   * public one just needs to be an Areon user at all (already
   * guaranteed by the global auth guard). A ban recorded on the room
   * blocks re-joining regardless of which kind it is.
   */
  async joinToken(userId: string, roomId: string, inviteCode?: string) {
    const { url, apiKey, apiSecret } = this.requireCredentials();
    const room = await this.prisma.voiceRoom.findUnique({ where: { id: roomId }, include: { createdBy: { select: { personaName: true } } } });
    if (!room || room.closedAt) throw new NotFoundException('Комната не найдена или уже закрыта');
    if (room.bannedUserIds.includes(userId)) throw new ForbiddenException('Вы заблокированы в этой комнате');
    if (room.isPrivate && room.createdByUserId !== userId && inviteCode !== room.inviteCode) {
      throw new ForbiddenException('Неверный код приглашения');
    }

    const user = await this.prisma.user.findUnique({ where: { id: userId }, select: { personaName: true, avatarFull: true } });
    const at = new AccessToken(apiKey, apiSecret, {
      identity: userId,
      name: user?.personaName ?? 'Player',
      // requirement: the room should be able to tell WHICH Areon
      // account someone is (not just a LiveKit-local identity) —
      // avatar travels in the token's metadata so the room UI can
      // render it without a second lookup per participant.
      metadata: JSON.stringify({ avatarFull: user?.avatarFull ?? null }),
    });
    at.addGrant({ roomJoin: true, room: roomId, canPublish: true, canSubscribe: true });

    return { token: await at.toJwt(), url, roomName: room.name, hostedBy: room.createdBy.personaName };
  }

  async kick(userId: string, roomId: string, targetUserId: string, ban: boolean) {
    const room = await this.prisma.voiceRoom.findUnique({ where: { id: roomId } });
    if (!room) throw new NotFoundException('Комната не найдена');
    if (room.createdByUserId !== userId) throw new ForbiddenException('Управлять участниками может только создатель комнаты');

    if (ban) {
      await this.prisma.voiceRoom.update({
        where: { id: roomId },
        data: { bannedUserIds: { push: targetUserId } },
      });
    }
    const creds = this.credentials;
    if (creds) {
      try {
        await this.roomServiceClient().removeParticipant(roomId, targetUserId);
      } catch (e: any) {
        this.logger.warn(`LiveKit removeParticipant failed for ${roomId}/${targetUserId}: ${e.message}`);
      }
    }
    return { kicked: true, banned: ban };
  }

  async inviteToRoom(fromUserId: string, roomId: string, toUserId: string) {
    const room = await this.prisma.voiceRoom.findUnique({ where: { id: roomId } });
    if (!room || room.closedAt) throw new NotFoundException('Комната не найдена или уже закрыта');
    const fromUser = await this.prisma.user.findUnique({ where: { id: fromUserId }, select: { personaName: true } });
    await this.notifications.create(toUserId, 'voice_invite', {
      roomId, roomName: room.name, fromUserId, fromName: fromUser?.personaName,
      inviteCode: room.isPrivate ? room.inviteCode : undefined,
    });
    return { invited: true };
  }
}
