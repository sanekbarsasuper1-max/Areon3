import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { OpenDotaService } from '../opendota/opendota.service';
import { MatchAnalyzerService } from './match-analyzer.service';
import { TrialEngineService } from '../trials/trial-engine.service';
import { HallOfFameService } from '../hall-of-fame/hall-of-fame.service';

export interface MatchListFilters {
  heroId?: number;
  result?: 'win' | 'loss';
  days?: number;
  page?: number;
  pageSize?: number;
}

@Injectable()
export class MatchesService {
  private readonly logger = new Logger(MatchesService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly openDota: OpenDotaService,
    private readonly analyzer: MatchAnalyzerService,
    private readonly trialEngine: TrialEngineService,
    private readonly hallOfFame: HallOfFameService,
  ) {}

  /**
   * Pulls recent matches from OpenDota and upserts them into our own
   * Match table. This is the only place that talks to OpenDota — every
   * other read (the "Все матчи" list, profile stats) reads from Postgres,
   * per the architecture: backend serves from storage, workers do the
   * external sync, never the other way around at request time.
   */
  async syncRecentMatches(userId: string, accountId32: number, limit = 20) {
    const summaries = await this.openDota.getPlayerMatches(accountId32, limit);

    let upserted = 0;
    let skipped = 0;
    for (const m of summaries) {
      // Defensive guard against exactly the failure mode that caused a
      // real outage: if OpenDota's response for a given match is
      // missing a field this row genuinely can't do without (unlike
      // goldPerMin/xpPerMin, which are legitimately nullable), skip
      // that one match rather than writing a corrupt row or crashing
      // the whole sync over one bad entry — every other match still
      // syncs normally.
      if (
        m.hero_id == null || m.kills == null || m.deaths == null || m.assists == null ||
        m.duration == null || m.start_time == null || m.radiant_win == null ||
        m.player_slot == null || m.lobby_type == null || m.game_mode == null
      ) {
        this.logger.warn(`Skipping match_id=${m.match_id} for user=${userId} — OpenDota response missing a required field`);
        skipped += 1;
        continue;
      }
      await this.prisma.match.upsert({
        where: {
          userId_matchId: { userId, matchId: BigInt(m.match_id) },
        },
        create: {
          userId,
          matchId: BigInt(m.match_id),
          heroId: m.hero_id,
          kills: m.kills,
          deaths: m.deaths,
          assists: m.assists,
          goldPerMin: m.gold_per_min ?? null,
          xpPerMin: m.xp_per_min ?? null,
          durationSec: m.duration,
          startTime: new Date(m.start_time * 1000),
          radiantWin: m.radiant_win,
          playerSlot: m.player_slot,
          lobbyType: m.lobby_type,
          gameMode: m.game_mode,
          laneRole: m.lane_role ?? null,
          heroDamage: m.hero_damage ?? null,
          heroHealing: m.hero_healing ?? null,
          lastHits: m.last_hits ?? null,
        },
        // A match's own core stats never change after the fact — but
        // laneRole/heroDamage/heroHealing/lastHits are fields we only
        // started capturing after some matches were already synced, so
        // they're worth backfilling on re-sync rather than leaving them
        // permanently null for anyone who synced before these existed.
        update: {
          syncedAt: new Date(),
          laneRole: m.lane_role ?? null,
          heroDamage: m.hero_damage ?? null,
          heroHealing: m.hero_healing ?? null,
          lastHits: m.last_hits ?? null,
        },
      });
      upserted += 1;
    }

    this.logger.log(`Synced ${upserted} matches for user=${userId}${skipped > 0 ? `, skipped ${skipped} with incomplete data` : ''}`);

    // Orion Trials: evaluate whatever's newly unprocessed. Failure here
    // shouldn't fail the whole sync response — the match data itself
    // synced fine regardless of whether trial-checking succeeded, and
    // Match.trialsProcessedAt being null just means the next sync (or a
    // future retry) picks it back up.
    try {
      await this.trialEngine.processUnevaluatedMatchesForUser(userId);
    } catch (e: any) {
      this.logger.warn(`Trial evaluation failed for user=${userId}: ${e.message}`);
    }

    try {
      await this.checkHallOfFameForMatches(userId);
    } catch (e: any) {
      this.logger.warn(`Hall of Fame check failed for user=${userId}: ${e.message}`);
    }

    return { synced: upserted, skipped };
  }

  /**
   * Re-scans this user's full match history on every sync (cheap — a
   * person's own history is never large) rather than trying to track
   * "did this specific sync introduce a new extreme," since a synced
   * batch could contain several old matches at once and the simplest
   * correct approach is just "what's the best/worst across everything
   * right now." recordEvent's own SUPERSEDING check means re-submitting
   * the same extreme value on every sync is a cheap no-op, not a bug.
   */
  private async checkHallOfFameForMatches(userId: string) {
    const matches = await this.prisma.match.findMany({ where: { userId }, orderBy: { startTime: 'asc' } });
    if (matches.length === 0) return;

    let fastest = matches[0];
    let longest = matches[0];
    for (const m of matches) {
      if (m.durationSec < fastest.durationSec) fastest = m;
      if (m.durationSec > longest.durationSec) longest = m;
    }
    const formatDuration = (sec: number) => `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`;

    await this.hallOfFame.recordEvent({
      key: 'fastest_real_match', userId, rawValue: fastest.durationSec, value: formatDuration(fastest.durationSec), relatedMatchId: fastest.id,
    });
    await this.hallOfFame.recordEvent({
      key: 'longest_real_match', userId, rawValue: longest.durationSec, value: formatDuration(longest.durationSec), relatedMatchId: longest.id,
    });

    let currentStreak = 0;
    let bestStreak = 0;
    for (const m of matches) {
      const isRadiant = m.playerSlot < 128;
      const won = isRadiant ? m.radiantWin : !m.radiantWin;
      if (won) {
        currentStreak += 1;
        bestStreak = Math.max(bestStreak, currentStreak);
      } else {
        currentStreak = 0;
      }
    }
    if (bestStreak > 0) {
      await this.hallOfFame.recordEvent({
        key: 'longest_real_match_win_streak', userId, rawValue: bestStreak, value: `${bestStreak} побед подряд`,
      });
    }
  }

  async listMatches(userId: string, filters: MatchListFilters) {
    const page = filters.page ?? 1;
    const pageSize = Math.min(filters.pageSize ?? 20, 50);

    const where: any = { userId };
    if (filters.heroId) where.heroId = filters.heroId;
    if (filters.days) {
      where.startTime = { gte: new Date(Date.now() - filters.days * 86_400_000) };
    }

    const matches = await this.prisma.match.findMany({
      where,
      orderBy: { startTime: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    });

    // radiant_win + player_slot together determine whether *this* player
    // won — player_slot < 128 means Radiant. Filtering on the derived
    // "did I win" value happens here rather than as a raw column, since
    // it's cheap to compute and keeps the stored row a direct mirror of
    // what OpenDota returned.
    const withResult = matches.map((m) => ({
      ...m,
      matchId: m.matchId.toString(), // BigInt isn't JSON-serialisable as-is
      won: m.playerSlot < 128 ? m.radiantWin : !m.radiantWin,
    }));

    if (filters.result) {
      return withResult.filter((m) =>
        filters.result === 'win' ? m.won : !m.won,
      );
    }

    return withResult;
  }

  /**
   * Match Analyzer's detail view. Cached after the first successful
   * PARSED fetch — an unparsed placeholder (empty goldT/xpT, because
   * OpenDota hadn't replay-parsed this match yet) is retried on the
   * next request instead of being treated as permanent, since parse
   * status is the one thing about a finished match that does change
   * over time.
   */
  async getOrFetchDetail(userId: string, accountId32: number, matchRowId: string) {
    const match = await this.prisma.match.findFirst({
      where: { id: matchRowId, userId },
      include: { detail: true },
    });
    if (!match) throw new NotFoundException('Match not found');

    if (match.detail && match.detail.goldT.length > 0) {
      return { match: this.serialize(match), detail: match.detail };
    }

    // No cached row yet, or a cached row from an earlier visit that
    // caught the match still unparsed — either way, kick a parse
    // request (harmless if one is already in flight) and see if a
    // fresh fetch has real data now.
    await this.openDota.requestParse(Number(match.matchId)).catch(() => {});

    const [full, benchmarks] = await Promise.all([
      this.openDota.getMatch(Number(match.matchId)),
      this.openDota.getBenchmarks(match.heroId),
    ]);

    const player = full.players.find((p) => p.account_id === accountId32);
    if (!player) {
      throw new NotFoundException(
        `account_id=${accountId32} not found in match=${match.matchId} — ` +
          `possibly an anonymous/unexposed slot even though the match itself synced`,
      );
    }

    const insights = this.analyzer.buildInsights(player, benchmarks, full.duration);
    const isParsed = (player.gold_t?.length ?? 0) > 0;

    const detail = await this.prisma.matchDetail.upsert({
      where: { matchRowId: match.id },
      create: {
        matchRowId: match.id,
        heroDamage: player.hero_damage,
        towerDamage: player.tower_damage,
        heroHealing: player.hero_healing,
        lastHits: player.last_hits,
        denies: player.denies,
        goldT: player.gold_t,
        xpT: player.xp_t,
        insights: insights as any,
        isParsed,
      },
      update: {
        heroDamage: player.hero_damage,
        towerDamage: player.tower_damage,
        heroHealing: player.hero_healing,
        lastHits: player.last_hits,
        denies: player.denies,
        goldT: player.gold_t,
        xpT: player.xp_t,
        insights: insights as any,
        isParsed,
      },
    });

    return { match: this.serialize(match), detail, isParsed };
  }

  private serialize(match: { matchId: bigint } & Record<string, any>) {
    return { ...match, matchId: match.matchId.toString() };
  }
}
