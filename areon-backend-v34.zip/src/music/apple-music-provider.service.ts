import { Injectable } from '@nestjs/common';

export interface AppleArtist {
  id: string;
  name: string;
  imageUrl: string | null;
  genres: string[];
}

export interface AppleTrack {
  id: string;
  name: string;
  artist: string;
  artistId: string | null;
  albumName: string;
  imageUrl: string | null;
  durationSec: number;
  previewUrl: string | null;
  releaseYear: string | null;
}

export interface AppleAlbum {
  id: string;
  name: string;
  artist: string;
  imageUrl: string | null;
  releaseYear: string | null;
}

/**
 * Apple's iTunes Search API (itunes.apple.com/search — the same
 * catalog the App Store/Apple Music search box uses) rather than
 * Spotify: genuinely free, no API key, no account, no Premium
 * requirement — Spotify locked search behind a Premium-only developer
 * account starting February 2026 (see the product discussion this was
 * built against), which ruled it out for a project with no budget.
 * iTunes has no combined multi-type search endpoint the way Spotify
 * did, so this does three parallel requests (song/musicArtist/album)
 * rather than one — still a single round trip from the frontend's
 * point of view, since it all happens inside one backend call.
 */
@Injectable()
export class AppleMusicProviderService {
  private readonly baseUrl = 'https://itunes.apple.com';

  async search(query: string, limit = 20): Promise<{ artists: AppleArtist[]; tracks: AppleTrack[]; albums: AppleAlbum[] }> {
    const [songsRes, artistsRes, albumsRes] = await Promise.all([
      fetch(`${this.baseUrl}/search?term=${encodeURIComponent(query)}&media=music&entity=song&limit=${limit}`),
      fetch(`${this.baseUrl}/search?term=${encodeURIComponent(query)}&media=music&entity=musicArtist&limit=10`),
      fetch(`${this.baseUrl}/search?term=${encodeURIComponent(query)}&media=music&entity=album&limit=10`),
    ]);
    if (!songsRes.ok || !artistsRes.ok || !albumsRes.ok) {
      throw new Error(`iTunes search failed: ${songsRes.status}/${artistsRes.status}/${albumsRes.status}`);
    }
    const [songsData, artistsData, albumsData] = await Promise.all([songsRes.json(), artistsRes.json(), albumsRes.json()]);

    const tracks: AppleTrack[] = (songsData.results ?? []).map((t: any) => ({
      id: String(t.trackId),
      name: t.trackName,
      artist: t.artistName,
      artistId: t.artistId ? String(t.artistId) : null,
      albumName: t.collectionName ?? '',
      imageUrl: t.artworkUrl100 ? t.artworkUrl100.replace('100x100', '300x300') : null,
      durationSec: Math.round((t.trackTimeMillis ?? 0) / 1000),
      previewUrl: t.previewUrl ?? null,
      releaseYear: t.releaseDate ? String(t.releaseDate).slice(0, 4) : null,
    }));

    const artists: AppleArtist[] = (artistsData.results ?? []).map((a: any) => ({
      id: String(a.artistId),
      name: a.artistName,
      imageUrl: null, // iTunes' artist search doesn't return artwork — only track/album lookups do
      genres: a.primaryGenreName ? [a.primaryGenreName] : [],
    }));

    const albums: AppleAlbum[] = (albumsData.results ?? []).map((al: any) => ({
      id: String(al.collectionId),
      name: al.collectionName,
      artist: al.artistName,
      imageUrl: al.artworkUrl100 ? al.artworkUrl100.replace('100x100', '300x300') : null,
      releaseYear: al.releaseDate ? String(al.releaseDate).slice(0, 4) : null,
    }));

    return { artists, tracks, albums };
  }

  /** requirement 1: clicking an artist shows their real songs. */
  async getArtistTracks(artistId: string): Promise<AppleTrack[]> {
    const res = await fetch(`${this.baseUrl}/lookup?id=${artistId}&entity=song&limit=25`);
    if (!res.ok) throw new Error(`iTunes artist lookup failed: ${res.status}`);
    const data = await res.json();
    // First result is the artist itself, not a track — the lookup endpoint's own convention.
    return (data.results ?? [])
      .filter((t: any) => t.wrapperType === 'track')
      .map((t: any) => ({
        id: String(t.trackId),
        name: t.trackName,
        artist: t.artistName,
        artistId: t.artistId ? String(t.artistId) : null,
        albumName: t.collectionName ?? '',
        imageUrl: t.artworkUrl100 ? t.artworkUrl100.replace('100x100', '300x300') : null,
        durationSec: Math.round((t.trackTimeMillis ?? 0) / 1000),
        previewUrl: t.previewUrl ?? null,
        releaseYear: t.releaseDate ? String(t.releaseDate).slice(0, 4) : null,
      }));
  }
}
