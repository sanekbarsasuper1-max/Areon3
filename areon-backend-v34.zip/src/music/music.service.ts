import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { AppleMusicProviderService } from './apple-music-provider.service';

const SEARCH_CACHE_TTL_MS = 15 * 60 * 1000; // 15 minutes — requirement 9

@Injectable()
export class MusicService {
  private searchCache = new Map<string, { data: unknown; expiresAt: number }>();

  constructor(
    private readonly prisma: PrismaService,
    private readonly appleMusic: AppleMusicProviderService,
  ) {}

  /**
   * requirement 9's cache — in-memory (this service already runs as a
   * single instance on the free tier, so this covers the actual case
   * that matters: many people searching the same popular artist
   * without each one round-tripping to Apple's search API) rather than adding a
   * new Redis client dependency just for this; Redis in this project
   * is already reserved for BullMQ's job queue, not a general cache.
   */
  // iTunes' search endpoint has no documented offset/pagination
  // parameter (unlike Spotify's), so this simplifies to a single page
  // of results per query rather than pretending to paginate something
  // the underlying API doesn't actually support.
  async searchCached(query: string) {
    const q = query?.trim().toLowerCase();
    if (!q) return { artists: [], tracks: [], albums: [] };

    const cached = this.searchCache.get(q);
    if (cached && cached.expiresAt > Date.now()) return cached.data;

    const result = await this.appleMusic.search(q);
    this.searchCache.set(q, { data: result, expiresAt: Date.now() + SEARCH_CACHE_TTL_MS });
    return result;
  }

  async listFavorites(userId: string) {
    return this.prisma.favoriteTrack.findMany({ where: { userId }, orderBy: { createdAt: 'desc' } });
  }

  async addFavorite(userId: string, track: { providerTrackId: string; name: string; artist: string; imageUrl?: string }) {
    // Upsert-by-hand rather than a real upsert — same effect, and this
    // codebase already leans on findUnique-then-create in a few places
    // (e.g. rank snapshots) for the same "don't error on a harmless
    // double-click" reasoning.
    const existing = await this.prisma.favoriteTrack.findUnique({
      where: { userId_provider_providerTrackId: { userId, provider: 'apple', providerTrackId: track.providerTrackId } },
    });
    if (existing) return existing;
    return this.prisma.favoriteTrack.create({
      data: { userId, provider: 'apple', ...track },
    });
  }

  async removeFavorite(userId: string, providerTrackId: string) {
    const existing = await this.prisma.favoriteTrack.findUnique({
      where: { userId_provider_providerTrackId: { userId, provider: 'apple', providerTrackId } },
    });
    if (!existing) return { deleted: false };
    await this.prisma.favoriteTrack.delete({ where: { id: existing.id } });
    return { deleted: true };
  }
}
