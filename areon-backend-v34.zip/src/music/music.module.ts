import { Module } from '@nestjs/common';
import { MusicController } from './music.controller';
import { MusicService } from './music.service';
import { AppleMusicProviderService } from './apple-music-provider.service';
import { PrismaService } from '../prisma.service';

@Module({
  controllers: [MusicController],
  providers: [MusicService, AppleMusicProviderService, PrismaService],
})
export class MusicModule {}
