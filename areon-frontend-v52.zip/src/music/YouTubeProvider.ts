import { MusicProvider, Track, SearchResults } from './MusicProvider';

const API_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:3000';

declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: () => void;
  }
}

let apiLoadPromise: Promise<void> | null = null;

/** Loads YouTube's IFrame API script exactly once, however many providers/pages end up asking for it. */
function loadYouTubeApi(): Promise<void> {
  if (window.YT?.Player) return Promise.resolve();
  if (apiLoadPromise) return apiLoadPromise;
  apiLoadPromise = new Promise((resolve) => {
    const prevReady = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => {
      prevReady?.();
      resolve();
    };
    const script = document.createElement('script');
    script.src = 'https://www.youtube.com/iframe_api';
    document.head.appendChild(script);
  });
  return apiLoadPromise;
}

/**
 * Full-length playback, legally — through YouTube's own official
 * embeddable IFrame Player, not an extracted audio stream (that would
 * violate YouTube's Terms of Service and isn't something this project
 * does). The tradeoff for full tracks instead of a 30-second preview
 * (see YouTubeProviderService's backend-side comment on why Deezer,
 * before this, could only ever offer previews) is that the player
 * itself has to stay visibly on the page — YouTube's terms require
 * that, so this renders a small persistent video area rather than
 * running as an invisible background <audio> element the way every
 * earlier provider here did.
 */
export class YouTubeProvider implements MusicProvider {
  private player: any = null;
  private playerReady: Promise<void> | null = null;
  private pendingEndedCb: (() => void) | null = null;
  private pendingTimeUpdateCb: ((time: number) => void) | null = null;
  private timeUpdateInterval: number | null = null;

  // Deliberately nothing here — this class is instantiated as part of
  // AudioManager's module-level singleton, which runs at script
  // import time, potentially before document.body exists yet
  // (document.body.appendChild on a null body was a real crash here,
  // taking the whole app down before it ever rendered). All DOM/API
  // setup is deferred to ensurePlayer(), called only once something
  // actually tries to play a track — which, with the player hidden
  // from the UI entirely right now, never happens, so no YouTube
  // branding appears anywhere either.
  private ensurePlayer(): Promise<void> {
    if (this.playerReady) return this.playerReady;

    // A small fixed container, not display:none — YouTube's own terms
    // require the player to be visibly presented, not hidden. Kept
    // modest (viewers came for the music, not to watch a video) and
    // GlobalMusicPlayer's own CSS decides exactly where this sits
    // visually via the #areon-youtube-player id.
    let container = document.getElementById('areon-youtube-player-host');
    if (!container) {
      container = document.createElement('div');
      container.id = 'areon-youtube-player-host';
      document.body.appendChild(container);
    }
    const target = document.createElement('div');
    target.id = 'areon-youtube-player';
    container.appendChild(target);

    this.playerReady = loadYouTubeApi().then(() => {
      return new Promise<void>((resolve) => {
        this.player = new window.YT.Player('areon-youtube-player', {
          height: '90',
          width: '160',
          playerVars: { playsinline: 1, controls: 1, modestbranding: 1, rel: 0 },
          events: {
            onReady: () => resolve(),
            onStateChange: (e: any) => {
              // 0 = ended
              if (e.data === 0) this.pendingEndedCb?.();
            },
          },
        });
      });
    });
    return this.playerReady;
  }

  async search(query: string): Promise<SearchResults> {
    const res = await fetch(`${API_URL}/music/search?q=${encodeURIComponent(query)}`, { credentials: 'include' });
    if (res.status === 429) throw new Error('Поиск музыки временно ограничен (дневная квота YouTube исчерпана) — попробуйте завтра.');
    if (res.status === 503) throw new Error('Музыкальный поиск ещё не настроен администратором.');
    if (!res.ok) throw new Error(`Не удалось выполнить поиск (ошибка ${res.status}). Попробуйте ещё раз.`);
    const data = await res.json();
    return {
      artists: [],
      albums: [],
      tracks: (data.tracks ?? []).map((t: any) => ({
        id: t.id, name: t.name, artist: t.artist, durationSec: t.durationSec, imageUrl: t.imageUrl,
      })),
    };
  }

  // YouTube search has no clean "this channel's top music tracks"
  // concept the way a real music catalog API does — degrades to a
  // plain search on the artist's name rather than leaving the
  // requirement unimplemented.
  async getArtistTracks(artistId: string): Promise<Track[]> {
    const results = await this.search(artistId);
    return results.tracks;
  }

  async load(track: Track): Promise<void> {
    await this.ensurePlayer();
    this.player.cueVideoById(track.id);
  }

  async play(): Promise<void> {
    await this.ensurePlayer();
    this.player.playVideo();
    this.startTimeUpdates();
  }

  pause(): void {
    this.player?.pauseVideo();
    this.stopTimeUpdates();
  }

  async resume(): Promise<void> {
    await this.ensurePlayer();
    this.player.playVideo();
    this.startTimeUpdates();
  }

  seek(seconds: number): void {
    this.player?.seekTo(seconds, true);
  }

  setVolume(volume: number): void {
    // YT.Player's volume is 0-100, not the 0-1 scale the rest of this
    // codebase (and the browser's own <audio>.volume) uses.
    this.player?.setVolume?.(Math.round(Math.max(0, Math.min(1, volume)) * 100));
  }

  getCurrentTime(): number {
    return this.player?.getCurrentTime?.() ?? 0;
  }

  getDuration(): number {
    return this.player?.getDuration?.() ?? 0;
  }

  onEnded(cb: () => void): void {
    this.pendingEndedCb = cb;
  }

  onTimeUpdate(cb: (time: number) => void): void {
    this.pendingTimeUpdateCb = cb;
  }

  // The IFrame Player API has no native timeupdate event (unlike
  // <audio>) — polling is the standard, documented way to track
  // progress with this API.
  private startTimeUpdates() {
    this.stopTimeUpdates();
    this.timeUpdateInterval = window.setInterval(() => {
      if (this.pendingTimeUpdateCb) this.pendingTimeUpdateCb(this.getCurrentTime());
    }, 500);
  }

  private stopTimeUpdates() {
    if (this.timeUpdateInterval != null) {
      window.clearInterval(this.timeUpdateInterval);
      this.timeUpdateInterval = null;
    }
  }
}
