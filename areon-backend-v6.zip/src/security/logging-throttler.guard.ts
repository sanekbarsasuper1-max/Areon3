import { ExecutionContext, Inject, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ThrottlerGuard, ThrottlerModuleOptions, ThrottlerStorage, THROTTLER_OPTIONS } from '@nestjs/throttler';
import { SecurityLogService } from './security-log.service';

/**
 * Same rate-limiting behavior as the plain ThrottlerGuard — this only
 * adds one thing: a SecurityEvent row before rejecting, so a burst of
 * rate-limit trips is actually visible somewhere (audit finding
 * MEDIUM #7), not just a silent 429 the admin never sees evidence of.
 */
@Injectable()
export class LoggingThrottlerGuard extends ThrottlerGuard {
  constructor(
    @Inject(THROTTLER_OPTIONS) options: ThrottlerModuleOptions,
    @Inject(ThrottlerStorage) storageService: ThrottlerStorage,
    reflector: Reflector,
    private readonly securityLog: SecurityLogService,
  ) {
    super(options, storageService, reflector);
  }

  protected async throwThrottlingException(context: ExecutionContext, detail: any): Promise<void> {
    const req = context.switchToHttp().getRequest();
    await this.securityLog.log('RATE_LIMITED', {
      userId: req.user?.sub,
      ip: req.ip,
      metadata: { route: req.originalUrl ?? req.url },
    });
    return super.throwThrottlingException(context, detail);
  }
}
