import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, Me, MatchSummary, ProfileSummary, Hero } from '../api';
import { HERO_ICON_FALLBACK } from '../components/HeroImage';

const PROFILE_EFFECT_STYLES = `
@keyframes voidDistort {
  0%, 100% { transform: rotate(0deg) scale(1); filter: hue-rotate(0deg); }
  50% { transform: rotate(180deg) scale(1.04); filter: hue-rotate(25deg); }
}
@keyframes voidRingPulse {
  0%, 100% { opacity: 0.55; }
  50% { opacity: 0.95; }
}
@keyframes aegisGlow {
  0%, 100% { box-shadow: 0 0 14px 3px rgba(230,196,110,0.55), 0 0 28px 8px rgba(230,196,110,0.25); }
  50% { box-shadow: 0 0 22px 6px rgba(230,196,110,0.85), 0 0 42px 14px rgba(230,196,110,0.4); }
}
@keyframes infernoFlicker {
  0%, 100% { opacity: 0.85; transform: scale(1); }
  25% { opacity: 1; transform: scale(1.015) rotate(1deg); }
  50% { opacity: 0.9; transform: scale(0.995) rotate(-1deg); }
  75% { opacity: 1; transform: scale(1.02); }
}
@keyframes profileAmbientPulse {
  0%, 100% { box-shadow: 0 0 0 0 rgba(124,111,240,0); }
  50% { box-shadow: 0 0 32px 6px rgba(124,111,240,0.18); }
}
.profile-ambient-pulse { animation: profileAmbientPulse 3.2s ease-in-out infinite; }
@keyframes emblemFlamePulse {
  0%, 100% { filter: drop-shadow(0 0 4px rgba(80,160,255,0.5)) brightness(1); }
  50% { filter: drop-shadow(0 0 10px rgba(80,160,255,0.85)) brightness(1.08); }
}
.emblem-flame-pulse { animation: emblemFlamePulse 2.4s ease-in-out infinite; }
`;

/**
 * Real avatar frames, not a small badge next to the avatar — the
 * effect lives in a layer that sits BEHIND/AROUND the photo (an
 * oversized decorative ring), never on top of it, so the photo itself
 * always stays sharp and unobscured. Which effect renders is looked
 * up by the equipped frame's exact name — with only three frame items
 * existing today, a small map is more honest than inventing a generic
 * "effect type" taxonomy for a set this size.
 */
function AvatarWithFrame({ avatarUrl, frameName }: { avatarUrl: string; frameName?: string }) {
  const size = 128;
  if (!frameName) {
    return <img src={avatarUrl} alt="" style={{ width: size, height: size, borderRadius: 18, boxShadow: '0 12px 32px rgba(0,0,0,0.4)' }} />;
  }

  const wrapperSize = size + 24;

  if (frameName === 'Void Hunter') {
    return (
      <div style={{ position: 'relative', width: wrapperSize, height: wrapperSize, flexShrink: 0 }}>
        <div style={{
          position: 'absolute', inset: 0, borderRadius: 24,
          background: 'conic-gradient(from 0deg, #7C6FF0, #2FA98F, #5B8DEE, #8A5CF6, #7C6FF0)',
          animation: 'voidDistort 6s linear infinite', filter: 'blur(6px)',
        }} />
        <div style={{ position: 'absolute', inset: 3, borderRadius: 22, background: 'var(--bg)' }} />
        <img src={avatarUrl} alt="" style={{ position: 'absolute', inset: 12, width: size, height: size, borderRadius: 18, objectFit: 'cover', boxShadow: '0 12px 32px rgba(0,0,0,0.4)' }} />
        <div style={{ position: 'absolute', inset: 3, borderRadius: 22, border: '1.5px solid rgba(138,92,246,0.6)', animation: 'voidRingPulse 2.5s ease-in-out infinite', pointerEvents: 'none' }} />
      </div>
    );
  }

  if (frameName === 'Areon Aegis') {
    return (
      <div style={{ position: 'relative', width: wrapperSize, height: wrapperSize, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{
          position: 'absolute', width: size + 10, height: size + 10, borderRadius: 20,
          border: '2px solid #E6C46E', animation: 'aegisGlow 2.2s ease-in-out infinite',
        }} />
        <img src={avatarUrl} alt="" style={{ width: size, height: size, borderRadius: 18, objectFit: 'cover', position: 'relative', zIndex: 1 }} />
      </div>
    );
  }

  if (frameName === 'Inferno Wraps') {
    return (
      <div style={{ position: 'relative', width: wrapperSize, height: wrapperSize, flexShrink: 0 }}>
        <div style={{
          position: 'absolute', inset: 0, borderRadius: 24,
          background: 'conic-gradient(from 90deg, #ff8a3d, #ffcf5c, #ff5a3d, #ff8a3d, #ffb03d, #ff8a3d)',
          animation: 'infernoFlicker 1.6s ease-in-out infinite', filter: 'blur(4px)',
        }} />
        <div style={{ position: 'absolute', inset: 4, borderRadius: 20, background: 'var(--bg)' }} />
        <img src={avatarUrl} alt="" style={{ position: 'absolute', inset: 12, width: size, height: size, borderRadius: 18, objectFit: 'cover', boxShadow: '0 12px 32px rgba(0,0,0,0.4)' }} />
      </div>
    );
  }

  // A frame item exists but isn't one of the three above yet (a new
  // one added to the shop without a matching effect here) — falls
  // back to the plain avatar rather than silently rendering nothing.
  return <img src={avatarUrl} alt="" style={{ width: size, height: size, borderRadius: 18, boxShadow: '0 12px 32px rgba(0,0,0,0.4)' }} />;
}

export function Profile() {
  const [me, setMe] = useState<Me | null>(null);
  const [summary, setSummary] = useState<ProfileSummary | null>(null);
  const [matches, setMatches] = useState<MatchSummary[]>([]);
  const [heroesById, setHeroesById] = useState<Record<number, Hero>>({});
  const [syncing, setSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);
  const [shardBalance, setShardBalance] = useState<number | null>(null);
  const [hofCount, setHofCount] = useState<number | null>(null);
  const [equipped, setEquipped] = useState<{ id: string; itemId: string; item: { name: string; iconEmoji: string; iconUrl: string | null; rarity: string; category: string } }[]>([]);

  useEffect(() => {
    api.shardBalance().then((r) => setShardBalance(r.balance));
    api.hallOfFameMine().then((entries) => setHofCount(entries.length));
    api.shopEquipped().then(setEquipped).catch(() => {});
  }, []);

  async function load() {
    const [meRes, summaryRes, matchesRes, heroesRes] = await Promise.all([
      api.me(),
      api.summary(),
      api.matches({}),
      api.heroes(),
    ]);
    setMe(meRes);
    setSummary(summaryRes);
    setMatches(matchesRes.slice(0, 6));
    setHeroesById(Object.fromEntries(heroesRes.map((h) => [h.id, h])));
  }

  useEffect(() => {
    load();
  }, []);

  async function sync() {
    setSyncing(true);
    setSyncMessage(null);
    try {
      const result = await api.syncMatches();
      await load();
      setSyncMessage(
        result.skipped > 0
          ? `Загружено матчей: ${result.synced}. Пропущено (неполные данные от OpenDota): ${result.skipped}.`
          : `Загружено матчей: ${result.synced}.`,
      );
    } catch {
      setSyncMessage('Не удалось связаться с OpenDota — попробуйте ещё раз позже.');
    } finally {
      setSyncing(false);
    }
  }

  if (!me || !summary) {
    return (
      <div style={{ minHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, color: 'var(--text-secondary)' }}>
        Загрузка…
      </div>
    );
  }

  return (
    <div className="page-shell-wide">
      <style>{PROFILE_EFFECT_STYLES}</style>
      {/* ---------- Header: avatar + name + rating ---------- */}
      {(() => {
        const frame = equipped.find((e) => e.item.category === 'profile_frame');
        const title = equipped.find((e) => e.item.category === 'title');
        const badge = equipped.find((e) => e.item.category === 'badge');
        const ambientEffect = equipped.find((e) => e.item.category === 'profile_effect');
        return (
          <div
            style={{
              display: 'flex', gap: 28, marginBottom: 32, alignItems: 'center', flexWrap: 'wrap',
              position: 'relative', padding: ambientEffect ? 20 : 0, borderRadius: 16,
            }}
            className={ambientEffect ? 'profile-ambient-pulse' : undefined}
          >
            <AvatarWithFrame avatarUrl={me.avatarFull} frameName={frame?.item.name} />
            <div style={{ flex: 1, minWidth: 240 }}>
              <p style={{ fontSize: 34, fontWeight: 700, margin: '0 0 4px', letterSpacing: -0.5 }}>{me.personaName}</p>
              {title && (
                <p style={{ fontSize: 13, fontWeight: 600, letterSpacing: 1.5, margin: '0 0 8px', color: '#E0A63E', textTransform: 'uppercase' }}>
                  {title.item.name}
                </p>
              )}
              {badge && (
                <p style={{ fontSize: 12, margin: '0 0 8px', display: 'inline-flex', alignItems: 'center', gap: 5, background: 'rgba(124,111,240,0.12)', border: '1px solid var(--primary)', borderRadius: 20, padding: '3px 10px', color: 'var(--primary)' }}>
                  {badge.item.iconUrl ? <img src={badge.item.iconUrl} alt="" style={{ width: 14, height: 14, objectFit: 'contain' }} /> : badge.item.iconEmoji} {badge.item.name}
                </p>
              )}
              <p style={{ fontSize: 16, color: 'var(--text-secondary)', margin: 0 }}>
                {me.statsExposed ? 'Статистика доступна' : 'Статистика недоступна'}
              </p>
              <p style={{ fontSize: 14, color: 'var(--primary)', margin: '6px 0 0' }}>
                Site Rating: <strong>{me.siteRating}</strong>
                {'  ·  '}
                Drafter Rating: <strong>{me.draftRating}</strong>
              </p>
            </div>
            {equipped.filter((e) => e.item.category === 'emblem').length > 0 && (
              <div style={{ display: 'flex', gap: 14, marginLeft: 'auto', paddingLeft: 20 }}>
                {equipped.filter((e) => e.item.category === 'emblem').map((e) => (
                  <div key={e.id} title={e.item.name} style={{ textAlign: 'center', width: 76 }}>
                    {e.item.iconUrl ? (
                      <img src={e.item.iconUrl} onError={(ev) => { ev.currentTarget.onerror = null; ev.currentTarget.src = HERO_ICON_FALLBACK; }} alt={e.item.name} style={{ width: 64, height: 64, objectFit: 'contain' }} className={e.item.name === 'Scourgeborn Emblem' ? 'emblem-flame-pulse' : undefined} />
                    ) : (
                      <div style={{ fontSize: 40 }}>{e.item.iconEmoji}</div>
                    )}
                    <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '4px 0 0', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {e.item.name}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })()}

      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1fr) 320px', gap: 28, alignItems: 'flex-start' }}>
        {/* ---------- Main column ---------- */}
        <div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px,1fr))', gap: 16, marginBottom: 28 }}>
            <Stat label="Winrate" value={`${summary.winrate}%`} />
            <Stat label="Wins / Losses" value={`${summary.wins} / ${summary.losses}`} />
            <Stat label="KDA" value={summary.avgKda} />
            <Stat label="GPM / XPM" value={`${summary.avgGpm ?? '—'} / ${summary.avgXpm ?? '—'}`} />
          </div>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, flexWrap: 'wrap', gap: 10 }}>
            <p style={{ fontSize: 22, fontWeight: 600, margin: 0 }}>Последние матчи</p>
            <div style={{ display: 'flex', gap: 10 }}>
              <Link to="/matches" className="button-ghost" style={{ textDecoration: 'none' }}>
                Все матчи
              </Link>
              <button className="button-ghost" onClick={sync} disabled={syncing}>
                {syncing ? 'Синхронизация…' : 'Обновить из OpenDota'}
              </button>
            </div>
          </div>

          {syncMessage && (
            <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 12px' }}>{syncMessage}</p>
          )}

          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {matches.length === 0 && (
              <p style={{ fontSize: 16, color: 'var(--text-muted)' }}>
                Матчей пока нет — нажмите «Обновить из OpenDota».
              </p>
            )}
            {matches.map((m) => {
              const hero = heroesById[m.heroId];
              return (
                <Link
                  key={m.matchId}
                  to={`/matches/${m.id}`}
                  className="card"
                  style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', textDecoration: 'none', color: 'inherit' }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                    <span
                      style={{
                        width: 5, height: 30, borderRadius: 3,
                        background: m.won ? 'var(--accent)' : 'var(--danger)',
                      }}
                    />
                    {hero?.iconUrl && (
                      <img src={hero.iconUrl} onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = HERO_ICON_FALLBACK; }} alt="" style={{ width: 52, aspectRatio: '16/9', objectFit: 'cover', borderRadius: 6 }} />
                    )}
                    <span style={{ fontSize: 17, fontWeight: 500 }}>{hero?.localizedName ?? `Герой #${m.heroId}`}</span>
                  </div>
                  <span style={{ fontSize: 16, color: 'var(--text-secondary)' }}>
                    {m.kills}/{m.deaths}/{m.assists}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>

        {/* ---------- Side column: extra info ---------- */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {shardBalance != null && (
            <Link to="/trials" className="card" style={{ textDecoration: 'none', color: 'inherit', display: 'block' }}>
              <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '0 0 6px', letterSpacing: 1.5 }}>ORION PLUS</p>
              <p style={{ fontSize: 30, fontWeight: 700, margin: 0, color: 'var(--gold)' }}>{shardBalance}</p>
            </Link>
          )}

          {hofCount != null && hofCount > 0 && (
            <Link
              to="/hall-of-fame"
              className="card"
              style={{ textDecoration: 'none', color: 'inherit', display: 'block', border: '1px solid rgba(217,184,74,0.35)' }}
            >
              <p style={{ fontSize: 17, margin: '0 0 4px' }}>🏛️ Зал славы Areon</p>
              <p style={{ fontSize: 14, color: 'var(--text-muted)', margin: 0 }}>
                {hofCount} {hofCount === 1 ? 'историческое достижение' : hofCount < 5 ? 'исторических достижения' : 'исторических достижений'}
              </p>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="card">
      <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: '0 0 8px' }}>{label}</p>
      <p style={{ fontSize: 28, fontWeight: 700, margin: 0 }}>{value}</p>
    </div>
  );
}
