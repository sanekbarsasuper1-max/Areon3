import { MusicProvider, Track, SearchResults } from './MusicProvider';

const API_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:3000';

/**
 * Backed by Apple's free iTunes Search API (via our own backend, see
 * apple-music-provider.service.ts) rather than Spotify — Spotify
 * locked app creation behind a Premium-only developer account
 * starting February 2026, which ruled it out for a project with no
 * paid accounts to spend. iTunes needs no key/token at all, and its
 * previewUrl is a real, reliably-populated 30-second clip (unlike
 * Spotify's, which had become null for many tracks even before the
 * February lockdown) — plays through a single reused <audio> element,
 * same pattern the original Jamendo provider used.
 */
export class AppleMusicProvider implements MusicProvider {
  private audio = new Audio();

  constructor() {
    this.audio.preload = 'auto';
  }

  async search(query: string): Promise<SearchResults> {
    const res = await fetch(`${API_URL}/music/search?q=${encodeURIComponent(query)}`);
    if (!res.ok) throw new Error(`Music search failed: ${res.status}`);
    const data = await res.json();
    return {
      artists: (data.artists ?? []).map((a: any) => ({ id: a.id, name: a.name, imageUrl: a.imageUrl, genres: a.genres ?? [] })),
      tracks: (data.tracks ?? []).map((t: any) => ({
        id: t.id, name: t.name, artist: t.artist, durationSec: t.durationSec, imageUrl: t.imageUrl, previewUrl: t.previewUrl,
      })),
      albums: (data.albums ?? []).map((al: any) => ({ id: al.id, name: al.name, artist: al.artist, imageUrl: al.imageUrl, releaseYear: al.releaseYear })),
    };
  }

  async getArtistTracks(artistId: string): Promise<Track[]> {
    const res = await fetch(`${API_URL}/music/artist/${artistId}/top-tracks`);
    if (!res.ok) throw new Error(`Artist top tracks failed: ${res.status}`);
    const data = await res.json();
    return (data ?? []).map((t: any) => ({
      id: t.id, name: t.name, artist: t.artist, durationSec: t.durationSec, imageUrl: t.imageUrl, previewUrl: t.previewUrl,
    }));
  }

  async load(track: Track): Promise<void> {
    if (!track.previewUrl) {
      throw new Error('Превью недоступно для этого трека — у Apple Music нет клипа для этой записи, не ошибка Areon.');
    }
    this.audio.src = track.previewUrl;
    this.audio.currentTime = 0;
  }

  async play(): Promise<void> {
    await this.audio.play();
  }

  pause(): void {
    this.audio.pause();
  }

  async resume(): Promise<void> {
    await this.audio.play();
  }

  seek(seconds: number): void {
    this.audio.currentTime = seconds;
  }

  setVolume(volume: number): void {
    this.audio.volume = Math.max(0, Math.min(1, volume));
  }

  getCurrentTime(): number {
    return this.audio.currentTime || 0;
  }

  getDuration(): number {
    return this.audio.duration || 0;
  }

  onEnded(cb: () => void): void {
    this.audio.addEventListener('ended', cb);
  }

  onTimeUpdate(cb: (time: number) => void): void {
    this.audio.addEventListener('timeupdate', () => cb(this.audio.currentTime));
  }
}
