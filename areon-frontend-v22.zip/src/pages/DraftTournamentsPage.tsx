import { useEffect, useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { api, Me } from '../api';

export function DraftTournamentsPage() {
  const { id } = useParams<{ id: string }>();
  return id ? <DraftTournamentDetail id={id} /> : <DraftTournamentsList />;
}

function DraftTournamentsList() {
  const [tournaments, setTournaments] = useState<any[]>([]);
  const [me, setMe] = useState<Me | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [name, setName] = useState('');
  const [maxPlayers, setMaxPlayers] = useState(8);
  const navigate = useNavigate();

  useEffect(() => {
    api.draftTournaments().then(setTournaments);
    api.me().then(setMe);
  }, []);

  async function create() {
    if (!name.trim()) return;
    const t = await api.draftTournamentCreate(name.trim(), maxPlayers);
    navigate(`/draft-tournaments/${t.id}`);
  }

  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: '40px 24px 100px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div>
          <p style={{ fontSize: 21, fontWeight: 500, margin: 0 }}>Драфт-турниры</p>
          <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '4px 0 0' }}>
            Соревнование 1 на 1 прямо в Draft Trainer — сетка обновляется автоматически
          </p>
        </div>
        {me?.isAdmin && (
          <button className="button-primary" onClick={() => setShowCreate((v) => !v)}>
            Создать турнир
          </button>
        )}
      </div>

      {showCreate && (
        <div className="card" style={{ marginBottom: 20, display: 'flex', gap: 8, alignItems: 'center' }}>
          <input placeholder="Название" value={name} onChange={(e) => setName(e.target.value)} style={{ flex: 1, background: 'var(--card-2)', border: '0.5px solid var(--border)', borderRadius: 6, padding: '8px 10px', color: 'var(--text)' }} />
          <select value={maxPlayers} onChange={(e) => setMaxPlayers(Number(e.target.value))} style={{ background: 'var(--card-2)', border: '0.5px solid var(--border)', borderRadius: 6, padding: '8px 10px', color: 'var(--text)' }}>
            {[4, 8, 16, 32].map((n) => <option key={n} value={n}>{n} игроков</option>)}
          </select>
          <button className="button-primary" onClick={create}>Создать</button>
        </div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {tournaments.map((t) => (
          <Link key={t.id} to={`/draft-tournaments/${t.id}`} className="card" style={{ textDecoration: 'none', color: 'inherit', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <p style={{ fontSize: 15, fontWeight: 500, margin: 0 }}>{t.name}</p>
              <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '2px 0 0' }}>{t.maxPlayers} игроков</p>
            </div>
            <span className="pill" style={{
              background: t.status === 'live' ? 'var(--accent-bg)' : t.status === 'completed' ? 'var(--card-2)' : 'var(--primary-bg)',
              color: t.status === 'live' ? 'var(--accent)' : t.status === 'completed' ? 'var(--text-muted)' : 'var(--primary)',
            }}>
              {t.status === 'registration' ? 'Регистрация' : t.status === 'live' ? 'Идёт' : t.status === 'completed' ? 'Завершён' : t.status}
            </span>
          </Link>
        ))}
        {tournaments.length === 0 && <p style={{ fontSize: 14, color: 'var(--text-muted)' }}>Турниров пока нет.</p>}
      </div>
    </div>
  );
}

function DraftTournamentDetail({ id }: { id: string }) {
  const [t, setT] = useState<any>(null);
  const [me, setMe] = useState<Me | null>(null);
  const [myMatch, setMyMatch] = useState<any>(null);
  const navigate = useNavigate();

  async function load() {
    const [detail, meRes] = await Promise.all([api.draftTournamentDetail(id), api.me()]);
    setT(detail);
    setMe(meRes);
    if (detail.status === 'live') {
      api.draftTournamentMyMatch(id).then(setMyMatch).catch(() => setMyMatch(null));
    }
  }

  useEffect(() => {
    load();
    const interval = setInterval(load, 15_000);
    return () => clearInterval(interval);
  }, [id]);

  if (!t) return <div style={{ minHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, color: 'var(--text-secondary)' }}>Загрузка…</div>;

  const playerName = (uid: string | null) => uid ? (t.players.find((p: any) => p.id === uid)?.personaName ?? '???') : null;
  const isRegistered = t.registrations.some((r: any) => r.userId === me?.id);
  const rounds = [...new Set(t.matches.map((m: any) => m.round))].sort((a: number, b: number) => a - b);

  async function startMyMatch() {
    const session = await api.draftTournamentStartMatch(myMatch.id);
    navigate(`/draft-trainer/${session.id}`);
  }

  return (
    <div style={{ maxWidth: 1100, margin: '0 auto', padding: '40px 24px 100px' }}>
      <Link to="/draft-tournaments" className="button-ghost" style={{ textDecoration: 'none' }}>← Все турниры</Link>
      <p style={{ fontSize: 21, fontWeight: 500, margin: '16px 0 4px' }}>{t.name}</p>
      <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 20px' }}>
        {t.registrations.length}/{t.maxPlayers} зарегистрировано · Single Elimination
      </p>

      {t.status === 'registration' && (
        <div className="card" style={{ marginBottom: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <p style={{ margin: 0, fontSize: 14 }}>Регистрация открыта</p>
          <div style={{ display: 'flex', gap: 8 }}>
            {!isRegistered && me && (
              <button className="button-primary" onClick={() => api.draftTournamentRegister(id).then(load)}>Зарегистрироваться</button>
            )}
            {isRegistered && <span style={{ fontSize: 13, color: 'var(--accent)' }}>Вы зарегистрированы</span>}
            {me?.isAdmin && (
              <button className="button-ghost" onClick={() => api.draftTournamentStart(id).then(load)}>Начать турнир (админ)</button>
            )}
          </div>
        </div>
      )}

      {me?.isAdmin && (
        <div className="card" style={{ marginBottom: 20, border: '1px solid var(--danger)' }}>
          <p style={{ fontSize: 12, color: 'var(--danger)', letterSpacing: 1, margin: '0 0 10px' }}>ADMIN TOOLS</p>

          {t.status === 'registration' && t.registrations.length > 0 && (
            <div style={{ marginBottom: 12 }}>
              <p style={{ fontSize: 12, color: 'var(--text-secondary)', margin: '0 0 6px' }}>Участники</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                {t.registrations.map((r: any) => (
                  <div key={r.userId} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 13 }}>
                    <span>{playerName(r.userId)}</span>
                    <button
                      className="button-ghost"
                      style={{ fontSize: 11, padding: '3px 8px', color: 'var(--danger)' }}
                      onClick={() => {
                        if (confirm(`Удалить ${playerName(r.userId)} из турнира?`)) {
                          api.draftTournamentRemovePlayer(id, r.userId).then(load);
                        }
                      }}
                    >
                      Удалить
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {t.status !== 'completed' && t.status !== 'cancelled' && (
            <button
              className="button-ghost"
              style={{ fontSize: 12, marginRight: 8 }}
              onClick={() => { if (confirm('Отменить турнир?')) api.draftTournamentCancel(id).then(load); }}
            >
              Отменить турнир
            </button>
          )}
          <button
            className="button-ghost"
            style={{ fontSize: 12, color: 'var(--danger)' }}
            onClick={() => {
              if (confirm('Удалить турнир полностью? Это необратимо.')) {
                api.draftTournamentDelete(id).then(() => navigate('/draft-tournaments'));
              }
            }}
          >
            Удалить турнир
          </button>
        </div>
      )}

      {myMatch && me && (
        <div className="card" style={{ marginBottom: 24, padding: 20, border: '1px solid var(--primary)' }}>
          <p style={{ fontSize: 11, color: 'var(--primary)', letterSpacing: 1, margin: '0 0 8px' }}>МОЙ МАТЧ · РАУНД {myMatch.round}</p>
          <p style={{ fontSize: 18, fontWeight: 600, margin: '0 0 12px' }}>
            {playerName(myMatch.playerAId) ?? '?'} <span style={{ color: 'var(--text-muted)' }}>vs</span> {playerName(myMatch.playerBId) ?? '?'}
          </p>
          {myMatch.status === 'ready' ? (
            <button className="button-primary" onClick={startMyMatch}>Войти в драфт</button>
          ) : myMatch.status === 'in_progress' ? (
            <Link to={`/draft-trainer/${myMatch.draftSessionId}`} className="button-primary" style={{ textDecoration: 'none', display: 'inline-block' }}>
              Продолжить драфт
            </Link>
          ) : (
            <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: 0 }}>Ожидаем завершения предыдущего матча</p>
          )}
        </div>
      )}

      {t.matches.length > 0 && (
        <div style={{ display: 'flex', gap: 24, overflowX: 'auto', paddingBottom: 10 }}>
          {rounds.map((round) => (
            <div key={round} style={{ minWidth: 200, flexShrink: 0 }}>
              <p style={{ fontSize: 12, color: 'var(--text-secondary)', margin: '0 0 8px' }}>
                {round === rounds[rounds.length - 1] ? 'Финал' : `Раунд ${round}`}
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {t.matches.filter((m: any) => m.round === round).map((m: any) => (
                  <div key={m.id} className="card" style={{ padding: '8px 10px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, padding: '3px 0', color: m.winnerId === m.playerAId ? 'var(--accent)' : m.winnerId ? 'var(--text-muted)' : 'var(--text)' }}>
                      <span>{playerName(m.playerAId) ?? '—'}</span>
                      {m.winnerId === m.playerAId && <span>✓</span>}
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, padding: '3px 0', color: m.winnerId === m.playerBId ? 'var(--accent)' : m.winnerId ? 'var(--text-muted)' : 'var(--text)' }}>
                      <span>{playerName(m.playerBId) ?? '—'}</span>
                      {m.winnerId === m.playerBId && <span>✓</span>}
                    </div>
                    {me?.isAdmin && m.playerAId && m.playerBId && (
                      <div style={{ display: 'flex', gap: 4, marginTop: 6, paddingTop: 6, borderTop: '1px solid var(--border)' }}>
                        <button
                          className="button-ghost"
                          style={{ fontSize: 10, padding: '2px 6px', flex: 1 }}
                          onClick={() => {
                            if (confirm(`Назначить победителем ${playerName(m.playerAId)}?`)) {
                              api.draftTournamentForceResult(m.id, m.playerAId).then(load);
                            }
                          }}
                        >
                          Победил A
                        </button>
                        <button
                          className="button-ghost"
                          style={{ fontSize: 10, padding: '2px 6px', flex: 1 }}
                          onClick={() => {
                            if (confirm(`Назначить победителем ${playerName(m.playerBId)}?`)) {
                              api.draftTournamentForceResult(m.id, m.playerBId).then(load);
                            }
                          }}
                        >
                          Победил B
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {t.status === 'completed' && (
        <div className="card" style={{ marginTop: 20, textAlign: 'center', padding: 24, border: '1px solid var(--gold)' }}>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: '0 0 6px', letterSpacing: 1 }}>ТУРНИР ЗАВЕРШЁН</p>
          <p style={{ fontSize: 22, fontWeight: 700, margin: 0, color: 'var(--gold)' }}>
            🏆 {playerName(t.matches.find((m: any) => m.round === rounds[rounds.length - 1])?.winnerId) ?? '—'}
          </p>
        </div>
      )}
    </div>
  );
}
