import { Body, Controller, Delete, Get, Param, Post, Query, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { MusicService } from './music.service';
import { DeezerProviderService } from './deezer-provider.service';

@Controller('music')
export class MusicController {
  constructor(
    private readonly musicService: MusicService,
    private readonly deezer: DeezerProviderService,
  ) {}

  // Requires login like everything else on the site (global JwtAuthGuard
  // — see public.decorator.ts's own comment on why only the Steam auth
  // routes are ever actually public). No @UseGuards needed here since
  // that's already the default; caching (requirement 9) lives inside
  // MusicService.searchCached, keyed by the normalized query.
  @Get('search')
  search(@Query('q') q: string) {
    return this.musicService.searchCached(q);
  }

  @Get('artist/:id/top-tracks')
  artistTopTracks(@Param('id') id: string) {
    return this.deezer.getArtistTracks(id);
  }

  @Get('favorites')
  @UseGuards(JwtAuthGuard)
  list(@Req() req: any) {
    return this.musicService.listFavorites(req.user.sub);
  }

  @Post('favorites')
  @UseGuards(JwtAuthGuard)
  add(@Req() req: any, @Body() body: { providerTrackId: string; name: string; artist: string; imageUrl?: string }) {
    return this.musicService.addFavorite(req.user.sub, body);
  }

  @Delete('favorites/:providerTrackId')
  @UseGuards(JwtAuthGuard)
  remove(@Req() req: any, @Param('providerTrackId') providerTrackId: string) {
    return this.musicService.removeFavorite(req.user.sub, providerTrackId);
  }
}
