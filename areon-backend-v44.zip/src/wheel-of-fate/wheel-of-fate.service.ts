import { BadRequestException, ForbiddenException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { PrismaService } from '../prisma.service';
import { OpenDotaService } from '../opendota/opendota.service';
import { MonitoringService } from '../monitoring/monitoring.service';
import { RewardEngineService } from '../rewards/reward-engine.service';
import { buildWheelPrompt, validateConcepts, HeroFacts, ItemCatalogEntry, GeneratedConcept } from './wheel-prompt-builder';

const CONCEPTS_PER_HERO = 3;
// A challenge that's been checked this many times without finding a
// qualifying match expires rather than being checked forever — an
// abandoned challenge (player never actually played it) shouldn't sit
// in "СПАМ" state indefinitely.
const MAX_CHECK_ATTEMPTS = 96; // ~48h at one check per 30 minutes

@Injectable()
export class WheelOfFateService {
  private readonly logger = new Logger(WheelOfFateService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly openDota: OpenDotaService,
    private readonly monitoring: MonitoringService,
    private readonly rewardEngine: RewardEngineService,
  ) {}

  private async getConfig() {
    const existing = await this.prisma.wheelConfig.findUnique({ where: { id: 'singleton' } });
    if (existing) return existing;
    return this.prisma.wheelConfig.create({ data: { id: 'singleton' } });
  }

  /**
   * Server picks the hero and build; the client only ever receives the
   * already-decided result plus the id of the (persisted, READY)
   * challenge row it lives in. accept()/reroll() act on that id and
   * never take hero_id/build from the client — that's the actual
   * anti-tamper guarantee, not just "the UI doesn't have a way to send
   * a different hero_id."
   */
  async spin(userId: string) {
    const active = await this.prisma.wheelChallenge.findFirst({
      where: { userId, status: { in: ['ACCEPTED', 'SEARCHING_MATCH', 'CHECKING'] } },
    });
    if (active) {
      throw new BadRequestException('У вас уже есть активное испытание — сначала завершите или дождитесь его результата');
    }

    // An un-accepted READY spin from earlier just gets replaced, not
    // accumulated — the player never committed to it.
    await this.prisma.wheelChallenge.deleteMany({ where: { userId, status: 'READY' } });

    const heroCount = await this.prisma.hero.count();
    if (heroCount === 0) throw new BadRequestException('No heroes synced yet — run hero sync first');

    const heroes = await this.prisma.hero.findMany({ select: { id: true } });
    const hero = await this.prisma.hero.findUniqueOrThrow({
      where: { id: heroes[Math.floor(Math.random() * heroes.length)].id },
    });

    const concepts = await this.ensureConcepts(hero.id);
    const concept = concepts[Math.floor(Math.random() * concepts.length)];

    const challenge = await this.prisma.wheelChallenge.create({
      data: { userId, heroId: hero.id, buildConceptId: concept.id, status: 'READY' },
    });

    const items = await this.prisma.item.findMany({ where: { id: { in: concept.itemIds } } });
    const orderedItems = concept.itemIds.map((id) => items.find((i) => i.id === id)!);

    this.monitoring.log(userId, 'wheel_spin', '/wheel-of-fate', { heroId: hero.id }).catch(() => {});
    return {
      challengeId: challenge.id,
      hero,
      concept: { conceptName: concept.conceptName, reasoning: concept.reasoning },
      items: orderedItems,
    };
  }

  /** Confirms the READY challenge the player was shown — starts the "play a real match" clock. */
  async accept(userId: string, challengeId: string) {
    const challenge = await this.prisma.wheelChallenge.findUnique({ where: { id: challengeId } });
    if (!challenge) throw new NotFoundException('Challenge not found');
    if (challenge.userId !== userId) throw new ForbiddenException('Not your challenge');
    if (challenge.status !== 'READY') throw new BadRequestException(`Challenge is not in a ready state (currently ${challenge.status})`);

    return this.prisma.wheelChallenge.update({
      where: { id: challengeId },
      data: { status: 'ACCEPTED', acceptedAt: new Date() },
    });
  }

  /**
   * −rerollCost Shards, no rating change (requirement 11: reroll never
   * touches rating). The old challenge is marked REROLLED (kept for
   * history, requirement 16), not deleted.
   */
  async reroll(userId: string, challengeId: string) {
    const challenge = await this.prisma.wheelChallenge.findUnique({ where: { id: challengeId } });
    if (!challenge) throw new NotFoundException('Challenge not found');
    if (challenge.userId !== userId) throw new ForbiddenException('Not your challenge');
    if (!['READY', 'ACCEPTED'].includes(challenge.status)) {
      throw new BadRequestException(`Cannot reroll a challenge in status ${challenge.status}`);
    }

    const config = await this.getConfig();
    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    if (user.shardBalance < config.rerollCost) {
      throw new BadRequestException('Недостаточно Orion Plus для переброса');
    }

    const result = await this.prisma.$transaction(async (tx) => {
      const newBalance = user.shardBalance - config.rerollCost;
      await tx.user.update({ where: { id: userId }, data: { shardBalance: newBalance } });
      await tx.shardTransaction.create({
        data: { userId, amount: -config.rerollCost, type: 'WHEEL_REROLL', reason: 'Wheel of Fate — переброс', relatedUserTrialId: null, balanceAfter: newBalance },
      });
      await tx.wheelChallenge.update({ where: { id: challengeId }, data: { status: 'REROLLED', resolvedAt: new Date() } });
      return newBalance;
    });

    const spun = await this.spin(userId);
    return { ...spun, newBalance: result };
  }

  async getActive(userId: string) {
    const challenge = await this.prisma.wheelChallenge.findFirst({
      where: { userId, status: { in: ['READY', 'ACCEPTED', 'SEARCHING_MATCH', 'CHECKING'] } },
      orderBy: { createdAt: 'desc' },
    });
    return challenge ? this.serialize(challenge) : null;
  }

  async getHistory(userId: string) {
    const list = await this.prisma.wheelChallenge.findMany({
      where: { userId, status: { in: ['WON', 'LOST', 'REROLLED', 'EXPIRED'] } },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    return list.map((c) => this.serialize(c));
  }

  async getChallenge(userId: string, id: string) {
    const challenge = await this.prisma.wheelChallenge.findUnique({ where: { id } });
    if (!challenge) throw new NotFoundException('Challenge not found');
    if (challenge.userId !== userId) throw new ForbiddenException('Not your challenge');
    return this.serialize(challenge);
  }

  // Prisma's BigInt (matchId) doesn't survive NestJS's default JSON
  // serialization — same fix matches.service.ts already applies to
  // Match.matchId.
  private serialize(challenge: { matchId: bigint | null } & Record<string, any>) {
    return { ...challenge, matchId: challenge.matchId != null ? challenge.matchId.toString() : null };
  }

  // ============================================================================
  // BACKGROUND MATCH CHECKER — every 5 minutes, looks at every
  // in-flight challenge, pulls the player's recent matches from
  // OpenDota, and resolves the first one that qualifies. If OpenDota
  // errors or nothing qualifies yet, the challenge is left exactly as
  // it was (requirement 18/14: never guess, never penalize on an API
  // hiccup) and picked up again next run.
  // ============================================================================
  @Cron('*/5 * * * *')
  async checkActiveChallenges() {
    const inFlight = await this.prisma.wheelChallenge.findMany({
      where: { status: { in: ['ACCEPTED', 'SEARCHING_MATCH', 'CHECKING'] } },
      include: { user: true },
    });
    for (const challenge of inFlight) {
      try {
        await this.checkOne(challenge as any);
      } catch (e) {
        this.logger.warn(`Wheel challenge ${challenge.id} check failed: ${e instanceof Error ? e.message : String(e)}`);
      }
    }
  }

  private async checkOne(challenge: { id: string; userId: string; heroId: number; acceptedAt: Date | null; checkAttempts: number; user: { accountId32: number } }) {
    if (!challenge.acceptedAt) return;

    const recent = await this.openDota.getPlayerMatches(challenge.user.accountId32, 20);
    const usedMatchIds = new Set(
      (await this.prisma.wheelChallenge.findMany({ where: { matchId: { not: null } }, select: { matchId: true } })).map((c) => String(c.matchId)),
    );

    const candidate = recent.find(
      (m) =>
        m.hero_id === challenge.heroId &&
        m.start_time * 1000 > challenge.acceptedAt!.getTime() &&
        !usedMatchIds.has(String(m.match_id)),
    );

    const config = await this.getConfig();

    if (!candidate) {
      const attempts = challenge.checkAttempts + 1;
      if (attempts >= MAX_CHECK_ATTEMPTS) {
        await this.prisma.wheelChallenge.update({
          where: { id: challenge.id },
          data: { status: 'EXPIRED', resolvedAt: new Date(), failureReason: 'Подходящий матч не был сыгран за отведённое время' },
        });
        return;
      }
      await this.prisma.wheelChallenge.update({
        where: { id: challenge.id },
        data: { status: 'SEARCHING_MATCH', checkAttempts: attempts },
      });
      return;
    }

    // player_slot < 128 = Radiant. Matches the same convention used
    // throughout matches.service.ts.
    const won = candidate.player_slot < 128 ? candidate.radiant_win : !candidate.radiant_win;

    await this.prisma.$transaction(async (tx) => {
      const user = await tx.user.findUniqueOrThrow({ where: { id: challenge.userId } });
      const shardsAwarded = won ? config.winShards : config.lossShards;
      const ratingChange = won ? config.winRating : config.lossRating;
      const newBalance = user.shardBalance + shardsAwarded;
      const newRating = user.rating + ratingChange;

      await tx.user.update({ where: { id: challenge.userId }, data: { shardBalance: newBalance, rating: newRating } });
      await tx.shardTransaction.create({
        data: {
          userId: challenge.userId,
          amount: shardsAwarded,
          type: won ? 'WHEEL_WIN' : 'WHEEL_LOSS',
          reason: `Wheel of Fate — ${won ? 'победа' : 'поражение'} (матч ${candidate.match_id})`,
          balanceAfter: newBalance,
        },
      });
      await tx.wheelChallenge.update({
        where: { id: challenge.id },
        data: {
          status: won ? 'WON' : 'LOST',
          matchId: BigInt(candidate.match_id),
          resolvedAt: new Date(),
          shardsAwarded,
          ratingChange,
        },
      });
    });

    this.monitoring.log(challenge.userId, 'wheel_resolved', '/wheel-of-fate', { won, matchId: candidate.match_id }).catch(() => {});
    this.rewardEngine.grant({
      userId: challenge.userId, activityType: 'wheel', activityId: challenge.id,
      siteRatingDelta: won ? 10 : 1, reason: won ? 'Победа в Wheel of Fate' : 'Участие в Wheel of Fate',
    }).catch(() => {});
  }

  private async ensureConcepts(heroId: number) {
    const existing = await this.prisma.heroBuildConcept.findMany({ where: { heroId } });
    if (existing.length > 0) return existing;
    return this.generateConcepts(heroId);
  }

  /**
   * The only place this feature calls an LLM — grounded in real
   * Hero/Item facts, response validated against the real Item catalog
   * before a single row is persisted. Zero usable concepts after
   * validation throws rather than silently persisting nothing — same
   * "fail loud" principle as PatchSyncService refusing to sync from an
   * empty OpenDota response.
   */
  private async generateConcepts(heroId: number) {
    const hero = await this.prisma.hero.findUniqueOrThrow({ where: { id: heroId } });
    const catalog: ItemCatalogEntry[] = await this.prisma.item.findMany({ select: { id: true, name: true, dname: true } });
    if (catalog.length === 0) throw new BadRequestException('No items synced yet — run item sync first');

    const heroFacts: HeroFacts = {
      id: hero.id,
      localizedName: hero.localizedName,
      primaryAttr: hero.primaryAttr,
      roles: hero.roles,
      popularItems: (hero.itemBuildsJson as any)?.items?.map((i: any) => ({ itemName: String(i.itemId), winrate: i.winrate })) ?? null,
    };

    const { system, user } = buildWheelPrompt(heroFacts, catalog);
    const raw = await this.callClaude(system, user);

    const validated = validateConcepts(raw, catalog);
    if (validated.length === 0) {
      throw new Error(`AI generated zero valid build concepts for hero ${hero.localizedName} — every candidate referenced an invalid item or was malformed`);
    }

    const created = [];
    for (const c of validated.slice(0, CONCEPTS_PER_HERO)) {
      created.push(
        await this.prisma.heroBuildConcept.create({
          data: { heroId, conceptName: c.conceptName, itemIds: c.itemIds, reasoning: c.reasoning },
        }),
      );
    }
    this.logger.log(`Generated ${created.length}/${validated.length} valid build concepts for ${hero.localizedName}`);
    return created;
  }

  /**
   * Same "don't make the first real user eat the slow path" fix as
   * counter-pick and ability sync earlier — without this, whichever
   * hero the wheel happened to land on FIRST (for anyone, sitewide)
   * paid for a live multi-second AI call during their own spin, which
   * looked exactly like the wheel hanging. Throttled sequential loop,
   * same pattern as syncAllMatchups, so this can run from the admin
   * panel without hammering the AI provider's rate limit.
   */
  async pregenerateAllConcepts() {
    const heroes = await this.prisma.hero.findMany({ select: { id: true } });
    let generated = 0;
    let skipped = 0;
    for (const h of heroes) {
      const existing = await this.prisma.heroBuildConcept.count({ where: { heroId: h.id } });
      if (existing > 0) {
        skipped += 1;
        continue;
      }
      try {
        await this.generateConcepts(h.id);
        generated += 1;
      } catch (e: any) {
        this.logger.warn(`Failed to pregenerate concepts for hero=${h.id}: ${e instanceof Error ? e.message : String(e)}`);
      }
      await new Promise((r) => setTimeout(r, 400));
    }
    this.logger.log(`Pregenerated concepts for ${generated} heroes (${skipped} already had them)`);
    return { generated, skipped };
  }

  /**
   * NOT executable in this sandbox — no network access to actually
   * call the Anthropic API here. Reviewed, not run, same honesty flag
   * as AI Coach's identical call pattern (deliberately reuses that
   * same structure, not a second copy of API-calling logic).
   */
  /**
   * Same provider swap as AI Coach — Google Gemini's free tier instead
   * of Anthropic's paid API. responseMimeType: 'application/json'
   * makes Gemini return JSON directly (its own structured-output
   * mode), same as the JSON we were relying on Claude to produce from
   * plain-text instructions before.
   */
  private async callClaude(system: string, user: string): Promise<GeneratedConcept[]> {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new BadRequestException('GEMINI_API_KEY is not set — Wheel of Fate needs it to generate builds. See FIRST_LAUNCH.md.');
    }
    const model = process.env.GEMINI_MODEL ?? 'gemini-3.6-flash';
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
    const body = JSON.stringify({
      systemInstruction: { parts: [{ text: system }] },
      contents: [{ role: 'user', parts: [{ text: user }] }],
      generationConfig: { maxOutputTokens: 2000, responseMimeType: 'application/json' },
    });

    // Gemini's free tier returns a plain 503 "high demand, try again
    // later" fairly often — genuinely transient, not a real failure,
    // so one short retry is worth it before surfacing an error to the
    // player over what's usually a momentary blip.
    let lastError: Error | null = null;
    for (let attempt = 0; attempt < 2; attempt++) {
      if (attempt > 0) await new Promise((r) => setTimeout(r, 2000));
      const res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body });
      if (res.ok) {
        const data = await res.json();
        const text = data.candidates?.[0]?.content?.parts?.map((p: any) => p.text ?? '').join('') ?? '{}';
        return JSON.parse(text.trim()).concepts ?? [];
      }
      lastError = new Error(`Gemini API call failed: ${res.status} ${await res.text()}`);
      if (res.status !== 503) break; // only retry the "temporarily overloaded" case
    }
    throw lastError;
  }
}
