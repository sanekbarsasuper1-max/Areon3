import { useState } from 'react';
import { Hero } from '../api';

/**
 * A tiny transparent-gray placeholder — swapped in via onError below
 * so a dead hero-icon URL degrades to a neutral box instead of the
 * browser's broken-image icon, without needing every call site to
 * restructure its layout around a stateful fallback component.
 */
export const HERO_ICON_FALLBACK =
  'data:image/svg+xml;utf8,' + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" width="160" height="90"><rect width="160" height="90" fill="#3a3a48"/><rect x="1" y="1" width="158" height="88" fill="none" stroke="#5a5a6a" stroke-width="2"/><text x="80" y="52" font-family="sans-serif" font-size="34" fill="#8a8a9a" text-anchor="middle">?</text></svg>',
  );

/**
 * Spread onto any existing hero `<img>` tag: `<img src={...} {...heroImgErrorProps(hero)} />`.
 * Logs once (browsers keep re-firing onError once the src is
 * swapped, unless the fallback itself never errors — an inline SVG
 * data URI never does, so this can't loop) and swaps to a neutral
 * placeholder instead of leaving the browser's broken-image icon or,
 * worse, a blank gap that looks like the surrounding layout is
 * broken rather than just one icon.
 */
export function heroImgErrorProps(hero?: { localizedName?: string; id?: number; iconUrl?: string }) {
  return {
    onError: (e: React.SyntheticEvent<HTMLImageElement>) => {
      const img = e.currentTarget;
      if (img.src === HERO_ICON_FALLBACK) return; // already showing the fallback — don't re-log/re-loop
      console.warn(`[HeroImage] Failed to load icon for ${hero?.localizedName ?? 'hero #' + (hero?.id ?? '?')}: ${hero?.iconUrl ?? img.src}`);
      img.src = HERO_ICON_FALLBACK;
    },
  };
}

/**
 * The single place every hero icon in Areon renders through —
 * Draft Trainer (picks, bans, mini-map, position assignment), Meta,
 * Profile, public profiles, matches, Wheel of Fate, admin panel all
 * used to each write their own `<img src={hero.iconUrl}>` with no
 * shared fallback or error handling, which is exactly how "icons
 * just don't load, and there's no way to tell why" happens — a CDN
 * hiccup or a hero missing from the synced table looked identical to
 * a real bug because nothing distinguished them visually or in the
 * console. Used where a call site wants the whole thing (fixed
 * sizing) rather than just wiring heroImgErrorProps onto its own
 * `<img>`.
 *
 * `hero` may be undefined (heroesById[id] lookups return that when
 * the local hero table hasn't synced that id yet) — that's the most
 * common real cause of "icons don't load" and gets a distinct visual
 * (dashed outline + "?") from an image that loaded-then-failed
 * (solid outline + hero initial), so the difference is diagnosable
 * from the screenshot alone, not just from devtools.
 */
export function HeroImage({
  hero, heroId, size = 56, rounded = 4, title,
}: {
  hero: Hero | undefined;
  heroId?: number;
  size?: number | string;
  rounded?: number;
  title?: string;
}) {
  const [failed, setFailed] = useState(false);

  const style: React.CSSProperties = {
    width: size, aspectRatio: '16/9', objectFit: 'cover', borderRadius: rounded,
    display: 'block', background: '#1a1a1a',
  };

  if (!hero) {
    // The hero table itself has no row for this id — a sync gap, not
    // a broken image URL. Distinct dashed style so this is
    // recognizable at a glance instead of looking like the same
    // failure as a dead CDN link.
    return (
      <div
        title={`Hero #${heroId ?? '?'} not synced`}
        style={{ ...style, border: '1px dashed var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)', fontSize: 11 }}
      >
        ?
      </div>
    );
  }

  if (failed || !hero.iconUrl) {
    return (
      <div
        title={hero.localizedName}
        style={{ ...style, border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)', fontSize: 11, fontWeight: 600 }}
      >
        {hero.localizedName?.slice(0, 2).toUpperCase() ?? '??'}
      </div>
    );
  }

  return (
    <img
      src={hero.iconUrl}
      alt={hero.localizedName}
      title={title ?? hero.localizedName}
      style={style}
      onError={() => {
        // Logged once per mount, not on every re-render — an <img>
        // that fails keeps re-firing onError if the src is
        // reassigned, but `failed` being true short-circuits this
        // whole branch on the next render so it can't loop.
        console.warn(`[HeroImage] Failed to load icon for ${hero.localizedName} (#${hero.id}): ${hero.iconUrl}`);
        setFailed(true);
      }}
    />
  );
}
