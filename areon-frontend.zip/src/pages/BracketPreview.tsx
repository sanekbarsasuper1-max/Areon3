import { useState } from 'react';
import { Link } from 'react-router-dom';

/**
 * A pure client-side sandbox — no API calls anywhere in this file, no
 * Prisma models touched, nothing saved. That's a deliberate design
 * choice, not a corner cut: the requirement was to let one person
 * fully exercise every bracket shape and see it resolve, without any
 * chance of a "test" team, match, or result ever reaching real
 * ratings, stats, profiles, or tournament history — the safest way to
 * guarantee that is for the data to never exist anywhere but this
 * component's own React state, which vanishes on refresh.
 */

const FORMAT_INFO: Record<string, { label: string; description: string }> = {
  single_elimination: { label: 'Одиночное выбывание', description: 'Проиграл — вылетел из турнира.' },
  double_elimination: { label: 'Двойное выбывание', description: 'После первого поражения участник переходит в нижнюю сетку и получает второй шанс. Второе поражение — вылет.' },
  round_robin: { label: 'Круговой турнир', description: 'Каждый участник играет с каждым. Победитель определяется по числу побед.' },
  swiss: { label: 'Швейцарская система', description: 'Несколько раундов; соперники каждый раз подбираются по текущему результату.' },
  group_stage: { label: 'Группы + плей-офф', description: 'Сначала круговой этап внутри групп, затем лучшие выходят в сетку на вылет.' },
};

const COUNT_OPTIONS = [4, 8, 16, 32, 64];

interface PreviewMatch {
  id: string;
  bracket: string; // 'winners' | 'losers' | 'grand_final' | 'round_robin' | 'swiss' | 'group_stage'
  round: number;
  position: number;
  groupIndex?: number;
  a: string | null;
  b: string | null;
  winner: string | null;
}

function makeNames(n: number): string[] {
  return Array.from({ length: n }, (_, i) => `Player ${String(i + 1).padStart(2, '0')}`);
}

function nextPow2(n: number) {
  let p = 1;
  while (p < n) p *= 2;
  return p;
}

/** Single elimination, padded to the next power of two with byes that auto-advance immediately. */
function genSingleElim(names: string[]): PreviewMatch[] {
  const size = nextPow2(names.length);
  const slots: (string | null)[] = [...names, ...Array(size - names.length).fill(null)];
  const matches: PreviewMatch[] = [];
  let round = 1;
  let current = slots;
  while (current.length > 1) {
    const next: (string | null)[] = [];
    for (let i = 0; i < current.length / 2; i++) {
      const a = current[i * 2];
      const b = current[i * 2 + 1];
      const isBye = a == null || b == null;
      const winner = isBye ? (a ?? b) : null;
      matches.push({ id: `w-${round}-${i}`, bracket: 'winners', round, position: i, a, b, winner });
      next.push(winner);
    }
    current = round === 1 ? next : Array(next.length).fill(null);
    round += 1;
  }
  return matches;
}

/** Round robin via the standard circle method — same algorithm as the real backend generator, just in plain JS with no DB writes. */
function genRoundRobin(names: string[]): PreviewMatch[] {
  const teams = names.length % 2 === 0 ? [...names] : [...names, null];
  const n = teams.length;
  const matches: PreviewMatch[] = [];
  for (let round = 0; round < n - 1; round++) {
    for (let i = 0; i < n / 2; i++) {
      const a = teams[i];
      const b = teams[n - 1 - i];
      if (a != null && b != null) {
        matches.push({ id: `rr-${round}-${i}`, bracket: 'round_robin', round: round + 1, position: i, a, b, winner: null });
      }
    }
    teams.splice(1, 0, teams.pop()!);
  }
  return matches;
}

export function BracketPreview() {
  const [format, setFormat] = useState<keyof typeof FORMAT_INFO>('single_elimination');
  const [count, setCount] = useState(8);
  const [matches, setMatches] = useState<PreviewMatch[] | null>(null);

  function fillAndGenerate() {
    const names = makeNames(count);
    if (format === 'double_elimination') {
      // A full double-elimination simulator (winners → losers routing,
      // grand final, bracket reset) is a lot of extra branching for a
      // sandbox tool — shown here as the same real static structure
      // the actual tournament would generate (so the shape is
      // accurate), without click-to-advance simulation for this one
      // format specifically.
      setMatches(genSingleElim(names).map((m) => ({ ...m, bracket: 'winners' })));
    } else if (format === 'round_robin' || format === 'swiss' || format === 'group_stage') {
      // Swiss and group-stage pairing both depend on standings that
      // only exist after real results — for a static preview, round
      // robin's fixed schedule is the closest honest stand-in for
      // "what does a multi-round, non-elimination bracket look like",
      // without pretending to simulate pairing logic this tool
      // doesn't actually run.
      setMatches(genRoundRobin(names));
    } else {
      setMatches(genSingleElim(names));
    }
  }

  function clear() {
    setMatches(null);
  }

  function reportWinner(matchId: string, winnerName: string) {
    if (!matches) return;
    const updated = matches.map((m) => (m.id === matchId ? { ...m, winner: winnerName } : m));
    const match = updated.find((m) => m.id === matchId)!;

    if (match.bracket === 'winners') {
      const nextRound = match.round + 1;
      const nextPos = Math.floor(match.position / 2);
      const nextMatch = updated.find((m) => m.bracket === 'winners' && m.round === nextRound && m.position === nextPos);
      if (nextMatch) {
        const slot: 'a' | 'b' = match.position % 2 === 0 ? 'a' : 'b';
        nextMatch[slot] = winnerName;
      }
    }
    setMatches(updated);
  }

  const rounds = matches ? Array.from(new Set(matches.map((m) => m.round))).sort((a, b) => a - b) : [];
  const isElim = format === 'single_elimination' || format === 'double_elimination';
  const champion = isElim && matches ? matches.find((m) => m.round === Math.max(...rounds) && m.winner)?.winner : null;

  const standings = !isElim && matches
    ? Array.from(new Set(matches.flatMap((m) => [m.a, m.b].filter((x): x is string => !!x))))
        .map((name) => ({
          name,
          wins: matches.filter((m) => m.winner === name).length,
          played: matches.filter((m) => (m.a === name || m.b === name) && m.winner != null).length,
        }))
        .sort((a, b) => b.wins - a.wins)
    : [];

  return (
    <div style={{ maxWidth: 1200, margin: '0 auto', padding: '40px 48px 100px' }}>
      <Link to="/tournaments" className="button-ghost" style={{ textDecoration: 'none' }}>← Турниры</Link>
      <p style={{ fontSize: 21, fontWeight: 600, margin: '16px 0 4px' }}>Предпросмотр сетки</p>
      <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: '0 0 20px' }}>
        Демонстрационный режим — тестовые участники и результаты нигде не сохраняются, реальные турниры и статистика не затрагиваются.
      </p>

      <div className="card" style={{ padding: 18, marginBottom: 24 }}>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 10 }}>
          <select
            value={format}
            onChange={(e) => { setFormat(e.target.value as any); setMatches(null); }}
            style={{ background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: 8, padding: '8px 12px', fontSize: 14, color: 'var(--text)' }}
          >
            {Object.entries(FORMAT_INFO).map(([key, info]) => (
              <option key={key} value={key}>{info.label}</option>
            ))}
          </select>
          <select
            value={count}
            onChange={(e) => { setCount(Number(e.target.value)); setMatches(null); }}
            style={{ background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: 8, padding: '8px 12px', fontSize: 14, color: 'var(--text)' }}
          >
            {COUNT_OPTIONS.map((n) => (
              <option key={n} value={n}>{n} участников</option>
            ))}
          </select>
          <button className="button-primary" onClick={fillAndGenerate}>Заполнить тестовыми участниками</button>
          {matches && <button className="button-ghost" onClick={clear}>Очистить тестовых участников</button>}
        </div>
        <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: 0 }}>{FORMAT_INFO[format].description}</p>
        {format === 'double_elimination' && (
          <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '6px 0 0' }}>
            В этом инструменте для двойного выбывания показывается только структура — без симуляции результатов по клику.
          </p>
        )}
        {(format === 'swiss' || format === 'group_stage') && (
          <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '6px 0 0' }}>
            Показан круговой этап — реальные Swiss/групповые пары формируются по текущему результату, который в этой песочнице не подставляется.
          </p>
        )}
      </div>

      {champion && (
        <div className="card" style={{ padding: 18, marginBottom: 24, textAlign: 'center', border: '1px solid var(--accent)' }}>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '0 0 4px', letterSpacing: 1 }}>ПОБЕДИТЕЛЬ ДЕМО-СЕТКИ</p>
          <p style={{ fontSize: 20, fontWeight: 700, color: 'var(--accent)', margin: 0 }}>{champion}</p>
        </div>
      )}

      {standings.length > 0 && (
        <div className="card" style={{ padding: 0, overflow: 'hidden', marginBottom: 24 }}>
          {standings.map((s, i) => (
            <div key={s.name} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 14px', borderTop: i > 0 ? '1px solid var(--border)' : undefined, fontSize: 14 }}>
              <span>{i + 1}. {s.name}</span>
              <span style={{ color: 'var(--text-secondary)' }}>{s.wins} побед из {s.played}</span>
            </div>
          ))}
        </div>
      )}

      {matches && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18, overflowX: 'auto' }}>
          {rounds.map((round) => (
            <div key={round}>
              <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: '0 0 6px' }}>Раунд {round}</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {matches.filter((m) => m.round === round).map((m) => (
                  <div key={m.id} className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 16px', minWidth: 420 }}>
                    <span style={{ fontSize: 14, color: m.winner === m.a ? 'var(--accent)' : undefined, fontWeight: m.winner === m.a ? 600 : 400 }}>
                      {m.a ?? 'TBD'}
                    </span>
                    <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{m.b ? 'vs' : '(бай)'}</span>
                    <span style={{ fontSize: 14, color: m.winner === m.b ? 'var(--accent)' : undefined, fontWeight: m.winner === m.b ? 600 : 400 }}>
                      {m.b ?? 'TBD'}
                    </span>
                    {!m.winner && m.a && m.b && (
                      <div style={{ display: 'flex', gap: 6, marginLeft: 12 }}>
                        <button className="button-ghost" onClick={() => reportWinner(m.id, m.a!)}>Победил {m.a}</button>
                        <button className="button-ghost" onClick={() => reportWinner(m.id, m.b!)}>Победил {m.b}</button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
