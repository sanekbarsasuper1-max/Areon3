import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, Hero, WheelSpinResult, WheelChallenge } from '../api';
import { useAudio } from '../audio/AudioContext';
import { HERO_ICON_FALLBACK } from '../components/HeroImage';

// DESIGN NOTE: the spec describes a literal circular wheel with heroes
// on sectors. With 120+ heroes in the roster, a real pie-slice wheel
// would make each sector illegible — a handful of degrees per hero.
// This implements the same "spin, heroes flick past rapidly, then
// decelerate and land on one" experience as a horizontal slot-machine
// reel instead, the standard readable way this kind of UI is built for
// a large item pool. Framed as "THE WHEEL" throughout the UI text,
// since that's the feature's identity, not its literal geometry.
const REEL_ITEM_WIDTH = 96;
const REEL_LENGTH = 40;
const WINNER_POSITION = 34;

export function WheelOfFatePage() {
  const [heroes, setHeroes] = useState<Hero[]>([]);
  const [heroesById, setHeroesById] = useState<Record<number, Hero>>({});
  const [spinning, setSpinning] = useState(false);
  const [waitingOnServer, setWaitingOnServer] = useState(false);
  const [reel, setReel] = useState<Hero[] | null>(null);
  const [result, setResult] = useState<WheelSpinResult | null>(null);
  const [active, setActive] = useState<WheelChallenge | null>(null);
  const [loadingActive, setLoadingActive] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const pendingResultRef = useRef<WheelSpinResult | null>(null);
  const { playSFX } = useAudio();

  useEffect(() => {
    api.heroes().then((hs) => {
      setHeroes(hs);
      setHeroesById(Object.fromEntries(hs.map((h) => [h.id, h])));
    });
    refreshActive();
  }, []);

  async function refreshActive() {
    setLoadingActive(true);
    try {
      const a = await api.wheelActive();
      setActive(a);
    } finally {
      setLoadingActive(false);
    }
  }

  // Poll while a challenge is out looking for a match — the
  // background checker on the server runs every 5 minutes, so this
  // just needs to notice when it's updated something, not to be
  // instant.
  useEffect(() => {
    if (!active || !['SEARCHING_MATCH', 'CHECKING', 'ACCEPTED'].includes(active.status)) return;
    const interval = setInterval(refreshActive, 30_000);
    return () => clearInterval(interval);
  }, [active?.status]);

  async function spin() {
    if (spinning || heroes.length === 0) return;
    setError(null);
    setResult(null);
    setSpinning(true);
    playSFX('wheel_spin_start');

    // Only shown if the server actually takes a while (see
    // pregenerateAllConcepts's own comment on why the very first spin
    // for a given hero can be slow) — never flashes on the normal
    // fast path, so it doesn't misleadingly claim "AI is working"
    // when the response was already cached.
    const slowTimer = setTimeout(() => setWaitingOnServer(true), 1200);

    let spinResult: WheelSpinResult;
    try {
      spinResult = await api.wheelSpin();
    } catch (e: any) {
      clearTimeout(slowTimer);
      setWaitingOnServer(false);
      setError(e?.message && e.message !== 'unauthenticated' ? e.message : 'Не удалось раскрутить колесо — попробуйте ещё раз через минуту.');
      setSpinning(false);
      return;
    }
    clearTimeout(slowTimer);
    setWaitingOnServer(false);

    const filler = Array.from({ length: REEL_LENGTH }, () => heroes[Math.floor(Math.random() * heroes.length)]);
    filler[WINNER_POSITION] = spinResult.hero;

    // Reset the track instantly (no transition) BEFORE swapping in the
    // new 40-item reel — done here, synchronously, rather than after
    // setReel, so the reset itself never races the DOM update.
    if (trackRef.current) {
      trackRef.current.style.transition = 'none';
      trackRef.current.style.transform = 'translateX(0)';
    }
    pendingResultRef.current = spinResult;
    setReel(filler);
  }

  // The actual animation start — deliberately in an effect keyed on
  // `reel`, not inline inside spin() right after setReel(). setState
  // is asynchronous; mutating trackRef.current in the same synchronous
  // block as setReel() was operating on the DOM as it existed BEFORE
  // React committed the new 40-item reel (still showing the old
  // 10-item preview on a person's very first spin) — the real cause
  // of the animation translating to the wrong place entirely. This
  // effect only runs after React has actually painted the new reel,
  // so the transform below is guaranteed to act on real content.
  useEffect(() => {
    if (!reel || !pendingResultRef.current) return;
    const track = trackRef.current;
    if (!track) return;
    const spinResult = pendingResultRef.current;

    // Force a reflow so the browser registers the "transition: none"
    // reset above before the transitioned transform is applied —
    // otherwise the two style writes can get coalesced into one paint
    // and the deceleration never renders.
    void track.offsetHeight;
    track.style.transition = 'transform 3.6s cubic-bezier(0.12, 0.85, 0.15, 1)';
    track.style.transform = `translateX(-${WINNER_POSITION * REEL_ITEM_WIDTH}px)`;

    const timer = setTimeout(() => {
      setSpinning(false);
      setResult(spinResult);
      pendingResultRef.current = null;
      playSFX('wheel_result');
    }, 3700);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reel]);

  function spinAgain() {
    setResult(null);
    setReel(null);
    spin();
  }

  async function acceptFate() {
    if (!result) return;
    try {
      await api.wheelAccept(result.challengeId);
      setResult(null);
      await refreshActive();
    } catch {
      setError('Не удалось принять испытание — попробуйте ещё раз.');
    }
  }

  async function rerollActive() {
    if (!active) return;
    try {
      const spinResult = await api.wheelReroll(active.id);
      setActive(null);
      setResult(spinResult);
    } catch {
      setError('Не удалось сделать переброс — проверьте баланс Orion Plus.');
    }
  }

  if (loadingActive) {
    return (
      <div style={{ minHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, color: 'var(--text-secondary)' }}>
        Загрузка…
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 1400, margin: '0 auto', padding: '40px 48px 100px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
        <div>
          <p style={{ fontSize: 21, fontWeight: 500, margin: 0 }}>WHEEL OF FATE</p>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: '4px 0 0' }}>Случайный герой — и полноценная сборка под него</p>
        </div>
        <Link to="/trials" className="button-ghost" style={{ textDecoration: 'none', fontSize: 13 }}>К испытаниям</Link>
      </div>

      {/* ---------- Active challenge: waiting for / checking a match ---------- */}
      {active && ['ACCEPTED', 'SEARCHING_MATCH', 'CHECKING'].includes(active.status) && (
        <ActiveChallengeCard challenge={active} hero={heroesById[active.heroId]} onReroll={rerollActive} />
      )}

      {/* ---------- Resolved challenge: WON / LOST / EXPIRED ---------- */}
      {active && ['WON', 'LOST', 'EXPIRED'].includes(active.status) && (
        <ResolvedChallengeCard challenge={active} hero={heroesById[active.heroId]} onContinue={() => { setActive(null); }} />
      )}

      {/* ---------- No active challenge: the reel + spin button ---------- */}
      {!active && (
        <>
          <div
            style={{
              position: 'relative',
              height: 96,
              overflow: 'hidden',
              borderRadius: 10,
              background: 'linear-gradient(180deg, #0d0f10, #08090a)',
              border: '0.5px solid var(--border)',
              marginBottom: 20,
            }}
          >
            <div style={{ position: 'absolute', left: '50%', top: 0, bottom: 0, width: 2, background: '#C9A227', zIndex: 2, transform: 'translateX(-1px)' }} />
            <div style={{ position: 'absolute', inset: 0, boxShadow: 'inset 0 0 24px 8px #08090a', zIndex: 1, pointerEvents: 'none' }} />

            <div ref={trackRef} style={{ display: 'flex', position: 'absolute', left: `calc(50% - ${REEL_ITEM_WIDTH / 2}px)`, top: 0 }}>
              {(reel ?? heroes.slice(0, 10)).map((h, i) => (
                <div key={i} style={{ width: REEL_ITEM_WIDTH, height: 96, flexShrink: 0, padding: 4 }}>
                  <img src={h.iconUrl} onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = HERO_ICON_FALLBACK; }} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 6 }} />
                </div>
              ))}
            </div>
          </div>

          {!result && (
            <button className="button-primary" onClick={spin} disabled={spinning || heroes.length === 0} style={{ width: '100%', marginBottom: 8 }}>
              {waitingOnServer ? 'ГОТОВИМ ПРЕДЛОЖЕНИЕ…' : spinning ? 'ВРАЩЕНИЕ…' : 'SPIN THE WHEEL'}
            </button>
          )}
          {waitingOnServer && (
            <p style={{ fontSize: 13, color: 'var(--text-muted)', textAlign: 'center', margin: '0 0 16px' }}>
              Для этого героя билд ещё ни разу не собирался — ИИ готовит его прямо сейчас, это может занять до 10-15 секунд.
            </p>
          )}
          {error && <p style={{ fontSize: 14, color: 'var(--danger)', marginBottom: 16 }}>{error}</p>}

          {result && (
            <div>
              <div className="card" style={{ textAlign: 'center', padding: 24, marginBottom: 16, background: 'linear-gradient(180deg, rgba(124,111,240,0.10), transparent)', border: '1px solid var(--primary)' }}>
                <p style={{ fontSize: 12, letterSpacing: 2, color: 'var(--primary)', margin: '0 0 8px' }}>YOUR FATE</p>
                <img src={result.hero.iconUrl} onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = HERO_ICON_FALLBACK; }} alt="" style={{ width: 160, aspectRatio: '16/9', objectFit: 'cover', borderRadius: 10, marginBottom: 10 }} />
                <p style={{ fontSize: 24, fontWeight: 600, margin: '0 0 4px' }}>{result.hero.localizedName.toUpperCase()}</p>
                <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: 0, textTransform: 'uppercase', letterSpacing: 1 }}>{result.hero.primaryAttr}</p>
              </div>

              <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: '0 0 8px', letterSpacing: 1 }}>INVENTORY — {result.concept.conceptName.toUpperCase()}</p>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 6, marginBottom: 16 }}>
                {result.items.map((item) => (
                  <div key={item.id} title={item.dname} style={{ aspectRatio: '1', background: '#111315', borderRadius: 6, border: '0.5px solid var(--border)', padding: 4, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <img src={item.iconUrl} onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = HERO_ICON_FALLBACK; }} alt={item.dname} style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
                  </div>
                ))}
              </div>

              <div className="card" style={{ marginBottom: 20 }}>
                <p style={{ fontSize: 13, color: 'var(--primary)', margin: '0 0 8px', letterSpacing: 1 }}>WHY THIS BUILD?</p>
                <p style={{ fontSize: 15, lineHeight: 1.6, margin: 0, whiteSpace: 'pre-wrap' }}>{result.concept.reasoning}</p>
              </div>

              <div style={{ display: 'flex', gap: 8 }}>
                <button className="button-primary" style={{ flex: 1 }} onClick={acceptFate}>ПРИНЯТЬ ИСПЫТАНИЕ</button>
                <button className="button-ghost" style={{ flex: 1 }} onClick={spinAgain}>SPIN AGAIN</button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function ActiveChallengeCard({ challenge, hero, onReroll }: { challenge: WheelChallenge; hero: Hero | undefined; onReroll: () => void }) {
  const statusText: Record<string, string> = {
    ACCEPTED: 'Испытание активно — ожидаем ваш матч',
    SEARCHING_MATCH: 'Ищем подходящий сыгранный матч…',
    CHECKING: 'Проверка матча…',
  };
  return (
    <div className="card" style={{ textAlign: 'center', padding: 28, marginBottom: 16 }}>
      {hero && <img src={hero.iconUrl} onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = HERO_ICON_FALLBACK; }} alt="" style={{ width: 140, aspectRatio: '16/9', objectFit: 'cover', borderRadius: 10, marginBottom: 12 }} />}
      <p style={{ fontSize: 20, fontWeight: 600, margin: '0 0 6px' }}>{hero?.localizedName ?? `Герой #${challenge.heroId}`}</p>
      <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: '0 0 16px' }}>{statusText[challenge.status] ?? challenge.status}</p>
      <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: '0 0 16px' }}>
        Сыграйте матч на этом герое — Areon сам найдёт его и проверит результат в течение нескольких минут после завершения.
      </p>
      <button className="button-ghost" onClick={onReroll}>ПЕРЕБРОС — 200 Orion Plus</button>
    </div>
  );
}

function ResolvedChallengeCard({ challenge, hero, onContinue }: { challenge: WheelChallenge; hero: Hero | undefined; onContinue: () => void }) {
  const won = challenge.status === 'WON';
  const expired = challenge.status === 'EXPIRED';
  return (
    <div
      className="card"
      style={{
        textAlign: 'center', padding: 28, marginBottom: 16,
        border: `1px solid ${expired ? 'var(--border)' : won ? 'var(--accent)' : 'var(--danger)'}`,
      }}
    >
      {hero && <img src={hero.iconUrl} onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = HERO_ICON_FALLBACK; }} alt="" style={{ width: 140, aspectRatio: '16/9', objectFit: 'cover', borderRadius: 10, marginBottom: 12 }} />}
      <p style={{ fontSize: 28, fontWeight: 700, margin: '0 0 8px', color: expired ? 'var(--text-secondary)' : won ? 'var(--accent)' : 'var(--danger)' }}>
        {expired ? 'ИСПЫТАНИЕ ПРОСРОЧЕНО' : won ? 'ПОБЕДА' : 'ПОРАЖЕНИЕ'}
      </p>
      {!expired && (
        <p style={{ fontSize: 16, margin: '0 0 16px' }}>
          {challenge.shardsAwarded! > 0 ? '+' : ''}{challenge.shardsAwarded} Orion Plus ·{' '}
          {challenge.ratingChange! > 0 ? '+' : ''}{challenge.ratingChange} рейтинга
        </p>
      )}
      {expired && challenge.failureReason && (
        <p style={{ fontSize: 14, color: 'var(--text-muted)', margin: '0 0 16px' }}>{challenge.failureReason}</p>
      )}
      <button className="button-primary" onClick={onContinue}>КРУТИТЬ СНОВА</button>
    </div>
  );
}
