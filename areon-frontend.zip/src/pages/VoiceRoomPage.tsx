import { useEffect, useRef, useState } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { Room, RoomEvent, RemoteParticipant, LocalParticipant, Track } from 'livekit-client';
import { api } from '../api';

interface ParticipantInfo {
  identity: string;
  name: string;
  avatarFull: string | null;
  isLocal: boolean;
  isSpeaking: boolean;
  isMuted: boolean;
}

export function VoiceRoomPage() {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const [connecting, setConnecting] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [roomLabel, setRoomLabel] = useState('');
  const [hostedBy, setHostedBy] = useState('');
  const [participants, setParticipants] = useState<ParticipantInfo[]>([]);
  const [muted, setMuted] = useState(false);
  const [deafened, setDeafened] = useState(false);
  const [micDenied, setMicDenied] = useState(false);

  const roomRef = useRef<Room | null>(null);

  function snapshotParticipants(room: Room) {
    const list: ParticipantInfo[] = [];
    const toInfo = (p: LocalParticipant | RemoteParticipant, isLocal: boolean): ParticipantInfo => {
      let avatarFull: string | null = null;
      try {
        avatarFull = p.metadata ? JSON.parse(p.metadata).avatarFull ?? null : null;
      } catch { /* metadata not JSON — ignore */ }
      return {
        identity: p.identity,
        name: p.name || p.identity,
        avatarFull,
        isLocal,
        isSpeaking: p.isSpeaking,
        isMuted: !p.isMicrophoneEnabled,
      };
    };
    list.push(toInfo(room.localParticipant, true));
    room.remoteParticipants.forEach((p) => list.push(toInfo(p, false)));
    setParticipants(list);
  }

  useEffect(() => {
    if (!id) return;
    let cancelled = false;
    const room = new Room({ adaptiveStream: true, dynacast: true });
    roomRef.current = room;

    (async () => {
      try {
        const { token, url, roomName: label, hostedBy: host } = await api.voiceJoin(id, searchParams.get('code') ?? undefined);
        if (cancelled) return;
        setRoomLabel(label);
        setHostedBy(host);

        room
          .on(RoomEvent.ParticipantConnected, () => snapshotParticipants(room))
          .on(RoomEvent.ParticipantDisconnected, () => snapshotParticipants(room))
          .on(RoomEvent.ActiveSpeakersChanged, () => snapshotParticipants(room))
          .on(RoomEvent.TrackMuted, () => snapshotParticipants(room))
          .on(RoomEvent.TrackUnmuted, () => snapshotParticipants(room))
          .on(RoomEvent.TrackSubscribed, (track) => {
            // requirement: audio actually plays for everyone else in
            // the room — attach remote audio tracks to a real <audio>
            // element; video/screenshare aren't part of this feature.
            if (track.kind === Track.Kind.Audio) {
              const el = track.attach();
              el.dataset.livekitTrack = track.sid ?? '';
              document.body.appendChild(el);
            }
          })
          .on(RoomEvent.TrackUnsubscribed, (track) => {
            track.detach().forEach((el) => el.remove());
          })
          .on(RoomEvent.Disconnected, () => {
            if (!cancelled) navigate('/voice');
          });

        await room.connect(url, token);
        try {
          await room.localParticipant.setMicrophoneEnabled(true);
        } catch {
          // requirement: mic permission denied shouldn't break the
          // whole room — join listen-only and say so plainly, rather
          // than treating a browser permission prompt as a site error.
          setMicDenied(true);
        }
        snapshotParticipants(room);
        if (!cancelled) setConnecting(false);
      } catch (e: any) {
        if (!cancelled) {
          setError(e?.message ?? 'Не удалось подключиться к комнате');
          setConnecting(false);
        }
      }
    })();

    return () => {
      cancelled = true;
      room.disconnect();
      // Any audio elements this room's tracks attached to document.body
      document.querySelectorAll('[data-livekit-track]').forEach((el) => el.remove());
    };
  }, [id]);

  function toggleMute() {
    const room = roomRef.current;
    if (!room) return;
    const next = !muted;
    room.localParticipant.setMicrophoneEnabled(!next).catch(() => setMicDenied(true));
    setMuted(next);
  }

  function toggleDeafen() {
    // requirement: deafen mutes what you HEAR, separate from your own
    // mic — implemented by muting every remote audio element directly,
    // since LiveKit itself has no single "deafen" concept.
    const next = !deafened;
    setDeafened(next);
    document.querySelectorAll<HTMLAudioElement>('[data-livekit-track]').forEach((el) => { el.muted = next; });
  }

  function leave() {
    roomRef.current?.disconnect();
    navigate('/voice');
  }

  if (error) {
    return (
      <div style={{ maxWidth: 500, margin: '80px auto', padding: '0 24px', textAlign: 'center' }}>
        <p style={{ color: 'var(--danger)', marginBottom: 16 }}>{error}</p>
        <button className="button-ghost" onClick={() => navigate('/voice')}>Назад к комнатам</button>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 700, margin: '0 auto', padding: '40px 24px 140px' }}>
      <p style={{ fontSize: 21, fontWeight: 500, margin: '0 0 4px' }}>🎙️ {roomLabel || 'Комната'}</p>
      {hostedBy && <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 24px' }}>Хост: {hostedBy}</p>}

      {connecting ? (
        <p style={{ color: 'var(--text-muted)' }}>Подключение…</p>
      ) : (
        <>
          {micDenied && (
            <p style={{ fontSize: 13, color: 'var(--danger)', marginBottom: 16 }}>
              Доступ к микрофону не разрешён браузером — вы в комнате только на прослушивание. Разрешите доступ к микрофону в настройках сайта и перезайдите.
            </p>
          )}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(110px, 1fr))', gap: 16, marginBottom: 32 }}>
            {participants.map((p) => (
              <div key={p.identity} style={{ textAlign: 'center' }}>
                <div
                  style={{
                    width: 72, height: 72, borderRadius: '50%', margin: '0 auto 8px', overflow: 'hidden',
                    border: p.isSpeaking ? '3px solid var(--accent)' : '3px solid var(--border)',
                    boxShadow: p.isSpeaking ? '0 0 16px rgba(47,169,143,0.6)' : 'none',
                    transition: 'all 0.15s ease',
                  }}
                >
                  {p.avatarFull ? (
                    <img src={p.avatarFull} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  ) : (
                    <div style={{ width: '100%', height: '100%', background: 'var(--card)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}>
                      {p.name.slice(0, 1).toUpperCase()}
                    </div>
                  )}
                </div>
                <p style={{ fontSize: 12, margin: 0, fontWeight: p.isLocal ? 700 : 400 }}>{p.name}{p.isLocal ? ' (вы)' : ''}</p>
                {p.isMuted && <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '2px 0 0' }}>🔇 mic off</p>}
              </div>
            ))}
          </div>
        </>
      )}

      {/* Fixed control bar — mute/deafen/leave always reachable, matches the pattern established by GlobalMusicPlayer's own bottom bar */}
      <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: 'var(--card)', borderTop: '1px solid var(--border)', padding: 14, display: 'flex', justifyContent: 'center', gap: 12 }}>
        <button className={muted ? 'button-primary' : 'button-ghost'} onClick={toggleMute} disabled={connecting || micDenied}>
          {muted ? '🔇 Микрофон выкл.' : '🎤 Микрофон вкл.'}
        </button>
        <button className={deafened ? 'button-primary' : 'button-ghost'} onClick={toggleDeafen} disabled={connecting}>
          {deafened ? '🔕 Звук выкл.' : '🔊 Звук вкл.'}
        </button>
        <button className="button-ghost" style={{ color: 'var(--danger)' }} onClick={leave}>
          Покинуть комнату
        </button>
      </div>
    </div>
  );
}
