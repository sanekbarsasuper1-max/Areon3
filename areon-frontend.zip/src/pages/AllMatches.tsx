import { useEffect, useState, type CSSProperties } from 'react';
import { Link } from 'react-router-dom';
import { api, Hero, MatchSummary } from '../api';
import { useAudio } from '../audio/AudioContext';
import { HERO_ICON_FALLBACK } from '../components/HeroImage';

export function AllMatches() {
  const [heroesById, setHeroesById] = useState<Record<number, Hero>>({});
  const [heroList, setHeroList] = useState<Hero[]>([]);
  const [matches, setMatches] = useState<MatchSummary[]>([]);
  const [heroId, setHeroId] = useState<number | undefined>();
  const [result, setResult] = useState<'win' | 'loss' | undefined>();
  const [days, setDays] = useState<number | undefined>();
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);
  const { playSFX } = useAudio();

  useEffect(() => {
    playSFX('nav_statistics_open');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    api.heroes().then((h) => {
      setHeroList(h);
      setHeroesById(Object.fromEntries(h.map((x) => [x.id, x])));
    });
  }, []);

  async function load() {
    setLoading(true);
    try {
      const data = await api.matches({ heroId, result, days });
      setMatches(data);
    } finally {
      setLoading(false);
    }
  }

  // Requirement: this page had no way to trigger a fresh OpenDota
  // sync at all — only Profile did. Someone who plays a match and
  // goes straight to "Матчи" (a very natural thing to do) never saw
  // it, not because sync itself was broken, but because nothing here
  // ever asked for one; the page was purely a viewer over whatever
  // Postgres already had.
  async function sync() {
    setSyncing(true);
    setSyncMessage(null);
    try {
      const res = await api.syncMatches();
      await load();
      const base = res.newMatches > 0
        ? `Новых матчей: ${res.newMatches} (из ${res.synced} проверенных).`
        : `Новых матчей нет — OpenDota пока отдаёт те же ${res.synced}, что уже были. Если вы недавно доиграли матч, OpenDota обрабатывает его не мгновенно — попробуйте синхронизировать снова через пару минут.`;
      setSyncMessage(res.skipped > 0 ? `${base} Пропущено: ${res.skipped}.` : base);
      playSFX('ui_confirm');
    } catch (e: any) {
      setSyncMessage(e?.message && e.message !== 'unauthenticated' ? e.message : 'Не удалось связаться с OpenDota — попробуйте ещё раз позже.');
      playSFX('ui_error');
    } finally {
      setSyncing(false);
    }
  }

  // Every filter change re-queries our own Postgres copy via
  // GET /players/me/matches — no live OpenDota call happens here.
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [heroId, result, days]);

  return (
    <div style={{ maxWidth: 1400, margin: '0 auto', padding: '40px 48px 100px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8, flexWrap: 'wrap', gap: 10 }}>
        <span style={{ fontSize: 18, fontWeight: 500 }}>Все матчи</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>{matches.length} матчей</span>
          <button className="button-ghost" onClick={sync} disabled={syncing}>
            {syncing ? 'Синхронизация…' : 'Обновить из OpenDota'}
          </button>
        </div>
      </div>
      {syncMessage && (
        <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 12px' }}>{syncMessage}</p>
      )}

      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 18 }}>
        <select
          value={heroId ?? ''}
          onChange={(e) => setHeroId(e.target.value ? Number(e.target.value) : undefined)}
          style={selectStyle}
        >
          <option value="">Герой: любой</option>
          {heroList.map((h) => (
            <option key={h.id} value={h.id}>{h.localizedName}</option>
          ))}
        </select>

        <select
          value={result ?? ''}
          onChange={(e) => setResult((e.target.value || undefined) as 'win' | 'loss' | undefined)}
          style={selectStyle}
        >
          <option value="">Результат: любой</option>
          <option value="win">Победы</option>
          <option value="loss">Поражения</option>
        </select>

        <select
          value={days ?? ''}
          onChange={(e) => setDays(e.target.value ? Number(e.target.value) : undefined)}
          style={selectStyle}
        >
          <option value="">Любой период</option>
          <option value="7">7 дней</option>
          <option value="30">30 дней</option>
          <option value="90">90 дней</option>
        </select>
      </div>

      {loading && <p style={{ fontSize: 14, color: 'var(--text-muted)' }}>Загрузка…</p>}

      {!loading && matches.length === 0 && (
        <p style={{ fontSize: 14, color: 'var(--text-muted)' }}>
          Ничего не найдено под эти фильтры — либо ещё нет синхронизированных матчей.
        </p>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {matches.map((m) => {
          const hero = heroesById[m.heroId];
          return (
            <Link
              key={m.matchId}
              to={`/matches/${m.id}`}
              className="card"
              style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                textDecoration: 'none', color: 'inherit',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span
                  style={{
                    width: 4, height: 20, borderRadius: 2,
                    background: m.won ? 'var(--accent)' : 'var(--danger)',
                  }}
                />
                {hero?.iconUrl && (
                  <img src={hero.iconUrl} onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = HERO_ICON_FALLBACK; }} alt="" style={{ width: 32, aspectRatio: '16/9', objectFit: 'cover', borderRadius: 4 }} />
                )}
                <span style={{ fontSize: 15 }}>{hero?.localizedName ?? `Герой #${m.heroId}`}</span>
              </div>
              <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>
                {m.kills}/{m.deaths}/{m.assists} · {m.goldPerMin} GPM · {formatDuration(m.durationSec)}
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}

function formatDuration(sec: number) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

const selectStyle: CSSProperties = {
  background: 'var(--card)',
  border: '0.5px solid var(--border)',
  borderRadius: 6,
  padding: '8px 10px',
  fontSize: 14,
  color: 'var(--text)',
};
