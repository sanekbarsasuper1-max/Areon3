import { useEffect, useRef, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api, Tournament, Team, Me } from '../api';

const FORMAT_LABEL: Record<Tournament['bracketFormat'], string> = {
  single_elimination: 'Одиночное выбывание',
  double_elimination: 'Двойное выбывание',
  round_robin: 'Круговой турнир',
  swiss: 'Швейцарская система',
  group_stage: 'Группы + плей-офф',
};

export const TOURNAMENT_STYLES = `
@keyframes tourFlicker {
  0%, 100% { text-shadow: 0 0 6px #ff8a2a, 0 0 12px #ff4d1a, 0 0 20px #ff2d00; }
  25% { text-shadow: 0 0 8px #ffb03d, 0 0 16px #ff5a1a, 0 0 24px #ff3000; }
  50% { text-shadow: 0 0 5px #ff7a1a, 0 0 10px #ff3d00, 0 0 18px #d92600; }
  75% { text-shadow: 0 0 9px #ffae3d, 0 0 14px #ff5500, 0 0 22px #ff2a00; }
}
@keyframes tourEmberRise {
  0% { transform: translateY(0) translateX(0) scale(1); opacity: 0.9; }
  100% { transform: translateY(-30px) translateX(var(--dx)) scale(0.3); opacity: 0; }
}
@keyframes tourSmokeRise {
  0% { transform: translateY(0) translateX(0) scale(0.6); opacity: 0.35; }
  100% { transform: translateY(-36px) translateX(var(--dx)) scale(1.6); opacity: 0; }
}
@keyframes tourCardGlow {
  0%, 100% { box-shadow: 0 0 14px 1px rgba(255,90,20,0.22), inset 0 0 24px rgba(255,60,0,0.07); }
  50% { box-shadow: 0 0 22px 4px rgba(255,120,20,0.35), inset 0 0 32px rgba(255,80,0,0.1); }
}
.tour-match { background: linear-gradient(135deg, #1c1610 0%, #12100c 55%, #0a0806 100%); border: 1px solid #2e2418; border-radius: 10px; }
.tour-match-winner { animation: tourCardGlow 2.4s ease-in-out infinite; border-color: #6b4420 !important; }
.tour-name-winner { color: #ffcf8a; font-weight: 700; animation: tourFlicker 1.8s ease-in-out infinite; }
.tour-name-loser { color: #55504a; text-decoration: line-through; text-decoration-color: #3a3530; }
.tour-ember { position: absolute; width: 3px; height: 3px; border-radius: 50%; background: #ff8a2a; bottom: 2px; animation: tourEmberRise 1.6s ease-out infinite; pointer-events: none; }
.tour-smoke { position: absolute; width: 9px; height: 9px; border-radius: 50%; background: radial-gradient(circle, rgba(120,115,110,0.5), transparent 70%); bottom: 0px; animation: tourSmokeRise 2.8s ease-out infinite; filter: blur(1px); pointer-events: none; }
`;

/** A few small embers/smoke wisps at varied positions and delays — pure decoration, purely CSS. */
export function EmberBurst({ kind }: { kind: 'ember' | 'smoke' }) {
  const specs = kind === 'ember'
    ? [{ l: '15%', dx: -8, d: 0 }, { l: '45%', dx: 5, d: 0.4 }, { l: '75%', dx: 9, d: 0.8 }]
    : [{ l: '20%', dx: -9, d: 0 }, { l: '55%', dx: 6, d: 0.9 }, { l: '80%', dx: -4, d: 1.8 }];
  return (
    <>
      {specs.map((s, i) => (
        <span
          key={i}
          className={kind === 'ember' ? 'tour-ember' : 'tour-smoke'}
          style={{ left: s.l, ['--dx' as any]: `${s.dx}px`, animationDelay: `${s.d}s` }}
        />
      ))}
    </>
  );
}

const ROW_HEIGHT = 96;
const COLUMN_WIDTH = 260;
const CARD_HEIGHT = 72;
const HEADER_HEIGHT = 40;

interface BracketMatchLike {
  id: string;
  round: number;
  position: number;
  teamAId: string | null;
  teamBId: string | null;
  winnerTeamId: string | null;
  status: 'PENDING' | 'COMPLETED';
}

/**
 * Standard esports round naming, counted backward from whichever
 * round is LAST in this particular bracket group — a losers bracket's
 * own last round is still that bracket's "final", even though the
 * real tournament final lives in a separate grand_final group the
 * parent renders as its own BracketTree instance. bracketKind only
 * changes the label for round 0 (a true bracket_reset/grand_final
 * group gets "ГРАНД-ФИНАЛ" instead of plain "ФИНАЛ").
 */
function roundLabel(roundsFromEnd: number, bracketKind: string, roundNumber: number): string {
  if (roundsFromEnd === 0) return bracketKind === 'grand_final' || bracketKind === 'bracket_reset' ? 'ГРАНД-ФИНАЛ' : 'ФИНАЛ';
  if (roundsFromEnd === 1) return 'ПОЛУФИНАЛ';
  if (roundsFromEnd === 2) return 'ЧЕТВЕРТЬФИНАЛ';
  if (roundsFromEnd === 3) return '1/16 ФИНАЛА';
  if (roundsFromEnd === 4) return '1/32 ФИНАЛА';
  return `РАУНД ${roundNumber}`;
}

/**
 * A real esports tournament bracket — round names across the top
 * (Quarterfinals → Semifinals → Grand Final, the way The
 * International or any major bracket actually reads), cards linked by
 * connecting lines showing exactly which match a winner advances
 * into, and the final round visually called out rather than looking
 * like just one more column. Only meaningful for elimination-style
 * brackets (winners/losers/grand_final/bracket_reset), where "who
 * plays whom next" is a real structural relationship — round robin,
 * swiss and the group stage don't have one (everyone plays a fixed
 * schedule regardless of results), so those stay as the standings
 * table + round list elsewhere instead of forcing a tree shape onto
 * data that isn't actually shaped like one.
 *
 * Layout: the first round's matches are evenly spaced top to bottom;
 * every later round's match Y-position is the average of the two
 * earlier-round matches that feed into it (position 2p and 2p+1) —
 * the standard way a bracket visually converges without needing a
 * layout library. Horizontal scroll (not a forced vertical stack) is
 * what keeps this the same real bracket shape on a phone as on a
 * desktop — see the wrapping container's overflowX below.
 */
export function BracketTree({
  matches, teamName, isOrganizer, onReport, bracketKind = 'winners',
}: {
  matches: BracketMatchLike[];
  teamName: (id: string | null) => string;
  isOrganizer: boolean;
  onReport: (matchId: string, winnerTeamId: string) => void;
  bracketKind?: string;
}) {
  const rounds = Array.from(new Set(matches.map((m) => m.round))).sort((a, b) => a - b);
  const matchesByRound = rounds.map((r) => matches.filter((m) => m.round === r).sort((a, b) => a.position - b.position));

  const yByMatchId = new Map<string, number>();
  matchesByRound.forEach((roundMatches, ri) => {
    roundMatches.forEach((m) => {
      if (ri === 0) {
        yByMatchId.set(m.id, m.position * ROW_HEIGHT);
        return;
      }
      const prevRound = matchesByRound[ri - 1];
      const feeders = prevRound.filter((pm) => Math.floor(pm.position / 2) === m.position);
      const ys = feeders.map((f) => yByMatchId.get(f.id)).filter((y): y is number => y != null);
      yByMatchId.set(m.id, ys.length > 0 ? ys.reduce((a, b) => a + b, 0) / ys.length : m.position * ROW_HEIGHT);
    });
  });

  const maxY = Math.max(0, ...Array.from(yByMatchId.values()));
  const width = rounds.length * COLUMN_WIDTH;
  const height = maxY + CARD_HEIGHT + HEADER_HEIGHT + 24;
  const isFinalRound = (ri: number) => ri === rounds.length - 1;
  const containerRef = useRef<HTMLDivElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // requirement: a large bracket (32/64 участника) needs real room to
  // read, more than fits in the normal page column — the Fullscreen
  // API expands this one element to fill the whole screen without
  // actually opening a second browser window/tab, which would just
  // lose all the styling and interactivity that live in this page.
  function toggleFullscreen() {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen?.();
    } else {
      document.exitFullscreen?.();
    }
  }

  useEffect(() => {
    const handler = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', handler);
    return () => document.removeEventListener('fullscreenchange', handler);
  }, []);

  return (
    <div
      ref={containerRef}
      style={{
        overflowX: 'auto', overflowY: isFullscreen ? 'auto' : undefined, paddingBottom: 8,
        ...(isFullscreen ? { background: '#0a0a10', padding: 24, minHeight: '100vh' } : {}),
      }}
    >
      {rounds.length > 3 && (
        <button
          className="button-ghost"
          style={{ marginBottom: 10, color: isFullscreen ? '#fff' : undefined }}
          onClick={toggleFullscreen}
        >
          {isFullscreen ? '✕ Закрыть полноэкранный режим' : '⛶ Открыть на весь экран'}
        </button>
      )}
      <div style={{ position: 'relative', width, height, minWidth: '100%' }}>
        {/* Round name headers — the actual "Quarterfinals → Semifinals → Grand Final" row */}
        {rounds.map((r, ri) => (
          <div
            key={`hdr-${r}`}
            style={{
              position: 'absolute', left: ri * COLUMN_WIDTH, top: 0, width: COLUMN_WIDTH - 28,
              textAlign: 'center', fontSize: 12, fontWeight: 700, letterSpacing: 1.5,
              color: isFinalRound(ri) ? '#FFD866' : 'rgba(255,255,255,0.65)',
            }}
          >
            {roundLabel(rounds.length - 1 - ri, bracketKind, r)}
          </div>
        ))}

        <svg width={width} height={height} style={{ position: 'absolute', top: HEADER_HEIGHT, left: 0, pointerEvents: 'none' }}>
          {matchesByRound.slice(1).map((roundMatches, riMinus1) =>
            roundMatches.map((m) => {
              const prevRound = matchesByRound[riMinus1];
              const feeders = prevRound.filter((pm) => Math.floor(pm.position / 2) === m.position);
              const x0 = riMinus1 * COLUMN_WIDTH + COLUMN_WIDTH - 28;
              const x1 = (riMinus1 + 1) * COLUMN_WIDTH;
              const myY = (yByMatchId.get(m.id) ?? 0) + CARD_HEIGHT / 2;
              return feeders.map((f) => {
                const fy = (yByMatchId.get(f.id) ?? 0) + CARD_HEIGHT / 2;
                const isWinningPath = f.winnerTeamId != null && f.winnerTeamId === (m.teamAId ?? m.teamBId ?? undefined) &&
                  (f.winnerTeamId === m.teamAId || f.winnerTeamId === m.teamBId);
                return (
                  <path
                    key={f.id}
                    d={`M ${x0} ${fy} H ${x0 + 14} V ${myY} H ${x1}`}
                    stroke={isWinningPath ? '#FFD866' : 'rgba(255,255,255,0.28)'}
                    strokeWidth={isWinningPath ? 2.5 : 1.5}
                    fill="none"
                  />
                );
              });
            }),
          )}
        </svg>

        {matchesByRound.map((roundMatches, ri) =>
          roundMatches.map((m, mi) => {
            const isGrandFinal = isFinalRound(ri) && bracketKind !== 'losers';
            const cardW = isGrandFinal ? COLUMN_WIDTH - 4 : COLUMN_WIDTH - 28;
            return (
              <div
                key={m.id}
                className={`tour-match ${m.status === 'COMPLETED' ? 'tour-match-winner' : ''}`}
                style={{
                  position: 'absolute', left: ri * COLUMN_WIDTH, top: HEADER_HEIGHT + (yByMatchId.get(m.id) ?? 0),
                  width: cardW, minHeight: CARD_HEIGHT, padding: '6px 10px',
                  display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 3,
                  ...(isGrandFinal ? { border: '1.5px solid #FFD866', boxShadow: '0 0 20px rgba(255,216,102,0.35)' } : {}),
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, color: 'rgba(255,255,255,0.45)', marginBottom: 1 }}>
                  <span>МАТЧ {ri === 0 ? mi + 1 : `${ri + 1}.${mi + 1}`}</span>
                  <span>{m.status === 'COMPLETED' ? 'ЗАВЕРШЁН' : m.teamAId && m.teamBId ? 'ИДЁТ' : 'ОЖИДАНИЕ'}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'relative' }}>
                  <span className={m.winnerTeamId === m.teamAId ? 'tour-name-winner' : m.status === 'COMPLETED' ? 'tour-name-loser' : undefined} style={{ fontSize: 13 }}>
                    {teamName(m.teamAId)}
                  </span>
                  {m.winnerTeamId === m.teamAId && <EmberBurst kind="ember" />}
                  {m.status === 'COMPLETED' && m.winnerTeamId !== m.teamAId && m.teamAId && <EmberBurst kind="smoke" />}
                  {isOrganizer && m.status === 'PENDING' && m.teamAId && (
                    <button className="button-ghost" style={{ fontSize: 9, padding: '1px 5px' }} onClick={() => onReport(m.id, m.teamAId!)}>W</button>
                  )}
                </div>
                <div style={{ height: 1, background: 'rgba(255,255,255,0.15)' }} />
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'relative' }}>
                  <span className={m.winnerTeamId === m.teamBId ? 'tour-name-winner' : m.status === 'COMPLETED' && m.teamBId ? 'tour-name-loser' : undefined} style={{ fontSize: 13 }}>
                    {m.teamBId ? teamName(m.teamBId) : '(бай)'}
                  </span>
                  {m.winnerTeamId === m.teamBId && <EmberBurst kind="ember" />}
                  {m.status === 'COMPLETED' && m.winnerTeamId !== m.teamBId && m.teamBId && <EmberBurst kind="smoke" />}
                  {isOrganizer && m.status === 'PENDING' && m.teamBId && (
                    <button className="button-ghost" style={{ fontSize: 9, padding: '1px 5px' }} onClick={() => onReport(m.id, m.teamBId!)}>W</button>
                  )}
                </div>
                {isGrandFinal && m.winnerTeamId && (
                  <p style={{ fontSize: 10, color: '#FFD866', fontWeight: 700, textAlign: 'center', margin: '4px 0 0', letterSpacing: 1 }}>
                    🏆 ЧЕМПИОН: {teamName(m.winnerTeamId)}
                  </p>
                )}
              </div>
            );
          }),
        )}
      </div>
    </div>
  );
}

export function TournamentDetail() {
  const { id } = useParams<{ id: string }>();
  const [tournament, setTournament] = useState<Tournament | null>(null);
  const [me, setMe] = useState<Me | null>(null);
  const [myTeams, setMyTeams] = useState<Team[]>([]);
  const [selectedTeam, setSelectedTeam] = useState('');
  const [error, setError] = useState<string | null>(null);

  async function load() {
    if (!id) return;
    const [t, m, teams] = await Promise.all([api.tournament(id), api.me(), api.myTeams()]);
    setTournament(t);
    setMe(m);
    setMyTeams(teams);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function register() {
    if (!id || !selectedTeam) return;
    setError(null);
    try {
      await api.registerTeam(id, selectedTeam);
      load();
    } catch (e: any) {
      setError(e?.message ?? 'Не удалось зарегистрировать команду — проверьте, что вы владелец или капитан.');
    }
  }

  async function generate() {
    if (!id) return;
    setError(null);
    try {
      await api.generateBracket(id);
      load();
    } catch (e: any) {
      setError(e?.message ?? 'Не удалось построить сетку — нужно минимум 2 команды и права организатора.');
    }
  }

  async function report(matchId: string, winnerTeamId: string) {
    if (!id) return;
    try {
      await api.reportResult(id, matchId, winnerTeamId, 1, 0);
      load();
    } catch {
      setError('Не удалось сохранить результат.');
    }
  }

  if (!tournament || !me) return <p style={{ padding: 24, color: '#fff' }}>Загрузка…</p>;

  const isOrganizer = tournament.createdByUserId === me.id;
  const teamName = (teamId: string | null) =>
    teamId ? tournament.registrations.find((r) => r.teamId === teamId)?.team.name ?? '?' : 'TBD';

  const BRACKET_ORDER = ['group_stage', 'round_robin', 'swiss', 'winners', 'losers', 'grand_final', 'bracket_reset'];
  const BRACKET_LABEL: Record<string, string> = {
    winners: tournament.bracketFormat === 'group_stage' ? 'Плей-офф' : 'Верхняя сетка',
    losers: 'Нижняя сетка',
    grand_final: 'Гранд-финал',
    bracket_reset: 'Решающий матч (bracket reset)',
    round_robin: 'Круговой этап',
    swiss: 'Swiss',
    group_stage: 'Групповой этап',
  };
  const presentBrackets = BRACKET_ORDER.filter((b) => tournament.matches.some((m) => m.bracket === b));
  const isDoubleElim = tournament.bracketFormat === 'double_elimination';
  const myRegistration = tournament.registrations.find((r) => myTeams.some((t) => t.id === r.teamId));

  // Wins-based standings for the formats that have them — nothing to
  // show for single/double elimination, where "still in it" already
  // says everything a standings table would.
  const hasStandings = ['round_robin', 'swiss', 'group_stage'].includes(tournament.bracketFormat);
  const standings = hasStandings
    ? tournament.registrations
        .map((r) => {
          const relevant = tournament.matches.filter(
            (m) => (m.bracket === tournament.bracketFormat || (tournament.bracketFormat === 'group_stage' && m.bracket === 'group_stage'))
              && (m.teamAId === r.teamId || m.teamBId === r.teamId) && m.status === 'COMPLETED',
          );
          const wins = relevant.filter((m) => m.winnerTeamId === r.teamId).length;
          return { teamId: r.teamId, name: r.team.name, wins, played: relevant.length, groupIndex: r.teamId ? tournament.matches.find((m) => (m.teamAId === r.teamId || m.teamBId === r.teamId) && m.groupIndex != null)?.groupIndex : undefined };
        })
        .sort((a, b) => b.wins - a.wins)
    : [];

  return (
    <div className="tour-page">
      <style>{TOURNAMENT_STYLES}</style>
      <style>{`
        .tour-page { background: linear-gradient(135deg, #5B3FD9 0%, #3E6FE0 45%, #22C7B8 100%); padding: 40px 48px 100px; min-height: 100vh; }
        .tour-free-badge { background: linear-gradient(135deg, #FFD866, #FFB020); color: #3a2400; font-weight: 700; font-size: 11px; letter-spacing: 0.5px; padding: 4px 10px; border-radius: 20px; display: inline-block; }
        .tour-page-glass { background: rgba(255,255,255,0.14); backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px); border: 1px solid rgba(255,255,255,0.28); border-radius: 18px; color: #fff; }
        .tour-page-input { background: rgba(255,255,255,0.18); border: 1px solid rgba(255,255,255,0.35); border-radius: 8px; padding: 9px 12px; font-size: 14px; color: #fff; }
        .tour-page-input::placeholder { color: rgba(255,255,255,0.65); }
        .tour-page-cta { background: linear-gradient(135deg, #FFD866, #FF9D3D); color: #3a1e00; font-weight: 700; border: none; border-radius: 10px; padding: 10px 20px; cursor: pointer; box-shadow: 0 4px 14px rgba(255,157,61,0.4); }
        .tour-page-ghost { background: transparent; color: #fff; border: 1px solid rgba(255,255,255,0.4); border-radius: 8px; padding: 8px 14px; cursor: pointer; font-size: 13px; }
      `}</style>

      <Link to="/tournaments" className="tour-page-ghost" style={{ textDecoration: 'none', display: 'inline-block' }}>← Турниры</Link>

      <p style={{ fontSize: 26, fontWeight: 800, margin: '16px 0 4px', color: '#fff' }}>{tournament.name}</p>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginBottom: 20 }}>
        <span className="tour-free-badge">БЕСПЛАТНО</span>
        <p style={{ fontSize: 14, color: 'rgba(255,255,255,0.85)', margin: 0 }}>
          {tournament.matchFormat} · {FORMAT_LABEL[tournament.bracketFormat]} · {tournament.teamSize}×{tournament.teamSize} ·{' '}
          {tournament.registrations.length}/{tournament.maxTeams} команд · {tournament.status}
        </p>
      </div>

      {tournament.status === 'REGISTRATION_OPEN' && !myRegistration && (
        <div className="tour-page-glass" style={{ padding: 20, marginBottom: 24 }}>
          <p style={{ fontSize: 15, fontWeight: 700, margin: '0 0 10px' }}>Зарегистрировать команду</p>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <select
              className="tour-page-input"
              value={selectedTeam}
              onChange={(e) => setSelectedTeam(e.target.value)}
              style={{ flex: 1, minWidth: 160 }}
            >
              <option value="" style={{ color: '#000' }}>Выберите команду</option>
              {myTeams.map((t) => (
                <option key={t.id} value={t.id} style={{ color: '#000' }}>{t.name}</option>
              ))}
            </select>
            <button className="tour-page-cta" onClick={register}>Зарегистрировать</button>
          </div>

          {isOrganizer && (
            <button className="tour-page-ghost" style={{ marginTop: 10 }} onClick={generate}>
              Построить сетку
            </button>
          )}
          {isDoubleElim && (
            <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', margin: '8px 0 0' }}>
              Double elimination требует ровно {tournament.maxTeams} команд (степень двойки) на момент построения сетки.
            </p>
          )}
        </div>
      )}

      {error && <p style={{ fontSize: 14, color: '#FFDDE0', marginBottom: 16 }}>{error}</p>}

      {hasStandings && standings.length > 0 && (
        <div className="tour-page-glass" style={{ padding: 0, overflow: 'hidden', marginBottom: 24 }}>
          <p style={{ fontSize: 14, fontWeight: 700, margin: 0, padding: '14px 16px 6px' }}>Таблица результатов</p>
          {(tournament.bracketFormat === 'group_stage'
            ? Object.entries(
                standings.reduce((acc, s) => {
                  const g = s.groupIndex ?? 0;
                  (acc[g] ??= []).push(s);
                  return acc;
                }, {} as Record<number, typeof standings>),
              )
            : [[null, standings]] as any
          ).map(([groupIdx, rows]: [string | null, typeof standings]) => (
            <div key={groupIdx ?? 'all'}>
              {groupIdx != null && (
                <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', margin: '10px 16px 4px' }}>Группа {Number(groupIdx) + 1}</p>
              )}
              {rows.sort((a, b) => b.wins - a.wins).map((s, i) => (
                <div key={s.teamId} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 16px', borderTop: '1px solid rgba(255,255,255,0.15)', fontSize: 14 }}>
                  <span>{i + 1}. {s.name}</span>
                  <span style={{ color: 'rgba(255,255,255,0.75)' }}>{s.wins} побед из {s.played}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}

      {presentBrackets.map((bracket) => {
        const bracketMatches = tournament.matches.filter((m) => m.bracket === bracket);
        const isTreeBracket = ['winners', 'losers', 'grand_final', 'bracket_reset'].includes(bracket);

        if (isTreeBracket) {
          return (
            <div key={bracket} style={{ marginBottom: 24 }}>
              <p style={{ fontSize: 15, color: '#fff', margin: '0 0 10px', fontWeight: 700 }}>
                {BRACKET_LABEL[bracket] ?? bracket}
              </p>
              <BracketTree matches={bracketMatches} teamName={teamName} isOrganizer={isOrganizer} onReport={report} bracketKind={bracket} />
            </div>
          );
        }

        const rounds = Array.from(new Set(bracketMatches.map((m) => m.round))).sort((a, b) => a - b);
        return (
          <div key={bracket} style={{ marginBottom: 24 }}>
            <p style={{ fontSize: 15, color: '#fff', margin: '0 0 10px', fontWeight: 700 }}>
              {BRACKET_LABEL[bracket] ?? bracket}
            </p>
            {/* Requirement: this still isn't an elimination tree — round
                robin/Swiss/group play has no "winner advances into this
                slot" relationship for lines to show — but stacking
                rounds vertically read as "just columns again" the same
                way the old bracket view did. Laid out side by side
                instead, like a real schedule/fixture list: each round
                is its own horizontally-scrolling column of matches,
                not the whole page scrolling down through round after
                round. */}
            <div style={{ display: 'flex', gap: 14, overflowX: 'auto', paddingBottom: 8 }}>
              {rounds.map((round) => (
                <div key={round} style={{ minWidth: 240, flexShrink: 0 }}>
                  <p style={{ fontSize: 12, color: '#FFD866', margin: '0 0 8px', fontWeight: 700, letterSpacing: 1, textAlign: 'center' }}>
                    {bracket === 'group_stage' ? `ГРУППА ${Math.floor(round / 100) + 1} · ТУР ${(round % 100)}` : `ТУР ${round}`}
                  </p>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    {bracketMatches.filter((m) => m.round === round).map((m) => (
                      <div
                        key={m.id}
                        className={`tour-match ${m.status === 'COMPLETED' ? 'tour-match-winner' : ''}`}
                        style={{ padding: '8px 12px' }}
                      >
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'relative' }}>
                          <span style={{ fontSize: 13 }} className={m.winnerTeamId === m.teamAId ? 'tour-name-winner' : m.status === 'COMPLETED' ? 'tour-name-loser' : undefined}>
                            {teamName(m.teamAId)}
                          </span>
                          {m.winnerTeamId === m.teamAId && <EmberBurst kind="ember" />}
                          {m.status === 'COMPLETED' && m.winnerTeamId !== m.teamAId && m.teamAId && <EmberBurst kind="smoke" />}
                          {isOrganizer && m.status === 'PENDING' && m.teamAId && m.teamBId && (
                            <button className="button-ghost" style={{ fontSize: 9, padding: '1px 5px' }} onClick={() => report(m.id, m.teamAId!)}>W</button>
                          )}
                        </div>
                        <div style={{ height: 1, background: 'rgba(255,255,255,0.15)', margin: '4px 0' }} />
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'relative' }}>
                          <span style={{ fontSize: 13 }} className={m.winnerTeamId === m.teamBId ? 'tour-name-winner' : m.status === 'COMPLETED' && m.teamBId ? 'tour-name-loser' : undefined}>
                            {m.teamBId ? teamName(m.teamBId) : '(бай)'}
                          </span>
                          {m.winnerTeamId === m.teamBId && <EmberBurst kind="ember" />}
                          {m.status === 'COMPLETED' && m.winnerTeamId !== m.teamBId && m.teamBId && <EmberBurst kind="smoke" />}
                          {isOrganizer && m.status === 'PENDING' && m.teamAId && m.teamBId && (
                            <button className="button-ghost" style={{ fontSize: 9, padding: '1px 5px' }} onClick={() => report(m.id, m.teamBId!)}>W</button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

