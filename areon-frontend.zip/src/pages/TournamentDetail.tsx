import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api, Tournament, Team, Me } from '../api';

const FORMAT_LABEL: Record<Tournament['bracketFormat'], string> = {
  single_elimination: 'Одиночное выбывание',
  double_elimination: 'Двойное выбывание',
  round_robin: 'Круговой турнир',
  swiss: 'Швейцарская система',
  group_stage: 'Группы + плей-офф',
};

const TOURNAMENT_STYLES = `
@keyframes tourFlicker {
  0%, 100% { text-shadow: 0 0 6px #ff8a2a, 0 0 12px #ff4d1a, 0 0 20px #ff2d00; }
  25% { text-shadow: 0 0 8px #ffb03d, 0 0 16px #ff5a1a, 0 0 24px #ff3000; }
  50% { text-shadow: 0 0 5px #ff7a1a, 0 0 10px #ff3d00, 0 0 18px #d92600; }
  75% { text-shadow: 0 0 9px #ffae3d, 0 0 14px #ff5500, 0 0 22px #ff2a00; }
}
@keyframes tourEmberRise {
  0% { transform: translateY(0) translateX(0) scale(1); opacity: 0.9; }
  100% { transform: translateY(-30px) translateX(var(--dx)) scale(0.3); opacity: 0; }
}
@keyframes tourSmokeRise {
  0% { transform: translateY(0) translateX(0) scale(0.6); opacity: 0.35; }
  100% { transform: translateY(-36px) translateX(var(--dx)) scale(1.6); opacity: 0; }
}
@keyframes tourCardGlow {
  0%, 100% { box-shadow: 0 0 14px 1px rgba(255,90,20,0.22), inset 0 0 24px rgba(255,60,0,0.07); }
  50% { box-shadow: 0 0 22px 4px rgba(255,120,20,0.35), inset 0 0 32px rgba(255,80,0,0.1); }
}
.tour-match { background: linear-gradient(135deg, #1c1610 0%, #12100c 55%, #0a0806 100%); border: 1px solid #2e2418; border-radius: 10px; }
.tour-match-winner { animation: tourCardGlow 2.4s ease-in-out infinite; border-color: #6b4420 !important; }
.tour-name-winner { color: #ffcf8a; font-weight: 700; animation: tourFlicker 1.8s ease-in-out infinite; }
.tour-name-loser { color: #55504a; text-decoration: line-through; text-decoration-color: #3a3530; }
.tour-ember { position: absolute; width: 3px; height: 3px; border-radius: 50%; background: #ff8a2a; bottom: 2px; animation: tourEmberRise 1.6s ease-out infinite; pointer-events: none; }
.tour-smoke { position: absolute; width: 9px; height: 9px; border-radius: 50%; background: radial-gradient(circle, rgba(120,115,110,0.5), transparent 70%); bottom: 0px; animation: tourSmokeRise 2.8s ease-out infinite; filter: blur(1px); pointer-events: none; }
`;

/** A few small embers/smoke wisps at varied positions and delays — pure decoration, purely CSS. */
function EmberBurst({ kind }: { kind: 'ember' | 'smoke' }) {
  const specs = kind === 'ember'
    ? [{ l: '15%', dx: -8, d: 0 }, { l: '45%', dx: 5, d: 0.4 }, { l: '75%', dx: 9, d: 0.8 }]
    : [{ l: '20%', dx: -9, d: 0 }, { l: '55%', dx: 6, d: 0.9 }, { l: '80%', dx: -4, d: 1.8 }];
  return (
    <>
      {specs.map((s, i) => (
        <span
          key={i}
          className={kind === 'ember' ? 'tour-ember' : 'tour-smoke'}
          style={{ left: s.l, ['--dx' as any]: `${s.dx}px`, animationDelay: `${s.d}s` }}
        />
      ))}
    </>
  );
}

const ROW_HEIGHT = 64;
const COLUMN_WIDTH = 220;
const CARD_HEIGHT = 46;

interface BracketMatchLike {
  id: string;
  round: number;
  position: number;
  teamAId: string | null;
  teamBId: string | null;
  winnerTeamId: string | null;
  status: 'PENDING' | 'COMPLETED';
}

/**
 * A real bracket tree, not a list — connecting lines drawn so a match
 * visually feeds into the next one, the way every tournament bracket
 * anyone has seen actually looks. Only meaningful for elimination-
 * style brackets (winners/losers/grand_final/bracket_reset), where
 * "who plays whom next" is a real structural relationship — round
 * robin, swiss and the group stage don't have one (everyone plays a
 * fixed schedule regardless of results), so those stay as the
 * standings table + round list above instead of forcing a tree shape
 * onto data that isn't actually shaped like one.
 *
 * Layout: the first round's matches are evenly spaced top to bottom;
 * every later round's match Y-position is the average of the two
 * earlier-round matches that feed into it (position 2p and 2p+1) —
 * the standard way a bracket visually converges without needing a
 * layout library.
 */
function BracketTree({
  matches, teamName, isOrganizer, onReport,
}: {
  matches: BracketMatchLike[];
  teamName: (id: string | null) => string;
  isOrganizer: boolean;
  onReport: (matchId: string, winnerTeamId: string) => void;
}) {
  const rounds = Array.from(new Set(matches.map((m) => m.round))).sort((a, b) => a - b);
  const matchesByRound = rounds.map((r) => matches.filter((m) => m.round === r).sort((a, b) => a.position - b.position));

  const yByMatchId = new Map<string, number>();
  matchesByRound.forEach((roundMatches, ri) => {
    roundMatches.forEach((m) => {
      if (ri === 0) {
        yByMatchId.set(m.id, m.position * ROW_HEIGHT);
        return;
      }
      const prevRound = matchesByRound[ri - 1];
      const feeders = prevRound.filter((pm) => Math.floor(pm.position / 2) === m.position);
      const ys = feeders.map((f) => yByMatchId.get(f.id)).filter((y): y is number => y != null);
      yByMatchId.set(m.id, ys.length > 0 ? ys.reduce((a, b) => a + b, 0) / ys.length : m.position * ROW_HEIGHT);
    });
  });

  const maxY = Math.max(0, ...Array.from(yByMatchId.values()));
  const width = rounds.length * COLUMN_WIDTH;
  const height = maxY + CARD_HEIGHT + 20;

  return (
    <div style={{ position: 'relative', width, height, overflowX: 'auto' }}>
      <svg width={width} height={height} style={{ position: 'absolute', top: 0, left: 0, pointerEvents: 'none' }}>
        {matchesByRound.slice(1).map((roundMatches, riMinus1) =>
          roundMatches.map((m) => {
            const prevRound = matchesByRound[riMinus1];
            const feeders = prevRound.filter((pm) => Math.floor(pm.position / 2) === m.position);
            const x0 = riMinus1 * COLUMN_WIDTH + COLUMN_WIDTH - 20;
            const x1 = (riMinus1 + 1) * COLUMN_WIDTH;
            const myY = (yByMatchId.get(m.id) ?? 0) + CARD_HEIGHT / 2;
            return feeders.map((f) => {
              const fy = (yByMatchId.get(f.id) ?? 0) + CARD_HEIGHT / 2;
              return (
                <path
                  key={f.id}
                  d={`M ${x0} ${fy} H ${x0 + 12} V ${myY} H ${x1}`}
                  stroke="var(--border)"
                  strokeWidth={1.5}
                  fill="none"
                />
              );
            });
          }),
        )}
      </svg>
      {matchesByRound.map((roundMatches, ri) =>
        roundMatches.map((m) => (
          <div
            key={m.id}
            className={`tour-match ${m.status === 'COMPLETED' ? 'tour-match-winner' : ''}`}
            style={{
              position: 'absolute', left: ri * COLUMN_WIDTH, top: yByMatchId.get(m.id) ?? 0,
              width: COLUMN_WIDTH - 32, height: CARD_HEIGHT, padding: '4px 8px',
              display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 2,
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, position: 'relative' }}>
              <span className={m.winnerTeamId === m.teamAId ? 'tour-name-winner' : m.status === 'COMPLETED' ? 'tour-name-loser' : undefined}>
                {teamName(m.teamAId)}
              </span>
              {m.winnerTeamId === m.teamAId && <EmberBurst kind="ember" />}
              {m.status === 'COMPLETED' && m.winnerTeamId !== m.teamAId && m.teamAId && <EmberBurst kind="smoke" />}
              {isOrganizer && m.status === 'PENDING' && m.teamAId && (
                <button className="button-ghost" style={{ fontSize: 10, padding: '1px 5px' }} onClick={() => onReport(m.id, m.teamAId!)}>W</button>
              )}
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, position: 'relative' }}>
              <span className={m.winnerTeamId === m.teamBId ? 'tour-name-winner' : m.status === 'COMPLETED' && m.teamBId ? 'tour-name-loser' : undefined}>
                {m.teamBId ? teamName(m.teamBId) : '(бай)'}
              </span>
              {m.winnerTeamId === m.teamBId && <EmberBurst kind="ember" />}
              {m.status === 'COMPLETED' && m.winnerTeamId !== m.teamBId && m.teamBId && <EmberBurst kind="smoke" />}
              {isOrganizer && m.status === 'PENDING' && m.teamBId && (
                <button className="button-ghost" style={{ fontSize: 10, padding: '1px 5px' }} onClick={() => onReport(m.id, m.teamBId!)}>W</button>
              )}
            </div>
          </div>
        )),
      )}
    </div>
  );
}

export function TournamentDetail() {
  const { id } = useParams<{ id: string }>();
  const [tournament, setTournament] = useState<Tournament | null>(null);
  const [me, setMe] = useState<Me | null>(null);
  const [myTeams, setMyTeams] = useState<Team[]>([]);
  const [selectedTeam, setSelectedTeam] = useState('');
  const [error, setError] = useState<string | null>(null);

  async function load() {
    if (!id) return;
    const [t, m, teams] = await Promise.all([api.tournament(id), api.me(), api.myTeams()]);
    setTournament(t);
    setMe(m);
    setMyTeams(teams);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function register() {
    if (!id || !selectedTeam) return;
    setError(null);
    try {
      await api.registerTeam(id, selectedTeam);
      load();
    } catch (e: any) {
      setError(e?.message ?? 'Не удалось зарегистрировать команду — проверьте, что вы владелец или капитан.');
    }
  }

  async function generate() {
    if (!id) return;
    setError(null);
    try {
      await api.generateBracket(id);
      load();
    } catch (e: any) {
      setError(e?.message ?? 'Не удалось построить сетку — нужно минимум 2 команды и права организатора.');
    }
  }

  async function report(matchId: string, winnerTeamId: string) {
    if (!id) return;
    try {
      await api.reportResult(id, matchId, winnerTeamId, 1, 0);
      load();
    } catch {
      setError('Не удалось сохранить результат.');
    }
  }

  if (!tournament || !me) return <p style={{ padding: 24, color: '#fff' }}>Загрузка…</p>;

  const isOrganizer = tournament.createdByUserId === me.id;
  const teamName = (teamId: string | null) =>
    teamId ? tournament.registrations.find((r) => r.teamId === teamId)?.team.name ?? '?' : 'TBD';

  const BRACKET_ORDER = ['group_stage', 'round_robin', 'swiss', 'winners', 'losers', 'grand_final', 'bracket_reset'];
  const BRACKET_LABEL: Record<string, string> = {
    winners: tournament.bracketFormat === 'group_stage' ? 'Плей-офф' : 'Верхняя сетка',
    losers: 'Нижняя сетка',
    grand_final: 'Гранд-финал',
    bracket_reset: 'Решающий матч (bracket reset)',
    round_robin: 'Круговой этап',
    swiss: 'Swiss',
    group_stage: 'Групповой этап',
  };
  const presentBrackets = BRACKET_ORDER.filter((b) => tournament.matches.some((m) => m.bracket === b));
  const isDoubleElim = tournament.bracketFormat === 'double_elimination';
  const myRegistration = tournament.registrations.find((r) => myTeams.some((t) => t.id === r.teamId));

  // Wins-based standings for the formats that have them — nothing to
  // show for single/double elimination, where "still in it" already
  // says everything a standings table would.
  const hasStandings = ['round_robin', 'swiss', 'group_stage'].includes(tournament.bracketFormat);
  const standings = hasStandings
    ? tournament.registrations
        .map((r) => {
          const relevant = tournament.matches.filter(
            (m) => (m.bracket === tournament.bracketFormat || (tournament.bracketFormat === 'group_stage' && m.bracket === 'group_stage'))
              && (m.teamAId === r.teamId || m.teamBId === r.teamId) && m.status === 'COMPLETED',
          );
          const wins = relevant.filter((m) => m.winnerTeamId === r.teamId).length;
          return { teamId: r.teamId, name: r.team.name, wins, played: relevant.length, groupIndex: r.teamId ? tournament.matches.find((m) => (m.teamAId === r.teamId || m.teamBId === r.teamId) && m.groupIndex != null)?.groupIndex : undefined };
        })
        .sort((a, b) => b.wins - a.wins)
    : [];

  return (
    <div className="tour-page">
      <style>{TOURNAMENT_STYLES}</style>
      <style>{`
        .tour-page { background: linear-gradient(135deg, #5B3FD9 0%, #3E6FE0 45%, #22C7B8 100%); padding: 40px 48px 100px; min-height: 100vh; }
        .tour-free-badge { background: linear-gradient(135deg, #FFD866, #FFB020); color: #3a2400; font-weight: 700; font-size: 11px; letter-spacing: 0.5px; padding: 4px 10px; border-radius: 20px; display: inline-block; }
        .tour-page-glass { background: rgba(255,255,255,0.14); backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px); border: 1px solid rgba(255,255,255,0.28); border-radius: 18px; color: #fff; }
        .tour-page-input { background: rgba(255,255,255,0.18); border: 1px solid rgba(255,255,255,0.35); border-radius: 8px; padding: 9px 12px; font-size: 14px; color: #fff; }
        .tour-page-input::placeholder { color: rgba(255,255,255,0.65); }
        .tour-page-cta { background: linear-gradient(135deg, #FFD866, #FF9D3D); color: #3a1e00; font-weight: 700; border: none; border-radius: 10px; padding: 10px 20px; cursor: pointer; box-shadow: 0 4px 14px rgba(255,157,61,0.4); }
        .tour-page-ghost { background: transparent; color: #fff; border: 1px solid rgba(255,255,255,0.4); border-radius: 8px; padding: 8px 14px; cursor: pointer; font-size: 13px; }
      `}</style>

      <Link to="/tournaments" className="tour-page-ghost" style={{ textDecoration: 'none', display: 'inline-block' }}>← Турниры</Link>

      <p style={{ fontSize: 26, fontWeight: 800, margin: '16px 0 4px', color: '#fff' }}>{tournament.name}</p>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginBottom: 20 }}>
        <span className="tour-free-badge">БЕСПЛАТНО</span>
        <p style={{ fontSize: 14, color: 'rgba(255,255,255,0.85)', margin: 0 }}>
          {tournament.matchFormat} · {FORMAT_LABEL[tournament.bracketFormat]} · {tournament.teamSize}×{tournament.teamSize} ·{' '}
          {tournament.registrations.length}/{tournament.maxTeams} команд · {tournament.status}
        </p>
      </div>

      {tournament.status === 'REGISTRATION_OPEN' && !myRegistration && (
        <div className="tour-page-glass" style={{ padding: 20, marginBottom: 24 }}>
          <p style={{ fontSize: 15, fontWeight: 700, margin: '0 0 10px' }}>Зарегистрировать команду</p>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <select
              className="tour-page-input"
              value={selectedTeam}
              onChange={(e) => setSelectedTeam(e.target.value)}
              style={{ flex: 1, minWidth: 160 }}
            >
              <option value="" style={{ color: '#000' }}>Выберите команду</option>
              {myTeams.map((t) => (
                <option key={t.id} value={t.id} style={{ color: '#000' }}>{t.name}</option>
              ))}
            </select>
            <button className="tour-page-cta" onClick={register}>Зарегистрировать</button>
          </div>

          {isOrganizer && (
            <button className="tour-page-ghost" style={{ marginTop: 10 }} onClick={generate}>
              Построить сетку
            </button>
          )}
          {isDoubleElim && (
            <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', margin: '8px 0 0' }}>
              Double elimination требует ровно {tournament.maxTeams} команд (степень двойки) на момент построения сетки.
            </p>
          )}
        </div>
      )}

      {error && <p style={{ fontSize: 14, color: '#FFDDE0', marginBottom: 16 }}>{error}</p>}

      {hasStandings && standings.length > 0 && (
        <div className="tour-page-glass" style={{ padding: 0, overflow: 'hidden', marginBottom: 24 }}>
          <p style={{ fontSize: 14, fontWeight: 700, margin: 0, padding: '14px 16px 6px' }}>Таблица результатов</p>
          {(tournament.bracketFormat === 'group_stage'
            ? Object.entries(
                standings.reduce((acc, s) => {
                  const g = s.groupIndex ?? 0;
                  (acc[g] ??= []).push(s);
                  return acc;
                }, {} as Record<number, typeof standings>),
              )
            : [[null, standings]] as any
          ).map(([groupIdx, rows]: [string | null, typeof standings]) => (
            <div key={groupIdx ?? 'all'}>
              {groupIdx != null && (
                <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', margin: '10px 16px 4px' }}>Группа {Number(groupIdx) + 1}</p>
              )}
              {rows.sort((a, b) => b.wins - a.wins).map((s, i) => (
                <div key={s.teamId} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 16px', borderTop: '1px solid rgba(255,255,255,0.15)', fontSize: 14 }}>
                  <span>{i + 1}. {s.name}</span>
                  <span style={{ color: 'rgba(255,255,255,0.75)' }}>{s.wins} побед из {s.played}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}

      {presentBrackets.map((bracket) => {
        const bracketMatches = tournament.matches.filter((m) => m.bracket === bracket);
        const isTreeBracket = ['winners', 'losers', 'grand_final', 'bracket_reset'].includes(bracket);

        if (isTreeBracket) {
          return (
            <div key={bracket} style={{ marginBottom: 24 }}>
              <p style={{ fontSize: 15, color: '#fff', margin: '0 0 10px', fontWeight: 700 }}>
                {BRACKET_LABEL[bracket] ?? bracket}
              </p>
              <BracketTree matches={bracketMatches} teamName={teamName} isOrganizer={isOrganizer} onReport={report} />
            </div>
          );
        }

        const rounds = Array.from(new Set(bracketMatches.map((m) => m.round))).sort((a, b) => a - b);
        return (
          <div key={bracket} style={{ marginBottom: 24 }}>
            <p style={{ fontSize: 15, color: '#fff', margin: '0 0 10px', fontWeight: 700 }}>
              {BRACKET_LABEL[bracket] ?? bracket}
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
              {rounds.map((round) => (
                <div key={round}>
                  <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.75)', margin: '0 0 6px' }}>
                    {bracket === 'group_stage' ? `Группа ${Math.floor(round / 100) + 1}, раунд ${(round % 100)}` : `Раунд ${round}`}
                  </p>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    {bracketMatches.filter((m) => m.round === round).map((m) => (
                      <div
                        key={m.id}
                        className={`tour-match ${m.status === 'COMPLETED' ? 'tour-match-winner' : ''}`}
                        style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 16px' }}
                      >
                        <span style={{ fontSize: 15, position: 'relative' }} className={m.winnerTeamId === m.teamAId ? 'tour-name-winner' : m.status === 'COMPLETED' ? 'tour-name-loser' : undefined}>
                          {teamName(m.teamAId)}
                          {m.winnerTeamId === m.teamAId && <EmberBurst kind="ember" />}
                          {m.status === 'COMPLETED' && m.winnerTeamId !== m.teamAId && m.teamAId && <EmberBurst kind="smoke" />}
                        </span>
                        <span style={{ fontSize: 13, color: '#6b5a3f', letterSpacing: 2 }}>{m.teamBId ? 'VS' : '(бай)'}</span>
                        <span style={{ fontSize: 15, position: 'relative' }} className={m.winnerTeamId === m.teamBId ? 'tour-name-winner' : m.status === 'COMPLETED' && m.teamBId ? 'tour-name-loser' : undefined}>
                          {teamName(m.teamBId)}
                          {m.winnerTeamId === m.teamBId && <EmberBurst kind="ember" />}
                          {m.status === 'COMPLETED' && m.winnerTeamId !== m.teamBId && m.teamBId && <EmberBurst kind="smoke" />}
                        </span>
                        {isOrganizer && m.status === 'PENDING' && m.teamAId && m.teamBId && (
                          <div style={{ display: 'flex', gap: 6, marginLeft: 12 }}>
                            <button className="button-ghost" onClick={() => report(m.id, m.teamAId!)}>А победил</button>
                            <button className="button-ghost" onClick={() => report(m.id, m.teamBId!)}>Б победил</button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

