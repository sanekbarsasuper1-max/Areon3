import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, AdminStats, AdminUser, Team, Tournament, HeroDetail, DraftSession } from '../api';
import { HERO_ICON_FALLBACK } from '../components/HeroImage';

export function AdminPanel() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [heroes, setHeroes] = useState<HeroDetail[]>([]);
  const [drafts, setDrafts] = useState<DraftSession[]>([]);
  const [heroSearch, setHeroSearch] = useState('');
  const [syncing, setSyncing] = useState(false);
  const [tab, setTab] = useState<'users' | 'teams' | 'tournaments' | 'heroes' | 'drafts' | 'trials' | 'security' | 'monitoring'>('users');
  const [securityLog, setSecurityLog] = useState<any[]>([]);
  const [reportQueue, setReportQueue] = useState<any[]>([]);
  const [trialTemplates, setTrialTemplates] = useState<any[]>([]);
  const [monitoringOverview, setMonitoringOverview] = useState<any>(null);
  const [onlineNow, setOnlineNow] = useState<any[]>([]);
  const [visits, setVisits] = useState<any[]>([]);
  const [shopItems, setShopItems] = useState<import('../api').ShopItem[]>([]);
  const [activity, setActivity] = useState<any[]>([]);
  const [selectedUserDetail, setSelectedUserDetail] = useState<any>(null);

  useEffect(() => {
    api.adminStats().then(setStats);
    api.adminUsers().then(setUsers);
    api.adminTeams().then(setTeams);
    api.adminTournaments().then(setTournaments);
    api.adminHeroes().then(setHeroes);
    api.adminActiveDrafts().then(setDrafts);
    api.adminTrialTemplates().then(setTrialTemplates);
    api.adminSecurityLog().then(setSecurityLog);
    api.adminReportQueue().then(setReportQueue);
  }, []);

  useEffect(() => {
    if (tab !== 'monitoring') return;
    const load = () => {
      api.adminMonitoringOverview().then(setMonitoringOverview);
      api.adminMonitoringOnline().then(setOnlineNow);
      api.adminMonitoringVisits().then(setVisits);
      api.adminMonitoringActivity().then(setActivity);
    };
    load();
    const interval = setInterval(load, 20_000);
    return () => clearInterval(interval);
  }, [tab]);

  async function openUserDetail(userId: string) {
    setSelectedUserDetail(await api.adminMonitoringUser(userId));
  }

  async function syncHeroes() {
    setSyncing(true);
    try {
      const res = await api.adminSyncHeroes();
      setHeroes(await api.adminHeroes());
      alert(`Синхронизировано героев: ${res.synced}`);
    } finally {
      setSyncing(false);
    }
  }

  async function syncAllMatchups() {
    const res = await api.adminSyncAllMatchups();
    alert(`Запущена синхронизация контрпиков для ${res.queued} героев — займёт около минуты, работает в фоне.`);
  }

  async function toggleHeroCm(heroId: number, current: boolean) {
    await api.adminSetHeroCmAvailable(heroId, !current);
    setHeroes(await api.adminHeroes());
  }

  async function syncItems() {
    setSyncing(true);
    try {
      const res = await api.adminSyncItems();
      alert(`Синхронизирован справочник предметов: ${res.synced}`);
    } finally {
      setSyncing(false);
    }
  }

  async function syncHeroItems(heroId: number) {
    const res = await api.adminSyncHeroItems(heroId);
    alert(`Собрано по ${res.sampledMatches} матчам, найдено предметов: ${res.items.length}`);
    setHeroes(await api.adminHeroes());
  }

  async function toggleTrialActive(id: string, current: boolean) {
    await api.adminUpdateTrialTemplate(id, { active: !current });
    setTrialTemplates(await api.adminTrialTemplates());
  }

  async function updateReportStatus(id: string, status: string) {
    await api.adminUpdateReport(id, status);
    setReportQueue(await api.adminReportQueue());
  }

  async function banUser(id: string) {
    const reason = prompt('Причина бана (необязательно):') ?? undefined;
    await api.adminBanUser(id, reason);
    setUsers(await api.adminUsers());
  }

  async function unbanUser(id: string) {
    await api.adminUnbanUser(id);
    setUsers(await api.adminUsers());
  }

  async function toggleTournamentPermission(id: string, current: boolean) {
    await api.adminSetTournamentPermission(id, !current);
    setUsers(await api.adminUsers());
  }

  async function editName(id: string, current: string) {
    const next = prompt('Новое отображаемое имя:', current);
    if (!next || next === current) return;
    await api.adminEditUser(id, { personaName: next });
    setUsers(await api.adminUsers());
  }

  async function grantShards(id: string, name: string) {
    const amountStr = prompt(`Сколько Arium Plus начислить пользователю ${name}? (отрицательное число — списать)`, '100000');
    if (!amountStr) return;
    const amount = Number(amountStr);
    if (!Number.isFinite(amount) || amount === 0) return;
    const reason = prompt('Причина (для истории операций):', 'Начислено администратором для тестирования') ?? 'Начислено администратором';
    await api.adminAdjustShards(id, amount, reason);
    alert('Готово — баланс обновлён.');
  }

  async function grantItem(id: string, name: string) {
    const items = shopItems.length > 0 ? shopItems : await api.shopItems().then((r) => { setShopItems(r); return r; });
    const list = items.map((it, i) => `${i + 1}. ${it.name}`).join('\n');
    const choice = prompt(`Какой предмет подарить пользователю ${name}?\n\n${list}\n\nВведите номер:`);
    if (!choice) return;
    const item = items[Number(choice) - 1];
    if (!item) return alert('Неверный номер.');
    try {
      await api.adminGrantItem(id, item.id);
      alert(`Готово — «${item.name}» подарен пользователю ${name}.`);
    } catch (e: any) {
      alert(e?.message?.includes('already owns') ? 'У этого пользователя уже есть этот предмет.' : 'Не удалось подарить предмет.');
    }
  }

  async function forceCloseTournament(id: string) {
    if (!confirm('Принудительно закрыть этот турнир? Незавершённые матчи останутся как есть.')) return;
    await api.adminForceCloseTournament(id);
    setTournaments(await api.adminTournaments());
  }

  const tabStyle = (t: string) => ({
    background: tab === t ? 'var(--accent-bg)' : undefined,
    color: tab === t ? 'var(--accent)' : undefined,
  });

  return (
    <div style={{ maxWidth: 1400, margin: '0 auto', padding: '40px 48px 100px' }}>
      <Link to="/profile" className="button-ghost" style={{ textDecoration: 'none' }}>← Профиль</Link>

      <p style={{ fontSize: 18, fontWeight: 500, margin: '16px 0 4px' }}>Админ-панель</p>
      <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: '0 0 18px' }}>
        Доступ определяется только переменной окружения ADMIN_STEAM_ID64 — в интерфейсе это не меняется.
      </p>

      {stats && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0,1fr))', gap: 8, marginBottom: 20 }}>
          <StatCard label="Пользователи" value={stats.users} />
          <StatCard label="Команды" value={stats.teams} />
          <StatCard label="Турниры" value={stats.tournaments} />
          <StatCard label="Матчи (синк)" value={stats.matches} />
          <StatCard label="Герои в базе" value={stats.heroes} />
          <StatCard label="Драфт-сессии" value={stats.draftSessions} />
        </div>
      )}

      <div style={{ marginBottom: 20 }}>
        <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: '0 0 8px' }}>Обслуживание</p>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button className="button-ghost" onClick={syncHeroes} disabled={syncing}>
            {syncing ? 'Синхронизация…' : 'Синхронизировать базу героев (OpenDota)'}
          </button>
          <button className="button-ghost" onClick={syncItems} disabled={syncing}>
            {syncing ? 'Синхронизация…' : 'Синхронизировать справочник предметов'}
          </button>
          <button className="button-ghost" onClick={syncAllMatchups}>
            Синхронизировать контрпики всех героев
          </button>
          <button className="button-ghost" onClick={() => api.adminSyncAbilities().then(() => alert('Способности синхронизированы'))}>
            Синхронизировать способности (иконки для AI Coach)
          </button>
          <button className="button-ghost" onClick={() => api.adminPregenerateWheelConcepts().then((r: any) => alert(
            r.quotaExceeded
              ? `Сгенерировано ${r.generated}, дневной лимит ИИ (Gemini, бесплатный тариф — 20 запросов/день) исчерпан. Осталось ${r.remaining} — нажмите ещё раз завтра, продолжит с того же места.`
              : `Готово: сгенерировано для ${r.generated} героев, у ${r.skipped} уже было`
          ))}>
            Подготовить все билды Wheel of Fate заранее (чтобы колесо не зависало на новом герое)
          </button>
          <button className="button-ghost" onClick={() => api.adminCheckPatchNow().then(() => alert('Проверка версии патча запущена'))}>
            Проверить версию патча сейчас
          </button>
          <button
            className="button-ghost"
            style={{ color: 'var(--danger)' }}
            onClick={() => {
              if (confirm('Откатить версию патча на предыдущую? Это только переключит метку версии — характеристики героев/предметов из старого патча не восстанавливаются, они не сохранялись отдельно.')) {
                api.adminRollbackPatch().then(() => alert('Откачено')).catch(() => alert('Нечего откатывать — нет сохранённой предыдущей версии'));
              }
            }}
          >
            Откатить патч
          </button>
        </div>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '6px 0 0' }}>
          Справочник предметов нужен один раз, до первого сбора сборок по герою — иначе там будут только числовые id.
          Версия патча проверяется автоматически каждые 45 минут — эта кнопка просто не заставляет ждать.
        </p>
      </div>

      <div style={{ display: 'flex', gap: 6, marginBottom: 12, flexWrap: 'wrap' }}>
        <button className="button-ghost" style={tabStyle('users')} onClick={() => setTab('users')}>Пользователи</button>
        <button className="button-ghost" style={tabStyle('teams')} onClick={() => setTab('teams')}>Команды</button>
        <button className="button-ghost" style={tabStyle('tournaments')} onClick={() => setTab('tournaments')}>Турниры</button>
        <button className="button-ghost" style={tabStyle('heroes')} onClick={() => setTab('heroes')}>Герои</button>
        <button className="button-ghost" style={tabStyle('drafts')} onClick={() => setTab('drafts')}>Драфты</button>
        <button className="button-ghost" style={tabStyle('trials')} onClick={() => setTab('trials')}>Trials</button>
        <button className="button-ghost" style={tabStyle('security')} onClick={() => setTab('security')}>Security</button>
        <button className="button-ghost" style={tabStyle('monitoring')} onClick={() => setTab('monitoring')}>Мониторинг</button>
      </div>

      {tab === 'users' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <div className="card" style={{ borderLeft: '3px solid #C9A227', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
            <p style={{ margin: 0, fontSize: 14 }}>
              Начислить или списать Arium Plus, подарить значок — кнопки <strong>«Arium Plus»</strong> и <strong>«Подарить значок»</strong> есть у каждого пользователя в списке ниже.
            </p>
            <button
              className="button-primary"
              onClick={async () => {
                const me = await api.me();
                await grantShards(me.id, me.personaName + ' (вы)');
              }}
            >
              Начислить себе
            </button>
          </div>
          {users.map((u) => (
            <div key={u.id} className="card" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <img src={u.avatarFull} alt="" width={28} height={28} style={{ borderRadius: 6, opacity: u.isBanned ? 0.4 : 1 }} />
                  <div>
                    <p style={{ fontSize: 15, margin: '0 0 2px' }}>
                      {u.personaName}
                      {u.isAdmin && <span className="pill" style={{ background: 'var(--accent-bg)', color: 'var(--accent)', marginLeft: 6 }}>ADMIN</span>}
                      {u.isBanned && <span className="pill" style={{ background: 'var(--danger-bg)', color: 'var(--danger)', marginLeft: 6 }}>BANNED</span>}
                    </p>
                    <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: 0 }}>
                      account_id {u.accountId32} · {u._count.matches} матчей · {u._count.teamMemberships} команд(ы)
                      {!u.statsExposed && ' · статистика закрыта'}
                      {u.isBanned && u.banReason && ` · причина: ${u.banReason}`}
                    </p>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
                  <button className="button-ghost" onClick={() => editName(u.id, u.personaName)}>Имя</button>
                  <button className="button-ghost" onClick={() => grantShards(u.id, u.personaName)}>Arium Plus</button>
                  <button className="button-ghost" onClick={() => grantItem(u.id, u.personaName)}>Подарить значок</button>
                  {!u.isAdmin && (
                    <button className="button-ghost" onClick={() => toggleTournamentPermission(u.id, u.canCreateFreeTournaments)}>
                      {u.canCreateFreeTournaments ? 'Отозвать турниры' : 'Разрешить турниры'}
                    </button>
                  )}
                  {u.isBanned ? (
                    <button className="button-ghost" onClick={() => unbanUser(u.id)}>Разбанить</button>
                  ) : (
                    !u.isAdmin && <button className="button-ghost" style={{ color: 'var(--danger)' }} onClick={() => banUser(u.id)}>Забанить</button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === 'teams' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {teams.map((t) => (
            <div key={t.id} className="card" style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 15 }}>{t.name}</span>
              <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{t.members.length} игроков</span>
            </div>
          ))}
        </div>
      )}

      {tab === 'tournaments' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {tournaments.map((t) => (
            <div key={t.id} className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 15 }}>{t.name}</span>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{t.status} · {t.registrations.length}/{t.maxTeams}</span>
                {t.status !== 'COMPLETED' && t.status !== 'CANCELLED' && (
                  <button className="button-ghost" style={{ color: 'var(--danger)' }} onClick={() => forceCloseTournament(t.id)}>
                    Закрыть принудительно
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === 'heroes' && (
        <div>
          <input
            placeholder="Поиск героя"
            value={heroSearch}
            onChange={(e) => setHeroSearch(e.target.value)}
            style={{ width: '100%', background: 'var(--card)', border: '0.5px solid var(--border)', borderRadius: 6, padding: '8px 10px', fontSize: 14, color: 'var(--text)', marginBottom: 10 }}
          />
          <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '0 0 10px' }}>
            По умолчанию все герои доступны в Captain's Mode — реального курируемого списка исключений (например, для только что вышедших героев) нет,
            это ручное переключение конкретных случаев.
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {heroes
              .filter((h) => h.localizedName.toLowerCase().includes(heroSearch.toLowerCase()))
              .map((h) => (
                <div key={h.id} className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <img src={h.iconUrl} onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = HERO_ICON_FALLBACK; }} alt="" style={{ width: 40, aspectRatio: '16/9', objectFit: 'cover', borderRadius: 4 }} />
                    <span style={{ fontSize: 15 }}>{h.localizedName}</span>
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button className="button-ghost" style={{ fontSize: 12 }} onClick={() => syncHeroItems(h.id)}>
                      Собрать предметы
                    </button>
                    <button
                      className="button-ghost"
                      style={{ color: h.captainsModeAvailable === false ? 'var(--danger)' : 'var(--accent)' }}
                      onClick={() => toggleHeroCm(h.id, h.captainsModeAvailable !== false)}
                    >
                      {h.captainsModeAvailable === false ? 'Недоступен в CM' : 'Доступен в CM'}
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {tab === 'drafts' && (
        <div>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '0 0 10px' }}>
            Любая активная или ожидающая партия — не только ваши собственные. Отмена хода доступна прямо на странице наблюдения.
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {drafts.length === 0 && <p style={{ fontSize: 14, color: 'var(--text-muted)' }}>Сейчас нет активных партий.</p>}
            {drafts.map((d) => (
              <Link
                key={d.id}
                to={`/draft-trainer/${d.id}`}
                className="card"
                style={{ display: 'flex', justifyContent: 'space-between', textDecoration: 'none', color: 'inherit' }}
              >
                <span style={{ fontSize: 15 }}>
                  {d.opponentType === 'matchmaking' ? 'Матч (поиск)' : d.opponentType === 'friend' ? 'С другом' : d.opponentType === 'ai' ? 'Против бота' : 'Соло'}
                </span>
                <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>
                  {d.status === 'waiting_for_opponent' ? 'Ждём соперника' : `Шаг ${d.actions.length}/${d.sequence.length}`}
                </span>
              </Link>
            ))}
          </div>
        </div>
      )}

      {tab === 'trials' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '0 0 10px' }}>
            Только COMMON/RARE/EPIC/LEGENDARY-параметры и вкл/выкл редактируются здесь — тип условия (`code`) привязан
            к конкретной функции-оценщику в коде, менять его через панель нельзя.
          </p>
          {trialTemplates.map((t) => (
            <div key={t.id} className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <p style={{ fontSize: 15, margin: '0 0 2px' }}>
                  {t.title}
                  <span className="pill" style={{ marginLeft: 8, fontSize: 11 }}>{t.difficulty}</span>
                </p>
                <p style={{ fontSize: 12, color: 'var(--text-secondary)', margin: 0 }}>
                  {t.category} · {t.code} · +{t.rewardShards} Shards · выполнено {t.completionCount ?? 0} раз
                </p>
              </div>
              <button
                className="button-ghost"
                style={{ color: t.active ? 'var(--accent)' : 'var(--danger)' }}
                onClick={() => toggleTrialActive(t.id, t.active)}
              >
                {t.active ? 'Активно' : 'Отключено'}
              </button>
            </div>
          ))}
        </div>
      )}

      {tab === 'security' && (
        <div>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: '0 0 10px' }}>Очередь жалоб на игроков</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 24 }}>
            {reportQueue.map((r) => (
              <div key={r.id} className="card">
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                  <p style={{ fontSize: 14, margin: 0 }}>
                    <strong>{r.reporter?.personaName}</strong> → <strong>{r.reported?.personaName}</strong>
                  </p>
                  <span className="pill" style={{ fontSize: 11 }}>{r.category}</span>
                </div>
                <p style={{ fontSize: 14, margin: '0 0 8px', color: 'var(--text-secondary)' }}>{r.description}</p>
                <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                  {['PENDING', 'REVIEWED', 'ACTION_TAKEN', 'DISMISSED'].map((s) => (
                    <button
                      key={s}
                      className="button-ghost"
                      style={{ fontSize: 12, background: r.status === s ? 'var(--accent-bg)' : undefined, color: r.status === s ? 'var(--accent)' : undefined }}
                      onClick={() => updateReportStatus(r.id, s)}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            ))}
            {reportQueue.length === 0 && <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>Жалоб пока нет.</p>}
          </div>

          <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: '0 0 10px' }}>Журнал безопасности (последние 200)</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4, maxHeight: 400, overflowY: 'auto' }}>
            {securityLog.map((e) => (
              <div key={e.id} className="card" style={{ padding: '8px 12px', display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                <span>
                  <strong>{e.type}</strong>{e.user ? ` — ${e.user.personaName}` : ''}
                  {e.metadata ? ` · ${JSON.stringify(e.metadata)}` : ''}
                </span>
                <span style={{ color: 'var(--text-muted)' }}>{new Date(e.createdAt).toLocaleString('ru-RU')}</span>
              </div>
            ))}
            {securityLog.length === 0 && <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>Событий пока нет.</p>}
          </div>
        </div>
      )}

      {tab === 'monitoring' && (
        <div>
          {monitoringOverview && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px,1fr))', gap: 10, marginBottom: 20 }}>
              <StatCard label="Онлайн сейчас" value={monitoringOverview.onlineNow} />
              <StatCard label="Пользователей сегодня" value={monitoringOverview.usersToday} />
              <StatCard label="Новых сегодня" value={monitoringOverview.newUsersToday} />
              <StatCard label="Сессий сегодня" value={monitoringOverview.sessionsToday} />
              <StatCard label="Ср. сессия (сек)" value={monitoringOverview.avgSessionSec} />
              <StatCard label="Активны за 24ч" value={monitoringOverview.activeLast24h} />
            </div>
          )}

          <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: '0 0 10px' }}>Онлайн сейчас</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4, marginBottom: 24 }}>
            {onlineNow.map((u) => (
              <div key={u.id} className="card" style={{ padding: '8px 12px', display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }} onClick={() => openUserDetail(u.id)}>
                <span>{u.status === 'online' ? '🟢' : u.status === 'idle' ? '🟡' : '⚫'}</span>
                <img src={u.avatarFull} alt="" style={{ width: 24, height: 24, borderRadius: 4 }} />
                <span style={{ fontSize: 13, flex: 1 }}>{u.personaName}</span>
                <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{u.currentPage ?? '—'}</span>
                <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{new Date(u.lastSeenAt).toLocaleTimeString('ru-RU')}</span>
              </div>
            ))}
            {onlineNow.length === 0 && <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>Сейчас никого нет онлайн.</p>}
          </div>

          <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: '0 0 10px' }}>Посещения (последние)</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4, marginBottom: 24, maxHeight: 300, overflowY: 'auto' }}>
            {visits.map((v) => (
              <div key={v.id} className="card" style={{ padding: '8px 12px', display: 'flex', justifyContent: 'space-between', fontSize: 12, cursor: 'pointer' }} onClick={() => openUserDetail(v.userId)}>
                <span>{v.user?.personaName ?? v.userId}</span>
                <span style={{ color: 'var(--text-secondary)' }}>{new Date(v.startedAt).toLocaleString('ru-RU')} · {Math.round(v.durationSec / 60)} мин · {v.pageViews} стр.</span>
              </div>
            ))}
            {visits.length === 0 && <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>Посещений пока нет.</p>}
          </div>

          <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: '0 0 10px' }}>История действий (последние 200)</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4, maxHeight: 300, overflowY: 'auto', marginBottom: 24 }}>
            {activity.map((e) => (
              <div key={e.id} className="card" style={{ padding: '8px 12px', display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                <span><strong>{e.user?.personaName}</strong> — {e.type}{e.page ? ` (${e.page})` : ''}</span>
                <span style={{ color: 'var(--text-muted)' }}>{new Date(e.createdAt).toLocaleString('ru-RU')}</span>
              </div>
            ))}
            {activity.length === 0 && <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>Событий пока нет.</p>}
          </div>

          {selectedUserDetail && (
            <div className="card" style={{ padding: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                <p style={{ fontSize: 15, fontWeight: 500, margin: 0 }}>
                  {selectedUserDetail.user.personaName} — {selectedUserDetail.totalSessions} визитов, {Math.round(selectedUserDetail.totalTimeSec / 60)} мин всего
                </p>
                <button className="button-ghost" style={{ fontSize: 12 }} onClick={() => setSelectedUserDetail(null)}>Закрыть</button>
              </div>
              <p style={{ fontSize: 12, color: 'var(--text-secondary)', margin: '0 0 8px' }}>
                Регистрация: {new Date(selectedUserDetail.user.createdAt).toLocaleDateString('ru-RU')} · Steam ID: {selectedUserDetail.user.steamId64}
              </p>
              <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 6px' }}>Последние действия</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4, maxHeight: 220, overflowY: 'auto' }}>
                {selectedUserDetail.recentActivity.map((e: any) => (
                  <div key={e.id} style={{ fontSize: 12, display: 'flex', justifyContent: 'space-between' }}>
                    <span>{e.type}{e.page ? ` (${e.page})` : ''}</span>
                    <span style={{ color: 'var(--text-muted)' }}>{new Date(e.createdAt).toLocaleString('ru-RU')}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  return (
    <div className="card">
      <p style={{ fontSize: 12, color: 'var(--text-secondary)', margin: '0 0 4px' }}>{label}</p>
      <p style={{ fontSize: 21, fontWeight: 600, margin: 0 }}>{value}</p>
    </div>
  );
}
