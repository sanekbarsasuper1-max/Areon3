import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, VoiceRoom } from '../api';

export function VoicePage() {
  const [rooms, setRooms] = useState<VoiceRoom[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  async function load() {
    setLoading(true);
    try {
      setRooms(await api.voiceRooms());
    } catch (e: any) {
      setError(e?.message ?? 'Не удалось загрузить список комнат');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function create() {
    if (!name.trim()) return;
    setCreating(true);
    setError(null);
    try {
      const room = await api.voiceCreateRoom(name.trim(), isPrivate);
      navigate(`/voice/${room.id}`);
    } catch (e: any) {
      setError(e?.message ?? 'Не удалось создать комнату');
    } finally {
      setCreating(false);
    }
  }

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '40px 24px 100px' }}>
      <p style={{ fontSize: 21, fontWeight: 500, margin: '0 0 4px' }}>🎙️ AREON VOICE</p>
      <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 24px' }}>
        Голосовые комнаты прямо на сайте — никакого стороннего приложения
      </p>

      <div className="card" style={{ padding: 16, marginBottom: 24, display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Название комнаты"
          style={{ flex: 1, minWidth: 180, background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: 8, padding: '10px 12px', color: 'var(--text)' }}
        />
        <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: 'var(--text-secondary)' }}>
          <input type="checkbox" checked={isPrivate} onChange={(e) => setIsPrivate(e.target.checked)} />
          Приватная
        </label>
        <button className="button-primary" onClick={create} disabled={creating || !name.trim()}>
          {creating ? '…' : 'Создать комнату'}
        </button>
      </div>

      {error && <p style={{ color: 'var(--danger)', fontSize: 13, marginBottom: 16 }}>{error}</p>}

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Загрузка…</p>
      ) : rooms.length === 0 ? (
        <p style={{ color: 'var(--text-muted)' }}>Пока нет ни одной комнаты — создайте первую.</p>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {rooms.map((r) => (
            <div key={r.id} className="card" style={{ padding: 14, display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{ fontSize: 20 }}>{r.isPrivate ? '🔒' : '🔊'}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ fontSize: 15, fontWeight: 600, margin: 0 }}>{r.name}</p>
                <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '2px 0 0' }}>
                  Хост: {r.createdBy.personaName}
                  {r.participantCount != null && <> · {r.participantCount} {r.participantCount === 1 ? 'участник' : 'участников'}</>}
                </p>
              </div>
              <button className="button-primary" onClick={() => navigate(`/voice/${r.id}`)}>Войти</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
