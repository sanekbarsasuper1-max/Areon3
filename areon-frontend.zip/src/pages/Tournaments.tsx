import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, Tournament, Me, Team } from '../api';
import { useAudio } from '../audio/AudioContext';

const statusLabel: Record<Tournament['status'], string> = {
  DRAFT: 'Черновик',
  REGISTRATION_OPEN: 'Регистрация открыта',
  IN_PROGRESS: 'Идёт сейчас',
  COMPLETED: 'Завершён',
  CANCELLED: 'Отменён администратором',
};

const FORMAT_LABEL: Record<Tournament['bracketFormat'], string> = {
  single_elimination: 'Одиночное выбывание',
  double_elimination: 'Двойное выбывание',
  round_robin: 'Круговой турнир',
  swiss: 'Швейцарская система',
  group_stage: 'Группы + плей-офф',
};

// Requirement 6: purple → blue → teal, bright and game-y, deliberately
// far from the near-black background every other Areon page uses —
// Tournaments is meant to feel like its own vivid arena, not one more
// dark page. Kept out of index.css on purpose: this palette belongs
// to this one section, not the whole site.
const TOURNAMENTS_STYLES = `
@keyframes tourGlowPulse {
  0%, 100% { box-shadow: 0 0 24px 2px rgba(255,255,255,0.15); }
  50% { box-shadow: 0 0 36px 6px rgba(255,255,255,0.28); }
}
@keyframes tourFloat {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-6px); }
}
.tour-page {
  background: linear-gradient(135deg, #5B3FD9 0%, #3E6FE0 45%, #22C7B8 100%);
  padding: 40px 48px 100px; min-height: 100vh;
}
.tour-glass {
  background: rgba(255,255,255,0.14); backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
  border: 1px solid rgba(255,255,255,0.28); border-radius: 18px;
}
.tour-card-hero {
  background: rgba(255,255,255,0.16); backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
  border: 1px solid rgba(255,255,255,0.3); border-radius: 18px; color: #fff;
  transition: transform 0.15s ease, box-shadow 0.15s ease;
}
.tour-card-hero:hover { transform: translateY(-3px); animation: tourGlowPulse 1.6s ease-in-out infinite; }
.tour-free-badge {
  background: linear-gradient(135deg, #FFD866, #FFB020); color: #3a2400; font-weight: 700; font-size: 11px;
  letter-spacing: 0.5px; padding: 4px 10px; border-radius: 20px; display: inline-block;
}
.tour-filter { color: #fff; opacity: 0.7; border: 1px solid rgba(255,255,255,0.35); background: transparent; }
.tour-filter.active { opacity: 1; background: rgba(255,255,255,0.22); border-color: rgba(255,255,255,0.6); }
.tour-input {
  background: rgba(255,255,255,0.18); border: 1px solid rgba(255,255,255,0.35); border-radius: 8px;
  padding: 9px 12px; font-size: 14px; color: #fff;
}
.tour-input::placeholder { color: rgba(255,255,255,0.65); }
.tour-cta {
  background: linear-gradient(135deg, #FFD866, #FF9D3D); color: #3a1e00; font-weight: 700; border: none;
  border-radius: 10px; padding: 10px 20px; cursor: pointer; box-shadow: 0 4px 14px rgba(255,157,61,0.4);
}
.tour-cta:disabled { opacity: 0.6; cursor: default; }
`;

type FilterKey = 'all' | 'upcoming' | 'live' | 'completed' | 'mine';

export function Tournaments() {
  const [list, setList] = useState<Tournament[]>([]);
  const [me, setMe] = useState<Me | null>(null);
  const [myTeams, setMyTeams] = useState<Team[]>([]);
  const [name, setName] = useState('');
  const [filter, setFilter] = useState<FilterKey>('all');
  const { playSFX } = useAudio();

  useEffect(() => {
    playSFX('nav_tournament_open');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const [maxTeams, setMaxTeams] = useState(8);
  const [bracketFormat, setBracketFormat] = useState<'single_elimination' | 'double_elimination' | 'round_robin' | 'swiss' | 'group_stage'>('single_elimination');
  const [teamSize, setTeamSize] = useState(5);
  const [swissRounds, setSwissRounds] = useState<number | ''>('');
  const [groupCount, setGroupCount] = useState(2);
  const [advancingPerGroup, setAdvancingPerGroup] = useState(2);
  const [createError, setCreateError] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const navigate = useNavigate();

  async function load() {
    const [tournaments, meData, teams] = await Promise.all([api.tournaments(), api.me(), api.myTeams()]);
    setList(tournaments);
    setMe(meData);
    setMyTeams(teams);
  }

  useEffect(() => {
    load();
  }, []);

  async function create() {
    setCreateError(null);
    // Requirement: this used to just silently `return` here with zero
    // visible feedback — clicking "Создать" with an empty name looked
    // EXACTLY like a broken button, because nothing on screen ever
    // told you why nothing happened.
    if (!name.trim()) {
      setCreateError('Укажите название турнира');
      return;
    }
    setCreating(true);
    try {
      const t = await api.createTournament({
        name: name.trim(), maxTeams, bracketFormat, teamSize,
        swissRounds: bracketFormat === 'swiss' && swissRounds !== '' ? Number(swissRounds) : undefined,
        groupCount: bracketFormat === 'group_stage' ? groupCount : undefined,
        advancingPerGroup: bracketFormat === 'group_stage' ? advancingPerGroup : undefined,
      });
      navigate(`/tournaments/${t.id}`);
    } catch (e: any) {
      // Same root problem, different cause — a rejected request with
      // no catch at all is just as silent as the empty-name case was.
      setCreateError(e?.message ?? 'Не удалось создать турнир');
    } finally {
      setCreating(false);
    }
  }

  const filtered = list.filter((t) => {
    if (filter === 'upcoming') return t.status === 'REGISTRATION_OPEN' || t.status === 'DRAFT';
    if (filter === 'live') return t.status === 'IN_PROGRESS';
    if (filter === 'completed') return t.status === 'COMPLETED';
    if (filter === 'mine') {
      const myTeamIds = new Set(myTeams.map((t) => t.id));
      return me != null && (t.createdByUserId === me.id || t.registrations.some((r) => myTeamIds.has(r.teamId)));
    }
    return true;
  });

  const FILTERS: { key: FilterKey; label: string }[] = [
    { key: 'all', label: 'Все' },
    { key: 'upcoming', label: 'Предстоящие' },
    { key: 'live', label: 'Идут сейчас' },
    { key: 'completed', label: 'Завершённые' },
    { key: 'mine', label: 'Мои турниры' },
  ];

  return (
    <div className="tour-page">
      <style>{TOURNAMENTS_STYLES}</style>
      <p style={{ fontSize: 30, fontWeight: 800, margin: '0 0 4px', color: '#fff', letterSpacing: -0.5 }}>TOURNAMENTS</p>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: 10, marginBottom: 24 }}>
        <p style={{ fontSize: 14, color: 'rgba(255,255,255,0.8)', margin: 0 }}>Турниры Areon — бесплатное участие для всех</p>
        <Link to="/tournaments-bracket-preview" className="tour-filter" style={{ textDecoration: 'none', borderRadius: 20, padding: '7px 16px', fontSize: 13 }}>
          🔍 Предпросмотр сетки
        </Link>
      </div>

      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 24 }}>
        {FILTERS.map((f) => (
          <button
            key={f.key}
            className={`tour-filter ${filter === f.key ? 'active' : ''}`}
            style={{ borderRadius: 20, padding: '7px 16px', fontSize: 13, cursor: 'pointer' }}
            onClick={() => setFilter(f.key)}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16, marginBottom: 32 }}>
        {filtered.length === 0 && (
          <p style={{ fontSize: 14, color: 'rgba(255,255,255,0.75)' }}>Турниров в этой категории пока нет.</p>
        )}
        {filtered.map((t, i) => {
          const accents = ['#FF6EC7', '#22C7B8', '#7C6FF0', '#FFD866', '#4FC3F7'];
          const accent = accents[i % accents.length];
          const freeSlots = t.maxTeams - t.registrations.length;
          return (
            <Link key={t.id} to={`/tournaments/${t.id}`} style={{ textDecoration: 'none' }}>
              <div className="tour-card-hero" style={{ padding: 20, height: '100%', display: 'flex', flexDirection: 'column', gap: 10 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div style={{ width: 44, height: 44, borderRadius: 12, background: accent, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, fontWeight: 800 }}>
                    🏆
                  </div>
                  <span className="tour-free-badge">БЕСПЛАТНО</span>
                </div>
                <p style={{ fontSize: 17, fontWeight: 700, margin: 0 }}>{t.name}</p>
                <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.75)', margin: 0 }}>
                  {FORMAT_LABEL[t.bracketFormat]} · {t.teamSize}×{t.teamSize}
                </p>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 'auto', paddingTop: 8 }}>
                  <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.85)' }}>
                    {t.registrations.length}/{t.maxTeams} команд
                    {t.status === 'REGISTRATION_OPEN' && freeSlots > 0 && ` · ${freeSlots} своб.`}
                  </span>
                  <span style={{ fontSize: 11, padding: '3px 10px', borderRadius: 20, background: 'rgba(255,255,255,0.2)', fontWeight: 600 }}>
                    {statusLabel[t.status]}
                  </span>
                </div>
              </div>
            </Link>
          );
        })}
      </div>

      <div className="tour-glass" style={{ padding: 24 }}>
        <p style={{ fontSize: 15, fontWeight: 700, color: '#fff', margin: '0 0 12px' }}>Создать турнир</p>
        {!(me?.isAdmin || me?.canCreateFreeTournaments) ? (
          <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.8)' }}>
            Создание турниров доступно только администратору или пользователям с разрешением.
          </p>
        ) : (
        <>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 8 }}>
          <input
            className="tour-input"
            placeholder="Название"
            value={name}
            onChange={(e) => setName(e.target.value)}
            style={{ flex: 1, minWidth: 140 }}
          />
          <input
            className="tour-input"
            type="number"
            min={1}
            title="Размер команды (1 = 1×1, 2 = 2×2 и т.д.)"
            value={teamSize}
            onChange={(e) => setTeamSize(Number(e.target.value))}
            style={{ width: 60 }}
          />
          <input
            className="tour-input"
            type="number"
            min={2}
            value={maxTeams}
            onChange={(e) => setMaxTeams(Number(e.target.value))}
            style={{ width: 70 }}
          />
          <select
            className="tour-input"
            value={bracketFormat}
            onChange={(e) => setBracketFormat(e.target.value as any)}
          >
            <option value="single_elimination" style={{ color: '#000' }}>Одиночное выбывание</option>
            <option value="double_elimination" style={{ color: '#000' }}>Двойное выбывание</option>
            <option value="round_robin" style={{ color: '#000' }}>Круговой турнир</option>
            <option value="swiss" style={{ color: '#000' }}>Швейцарская система</option>
            <option value="group_stage" style={{ color: '#000' }}>Группы + плей-офф</option>
          </select>
        </div>

        {bracketFormat === 'swiss' && (
          <div style={{ marginBottom: 8 }}>
            <input
              className="tour-input"
              type="number"
              min={1}
              placeholder="Число раундов (по умолчанию — авто)"
              value={swissRounds}
              onChange={(e) => setSwissRounds(e.target.value === '' ? '' : Number(e.target.value))}
              style={{ width: 260 }}
            />
          </div>
        )}

        {bracketFormat === 'group_stage' && (
          <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: 'rgba(255,255,255,0.85)' }}>
              Групп:
              <input className="tour-input" type="number" min={1} value={groupCount} onChange={(e) => setGroupCount(Number(e.target.value))} style={{ width: 50 }} />
            </label>
            <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: 'rgba(255,255,255,0.85)' }}>
              Проходят из группы:
              <input className="tour-input" type="number" min={1} value={advancingPerGroup} onChange={(e) => setAdvancingPerGroup(Number(e.target.value))} style={{ width: 50 }} />
            </label>
          </div>
        )}

        <button className="tour-cta" onClick={create} disabled={creating}>
          {creating ? '…' : 'Создать турнир'}
        </button>
        {createError && (
          <p style={{ fontSize: 13, color: '#FFDDE0', margin: '8px 0 0' }}>{createError}</p>
        )}
        <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.65)', margin: '8px 0 0' }}>
          Double elimination требует ровно 4/8/16/32 зарегистрированных команд.
          Размер команды — 1 для турнира 1×1, 2 для 2×2 и т.д. Все турниры Areon бесплатны.
        </p>
        </>
        )}
      </div>
    </div>
  );
}

