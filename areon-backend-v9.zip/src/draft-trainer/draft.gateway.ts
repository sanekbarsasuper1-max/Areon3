import {
  OnGatewayConnection,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma.service';

/**
 * Live updates for Draft Trainer sessions — replaces the frontend's 2s
 * poll for 'friend'/'matchmaking'/'ai' sessions with a proper push. Each
 * draft session is its own Socket.IO room (room name = session id); a
 * client joins only after we've verified they're actually one of the
 * two real participants in that session, using the exact same
 * areon_token cookie the REST API trusts — not a separate, weaker auth
 * path just because it's a socket.
 */
@WebSocketGateway({
  cors: { origin: process.env.FRONTEND_URL, credentials: true },
})
export class DraftGateway implements OnGatewayConnection {
  @WebSocketServer() server!: Server;

  constructor(
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
    private readonly prisma: PrismaService,
  ) {}

  handleConnection(client: Socket) {
    const token = parseCookie(client.handshake.headers.cookie, 'areon_token');
    if (!token) {
      client.disconnect();
      return;
    }
    try {
      const payload = this.jwt.verify(token, { secret: this.config.get('JWT_SECRET') });
      client.data.userId = payload.sub;
    } catch {
      client.disconnect();
    }
  }

  @SubscribeMessage('join')
  async handleJoin(client: Socket, sessionId: string) {
    const userId = client.data.userId;
    if (!userId) return;

    const [session, user] = await Promise.all([
      this.prisma.draftSession.findUnique({ where: { id: sessionId } }),
      this.prisma.user.findUnique({ where: { id: userId } }),
    ]);
    if (!session) return;

    const isParticipant = session.createdByUserId === userId || session.participantSecondUserId === userId;

    // Admins can spectate any session live, not just ones they're
    // playing in — that's the whole point of "admin can observe any
    // draft" and is what makes the admin-only undo below actually
    // usable (an admin needs to be watching to know when to use it).
    const isAdmin = !!user?.isAdmin;

    if (isParticipant || isAdmin) {
      client.join(sessionId);
    }
  }

  /**
   * Called by DraftTrainerService after any state change. BigInt fields
   * (sourceProMatchId) don't serialize through Socket.IO's JSON layer
   * any more than they do through Nest's HTTP one — same fix as
   * MatchesService.serialize(), applied here too.
   */
  emitUpdate(sessionId: string, session: Record<string, any>) {
    const payload = {
      ...session,
      sourceProMatchId: session.sourceProMatchId != null ? session.sourceProMatchId.toString() : null,
    };
    this.server.to(sessionId).emit('draft:update', payload);
  }
}

function parseCookie(cookieHeader: string | undefined, name: string): string | null {
  if (!cookieHeader) return null;
  const match = cookieHeader.split(';').map((c) => c.trim()).find((c) => c.startsWith(`${name}=`));
  return match ? decodeURIComponent(match.split('=').slice(1).join('=')) : null;
}
