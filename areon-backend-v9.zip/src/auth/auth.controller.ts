import { Controller, Get, Post, Req, Res, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ConfigService } from '@nestjs/config';
import { Response } from 'express';
import { AuthService } from './auth.service';
import { SteamProfile } from './steam.strategy';
import { PrismaService } from '../prisma.service';
import { Public } from './public.decorator';

@Controller('auth')
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly config: ConfigService,
    private readonly prisma: PrismaService,
  ) {}

  // GET /auth/steam — kicks off the redirect to Steam's login page.
  // Passport handles the redirect itself; this handler body never runs.
  @Public()
  @Get('steam')
  @UseGuards(AuthGuard('steam'))
  steamLogin() {}

  // GET /auth/steam/return — Steam redirects back here after login.
  // Must be @Public(): there's no session cookie yet at this point —
  // that's exactly what this handler is about to create.
  @Public()
  @Get('steam/return')
  @UseGuards(AuthGuard('steam'))
  async steamReturn(@Req() req: { user: SteamProfile }, @Res() res: Response) {
    const { accessToken, user } = await this.authService.loginOrCreate(req.user);
    const frontendUrl = this.config.get('FRONTEND_URL');

    // A banned user never gets a working cookie at all — logging in
    // successfully and then hitting 403 on the very first request
    // would look like a bug, not an explained ban.
    if (user.isBanned) {
      res.redirect(`${frontendUrl}/banned`);
      return;
    }

    res.cookie('areon_token', accessToken, {
      httpOnly: true,
      // Frontend and backend live on two different origins (separate
      // subdomains), so this cookie must be sent on cross-site fetch
      // requests — SameSite=Lax blocks that (it only allows top-level
      // navigations cross-site). 'none' requires secure:true, which we
      // already compute below whenever the frontend is on https.
      sameSite: 'none',
      // Was a dead comment ("secure: true in production") for a while —
      // actually wired up now. Derived from APP_URL's protocol rather
      // than a separate NODE_ENV check, so it can't drift out of sync
      // with the URL Steam's OpenID return actually points at.
      secure: frontendUrl?.startsWith('https://') ?? false,
    });

    // Redirect to the FRONTEND's origin, not a relative path on this API —
    // the SPA and this backend are two separate apps on two separate
    // ports/domains, so a bare "/profile" would 404 against the API itself.
    const target = user.statsExposed ? '/profile' : '/onboarding/expose-data';
    res.redirect(`${frontendUrl}${target}`);
  }

  // Lets the SPA ask "who am I / is my data exposed" on load without
  // re-running the Steam API check every time — that's what
  // /players/me/stats-status is for, triggered explicitly.
  @Get('me')
  async me(@Req() req: any) {
    const user = await this.prisma.user.findUnique({ where: { id: req.user.sub } });
    if (!user) return null;
    return {
      id: user.id,
      personaName: user.personaName,
      avatarFull: user.avatarFull,
      statsExposed: user.statsExposed,
      isAdmin: user.isAdmin,
    };
  }

  /**
   * A real logout, not just a client-side cookie clear: bumping
   * tokenVersion invalidates this token (and any other copy of it,
   * e.g. one an attacker had already stolen) immediately, server-side
   * — see JwtStrategy.validate()'s matching check. Clearing the cookie
   * on top of that is just good hygiene for the normal case.
   */
  @Post('logout')
  async logout(@Req() req: any, @Res() res: Response) {
    await this.prisma.user.update({
      where: { id: req.user.sub },
      data: { tokenVersion: { increment: 1 } },
    });
    res.clearCookie('areon_token');
    res.status(204).send();
  }
}

