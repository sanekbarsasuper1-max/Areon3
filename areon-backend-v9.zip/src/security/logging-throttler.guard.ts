import { ExecutionContext, Inject, Injectable } from '@nestjs/common';
import { ThrottlerGuard } from '@nestjs/throttler';
import { SecurityLogService } from './security-log.service';

/**
 * Same rate-limiting behavior as the plain ThrottlerGuard — this only
 * adds one thing: a SecurityEvent row before rejecting, so a burst of
 * rate-limit trips is actually visible somewhere (audit finding
 * MEDIUM #7), not just a silent 429 the admin never sees evidence of.
 */
@Injectable()
export class LoggingThrottlerGuard extends ThrottlerGuard {
  @Inject(SecurityLogService)
  private readonly securityLog!: SecurityLogService;

  protected async throwThrottlingException(context: ExecutionContext, detail: any): Promise<void> {
    const req = context.switchToHttp().getRequest();
    await this.securityLog.log('RATE_LIMITED', {
      userId: req.user?.sub,
      ip: req.ip,
      metadata: { route: req.originalUrl ?? req.url },
    });
    return super.throwThrottlingException(context, detail);
  }
}
