import { Injectable, Logger } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';
import { firstValueFrom } from 'rxjs';

@Injectable()
export class PlayersService {
  private readonly logger = new Logger(PlayersService.name);

  constructor(
    private readonly http: HttpService,
    private readonly config: ConfigService,
  ) {}

  /**
   * Determines whether a player currently has "Expose Public Match Data"
   * enabled in Dota 2.
   *
   * We call the official Steam Web API directly (IDOTA2Match_570/GetMatchHistory)
   * rather than OpenDota for this specific check. OpenDota can still be
   * holding matches it scraped or parsed before the user disabled the
   * setting, which would make an OpenDota-only check report a false
   * positive for someone who has since turned sharing off.
   *
   * IMPORTANT — verify before relying on this in production:
   * Valve does not publish a documented response shape for a blocked
   * account. The community-observed behaviour is a non-1 `result.status`
   * with a human-readable `result.statusDetail` explaining the account
   * hasn't allowed match history access. Confirm the exact status code
   * against a real test account (one with the setting off) before
   * shipping — undocumented Valve API behaviour has changed without
   * notice before, most recently around the Immortal Draft match-hiding
   * change.
   */
  async checkStatsExposed(accountId32: number): Promise<boolean> {
    const apiKey = this.config.get<string>('STEAM_API_KEY');
    const url = 'https://api.steampowered.com/IDOTA2Match_570/GetMatchHistory/v1/';

    try {
      const { data } = await firstValueFrom(
        this.http.get(url, {
          params: {
            key: apiKey,
            account_id: accountId32,
            matches_requested: 1,
          },
          timeout: 8000,
        }),
      );

      const status = data?.result?.status;

      if (status !== 1) {
        this.logger.debug(
          `account_id=${accountId32} appears blocked (status=${status}, ` +
            `detail=${data?.result?.statusDetail ?? 'n/a'})`,
        );
        return false;
      }

      return true;
    } catch (err) {
      this.logger.warn(
        `Steam API check failed for account_id=${accountId32}: ${err.message}`,
      );
      // Fail closed: an API error should read as "can't confirm access"
      // rather than silently telling the user their stats are available
      // when we don't actually know that.
      return false;
    }
  }
}
