import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { TRIAL_DATABASE } from './trial-database';

const CYCLE_DAYS = 5;
const TRIALS_PER_CYCLE = 10;
// Target spread across difficulty — filled best-effort from whatever's
// actually available (the seed pool is intentionally a starting point,
// not "hundreds", per the honest scope note in trial-database.ts;
// admins grow it via the panel without a code change).
const DIFFICULTY_TARGET: Record<string, number> = { COMMON: 4, RARE: 3, EPIC: 2, LEGENDARY: 1 };
// How many of a user's own past cycles to avoid repeating templates
// from, when there's enough pool variety to honor it.
const AVOID_REPEATS_LAST_N_CYCLES = 2;
const HERO_HISTORY_SAMPLE = 20; // "давно не играли" = absent from this many recent matches

@Injectable()
export class TrialGeneratorService {
  private readonly logger = new Logger(TrialGeneratorService.name);

  constructor(private readonly prisma: PrismaService) {}

  /** Idempotent — safe to call on every boot. Existing templates (matched
   * by `code`) get their tunable fields refreshed; new ones get created;
   * nothing here ever deletes an admin-added template. */
  async seedTemplates() {
    let created = 0;
    for (const seed of TRIAL_DATABASE) {
      const existing = await this.prisma.trialTemplate.findUnique({ where: { seedKey: seed.seedKey } });
      if (existing) continue; // don't clobber admin edits to a template that already exists
      await this.prisma.trialTemplate.create({ data: seed });
      created += 1;
    }
    this.logger.log(`Seeded ${created} new trial templates (${TRIAL_DATABASE.length - created} already existed)`);
    return { created };
  }

  async generateCycleForUser(userId: string) {
    const lastCycle = await this.prisma.userTrialCycle.findFirst({
      where: { userId },
      orderBy: { cycleNumber: 'desc' },
    });
    if (lastCycle?.status === 'ACTIVE') {
      await this.prisma.userTrialCycle.update({ where: { id: lastCycle.id }, data: { status: 'CLOSED' } });
    }

    const [templates, recentSeedKeys, favoriteHeroId, rarelyPlayedHeroId] = await Promise.all([
      this.prisma.trialTemplate.findMany({ where: { active: true } }),
      this.getRecentlyUsedSeedKeys(userId),
      this.getFavoriteHeroId(userId),
      this.getRarelyPlayedHeroId(userId),
    ]);

    const selected = this.selectTemplates(templates, recentSeedKeys, {
      hasFavoriteHero: favoriteHeroId != null,
      hasRarelyPlayedHero: rarelyPlayedHeroId != null,
    });

    const cycle = await this.prisma.userTrialCycle.create({
      data: {
        userId,
        cycleNumber: (lastCycle?.cycleNumber ?? 0) + 1,
        endsAt: new Date(Date.now() + CYCLE_DAYS * 24 * 60 * 60 * 1000),
      },
    });

    for (const template of selected) {
      const resolved = this.resolveConditionFor(template.code, favoriteHeroId, rarelyPlayedHeroId);
      await this.prisma.userTrial.create({
        data: {
          cycleId: cycle.id,
          userId,
          templateId: template.id,
          resolvedConditionJson: resolved as any,
        },
      });
    }

    return this.prisma.userTrialCycle.findUnique({
      where: { id: cycle.id },
      include: { trials: { include: { template: true } } },
    });
  }

  private async getRecentlyUsedSeedKeys(userId: string): Promise<Set<string>> {
    const recentCycles = await this.prisma.userTrialCycle.findMany({
      where: { userId },
      orderBy: { cycleNumber: 'desc' },
      take: AVOID_REPEATS_LAST_N_CYCLES,
      include: { trials: { include: { template: true } } },
    });
    // Keyed by seedKey (the exact template variant), NOT code. Several
    // templates deliberately share one code across difficulty tiers
    // (e.g. match_assists_threshold exists at both COMMON and RARE) —
    // keying this by code would mean using the RARE variant last cycle
    // blocks the COMMON variant too, starving the fresh pool far more
    // aggressively than intended and forcing repeats sooner than the
    // pool size should require. seedKey is unique per exact variant,
    // so this only ever avoids re-drawing that *specific* template.
    return new Set(
      recentCycles.flatMap((c) => c.trials.map((t) => t.template.seedKey).filter((k: string | null) => k != null)),
    );
  }

  /** Most-played hero across the user's synced match history, or null
   * if they have no synced matches yet (nothing to base this on). */
  private async getFavoriteHeroId(userId: string): Promise<number | null> {
    const grouped = await this.prisma.match.groupBy({
      by: ['heroId'],
      where: { userId },
      _count: { id: true },
      orderBy: { _count: { id: 'desc' } },
      take: 1,
    });
    return grouped[0]?.heroId ?? null;
  }

  /** A real, available-in-CM hero absent from the user's last N
   * matches — requirement 20's "герой, которого редко используете",
   * not a hero picked at random from the whole roster regardless of
   * whether they already play it constantly. */
  private async getRarelyPlayedHeroId(userId: string): Promise<number | null> {
    const recent = await this.prisma.match.findMany({
      where: { userId },
      orderBy: { startTime: 'desc' },
      take: HERO_HISTORY_SAMPLE,
      select: { heroId: true },
    });
    if (recent.length === 0) return null; // no history at all — can't call anything "rarely played" meaningfully

    const recentHeroIds = new Set(recent.map((m) => m.heroId));
    const candidates = await this.prisma.hero.findMany({
      where: { captainsModeAvailable: true, id: { notIn: [...recentHeroIds] } },
    });
    if (candidates.length === 0) return null;
    return candidates[Math.floor(Math.random() * candidates.length)].id;
  }

  private resolveConditionFor(
    code: string,
    favoriteHeroId: number | null,
    rarelyPlayedHeroId: number | null,
  ): Record<string, any> | null {
    if ((code === 'hero_matches_played' || code === 'hero_win') && favoriteHeroId != null) {
      return { heroId: favoriteHeroId };
    }
    if (code === 'hero_rarely_played' && rarelyPlayedHeroId != null) {
      return { heroId: rarelyPlayedHeroId };
    }
    return null;
  }

  /**
   * Picks TRIALS_PER_CYCLE templates, best-effort honoring
   * DIFFICULTY_TARGET and avoiding recentSeedKeys where the pool allows
   * it. Falls back to reusing a recent template (rather than shipping
   * fewer than 10 trials) once the non-repeated pool for a difficulty
   * is exhausted — a small pool repeating sometimes is a better
   * outcome than a cycle with 7 trials.
   */
  private selectTemplates(
    pool: { id: string; code: string; seedKey: string | null; difficulty: string; category: string }[],
    recentSeedKeys: Set<string>,
    context: { hasFavoriteHero: boolean; hasRarelyPlayedHero: boolean },
  ) {
    const eligible = pool.filter((t) => {
      if (t.code === 'hero_matches_played' || t.code === 'hero_win') return context.hasFavoriteHero;
      if (t.code === 'hero_rarely_played') return context.hasRarelyPlayedHero;
      return true;
    });

    const selected: typeof eligible = [];
    const usedIds = new Set<string>();

    const takeFrom = (candidates: typeof eligible, n: number) => {
      const shuffled = [...candidates].sort(() => Math.random() - 0.5);
      for (const t of shuffled) {
        if (selected.length >= TRIALS_PER_CYCLE) return;
        if (usedIds.has(t.id) || selected.some((s) => s.code === t.code)) continue;
        if (n <= 0) return;
        selected.push(t);
        usedIds.add(t.id);
        n -= 1;
      }
    };

    for (const [difficulty, target] of Object.entries(DIFFICULTY_TARGET)) {
      const byDifficulty = eligible.filter((t) => t.difficulty === difficulty);
      const fresh = byDifficulty.filter((t) => !recentSeedKeys.has(t.seedKey));
      takeFrom(fresh, target);
      // Pool exhausted for this difficulty without repeats — allow
      // repeats rather than shipping an incomplete cycle.
      const stillNeeded = target - selected.filter((s) => s.difficulty === difficulty).length;
      if (stillNeeded > 0) takeFrom(byDifficulty, stillNeeded);
    }

    // Still short (small seed pool, unusual distribution) — top up from
    // anything eligible and not already selected, regardless of
    // difficulty targeting.
    if (selected.length < TRIALS_PER_CYCLE) {
      takeFrom(eligible, TRIALS_PER_CYCLE - selected.length);
    }

    return selected;
  }
}
