import { useEffect, useState } from 'react';
import { api, ShopItem } from '../api';

const RARITY_COLOR: Record<string, string> = {
  rare: '#5B8DEE',
  epic: '#8A5CF6',
  legendary: '#E0A63E',
  mythic: '#E0735F',
};

const RARITY_LABEL: Record<string, string> = {
  rare: 'Rare',
  epic: 'Epic',
  legendary: 'Legendary',
  mythic: 'Mythic',
};

export function ShopPage() {
  const [items, setItems] = useState<ShopItem[]>([]);
  const [inventory, setInventory] = useState<{ id: string; itemId: string; equipped: boolean; item: ShopItem }[]>([]);
  const [balance, setBalance] = useState<number | null>(null);
  const [buying, setBuying] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [tab, setTab] = useState<'shop' | 'inventory'>('shop');

  const ownedIds = new Set(inventory.map((r) => r.itemId));

  async function load() {
    const [itemsRes, balanceRes] = await Promise.all([api.shopItems(), api.shardBalance()]);
    setItems(itemsRes);
    setBalance(balanceRes.balance);
    try {
      setInventory(await api.shopInventory());
    } catch {
      setInventory([]);
    }
  }

  useEffect(() => { load(); }, []);

  async function buy(item: ShopItem) {
    setBuying(item.id);
    setMessage(null);
    try {
      const res = await api.shopPurchase(item.id);
      setBalance(res.newBalance);
      await load();
      setMessage(`Получено: ${item.name}`);
    } catch (e: any) {
      setMessage(e?.message?.includes('Insufficient') ? 'Недостаточно Arium Points' : 'Не удалось совершить покупку');
    } finally {
      setBuying(null);
    }
  }

  async function toggleEquip(row: { id: string; equipped: boolean }) {
    if (row.equipped) await api.shopUnequip(row.id);
    else await api.shopEquip(row.id);
    await load();
  }

  return (
    <div style={{ maxWidth: 1000, margin: '0 auto', padding: '40px 24px 100px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24, flexWrap: 'wrap', gap: 10 }}>
        <div>
          <p style={{ fontSize: 21, fontWeight: 500, margin: 0 }}>🛍️ AREON SHOP</p>
          <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '4px 0 0' }}>
            Косметические награды за прогресс — не дают преимущества в игре
          </p>
        </div>
        {balance != null && (
          <p style={{ fontSize: 15, margin: 0 }}>
            Ваш баланс: <strong style={{ color: '#C9A227' }}>{balance.toLocaleString('ru-RU')} Arium Points</strong>
          </p>
        )}
      </div>

      {message && (
        <p style={{ fontSize: 13, color: message.startsWith('Получено') ? 'var(--accent)' : 'var(--danger)', margin: '0 0 16px' }}>
          {message}
        </p>
      )}

      <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
        <button className={tab === 'shop' ? 'button-primary' : 'button-ghost'} onClick={() => setTab('shop')}>Магазин</button>
        <button className={tab === 'inventory' ? 'button-primary' : 'button-ghost'} onClick={() => setTab('inventory')}>
          Мой инвентарь ({inventory.length})
        </button>
      </div>

      {tab === 'inventory' ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 14 }}>
          {inventory.length === 0 && (
            <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>Пока пусто — загляните в магазин.</p>
          )}
          {inventory.map((row) => {
            const color = RARITY_COLOR[row.item.rarity] ?? 'var(--text-muted)';
            return (
              <div key={row.id} className="card" style={{ padding: 18, border: `1px solid ${row.equipped ? color : 'var(--border)'}`, display: 'flex', flexDirection: 'column' }}>
                <ItemIcon item={row.item} />
                <p style={{ fontSize: 11, color, letterSpacing: 1, margin: '0 0 4px', textAlign: 'center' }}>{RARITY_LABEL[row.item.rarity]}</p>
                <p style={{ fontSize: 16, fontWeight: 600, margin: '0 0 14px', textAlign: 'center' }}>{row.item.name}</p>
                <button
                  className={row.equipped ? 'button-ghost' : 'button-primary'}
                  onClick={() => toggleEquip(row)}
                >
                  {row.equipped ? 'Снять' : 'Надеть'}
                </button>
              </div>
            );
          })}
        </div>
      ) : (
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 14 }}>
        {items.map((item) => {
          const owned = ownedIds.has(item.id);
          const color = RARITY_COLOR[item.rarity] ?? 'var(--text-muted)';
          const canAfford = balance != null && balance >= item.priceShards;
          return (
            <div key={item.id} className="card" style={{ padding: 18, border: `1px solid ${color}44`, display: 'flex', flexDirection: 'column' }}>
              <ItemIcon item={item} />
              <p style={{ fontSize: 11, color, letterSpacing: 1, margin: '0 0 4px', textAlign: 'center' }}>{RARITY_LABEL[item.rarity]}</p>
              <p style={{ fontSize: 16, fontWeight: 600, margin: '0 0 6px', textAlign: 'center' }}>{item.name}</p>
              <p style={{ fontSize: 12, color: 'var(--text-secondary)', margin: '0 0 14px', textAlign: 'center', flex: 1 }}>{item.description}</p>
              <p style={{ fontSize: 14, textAlign: 'center', margin: '0 0 10px', color: '#C9A227' }}>
                {item.priceShards.toLocaleString('ru-RU')} Arium Points
              </p>
              {owned ? (
                <button className="button-ghost" disabled style={{ opacity: 0.6 }}>Уже приобретено</button>
              ) : (
                <button
                  className="button-primary"
                  disabled={!canAfford || buying === item.id}
                  onClick={() => buy(item)}
                  style={!canAfford ? { opacity: 0.5 } : undefined}
                >
                  {buying === item.id ? 'Покупка…' : canAfford ? 'Купить' : 'Недостаточно Arium Points'}
                </button>
              )}
            </div>
          );
        })}
      </div>
      )}
    </div>
  );
}

function ItemIcon({ item }: { item: ShopItem }) {
  // 72px lands right in the middle of "not too small to read clearly,
  // not big enough to dominate the card" — bigger than a plain emoji
  // glyph needs to be legible, smaller than would crowd out the name
  // and description below it.
  if (item.iconUrl) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 8 }}>
        <img src={item.iconUrl} alt={item.name} style={{ width: 72, height: 72, objectFit: 'contain' }} />
      </div>
    );
  }
  return <div style={{ fontSize: 40, textAlign: 'center', marginBottom: 8 }}>{item.iconEmoji}</div>;
}
