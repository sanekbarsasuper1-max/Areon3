import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api, Hero, MatchDetail as MatchDetailType } from '../api';

const DEPTH_PRICE: Record<'quick' | 'full' | 'coach', number> = { quick: 0, full: 300, coach: 500 };
const DEPTH_LABEL: Record<'quick' | 'full' | 'coach', string> = { quick: 'SHORT', full: 'FULL', coach: 'MAXIMUM' };
const SECTION_LABEL: Record<string, string> = {
  summary: 'Итоговая оценка',
  laningPhase: 'Линия / ранняя игра',
  itemBuild: 'Сборка предметов',
  abilityBuild: 'Прокачка способностей',
  teamfights: 'Командные бои',
  midLatePhase: 'Мид / лейтгейм',
  mistakes: 'Ключевые ошибки',
  goodDecisions: 'Удачные решения',
  recommendations: 'Рекомендации',
  ifIWereYourCoach: 'Если бы я был твоим тренером',
};

export function MatchAnalyzer() {
  const { id } = useParams<{ id: string }>();
  const [data, setData] = useState<MatchDetailType | null>(null);
  const [hero, setHero] = useState<Hero | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [coachDepth, setCoachDepth] = useState<'quick' | 'full' | 'coach'>('quick');
  const [coachLoading, setCoachLoading] = useState(false);
  const [coachReport, setCoachReport] = useState<{ commentary: string | Record<string, string>; facts?: any; assetIcons?: any } | null>(null);
  const [coachStatus, setCoachStatus] = useState<string | null>(null);
  const [balance, setBalance] = useState<number | null>(null);

  useEffect(() => { api.shardBalance().then((r) => setBalance(r.balance)).catch(() => {}); }, []);

  async function runCoach(depth: 'quick' | 'full' | 'coach') {
    if (!id) return;
    setCoachDepth(depth);
    setCoachLoading(true);
    setCoachReport(null);
    setCoachStatus(null);
    try {
      const res = await api.coachAnalysis(id, depth);
      if (res.status === 'processing') {
        setCoachStatus(res.message ?? 'Матч ещё разбирается — попробуйте через минуту.');
      } else if (res.reportJson) {
        setCoachReport(res.reportJson);
        api.shardBalance().then((r) => setBalance(r.balance)).catch(() => {});
      }
    } catch (e: any) {
      setCoachStatus(e?.message?.includes('Insufficient') ? e.message : 'Не удалось получить разбор — возможно, матч слишком старый и его нельзя распарсить, либо AI Coach не настроен администратором.');
    } finally {
      setCoachLoading(false);
    }
  }

  useEffect(() => {
    if (!id) return;
    setData(null);
    setError(null);

    api
      .matchDetail(id)
      .then(async (res) => {
        setData(res);
        const heroes = await api.heroes();
        setHero(heroes.find((h) => h.id === res.match.heroId) ?? null);
      })
      // The heavier /matches/{id} fetch can fail for a match OpenDota
      // hasn't parsed yet, or one this account isn't actually in — show
      // that plainly instead of a blank screen.
      .catch(() => setError('Не удалось загрузить разбор этого матча. Попробуйте ещё раз позже.'));
  }, [id]);

  if (error) {
    return (
      <div className="page-shell-wide">
        <Link to="/matches" className="button-ghost" style={{ textDecoration: 'none' }}>← Все матчи</Link>
        <p style={{ fontSize: 17, color: 'var(--danger)', marginTop: 20 }}>{error}</p>
      </div>
    );
  }

  if (!data) {
    return (
      <div style={{ minHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, color: 'var(--text-secondary)' }}>
        Загрузка…
      </div>
    );
  }

  const { match, detail } = data;

  return (
    <div className="page-shell-wide">
      <Link to="/matches" className="button-ghost" style={{ textDecoration: 'none' }}>← Все матчи</Link>

      {/* ---------- Match header ---------- */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, margin: '20px 0 28px', flexWrap: 'wrap' }}>
        <span style={{ width: 8, height: 44, borderRadius: 4, background: match.won ? 'var(--accent)' : 'var(--danger)' }} />
        <div>
          <p style={{ fontSize: 26, fontWeight: 700, margin: 0 }}>
            {hero ? (
              <Link to={`/heroes/${hero.id}`} style={{ color: 'inherit' }}>{hero.localizedName}</Link>
            ) : (
              `Герой #${match.heroId}`
            )}
            {' '}· {match.won ? 'Победа' : 'Поражение'}
          </p>
          <p style={{ fontSize: 16, color: 'var(--text-secondary)', margin: '4px 0 0' }}>
            {formatDuration(match.durationSec)} · {new Date(match.startTime).toLocaleDateString('ru-RU')}
          </p>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px,1fr))', gap: 14, marginBottom: 28 }}>
        <Stat label="K / D / A" value={`${match.kills}/${match.deaths}/${match.assists}`} />
        <Stat label="GPM" value={match.goldPerMin ?? '—'} />
        <Stat label="XPM" value={match.xpPerMin ?? '—'} />
        <Stat label="Урон героям" value={detail.heroDamage} />
        <Stat label="Урон башням" value={detail.towerDamage} />
        <Stat label="Лечение" value={detail.heroHealing} />
        <Stat label="Last hits" value={detail.lastHits} />
        <Stat label="Denies" value={detail.denies} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1.4fr) minmax(0,1fr)', gap: 20, alignItems: 'start', marginBottom: 28 }}>
        <div>
          <p style={{ fontSize: 18, fontWeight: 600, color: 'var(--text-secondary)', margin: '0 0 10px' }}>
            Накопленное золото по ходу игры
          </p>
          <div className="card">
            <NetWorthChart series={detail.goldT} isParsed={data.isParsed} />
            <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: '8px 0 0' }}>
              Приближение net worth (без учёта потраченного/проданного золота)
            </p>
          </div>
        </div>

        <div>
          <p style={{ fontSize: 18, fontWeight: 600, color: 'var(--text-secondary)', margin: '0 0 10px' }}>Разбор игры</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {detail.insights.length === 0 && (
              <p style={{ fontSize: 15, color: 'var(--text-muted)' }}>
                Ничего не отклоняется от нормы настолько, чтобы это отмечать.
              </p>
            )}
            {detail.insights.map((insight, i) => (
              <div key={i} className="card" style={{ display: 'flex', gap: 14 }}>
                <span
                  className="pill"
                  style={{
                    background: insight.tone === 'positive' ? 'var(--accent-bg)' : 'var(--danger-bg)',
                    color: insight.tone === 'positive' ? 'var(--accent)' : 'var(--danger)',
                    flexShrink: 0,
                  }}
                >
                  {insight.tone === 'positive' ? '+' : '−'}
                </span>
                <p style={{ fontSize: 15, color: '#d9d5c8', margin: 0 }}>{insight.message}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ marginTop: 24, paddingTop: 28, borderTop: '1px solid var(--border)' }}>
        <p style={{ fontSize: 22, fontWeight: 600, margin: '0 0 8px' }}>AI Coach</p>
        <p style={{ fontSize: 14, color: 'var(--text-muted)', margin: '0 0 16px', maxWidth: 720 }}>
          Данные берутся из разбора реплея, который уже делает OpenDota (обычно 1-5 минут при первом запросе для
          матча) — скачивать и загружать реплей самому не нужно. Каждый пункт разбора помечается моделью как
          «Confirmed» (прямо следует из данных) или «Likely» (интерпретация ИИ).
        </p>

        <div style={{ display: 'flex', gap: 10, marginBottom: 16, flexWrap: 'wrap' }}>
          {(['quick', 'full', 'coach'] as const).map((depth) => {
            const price = DEPTH_PRICE[depth];
            const canAfford = price === 0 || (balance != null && balance >= price);
            return (
              <button
                key={depth}
                className={coachDepth === depth ? 'button-primary' : 'button-ghost'}
                onClick={() => runCoach(depth)}
                disabled={coachLoading || !canAfford}
                style={!canAfford ? { opacity: 0.5 } : undefined}
              >
                {DEPTH_LABEL[depth]}{price > 0 ? ` — ${price} Arium Plus` : ' — бесплатно'}
              </button>
            );
          })}
        </div>
        {coachLoading && <p style={{ fontSize: 15, color: 'var(--text-secondary)' }}>Готовим разбор…</p>}
        {coachStatus && <p style={{ fontSize: 15, color: 'var(--text-secondary)' }}>{coachStatus}</p>}

        {coachReport && typeof coachReport.commentary === 'string' && (
          <div className="card" style={{ whiteSpace: 'pre-wrap', fontSize: 16, lineHeight: 1.7, maxWidth: 900 }}>
            {coachReport.commentary}
          </div>
        )}

        {coachReport && typeof coachReport.commentary === 'object' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 900 }}>
            {coachReport.commentary.summary && (
              <div className="card">
                <p style={{ fontSize: 13, color: 'var(--text-muted)', letterSpacing: 1, margin: '0 0 6px' }}>ИТОГОВАЯ ОЦЕНКА</p>
                <p style={{ fontSize: 16, lineHeight: 1.6, margin: 0 }}>{coachReport.commentary.summary}</p>
              </div>
            )}

            {coachReport.facts?.abilityUpgrades?.length > 0 && (
              <div className="card">
                <p style={{ fontSize: 13, color: 'var(--text-muted)', letterSpacing: 1, margin: '0 0 10px' }}>ПРОКАЧКА СПОСОБНОСТЕЙ</p>
                <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 12 }}>
                  {coachReport.facts.abilityUpgrades.map((a: any, i: number) => {
                    const icon = coachReport.assetIcons?.abilityIcons?.[a.abilityId];
                    return (
                      <div key={i} title={icon?.dname ?? `ability_${a.abilityId}`} style={{ textAlign: 'center' }}>
                        <div style={{ width: 40, height: 30, borderRadius: 4, overflow: 'hidden', border: '1px solid var(--border)', background: '#000' }}>
                          {icon?.iconUrl ? <img src={icon.iconUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : null}
                        </div>
                        <span style={{ fontSize: 9, color: 'var(--text-muted)' }}>{a.level}</span>
                      </div>
                    );
                  })}
                </div>
                {coachReport.commentary.abilityBuild && <p style={{ fontSize: 14, lineHeight: 1.6, margin: 0, color: 'var(--text-secondary)' }}>{coachReport.commentary.abilityBuild}</p>}
              </div>
            )}

            {coachReport.facts?.itemPurchases?.length > 0 && (
              <div className="card">
                <p style={{ fontSize: 13, color: 'var(--text-muted)', letterSpacing: 1, margin: '0 0 10px' }}>СБОРКА ПРЕДМЕТОВ</p>
                <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 12 }}>
                  {coachReport.facts.itemPurchases.map((p: any, i: number) => {
                    const icon = coachReport.assetIcons?.itemIcons?.[p.itemKey];
                    return (
                      <div key={i} title={icon?.dname ?? p.itemKey} style={{ textAlign: 'center' }}>
                        <div style={{ width: 36, height: 26, borderRadius: 4, overflow: 'hidden', border: '1px solid var(--border)', background: '#000' }}>
                          {icon?.iconUrl ? <img src={icon.iconUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : null}
                        </div>
                        <span style={{ fontSize: 9, color: 'var(--text-muted)' }}>{formatDuration(p.timeSec)}</span>
                      </div>
                    );
                  })}
                </div>
                {coachReport.commentary.itemBuild && <p style={{ fontSize: 14, lineHeight: 1.6, margin: 0, color: 'var(--text-secondary)' }}>{coachReport.commentary.itemBuild}</p>}
              </div>
            )}

            {['laningPhase', 'teamfights', 'midLatePhase', 'mistakes', 'goodDecisions', 'recommendations', 'ifIWereYourCoach'].map((key) => {
              const text = (coachReport.commentary as Record<string, string>)[key];
              if (!text) return null;
              return (
                <div key={key} className="card">
                  <p style={{ fontSize: 13, color: 'var(--text-muted)', letterSpacing: 1, margin: '0 0 6px' }}>{SECTION_LABEL[key]?.toUpperCase()}</p>
                  <p style={{ fontSize: 14, lineHeight: 1.6, margin: 0, color: 'var(--text-secondary)' }}>{text}</p>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="card">
      <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 6px' }}>{label}</p>
      <p style={{ fontSize: 24, fontWeight: 700, margin: 0 }}>{value}</p>
    </div>
  );
}

// No chart library wired into this scaffold — a plain SVG polyline
// with a hover tooltip is enough for a real interactive trend line
// and keeps the frontend dependency list small.
function NetWorthChart({ series, isParsed }: { series: number[]; isParsed: boolean }) {
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);

  if (!series || series.length < 2) {
    return (
      <p style={{ fontSize: 15, color: 'var(--text-muted)' }}>
        {isParsed
          ? 'OpenDota не вернул данные по золоту для этого матча.'
          : 'Valve/OpenDota ещё не разобрали реплей этого матча — запрос на разбор отправлен, обычно занимает 1–5 минут. Откройте страницу ещё раз чуть позже.'}
      </p>
    );
  }

  const width = 600;
  const height = 160;
  const padding = { left: 44, bottom: 20, top: 10, right: 10 };
  const plotW = width - padding.left - padding.right;
  const plotH = height - padding.top - padding.bottom;
  const max = Math.max(...series);
  const min = 0; // gold never goes negative — anchoring at 0 makes the shape actually readable
  const range = max - min || 1;

  const xAt = (i: number) => padding.left + (i / (series.length - 1)) * plotW;
  const yAt = (v: number) => padding.top + plotH - ((v - min) / range) * plotH;
  const points = series.map((v, i) => `${xAt(i)},${yAt(v)}`).join(' ');

  const yTicks = [0, 0.5, 1].map((f) => Math.round(min + range * f));

  return (
    <svg
      width="100%"
      viewBox={`0 0 ${width} ${height}`}
      onMouseLeave={() => setHoverIdx(null)}
      onMouseMove={(e) => {
        const rect = (e.target as SVGElement).closest('svg')!.getBoundingClientRect();
        const relX = ((e.clientX - rect.left) / rect.width) * width;
        const idx = Math.round(((relX - padding.left) / plotW) * (series.length - 1));
        setHoverIdx(Math.max(0, Math.min(series.length - 1, idx)));
      }}
    >
      {yTicks.map((t, i) => (
        <g key={i}>
          <line x1={padding.left} x2={width - padding.right} y1={yAt(t)} y2={yAt(t)} stroke="var(--border)" strokeWidth={1} />
          <text x={0} y={yAt(t) + 4} fontSize={10} fill="var(--text-muted)">{t >= 1000 ? `${Math.round(t / 1000)}k` : t}</text>
        </g>
      ))}
      {[0, Math.floor(series.length / 2), series.length - 1].map((i) => (
        <text key={i} x={xAt(i)} y={height - 4} fontSize={10} fill="var(--text-muted)" textAnchor="middle">{i}:00</text>
      ))}
      <polyline points={points} fill="none" stroke="var(--accent)" strokeWidth={2.5} />
      {hoverIdx != null && (
        <>
          <line x1={xAt(hoverIdx)} x2={xAt(hoverIdx)} y1={padding.top} y2={height - padding.bottom} stroke="var(--text-muted)" strokeWidth={1} strokeDasharray="3,3" />
          <circle cx={xAt(hoverIdx)} cy={yAt(series[hoverIdx])} r={4} fill="var(--accent)" />
          <text x={Math.min(xAt(hoverIdx) + 8, width - 70)} y={yAt(series[hoverIdx]) - 8} fontSize={11} fill="var(--text)">
            {hoverIdx}:00 · {series[hoverIdx].toLocaleString('ru-RU')}
          </text>
        </>
      )}
    </svg>
  );
}

function formatDuration(sec: number) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${s.toString().padStart(2, '0')}`;
}
