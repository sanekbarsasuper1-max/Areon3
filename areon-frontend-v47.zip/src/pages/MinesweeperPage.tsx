import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, MinesweeperConfig, MinesweeperSession, MiniGameStats } from '../api';
import { useAudio, useAppMode } from '../audio/AudioContext';

// Same attribute palette Draft Trainer already uses (STR/AGI/INT/UNIVERSAL)
// — reused here for the mine-count numbers so this reads as part of the
// same visual system, not a bolted-on foreign game.
const NUMBER_COLOR: Record<number, string> = {
  1: '#5B9EF0',
  2: '#5ED184',
  3: '#F0665F',
  4: '#C89BF0',
  5: '#F0C23E',
  6: '#4FD9E0',
  7: '#EDE6D3',
  8: '#A9A499',
};

function BombIcon({ size = 15 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24">
      <defs>
        <radialGradient id="bombBody" cx="35%" cy="30%" r="70%">
          <stop offset="0%" stopColor="#4a4a4a" />
          <stop offset="60%" stopColor="#1a1a1a" />
          <stop offset="100%" stopColor="#050505" />
        </radialGradient>
      </defs>
      <circle cx="12" cy="14" r="8" fill="url(#bombBody)" stroke="#C97B63" strokeWidth="1.3" />
      <ellipse cx="9.5" cy="11" rx="2" ry="1.3" fill="#ffffff" opacity="0.25" />
      <path d="M12 6 L15 2 M15 2 L13.5 2.5 M15 2 L14.5 3.5" stroke="#F0C23E" strokeWidth="1.5" fill="none" strokeLinecap="round" />
      <circle cx="15" cy="2" r="1.3" fill="#F0665F" />
    </svg>
  );
}

function FlagIcon({ size = 13 }: { size?: number }) {
  // A stand-in "danger marker" — a stake with a pennant, deliberately
  // not a reproduction of any real Dota 2 asset. key=flag-in on the
  // wrapper below makes this a fresh DOM node whenever it appears, so
  // the CSS pop-in animation plays every time a flag is placed, not
  // just on first mount of the board.
  return (
    <svg width={size} height={size} viewBox="0 0 24 24">
      <line x1="7" y1="3" x2="7" y2="21" stroke="#B8B3A5" strokeWidth="1.6" />
      <path d="M7 4 L18 8 L7 12 Z" fill="#2FA98F" />
      <path d="M7 4 L18 8 L7 12 Z" fill="none" stroke="#4FD9C4" strokeWidth="0.5" opacity="0.7" />
    </svg>
  );
}

const CELL_ANIM_STYLES = `
@keyframes flagPop {
  0% { transform: scale(0.2) rotate(-15deg); opacity: 0; }
  60% { transform: scale(1.25) rotate(8deg); opacity: 1; }
  100% { transform: scale(1) rotate(0deg); opacity: 1; }
}
@keyframes cellReveal {
  0% { transform: scale(0.85); opacity: 0.4; }
  100% { transform: scale(1); opacity: 1; }
}
@keyframes mineFlash {
  0% { background: #ffb199; box-shadow: 0 0 24px 8px rgba(255,120,80,0.9); }
  40% { background: #C97B63; box-shadow: 0 0 14px 4px rgba(255,120,80,0.6); }
  100% { background: #3a1512; box-shadow: none; }
}
@keyframes boardShake {
  0%, 100% { transform: translateX(0); }
  20% { transform: translateX(-6px) rotate(-0.3deg); }
  40% { transform: translateX(5px) rotate(0.3deg); }
  60% { transform: translateX(-4px); }
  80% { transform: translateX(3px); }
}
@keyframes boardFlash {
  0% { box-shadow: inset 0 0 60px 10px rgba(240,102,95,0.55); }
  100% { box-shadow: inset 0 2px 8px rgba(0,0,0,0.6); }
}
@keyframes particleBurst {
  0% { transform: translate(0,0) scale(1); opacity: 1; }
  100% { transform: translate(var(--dx), var(--dy)) scale(0); opacity: 0; }
}
`;

function ExplosionParticles() {
  // 8 small shards flying outward from the detonated cell — plain CSS,
  // no canvas/library needed for something this small and short-lived.
  const particles = Array.from({ length: 8 }, (_, i) => {
    const angle = (i / 8) * Math.PI * 2;
    const dist = 22 + (i % 3) * 6;
    return { dx: Math.cos(angle) * dist, dy: Math.sin(angle) * dist, delay: i * 15 };
  });
  return (
    <>
      {particles.map((p, i) => (
        <span
          key={i}
          style={{
            position: 'absolute', top: '50%', left: '50%', width: 4, height: 4, borderRadius: '50%',
            background: i % 2 === 0 ? '#F0C23E' : '#F0665F',
            animation: `particleBurst 0.5s ease-out ${p.delay}ms forwards`,
            ['--dx' as any]: `${p.dx}px`, ['--dy' as any]: `${p.dy}px`,
            pointerEvents: 'none',
          }}
        />
      ))}
    </>
  );
}


export function MinesweeperPage() {
  const [configs, setConfigs] = useState<MinesweeperConfig[]>([]);
  const [difficulty, setDifficulty] = useState('EASY');
  const [session, setSession] = useState<MinesweeperSession | null>(null);
  const [stats, setStats] = useState<MiniGameStats | null>(null);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [detonatedIndex, setDetonatedIndex] = useState<number | null>(null);
  const [boardShaking, setBoardShaking] = useState(false);
  const { playSFX } = useAudio();
  useAppMode('minesweeper');

  useEffect(() => {
    api.minesweeperConfigs().then((list) => {
      setConfigs(list);
      if (list[0]) setDifficulty(list[0].difficulty);
    });
    api.minesweeperStats().then(setStats);
  }, []);

  useEffect(() => {
    if (!session || session.status !== 'IN_PROGRESS' || !startedAt) return;
    const interval = setInterval(() => setElapsed(Math.floor((Date.now() - startedAt) / 1000)), 500);
    return () => clearInterval(interval);
  }, [session, startedAt]);

  async function startGame() {
    const s = await api.minesweeperStart(difficulty);
    setSession(s);
    setStartedAt(Date.now());
    setElapsed(0);
    setDetonatedIndex(null);
  }

  async function reveal(index: number) {
    if (!session || session.status !== 'IN_PROGRESS') return;
    if (session.flaggedJson.includes(index) || session.revealedJson.includes(index)) return;
    const result = await api.minesweeperReveal(session.id, index);
    setSession(result.session);
    if (result.hitMine) {
      setDetonatedIndex(index);
      setBoardShaking(true);
      setTimeout(() => setBoardShaking(false), 500);
      playSFX('minesweeper_explosion');
      setTimeout(() => playSFX('minesweeper_defeat'), 400);
    } else if (result.session.status === 'WON') {
      playSFX('minesweeper_victory');
    } else {
      playSFX('minesweeper_reveal');
    }
    if (result.session.status !== 'IN_PROGRESS') {
      api.minesweeperStats().then(setStats);
    }
  }

  async function toggleFlag(e: React.MouseEvent, index: number) {
    e.preventDefault();
    if (!session || session.status !== 'IN_PROGRESS') return;
    if (session.revealedJson.includes(index)) return;
    const wasFlagged = session.flaggedJson.includes(index);
    const updated = await api.minesweeperFlag(session.id, index);
    setSession(updated);
    playSFX(wasFlagged ? 'minesweeper_flag_remove' : 'minesweeper_flag_place');
  }

  const config = configs.find((c) => c.difficulty === difficulty);

  return (
    <div style={{ maxWidth: 1400, margin: '0 auto', padding: '40px 48px 100px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
        <div>
          <p style={{ fontSize: 21, fontWeight: 500, margin: 0 }}>ТЕХИС: САПЁР</p>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: '4px 0 0' }}>Mini Games · Orion</p>
        </div>
        <Link to="/trials" className="button-ghost" style={{ textDecoration: 'none', fontSize: 13 }}>К испытаниям</Link>
      </div>

      {stats && (
        <div className="card" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8, marginBottom: 16, fontSize: 13 }}>
          <div><p style={{ color: 'var(--text-muted)', margin: '0 0 2px' }}>Сыграно</p><p style={{ margin: 0 }}>{stats.played}</p></div>
          <div><p style={{ color: 'var(--text-muted)', margin: '0 0 2px' }}>Побед</p><p style={{ margin: 0 }}>{stats.wins} ({stats.played ? Math.round((stats.wins / stats.played) * 100) : 0}%)</p></div>
          <div><p style={{ color: 'var(--text-muted)', margin: '0 0 2px' }}>Серия</p><p style={{ margin: 0 }}>{stats.currentWinStreak} (лучшая {stats.bestWinStreak})</p></div>
          <div><p style={{ color: 'var(--text-muted)', margin: '0 0 2px' }}>Лучшее время</p><p style={{ margin: 0 }}>{stats.bestTimeSec != null ? `${stats.bestTimeSec}s` : '—'}</p></div>
        </div>
      )}

      {(!session || session.status !== 'IN_PROGRESS') && (
        <div className="card" style={{ marginBottom: 16 }}>
          <div style={{ display: 'flex', gap: 8, marginBottom: 10, flexWrap: 'wrap' }}>
            {configs.map((c) => (
              <button
                key={c.difficulty}
                className="button-ghost"
                style={{ background: difficulty === c.difficulty ? 'var(--accent-bg)' : undefined, color: difficulty === c.difficulty ? 'var(--accent)' : undefined }}
                onClick={() => setDifficulty(c.difficulty)}
              >
                {c.difficulty} · {c.boardWidth}×{c.boardHeight} · {c.mineCount} мин
              </button>
            ))}
          </div>
          {config && (
            <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: '0 0 10px' }}>
              Победа: +{config.winShards} Orion Plus, +{config.winRating} рейтинга. Поражение: {config.lossShards} Orion Plus, {config.lossRating} рейтинга.
              Серия от {config.streakBonusThreshold} побед подряд — бонус +{config.streakBonusShards}.
            </p>
          )}
          <button className="button-primary" onClick={startGame}>
            {session?.status === 'WON' || session?.status === 'LOST' ? 'Играть снова' : 'Начать игру'}
          </button>
        </div>
      )}

      {session && (
        <>
          {session.status === 'IN_PROGRESS' && (
            <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: '0 0 10px' }}>
              {session.difficulty} · {elapsed}s · флажков: {session.flaggedJson.length}
            </p>
          )}

          {session.status === 'WON' && (
            <div className="card" style={{ marginBottom: 12, borderLeft: '3px solid #2FA98F', textAlign: 'center', padding: 20 }}>
              <p style={{ fontSize: 18, fontWeight: 500, color: '#2FA98F', margin: '0 0 6px', letterSpacing: 1 }}>ОБЕЗВРЕЖЕНО</p>
              <p style={{ fontSize: 14, color: '#C9A227', margin: 0 }}>+{session.shardsAwarded} Orion Plus · +{session.ratingChange} рейтинга</p>
            </div>
          )}
          {session.status === 'LOST' && (
            <div className="card" style={{ marginBottom: 12, borderLeft: '3px solid #C97B63', textAlign: 'center', padding: 20 }}>
              <p style={{ fontSize: 18, fontWeight: 500, color: '#C97B63', margin: '0 0 6px', letterSpacing: 1 }}>ПОДРЫВ</p>
              <p style={{ fontSize: 14, color: 'var(--text-secondary)', margin: 0 }}>
                {session.shardsAwarded ? `${session.shardsAwarded} Orion Plus · ` : ''}{session.ratingChange} рейтинга
              </p>
            </div>
          )}

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: `repeat(${session.boardWidth}, 1fr)`,
              gap: 3,
              background: 'linear-gradient(160deg, #17132b, #0a0815)',
              padding: 6,
              borderRadius: 10,
              maxWidth: '100%',
              overflowX: 'auto',
              boxShadow: 'inset 0 2px 8px rgba(0,0,0,0.6)',
              animation: boardShaking ? 'boardShake 0.5s ease-in-out, boardFlash 0.6s ease-out' : undefined,
            }}
          >
            <style>{CELL_ANIM_STYLES}</style>
            {Array.from({ length: session.boardWidth * session.boardHeight }, (_, i) => {
              const isRevealed = session.revealedJson.includes(i);
              const isFlagged = session.flaggedJson.includes(i);
              const isMine = session.status === 'LOST' && session.mineLayoutJson.includes(i);
              const isDetonated = i === detonatedIndex;
              const number = session.cellNumbersJson[i];

              return (
                <button
                  key={i}
                  onClick={() => reveal(i)}
                  onContextMenu={(e) => toggleFlag(e, i)}
                  disabled={session.status !== 'IN_PROGRESS'}
                  style={{
                    position: 'relative',
                    aspectRatio: '1',
                    minWidth: 22,
                    background: isDetonated
                      ? '#3a1512'
                      : isMine
                      ? 'linear-gradient(155deg, #4a231a, #2a1310)'
                      : isRevealed
                      ? 'linear-gradient(155deg, #163b38, #0d2422)'
                      : isFlagged
                      ? 'linear-gradient(155deg, #4a3a2a, #332616)'
                      : 'linear-gradient(155deg, #4a3f8a, #2d2560)',
                    border: 'none',
                    borderRadius: 4,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: session.status === 'IN_PROGRESS' ? 'pointer' : 'default',
                    padding: 0,
                    fontSize: 14,
                    fontWeight: 700,
                    color: number != null ? NUMBER_COLOR[number] ?? 'var(--text-muted)' : undefined,
                    textShadow: number != null ? '0 0 6px currentColor' : undefined,
                    boxShadow: isRevealed || isMine
                      ? 'inset 0 2px 4px rgba(0,0,0,0.55), inset 0 0 12px rgba(47,169,143,0.12)'
                      : '0 2px 0 rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.15), 0 0 10px rgba(124,111,240,0.25)',
                    animation: isRevealed && !isMine ? 'cellReveal 0.18s ease-out' : isDetonated ? 'mineFlash 0.5s ease-out forwards' : undefined,
                    overflow: 'visible',
                  }}
                >
                  {isDetonated && <ExplosionParticles />}
                  {isMine ? (
                    <BombIcon />
                  ) : isFlagged ? (
                    <span key="flag-in" style={{ display: 'inline-block', animation: 'flagPop 0.28s cubic-bezier(0.34,1.56,0.64,1)' }}>
                      <FlagIcon />
                    </span>
                  ) : isRevealed && number ? (
                    number
                  ) : null}
                </button>
              );
            })}
          </div>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '8px 0 0' }}>
            Левый клик — открыть клетку. Правый клик — поставить/снять флажок.
          </p>
        </>
      )}
    </div>
  );
}
