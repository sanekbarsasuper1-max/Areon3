import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

export interface VersionInput {
  version: string;
  added?: string[];
  fixed?: string[];
  improved?: string[];
  addressed?: string[];
  knownIssues?: string[];
}

@Injectable()
export class VersionsService {
  constructor(private readonly prisma: PrismaService) {}

  async listAll() {
    return this.prisma.areonVersion.findMany({ orderBy: { releasedAt: 'desc' } });
  }

  async getCurrent() {
    return this.prisma.areonVersion.findFirst({ where: { isCurrent: true } });
  }

  async getByVersion(version: string) {
    const row = await this.prisma.areonVersion.findUnique({ where: { version } });
    if (!row) throw new NotFoundException('Version not found');
    return row;
  }

  /**
   * Creates a new version and makes it current — atomically flips the
   * old current version's isCurrent to false in the same transaction,
   * so there is never a moment with zero or two current versions, even
   * under concurrent admin requests.
   */
  async createVersion(input: VersionInput) {
    return this.prisma.$transaction(async (tx) => {
      const previous = await tx.areonVersion.findFirst({ where: { isCurrent: true } });
      if (previous) {
        await tx.areonVersion.update({ where: { id: previous.id }, data: { isCurrent: false } });
      }
      return tx.areonVersion.create({
        data: {
          version: input.version,
          added: input.added ?? [],
          fixed: input.fixed ?? [],
          improved: input.improved ?? [],
          addressed: input.addressed ?? [],
          knownIssues: input.knownIssues ?? [],
          isCurrent: true,
        },
      });
    });
  }

  async updateVersion(id: string, input: Partial<VersionInput>) {
    return this.prisma.areonVersion.update({ where: { id }, data: input });
  }

  /** Admin can also re-flag an OLDER version as current, e.g. after
   * rolling back a broken release — same atomic guarantee. */
  async setCurrent(id: string) {
    return this.prisma.$transaction(async (tx) => {
      const previous = await tx.areonVersion.findFirst({ where: { isCurrent: true } });
      if (previous && previous.id !== id) {
        await tx.areonVersion.update({ where: { id: previous.id }, data: { isCurrent: false } });
      }
      return tx.areonVersion.update({ where: { id }, data: { isCurrent: true } });
    });
  }

  /** Links an already-implemented Suggestion to the version that
   * shipped it — requirement 7. */
  async linkSuggestion(versionId: string, suggestionId: string) {
    return this.prisma.suggestion.update({
      where: { id: suggestionId },
      data: { status: 'IMPLEMENTED', implementedInVersionId: versionId },
    });
  }

  /**
   * Idempotent — only runs if literally zero versions exist yet. Does
   * NOT fabricate a detailed changelog history (no invented past
   * entries) — just a real, honest baseline so the version display and
   * update-notification banner have something to show on a fresh
   * install, before an admin has written a real first changelog entry.
   */
  async seedInitialVersion() {
    const existing = await this.prisma.areonVersion.count();
    if (existing > 0) return { created: false };
    await this.createVersion({
      version: '1.0.0',
      added: ['Запуск платформы Areon'],
    });
    return { created: true };
  }

  /**
   * Idempotent (keyed on the version string, not "any versions
   * exist") — safe to run on every boot. Records the visual-redesign
   * release without needing an admin to type it in through a UI that
   * doesn't exist yet.
   */
  async ensureVersion2() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.0.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.0.0',
      improved: [
        'Интерфейс переработан на полноэкранный: боковая навигация вместо узкой верхней полосы',
        'Все страницы используют всю ширину экрана вместо маленького окна по центру',
        'Увеличен размер текста и элементов по всему сайту для читаемости',
        'Повышена контрастность вторичного и приглушённого текста',
        'Профиль и страница разбора матча переработаны с более крупными карточками и двухколоночной раскладкой',
        'Добавлена адаптивная раскладка для узких экранов (боковая панель сворачивается в верхнюю полосу)',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern as ensureVersion2 — keyed on version string. */
  async ensureVersion21() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.1.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.1.0',
      fixed: [
        'GPM/XPM в статистике матча больше не показывают 0 — запрос к OpenDota теперь явно запрашивает эти поля',
        'Графики золота по ходу игры: матч теперь автоматически отправляется на разбор Valve, если он ещё не распарсен, вместо пустого графика',
        'Исправлена ошибка в расчёте отклонения от медианы (сравнивались показатели в разных единицах — из-за этого могли появляться значения вроде «+6520%»)',
        'Вход через Steam стал заметно быстрее — проверка доступности статистики больше не блокирует вход при каждом заходе, используется сохранённое значение с фоновым обновлением',
      ],
      improved: [
        'Новая цветовая система: многослойный тёмный фон с мягкими индиго- и сине-фиолетовыми акцентами вместо плоского чёрного',
        'Карточки получили собственную поверхность, границу и мягкую тень для визуальной иерархии',
        'История обновлений и уведомление о новой версии теперь видны и гостям, не только вошедшим пользователям',
        'В меню появился индикатор NEW рядом с «Что нового», когда есть непросмотренное обновление',
        'На страницу разбора матча добавлены урон по башням, лечение и denies',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — third entry in the changelog history. */
  async ensureVersion22() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.2.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.2.0',
      added: [
        'Wheel of Fate полностью запущен: случайный герой и AI-сборка → принятие испытания → реальный матч → автоматическая проверка результата → Orion Plus и рейтинг',
      ],
      improved: [
        'ИИ в Draft Trainer теперь собирает состав по ролям (Carry/Support/Disabler/Durable/Nuker), а не только ищет контрпики',
        'Баны в Draft Trainer разделены по командам и визуально меньше пиков',
        'После завершения драфта — честная эвристическая оценка того, чей состав сильнее (не прогноз реальной победы)',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — fourth entry. */
  async ensureVersion23() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.3.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.3.0',
      added: [
        'Мониторинг пользователей в админ-панели: кто сейчас онлайн, история посещений, журнал значимых действий, карточка конкретного пользователя',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — fifth entry. */
  async ensureVersion24() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.4.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.4.0',
      added: [
        'Драфт-турниры 1v1: живая турнирная сетка, автоматическое продвижение победителя, блок «Мой матч», инструменты администратора (отмена/удаление турнира, исправление результата, удаление участника)',
      ],
      improved: [
        'Музыкальный поиск переведён на настоящий каталог Apple Music (бесплатный, без ключа) вместо Jamendo — теперь находит реальных исполнителей и треки, с разделением на Артисты/Треки/Альбомы',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — sixth entry. */
  async ensureVersion25() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.5.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.5.0',
      added: [
        'Drafter Rating: отдельный Elo-рейтинг за реальные драфты 1 на 1 (friend/matchmaking), с историей изменений',
        'Расстановка позиций после драфта и визуализация синергии героев (по реальным тегам ролей)',
      ],
      fixed: [
        'Победитель драфта теперь определяется всегда — убраны формулировки «примерно равны»',
        'Сравнение составов было заблокировано до завершения драфта — теперь работает и во время живого драфта',
        'Синхронизация OpenDota: явный запрос дополнительных полей случайно вытеснял базовые (герой, K/D/A, дата матча) — матчи с неполными данными больше не ломают всю синхронизацию',
      ],
      improved: [
        'Пики и баны в драфтере визуально различаются по размеру, у банов — яркий красный крестик, у каждой карточки — настоящий номер хода',
      ],
    });
    return { created: true };
  }

  /** Same idempotent pattern — seventh entry. */
  async ensureVersion26() {
    const existing = await this.prisma.areonVersion.findUnique({ where: { version: '2.6.0' } });
    if (existing) return { created: false };
    await this.createVersion({
      version: '2.6.0',
      added: [
        'Расстановка позиций после драфта — теперь перетаскиванием героев на стилизованную мини-карту вместо выпадающих списков',
        'Противостояние по позициям (Your Carry vs Enemy Offlane и т.д.) — по реальным данным контрпиков',
        'Пятиугольник синергии — визуализация связей между всеми пятью героями команды',
      ],
    });
    return { created: true };
  }
}
