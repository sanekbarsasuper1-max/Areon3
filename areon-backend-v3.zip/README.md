# Areon backend — Steam auth + Expose Public Match Data scaffold

This is a working starting point for exactly the two things we designed the
mockups around: Steam login, and the check that decides whether someone
lands on the profile screen or the "включите Expose Public Match Data"
onboarding screen.

## Flow

1. `GET /auth/steam` → redirects to Steam's login page.
2. Steam redirects back to `GET /auth/steam/return` with the user's identity.
3. `AuthService.loginOrCreate`:
   - Converts the 64-bit SteamID to Dota's 32-bit `account_id`.
   - Finds or creates the `User` row.
   - Calls `PlayersService.checkStatsExposed` immediately.
   - Issues a JWT in an httpOnly cookie.
4. The controller redirects to `/profile` or `/onboarding/expose-data`
   depending on the result — matching the two screens already mocked up.
5. The onboarding screen's "Проверить снова" button calls
   `GET /players/me/stats-status`, which re-runs the same check and updates
   the stored flag. This is designed to be called again at any point later
   too, not just once — someone can turn the Dota setting back off after
   months of normal use.

## Before this touches production

- **Verify the exact Steam API response for a blocked account** against a
  real test account with "Expose Public Match Data" turned off. The
  `status !== 1` check in `players.service.ts` is based on documented
  community behaviour, not an official Valve spec — Valve's Dota 2 Web API
  is largely undocumented and has changed without notice before (see the
  2025 Immortal Draft match-hiding change).
- Get a Steam Web API key at https://steamcommunity.com/dev/apikey and
  read the Terms of Use at https://steamcommunity.com/dev/apiterms before
  going live: 100,000 calls/day cap, key must stay confidential, and you
  can't present the data as endorsed by Valve.
- Run `npx prisma migrate dev` against a real Postgres instance to create
  the `User` / `RankSnapshot` tables.
- `RankSnapshot` is here but nothing writes to it yet — that's the daily
  cron worker we discussed (Valve doesn't expose historical MMR, so Areon
  has to start accumulating its own snapshots from day one of each user's
  account).
- Add `secure: true` to the auth cookie once served over HTTPS.

## Match sync (OpenDota)

- `POST /players/me/matches/sync` — pulls the player's recent matches from
  OpenDota's `/players/{account_id}/matches` summary endpoint and upserts
  them into the `Match` table. Manually triggered for now; the daily
  background worker that calls this automatically is the next piece.
- `GET /players/me/matches?heroId=&result=win|loss&days=&page=` — powers
  the "Все матчи" screen. Filtering runs against our own Postgres copy,
  not a live OpenDota call, matching the architecture we settled on
  (backend reads from storage, sync jobs are the only thing that talk to
  external APIs).
- This is the "cheap tier" from the match-analysis discussion: summary
  fields only (K/D/A, GPM/XPM, duration, hero, win/loss). Per-match detail
  for Match Analyzer (net worth over time, teamfights, the auto-generated
  insight rules) needs a separate fetch to OpenDota's `/matches/{id}`
  endpoint per match — not built yet.
- OpenDota's `/players/{id}/matches` has no offset pagination, only a
  `limit`. A full historical backfill beyond the most recent N matches
  needs date-windowed queries, which this scaffold doesn't do.

## Hero database

- `POST /heroes/sync` — now pulls from `/heroStats` instead of `/heroes`,
  so base attributes (str/agi/int, gains, move speed) are stored
  alongside name/icon in one pass.
- `POST /heroes/:id/sync-matchups` — computes "хорош против / слаб
  против" from real per-opponent win rates (OpenDota's confirmed
  `/heroes/{id}/matchups` endpoint), filtered to matchups with at least
  200 games so a 2-game sample doesn't produce a misleading 100%/0%.
  Per-hero, not batched — syncing all 120+ heroes' matchups is a slow
  job that belongs on a queue, not a single request.
- **"Хорошо сочетается с" (ally synergy) is not implemented.** There's no
  OpenDota endpoint confirmed here for ally win rate, only opponent
  matchups. Shipping a guessed synergy list would be worse than shipping
  none — `synergiesJson` stays null until this is actually verified
  against OpenDota's docs or another source.
- Icon URLs point at `cdn.cloudflare.steamstatic.com` — Valve's own Steam
  CDN, per the asset-rights discussion.
- **Guarded behind login** even though it isn't personal data, because the
  product decision was "полностью закрыто без исключений" — if that
  decision changes, this is the controller to unguard.

## Match Analyzer detail

- `GET /players/me/matches/:id/detail` — the heavier per-match fetch
  (`/matches/{id}` + `/benchmarks?hero_id=`), cached in `MatchDetail`
  after the first request since a finished match's data never changes.
- `MatchAnalyzerService` generates up to 3 short insights per match, all
  built only from OpenDota fields confirmed in their own docs: percentile
  comparison against hero benchmarks (GPM, hero damage), and a
  first-third-vs-last-third net worth growth trend from `gold_t`.
- **Deliberately not implemented**: the death-clustering and "solo death,
  no allies nearby" rules from the original product design. Those need
  positional/replay-level data that the standard `/matches/{id}` response
  doesn't include — implementing them with the fields that *are* present
  would mean presenting a guess as an observation. See the comment at the
  top of `match-analyzer.service.ts`.
- `gold_t` is OpenDota's cumulative-gold-per-minute array — a reasonable
  proxy for net worth over time, but not an exact match (it doesn't fully
  reconcile against items sold or gold spent). Fine for a trend line,
  not for precise per-minute net worth figures.

## Rank / MMR snapshot worker

- Runs daily at 3am (`RankSnapshotService`, `@nestjs/schedule`), one
  `rank_tier` + `mmr_estimate` snapshot per user, written to
  `RankSnapshot`.
- This is the **only** source of rank history in Areon. Valve doesn't
  expose it retroactively — a missed day is a permanent gap in that
  user's chart, not something recoverable later. Worth alerting on job
  failures once this is running for real users, not just logging them.
- `rank_tier` (the medal) doesn't need Expose Public Match Data, so this
  runs for every user regardless of their stats-exposure state.
- `GET /players/me/rank-history` / `POST /players/me/rank-history` — read
  the accumulated history, or trigger one snapshot manually (useful for
  testing without waiting for 3am).
- **Now runs through BullMQ/Redis, not the in-process cron loop this
  used to be.** `@Cron` still fires once a day, but it now only
  *enqueues* — `RankSnapshotService.enqueueAllUsers()` adds one job per
  user (`addBulk`, `jobId` scoped to the user+date so a stray re-run
  doesn't double-queue) to the `rank-snapshot` queue, and
  `RankSnapshotProcessor` (a separate `@Processor`) does the actual
  per-user OpenDota call and DB write. This is the real point of the
  move: one user's slow or failing response used to risk holding up (or
  aborting) the whole night's batch in a single in-process loop: now
  it's an independent job with its own retry (3 attempts, exponential
  backoff), and every other user's job proceeds regardless.
- **Requires `REDIS_URL`** (see `.env.example`) — `BullModule.forRootAsync`
  is registered globally in `app.module.ts` with no in-memory fallback,
  so a missing/unreachable Redis fails loudly at startup rather than
  silently falling back to "the cron never actually does anything."
- **Testing limitation, stated plainly**: unlike the Draft Trainer and
  Tournaments logic (verified end-to-end against the real,
  unmodified service files using an in-memory Prisma double — see
  those sections), this BullMQ integration was **not** run against a
  live Redis in this environment; there's no equivalent meaningful
  in-memory stand-in for "does `Queue.add()`/a `Worker` actually work,"
  the way there was for pure business logic. The queue/processor wiring
  follows BullMQ's standard, stable API closely, but treat it as
  reviewed-not-executed until it's actually run against a real Redis.

## Teams

- `POST /teams` — create a team, creator becomes `OWNER`.
- `GET /teams/me` — teams the caller belongs to. `GET /teams/:id` — roster detail.
- `POST /teams/:id/invites` — invite by Dota `account_id32`.
  **Deliberate limitation**: only works if the invited person has already
  logged into Areon at least once, since there's no player-search API in
  this scaffold yet (that's the separate FIND PLAYERS system from the
  product doc). Inviting a stranger by account_id who's never touched
  Areon isn't possible here.
- `POST /teams/invites/:id/accept` / `.../decline` — accepting both flips
  the invite and creates the roster row in one transaction, so there's
  never an "ACCEPTED" invite with no matching `TeamMember`.
- `PATCH /teams/:id/members/:userId` — role and position. A player can
  always set *their own* position without needing captain rights; role
  changes and editing someone else's position require `OWNER`/`CAPTAIN`.
- `DELETE /teams/:id/members/:userId` — leave (self) or remove (captain+).
  The owner still can't be removed or leave directly — but now there's
  a real way out of that: `POST /teams/:id/transfer-ownership`.
- **`transferOwnership`** — demotes the current `OWNER` to `CAPTAIN`
  (not removed outright, so they stay on the roster and can leave
  normally afterward) and promotes a chosen existing member to `OWNER`,
  in one `$transaction` so there's never a moment with zero or two
  owners. Verified against the real, unmodified service with an
  in-memory Prisma double (non-owner can't transfer, can't transfer to
  someone off the roster, demotion + promotion both land correctly, and
  the demoted former owner is no longer blocked from leaving).
- Positions (`carry`/`mid`/`offlane`/`support`/`hard_support`) are
  validated in the service layer, not a DB enum, so relabeling one is a
  code change, not a migration.

## Tournaments

- **Single elimination and double elimination**, selected via
  `Tournament.bracketFormat` at creation (`'single_elimination'` default,
  or `'double_elimination'`). Group stages from the original product
  doc are still a genuinely different data model (standings/tiebreak
  rules, not bracket routing) and remain out of scope.
- `POST /tournaments` — create (creator becomes the organizer, no
  separate admin role), now accepting `bracketFormat`.
- `POST /tournaments/:id/register` — a team's `OWNER`/`CAPTAIN` registers
  it; capped at `maxTeams`.
- `POST /tournaments/:id/generate-bracket` — locks registration and
  builds the bracket by **registration order**, not skill-based seeding,
  for both formats.
- `POST /tournaments/:id/matches/:matchId/result` — organizer reports a
  winner; routing (which match a winner — and for double elimination, a
  loser too — advances into) is automatic. The tournament auto-closes
  when there's nothing left to route into.
- No player-vs-player 1v1/2v2/3v3 modes wired up — `teamSize` exists on
  the model but registration is always by `Team`.

### Single elimination — bye distribution, regression found and fixed

- Byes (for a non-power-of-two team count) are now distributed **one
  per match**, to the first N registered teams, rather than clustered
  at the end of the pairing list.
- **Real bug found and fixed while building double elimination's test
  suite, unrelated to double elimination itself**: the original
  clustered-bye approach could produce a round-1 match with **both**
  slots empty whenever more than one bye was needed (e.g. 5 or 6 teams
  padded to a bracket of 8 — verified failing before the fix, and
  passing after, for team counts 3/5/6/7/9/12 in
  `tournaments.service.spec.ts`). A fully-empty match can never be
  played, and nothing downstream of it could ever be filled in either
  — the tournament would silently get stuck mid-bracket. Since
  `bracketSize` is always the smallest power of two ≥ the team count,
  the number of byes needed is mathematically always smaller than the
  number of round-1 matches, so one-bye-per-match is always achievable
  — this wasn't a fundamental limitation, just a bug in how byes were
  assigned to slots.

### Double elimination

- **Only supported for an exact power-of-two team count** (4/8/16/32).
  Single elimination's bye mechanism has no equally simple equivalent
  here — a bye would need to propagate consistently through both the
  winners AND losers brackets, and getting that subtly wrong would
  silently produce an unfair or broken bracket rather than a loud
  error. A non-power-of-two count is rejected outright at
  `generate-bracket` time instead.
- Structure: winners bracket (WB) shaped exactly like single
  elimination; losers bracket (LB) with `2*(log2(N)-1)` rounds,
  alternating "minor" rounds (LB survivors face each other) and "major"
  rounds (LB survivors face a fresh loser just dropped from the
  corresponding WB round); a grand final (WB champion vs LB champion);
  and a conditional bracket-reset match, created only if the LB-side
  finalist wins the grand final (at that point both finalists have
  exactly one loss, so a single decisive match is needed — if the
  WB-side finalist wins instead, the tournament ends there).
- **This routing logic was derived by hand, not copied from a known
  reference implementation** (e.g. Challonge's exact seeding
  convention) — it was cross-checked against the well-known "double
  elimination needs 2N-2 (or 2N-1 with a reset) total matches" formula
  for both N=4 and N=8, and verified end-to-end against the real,
  unmodified service (`tournaments.service.spec.ts`): full 4-team and
  8-team tournaments played to completion with zero stuck matches, a
  forced bracket-reset scenario, and structural match-count checks.
  The overall *shape* (round counts, WB/LB interaction, reset
  condition) is sound; exactly which specific losers face each other
  first within a given LB round is this implementation's own
  deterministic convention, not validated against any specific external
  platform's seeding.
- **A real regression was introduced and caught while building this**:
  an early rewrite of `completeMatch` accidentally passed the
  *pre-update* match object into single-elimination's `advanceWinner`
  (still showing a `null` winner) instead of the post-update row —
  caught immediately by the existing single-elimination test suite
  going red, fixed before shipping. Left in this note as a concrete
  example of why the tests exist, not just a hypothetical.
- **Schema change**: `TournamentMatch` gained a `bracket` field
  (`'winners' | 'losers' | 'grand_final' | 'bracket_reset'`) and its
  unique constraint changed to `(tournamentId, bracket, round,
  position)` — running `npx prisma migrate dev` is required before this
  works against a real database that already has the old schema.

## Draft Trainer

- **Free Draft** now runs a real config-driven Captain's Mode engine
  (`draft-trainer.service.ts`), not a flat alternating placeholder.
  `buildCaptainsModeSequence()` is the single source of truth for the
  24-step order — the controller and frontend never hardcode step
  numbers, per the "don't hardcode steps in the UI" requirement.
- **Updated against official Valve patch notes for 7.40** (dota2.com/patches/7.40,
  released Dec 2025): the intra-order of ban phase 1 and ban phase 3
  changed — quoted directly from the patch note:
  `First Ban Phase NEW: First-First-Second-Second-First-Second-Second`,
  `Third Ban Phase NEW: First-Second-First-Second`. The counts in those
  phases did NOT change (still 7 and 4 bans) — only the order within
  them. No later patch (7.40b/c, 7.41 and its point releases) was found
  changing the draft order further; 7.40c's only CM-relevant change was
  adding a new hero (Largo) to the pool, not a reorder.
- **A previously-supplied 25-step sequence claiming a further 7.40
  restructuring (extra pick-phase actions, 25 actions total) was checked
  against the official patch note above and does not match it** — the
  patch note only touches ban-phase order, not pick phases, and the
  total stays 24 actions. That version was not implemented; the ban
  phase 1/3 reorder that IS confirmed above was, instead.
- **Still not independently confirmed**: the intra-phase order of ban
  phase 2 and all three pick phases — only totals (7/3/4 bans split
  3-2-2/4-1-2, 2/6/2 picks split 1-3-1) are sourced; no table gives their
  turn-by-turn order. A further search pass turned up only fragments
  describing a *different, older* draft structure (4- and 6-action
  phases from before patch 7.34) — those numbers don't match the
  current 3/6/2-action phases, so applying them here would be forcing a
  fact that answers a different question. Third-party draft simulators
  claim "the real pick & ban order" but aren't Valve or a wiki citing
  Valve, so per the stated source-priority (official Valve data, then
  in-game data, then patch data, then third-party databases), they
  don't outrank the existing reconstruction. Marked as a reconstruction
  in code, same as before — this is a genuine, checked gap, not an
  unchecked one.
- **What's confirmed** (Liquipedia's Game Modes page): ban-phase totals
  7/3/4, pick-phase totals 2/6/2, 24 actions total, 15s per ban in the
  first ban phase, 30s for every other action, 130s total reserve time
  per side, and timeout behavior (ban timeout = skipped, pick timeout =
  random hero).
- **First Pick / Second Pick is independent from Radiant / Dire.**
  `DraftSession.radiantSide` is a single flag (random coin flip, or an
  explicit choice via `POST /draft-trainer/free` body) marking which
  logical side (FIRST_PICK/SECOND_PICK) plays Radiant. One flag is
  enough for all 4 real combinations — there are only two sides, and
  going first is a property of the FIRST_PICK label itself, baked into
  `buildCaptainsModeSequence()`'s fixed construction — so a separate
  "which side is first pick" field would just duplicate that.
- **Server-enforced timeouts**: `POST /draft-trainer/sessions/:id/timeout`
  re-checks elapsed time against `currentStepStartedAt` before applying
  anything, so a client can't fast-forward its own countdown.
- **`captainsModeAvailable` on Hero** — not populated from a real
  curated exclusion list yet (defaults to `true` for everyone). The
  mechanism is real; the actual current data isn't sourced here.
- **130s reserve time bank — now implemented**, confirmed against
  Liquipedia's Game Modes page and an academic UI-analysis paper on
  Captain's Mode: each side (`reserveFirstSec`/`reserveSecondSec`,
  starting at 130, non-replenishing, shared across the whole draft) only
  starts depleting once that side's main per-action timer (15s/30s) is
  spent — before that point the main timer is unaffected. A forced
  outcome (skipped ban / random pick) only fires once BOTH the main
  timer AND that side's reserve are exhausted; a manual action that ran
  a little over the main allowance deducts just the overflow from
  reserve, not the whole thing. See `appendAction` in
  `draft-trainer.service.ts`.
- AI Draft, Training scenarios, and Draft Analysis remain unimplemented,
  unchanged by this pass.
- **Pro Draft** (real match replay) is unaffected by this rework —
  it already used real `picks_bans` data, not the placeholder sequence.
- Frontend additions in this same pass: a Restart control available
  mid-draft (with a confirm prompt, not silent), a Rematch button on
  the completion screen that reuses the same Radiant/Dire assignment
  (vs. New Draft's fresh coin flip), and a lightweight hover preview
  card for each hero (name/attribute/roles) that links out to the
  existing hero database page for abilities/counters rather than
  duplicating that data in a second place.

- **Play with friends — reworked away from link-sharing** per direct
  feedback: instead of copying/sending a URL, `POST /draft-trainer/invite`
  sends an on-site invite to a specific *online* user
  (`DraftSession.invitedUserId`), who sees it via
  `GET /draft-trainer/invites` and accepts with one click — no link
  ever changes hands. "Online" comes from `User.lastSeenAt`, updated by
  a `POST /players/me/heartbeat` the frontend calls every 20s; `GET
  /players/online` lists anyone seen in the last 60s. This is a
  simplification of the FIND PLAYERS system from the product doc, not
  that system — there's no friends list, just "everyone currently
  active on the site."
- **Matchmaking queue added**: `POST /draft-trainer/matchmaking/search`
  — if someone else is already waiting (`opponentType: 'matchmaking'`,
  `status: 'waiting_for_opponent'`), joins them immediately; otherwise
  becomes the one waiting. The `DraftSession` row itself is the queue,
  no separate ticket table. **Known simplification**: the find-or-create
  check isn't wrapped in a strict row lock, so two people searching in
  the exact same instant could theoretically both end up waiting instead
  of matching each other — self-correcting on the next search, not
  stuck, but a real production queue would want proper locking to close
  that narrow window.
- `participantForSide` now treats both `'friend'` and `'matchmaking'` as
  two-real-participant modes (previously only `'friend'` was handled
  this way).
- `POST /draft-trainer/sessions/:id/cancel` — withdraw from matchmaking
  or retract a not-yet-accepted invite.

- **AI bot — added.** `POST /draft-trainer/ai` creates an `opponentType:
  'ai'` session with one side (`aiSide`) controlled by a fixed
  heuristic, **not a trained model** — calling it "AI" is the product's
  label, not a technical claim:
  - Bans: uniformly random among available Captain's-Mode-eligible
    heroes. No pick/win-rate weighting — that data isn't stored yet.
  - Picks: scores each available hero by how many of the human's
    already-picked heroes appear in its `Hero.countersJson.goodAgainst`
    list (real per-matchup win rates from OpenDota, synced via
    `HeroesService.syncMatchups`). Highest score wins, ties broken
    randomly. Degrades to a random pick when the human has picked
    nothing yet, or when none of the candidate heroes have synced
    matchup data — an honest gap, not a silently wrong answer.
  - The bot resolves all of its consecutive turns synchronously inside
    `performAction`/`performTimeout`/`createAiDraft` itself
    (`resolveBotTurns`), so the session state the frontend ever sees is
    always sitting at the human's next turn or completed — no polling
    needed for this mode, unlike friend/matchmaking.
  - `participantForSide` returns `null` for the bot's side — no human
    can ever submit an action on its behalf, enforced the same way as
    every other mode.

- **Draft rating — added.** `GET /draft-trainer/sessions/:id/rating`,
  available once `status: 'completed'`. **This scores structural
  properties of the finished composition, not win probability** — a
  real prediction would need outcome data trained on thousands of
  games, which this scaffold doesn't have and shouldn't pretend to.
  Three components summing to 100:
  - Role coverage (40 pts) — does the lineup's `Hero.roles` tags cover
    Carry/Support/Disabler/Durable/Nuker?
  - Attribute diversity (20 pts) — how many distinct primary attributes
    (str/agi/int/universal) appear among the 5 picks.
  - Counter-awareness (40 pts) — reuses the exact same
    `countersJson.goodAgainst` scoring the AI bot uses (see
    `pickBotHero`), applied retroactively: of the picks made after at
    least one enemy hero was already visible, what fraction actually
    countered something on the board? Picks made before the enemy
    showed anyone aren't counted against this at all — there was
    nothing to counter yet, `counterAwareRatio` comes back `null` (not
    a bad score) if that never happened for a whole side.
  - Works for Pro Draft replays too, not just Free Draft — it's purely
    a function of the finished `actions`/`radiantSide`, mode-agnostic.

- **Draft rating extended into a fuller breakdown**, still no win
  probability:
  - `reasons: string[]` — plain-language sentences generated
    mechanically from the same numbers the score is built from (missing
    roles, attribute concentration, counter-awareness ratio), not a
    separate free-form opinion.
  - `counterPairs` — every (Radiant pick, Dire pick) pair where one
    hero's real, synced `countersJson.goodAgainst` includes the other —
    concrete "X counters Y" callouts, not vibes.
  - `mostDangerousUnbanned` — among heroes nobody banned or picked,
    which one has the strongest synced matchup against a given side's
    final five? Frequently `null`, honestly, because most heroes never
    had `syncMatchups` run on them — see the hero-database notes above.
  - `notes.synergiesAvailable: false` — still true, still no confirmed
    OpenDota source for ally win rate, unchanged from the earlier
    hero-database investigation.
  - `notes.itemRecommendationsAvailable: false` — **different kind of
    gap than synergies**: the data exists in principle
    (`/heroes/{id}/matches` for a hero's recent games, then per-match
    item slots), but computing real win-rate-weighted item suggestions
    needs a background aggregation job pulling and caching dozens of
    matches per hero — not something to approximate with a couple of
    live calls at draft-completion time. Worth building as a proper
    scheduled job later, not faking now.

## Find Players

- **`GET /players/search`** — real search over Areon's own registered
  users (not all of Dota 2), by nickname, rank range, lane role, hero
  played, and minimum match count.
- **New confirmed field: `Match.laneRole`.** OpenDota's
  `/players/{id}/matches` does include `lane_role` (1=Safe, 2=Mid,
  3=Off, 4=Jungle) — verified via a secondary source reflecting the
  real API shape. Now captured on every sync (and backfilled on
  re-sync for matches synced before this field existed).
- **Important limitation, stated up front rather than implied**:
  `lane_role` is lane assignment, NOT the 5-position system
  (Carry/Mid/Offlane/Soft Support/Hard Support) players actually mean
  by "role". Safe and Off lanes each host one core and one support —
  `lane_role` can't distinguish them. A "Safe lane" filter match could
  be either a carry or a hard support. This is a real data gap, not a
  UI choice; true position detection would need parsed replay data
  (e.g. gold/xp curves or ability-cast patterns) this scaffold doesn't
  have.
- Rank filtering uses each user's latest `RankSnapshot.rankTier`
  (medal), same source as the profile's rank hierarchy — inherits the
  same honesty caveats from that discussion (missing for anyone whose
  snapshot job hasn't run, or who has stats exposure off).
- "Has played this hero" / "minimum matches" both come from `Match`
  rows already synced through the normal sync flow — someone who's
  never clicked "Обновить из OpenDota" simply won't show up for these
  filters, regardless of how much they actually play.
- **Not implemented**: region and language, per the original product
  doc's search criteria — Areon never collects either, and fabricating
  a filter on data that doesn't exist would be worse than omitting it.
- Results feed directly into two existing invite flows: Draft Trainer's
  on-site invite (`inviteFriend`) and Team invite by `account_id32` —
  this closes the "you can only invite people whose account_id you
  already know" limitation noted when Teams was first built.

## Admin

- **Single source of truth: `ADMIN_STEAM_ID64`.** No API route grants or
  revokes admin status — it's recomputed on every login by comparing the
  logging-in SteamID64 against this env var (`AuthService.loginOrCreate`).
  Change the env var and have that person log in again to move admin
  to a different account; the previous holder is demoted in the same
  pass, not left as a lingering admin from an old config.
- `AdminGuard` re-checks `User.isAdmin` from the database on every
  request rather than trusting a claim baked into the 30-day JWT — a
  token issued while someone was admin shouldn't still work as one
  after `ADMIN_STEAM_ID64` changes and they log in again elsewhere (or
  don't log in again at all).
- `GET /admin/stats`, `/admin/users`, `/admin/teams`, `/admin/tournaments`
  — read-only oversight of the whole platform.
- **`POST /heroes/sync` and `POST /heroes/:id/sync-matchups` moved from
  `HeroesController` to `AdminController`.** These were sitting behind
  only the global login guard before — any logged-in user could trigger
  a full hero-database resync. That's exactly the kind of gap the
  earlier `/heroes` guard discussion was about, just one level up:
  global, moderately expensive actions need admin gating, not just
  "logged in."
- No promote/demote UI, no multi-admin support — the product ask was
  specifically "only I should be owner," and the env var already
  guarantees exactly one admin (or zero) without needing a management
  screen for it.

## Support actions

- **Ban**: `POST /admin/users/:id/ban` / `.../unban`. Enforced in
  `JwtStrategy.validate()`, not just at login — a banned account's
  already-issued 30-day JWT stops working on its very next request,
  not just next time they try to log in. `steamReturn` also checks
  `isBanned` before ever setting the auth cookie, so a banned person
  logging in fresh gets redirected to `/banned` instead of a
  session that would immediately 403 on first use.
  **Known gap**: an already-open browser tab with a now-invalid cookie
  just gets treated as "logged out" (falls back to the login screen),
  not shown the banned message specifically — only a fresh login
  attempt sees `/banned`. Distinguishing those would need the frontend
  to inspect the 401 response body, which the current `request()`
  wrapper collapses into a generic error.
- The admin UI won't let you ban another admin — with a single-admin
  model this is mostly a guard against banning yourself by mistake, not
  a real multi-admin safety feature.
- **Edit user**: `PATCH /admin/users/:id`, deliberately narrow —
  `personaName` and `statsExposed` only. `accountId32`/`steamId64` are
  real Steam identity and editing them would desync the account;
  `isAdmin` is excluded on purpose since that stays governed solely by
  `ADMIN_STEAM_ID64`.
- **Force-close a tournament**: `POST /admin/tournaments/:id/force-close`
  sets status to a new `CANCELLED` value (distinct from a natural
  `COMPLETED` finish) regardless of current state. Matches that were
  still `PENDING` are left exactly as they were — cancelling the
  tournament just makes them unreachable through the normal flow.
- **Force a match result**: `POST /admin/tournaments/:id/matches/:matchId/force-result`
  reuses the exact same `completeMatch` logic as a normal organizer
  result (winner advances through the bracket the same way), just
  without requiring the caller to be that tournament's organizer.
  **No frontend UI for this one yet** — the API exists, but picking a
  specific stuck match to force isn't wired into the admin panel in
  this pass; ban/unban, edit, and tournament force-close are.

## Realtime (WebSockets, replacing polling)

- **`DraftGateway`** (Socket.IO, via `@nestjs/websockets`) replaces the
  frontend's old 2s poll for `friend`/`matchmaking`/`ai` draft sessions.
  Each session is its own room (room name = session id).
- **Auth reuses the exact same `areon_token` cookie the REST API
  trusts** — `handleConnection` verifies it with the same `JwtService`,
  no separate/weaker socket-only auth path. A client only gets joined to
  a session's room after the server confirms they're actually one of
  that session's two real participants (`createdByUserId` or
  `participantSecondUserId`) — a stranger's `join` request is silently
  ignored, not errored, so they never receive that session's updates.
- Every state-changing path funnels through one place —
  `appendAction()` — which is where the single `emitUpdate` call lives.
  `joinFriendDraft` gets its own explicit emit too, since claiming the
  open seat doesn't go through `appendAction` and the waiting creator
  needs to know the moment someone shows up, not on their next poll.
- BigInt (`sourceProMatchId`) doesn't serialize through Socket.IO's JSON
  layer any more than Nest's HTTP one — `DraftGateway.emitUpdate`
  stringifies it the same way `MatchesService.serialize()` already does
  for REST responses.
- **Solo (`self`) sessions still don't use sockets at all** — there's only
  one real actor, so there's nothing to push to.
- **Undo is admin-only, by design — there is no player-facing undo.**
  `GET /admin/draft-sessions` lists every active/waiting free-mode
  draft platform-wide, not scoped to the admin's own games, so an admin
  can open and spectate any of them. `POST /admin/draft-sessions/:id/undo`
  pops the last action and reopens that step. Admins can also join any
  session's WebSocket room as a spectator (`DraftGateway.handleJoin`
  checks `isAdmin` alongside the normal participant check), which is
  what makes watching a live game and then undoing something in it
  actually work end to end, not just as two disconnected features.
  **Known limitation**: reserve time isn't refunded on undo — only the
  running total is stored, not a per-action delta, so there's nothing
  to hand back precisely. The step becomes replayable with a fresh main
  timer; whatever reserve the undone action spent stays spent.

- **Share Draft** — the "Поделиться" button on a completed draft just
  copies the URL; no new backend work was needed because
  `GET /draft-trainer/sessions/:id` was already unrestricted to any
  participant (only the global login guard applies). That's
  deliberate, not an oversight being papered over: per the "полностью
  закрыто без исключений" access decision, a shared link still requires
  an Areon/Steam login to view — there's no public, no-login viewing
  mode, unlike a real "share to anyone" feature would imply.
- **Pre-existing minor gap surfaced by this**: any logged-in user can
  already view any draft session (in progress or completed) by its
  link/id, not just completed ones — the REST endpoint doesn't
  distinguish. Picking/banning is still correctly blocked for
  non-participants via `isMyTurn`, so this is a viewing-privacy
  question, not a game-integrity one. Worth tightening if that matters,
  not done here since it wasn't the ask.

## Closing out remaining Draft Trainer gaps

- **Viewing privacy, fixed with a distinction**: `getSessionForViewer`
  now allows any logged-in Areon user to view a **completed** draft
  (that's the whole point of Share Draft — a finished outcome can't be
  unfairly influenced by being looked at), but restricts an
  **in-progress** draft to its two real participants or an admin. The
  earlier version had no restriction at all, which would have let a
  stranger peek at a live friend/matchmaking draft.
- **Reserve time is now precisely refundable on undo.** `DraftEvent`
  gained a `reserveSpent` field, written by `appendAction` for every
  action (0 if it finished within the main allowance). `adminUndo`
  reads the popped action's `reserveSpent` and adds it back to the
  correct side's pool — the earlier version could only reopen the step,
  not restore what that step had cost.
- **Item recommendations, built on the same pattern as `syncMatchups`.**
  New `Item` table (id -> display name/icon, via `GET /constants/items`)
  populated by `POST /admin/items/sync`. `HeroesService.syncItemBuilds`
  (`POST /admin/heroes/:id/sync-items`) pulls a hero's recent matches
  (`/heroes/{id}/matches`), fetches full detail for each
  (`getMatch`), tallies win rate per final item slot, and stores the
  top 10 (min 5 games) on `Hero.itemBuildsJson`.
  - **Still not conditioned on a specific enemy hero** — that data
    source doesn't exist, same as the synergies gap. This is "items
    that correlate with winning on this hero recently," not "build
    this against that hero."
  - **Real cost, stated plainly**: this is `limit` (default 20) full
    match-detail fetches per call, not a cheap operation — an on-demand
    admin action with a small sample, not a production-scale job. A
    real rollout would want this as a proper scheduled/batched pipeline
    instead of a button.

## Orion Trials

- **Scope decision, stated plainly**: the original spec's ABILITY
  category ("5 kills with Finger of Death") and precise multi-kill
  COMBAT detection (double/triple kill, Rampage) are **not in the
  active pool**. Both need per-event replay data (`kills_log`,
  killstreak detection) that only exists on parsed match replays —
  confirmed via multiple independent sources that only ~5% of matches
  get parsed by default, parsing is requested per-match and takes
  1-5 minutes, and isn't guaranteed to succeed for old/private
  matches. Per the spec's own requirement 18 ("если конкретное
  действие невозможно определить по доступным данным, такое испытание
  нельзя выпускать в активный пул"), taken literally: excluded, not
  approximated with a worse signal. Ward-count SUPPORT trials
  (`obs_placed`/`sen_placed`) are also excluded — not confirmed
  parse-only, but not confirmed safe either, and left out on the same
  "unsure means leave it out" principle. `hero_healing`-based SUPPORT
  trials ARE included — confirmed present in the same lightweight sync
  endpoint by multiple independent client library field mappings.
- `Match` gained `heroDamage`/`heroHealing`/`lastHits` (backfilled on
  re-sync, same pattern as `laneRole`) and `trialsProcessedAt` — the
  idempotency anchor: a match is evaluated against Orion Trials exactly
  once, ever, regardless of how many times sync runs afterward.
- **Pipeline**: `MatchesService.syncRecentMatches` calls
  `TrialEngineService.processUnevaluatedMatchesForUser` right after
  every sync. This is the actual "MATCH → TRIAL ENGINE" trigger from
  requirement 9 — **honestly bounded by how often sync itself runs**,
  since neither OpenDota nor Steam expose a webhook for "a match just
  ended." Freshness is "next time this user syncs," not true real-time
  push, and that's stated here rather than implied otherwise.
- `trial-evaluators.ts` — one pure function per `TrialTemplate.code`
  (`play_n_matches`, `win_n_matches`, `hero_matches_played`,
  `win_streak`, etc.), each taking `(match, condition, progress) ->
  {progress, completed}`. Verified directly (no Prisma stub needed,
  they're pure) — 19/19 checks, covering win/loss slot math, streak
  reset-on-loss behavior, null-field handling (a field missing on an
  old match never falsely completes a trial), and hero-scoping.
- `TrialEngineService.processUnevaluatedMatchesForUser` — the whole
  match → validation → reward pipeline runs inside one Prisma
  `$transaction`: marking a trial COMPLETED, creating its
  `ShardTransaction`, and updating `User.shardBalance` either all
  happen or none do. Verified against the real, unmodified service
  with an in-memory Prisma double — 16/16 checks, specifically
  including idempotency (re-running processing after everything's
  already marked pays out nothing twice) and that a match arriving
  after a trial already COMPLETED never re-triggers it.
- **Anti-exploit** (requirement 17): `shardBalance` is a cached field
  on `User`, but never written outside the same transaction as a
  `ShardTransaction` insert — there's no code path that updates one
  without the other. The client only ever reads; every write path
  (trial completion, admin adjustment) is server-only. Progress and
  status live in the DB, keyed by `UserTrial.id`, never trusted from
  request bodies.
- `TrialGeneratorService` — personalizes `hero_matches_played`/
  `hero_win` to the user's most-played hero (from their own synced
  match history) and `hero_rarely_played` to a real CM-eligible hero
  absent from their last 20 matches. Falls back to excluding
  hero-personalized templates entirely for a user with zero synced
  matches, rather than guessing. Avoids repeating a template used in
  the last 2 cycles where the pool allows it, falls back to allowing a
  repeat rather than shipping fewer than 10 trials. **Not run through
  the same rigorous in-memory-stub test as the engine/evaluators** —
  reviewed, not executed, given the scope already covered elsewhere in
  this pass.
- Cycle rotation is a plain `@Cron` hourly pass (`TrialsService`), not
  a BullMQ queue like rank-snapshot's — deliberately: generating a
  cycle is pure DB reads/writes, no external API call that could hang
  or fail independently of the DB itself, so BullMQ's
  retry-with-backoff machinery wouldn't buy anything a per-user
  try/catch loop doesn't already provide here.
- Seed pool is ~37 templates across MATCH/HERO/SURVIVAL/FARM/SUPPORT/
  STREAK, spread specifically to keep COMMON and LEGENDARY (the
  thinnest tiers at 4 and 2 templates in the first pass) well past
  their per-cycle draw size — a pool exactly equal to the draw count
  means every single cycle repeats, which defeats the point of
  "avoid repeats" entirely.
- **A real bug was found and fixed while doing this expansion,
  unrelated to database size itself**: several templates deliberately
  share one evaluator `code` across difficulty tiers (e.g.
  `match_assists_threshold` exists at both COMMON and RARE, with
  different thresholds). Cross-cycle repeat-avoidance was originally
  keyed by that same `code` — meaning using the RARE variant one cycle
  would also block the COMMON variant the next cycle, and vice versa,
  starving the "fresh" pool far more aggressively than the raw
  template count suggested. Verified failing (COMMON tier specifically
  collapsed to only 2 truly "fresh" candidates against a target of 4,
  forcing an unwanted repeat-fallback) and fixed by introducing a
  separate `seedKey` (unique per exact template variant) for
  cross-cycle avoidance, while keeping in-cycle same-theme dedup keyed
  by `code` as before (still correctly prevents drawing two
  "kill count" trials in the same cycle, just doesn't over-block across
  cycles). Verified against the real, unmodified generator: 6/6 checks,
  specifically confirming zero exact-template repeats across 3
  consecutive cycles while theme-level (code) overlap across cycles is
  now correctly *allowed* rather than accidentally suppressed.
- `TrialTemplate.code` is deliberately NOT unique (many templates share
  one evaluator at different tiers); `TrialTemplate.seedKey` is the
  real unique identifier, used only by `seedTemplates()`'s idempotency
  check. Admin-created templates can leave `seedKey` null — Postgres
  allows multiple nulls under a unique constraint.
- `Trial Management` in the admin panel: list with per-template
  completion counts, activate/deactivate toggle. Editing a template's
  `code` or the *shape* of `conditionJson` isn't exposed — those are
  tied to a specific evaluator function; changing what *kind* of
  condition a template checks needs a new evaluator, not just an admin
  edit, same reasoning as `captainsModeAvailable` being curation, not a
  rules engine.
- `ORION PLUS SHARDS` is deliberately not tied to a shop yet — the
  ledger, balance, and reward pipeline are real and complete;
  `ShardTransaction.type` already anticipates `'SHOP_PURCHASE'`
  alongside `'TRIAL_REWARD'`/`'ADMIN_ADJUST'`, but no spending surface
  exists yet, per the spec's own "сейчас главное — создать саму валюту
  и систему начисления." A `/shop` page exists in the nav as an
  explicit "Скоро" (Coming Soon) placeholder — visible, honestly
  labeled as non-functional, not a hidden or half-wired feature.

## Global Music Player (favorites only)

- The actual music search/streaming lives entirely in the frontend
  (`JamendoProvider` calling Jamendo's CORS-enabled API directly) — the
  backend's only role is `FavoriteTrack`, since that's the one piece
  requirement 10 explicitly asked to survive across devices. Current
  track, position, queue, volume, shuffle/repeat all stay client-side
  (`localStorage`) on purpose, per the same requirement's "временное
  состояние — локально."
- `FavoriteTrack` is scoped by `(userId, provider, providerTrackId)` —
  not a global track id, since a track's identity only makes sense
  together with which provider returned it. If the provider is ever
  swapped (the whole point of the `MusicProvider` abstraction on the
  frontend), old favorites become orphaned rows, not broken foreign
  keys, since nothing else joins against this table.
- `GET/POST/DELETE /music/favorites` — straightforward, no special
  anti-exploit concerns here the way Trials/Tournaments needed (this
  is just "remember what I liked," not something with a reward or
  competitive stake attached).

## AI Coach

- **Feasibility researched before building anything** — cross-checked
  independent sources (Go/R client libraries, MCP server docs) for
  exactly what OpenDota's PARSED match data actually contains.
  Confirmed real: `teamfights[]` (per-fight damage/healing/gold/xp
  deltas and kills, per player), `purchase_log`, `ability_upgrades_arr`,
  `kills_log`, ward logs, objectives timeline. All of this is
  parse-only — same ~5% default-parse-rate fact that shaped Orion
  Trials' scope — but here a match is parsed **on demand, per user
  request**, not passively for every synced match, which is a
  meaningfully different cost calculus than Trials faced.
- **Two real, documented data-quality gaps surfaced by the research,
  not invented caution**: an open `odota/parser` GitHub PR documents
  Aegis-reincarnation deaths sometimes leaking into `kills_log`; an
  independent research project documented unexplained gaps in
  `ability_upgrades_arr`/`hero_healing`/etc even on parsed matches.
  Both are called out directly in the AI Coach system prompt.
- **Deliberately deferred to a later phase, not attempted**: exact
  HP/mana reconstruction at an arbitrary timestamp (requirement 17) and
  live cooldown-availability tracking (requirement 11) — both would
  need a real state-simulation engine built from raw event logs, and
  are the two pieces most likely to produce a plausible-sounding but
  wrong answer if rushed. Also deferred: patch-versioned historical
  hero/item stats (requirement 21) — we only store a *current* snapshot
  of Hero/Item data, no versioned-by-patch history exists yet.
- `src/coach/coach-data-extractor.ts` — pure functions, no AI, no
  Prisma, no network: turns raw parsed OpenDota fields into a
  `MatchFacts` object. This is the actual enforcement point for "never
  invent data" — a missing field surfaces as `null`
  (**verified**: 12/12 checks against the real, unmodified function,
  specifically confirming a missing `hero_healing` stays `null` rather
  than silently defaulting to 0, and a match with no `teamfights` field
  returns `null` — "data unavailable" — not an empty array that would
  read as "confirmed, no fights happened").
- `src/coach/coach-prompt-builder.ts` — the LLM only ever receives this
  pre-extracted `MatchFacts` object as JSON, never raw match data. The
  system prompt enforces the Confirmed/Likely/Data-unavailable
  labeling discipline from requirement 26 explicitly, not as an
  afterthought.
- `src/coach/coach.service.ts` — orchestrates: request a parse if
  needed, poll with a **bounded** budget (6 attempts, 10s apart — a
  request/response HTTP handler blocking for minutes indefinitely is a
  bad pattern regardless of patience), extract facts, resolve hero/item
  names, build draft-threat context from the same `Hero.countersJson`
  Draft Trainer already uses, call the LLM, cache the result
  (`CoachReport`, keyed by match+user+depth — expensive to regenerate).
- **NOT executable in this sandbox** — no network access to actually
  call OpenDota's parse endpoint or the Anthropic API here. Reviewed,
  not run, same honesty flag as BullMQ/Docker/Jamendo. Requires
  `ANTHROPIC_API_KEY` (see `.env.example`/`FIRST_LAUNCH.md`) — verify
  the current correct model slug against https://docs.claude.com
  before deploying; the default in code is a best-effort guess, not a
  confirmed-current API model identifier.

## Automatic Patch Detection & Sync

- **Verified before building**: confirmed via multiple independent,
  recent (within the last month) sources that **7.41e is genuinely the
  current Dota 2 patch** — this is what `PatchSyncService` seeds as the
  initial value, not a placeholder or an invented future version.
- **Detection is deliberately dumb** (requirement 8): the only
  comparison ever made is `detected !== stored`, a plain string
  inequality against OpenDota's `/constants/patch` list (the same
  human-readable "7.41e" naming already used elsewhere in this
  codebase — `Match.patch`, `DraftSession.rulesVersion`'s comment).
  Nothing parses a patch name into components; nothing hardcodes any
  specific version, past or future. Checked every 45 minutes
  (`@Cron('*/45 * * * *')`) — inside the 30-60 minute window asked for.
- **Real atomicity, verified against the real, unmodified service**:
  new hero/item data is fetched OUTSIDE any transaction (network calls
  don't belong inside one), then written INSIDE a single
  `$transaction` alongside flipping `PatchVersion.currentPatch`. 15/15
  checks passed, including the one that actually matters most — a
  mid-transaction failure (a malformed item entry crashing the loop
  partway through) leaves a hero that WAS upserted during that same
  failed attempt correctly rolled back to not existing, not as a
  partial write. This required building a test stub with a genuinely
  rollback-on-throw `$transaction` (earlier test stubs in this project
  were no-op passthroughs — that wouldn't have proven anything here).
- **No parallel data system** — `HeroesService.syncHeroes`/`syncItems`
  gained optional `dataPatch`/`client` parameters so
  `PatchSyncService` calls the SAME methods (inside its own
  transaction) rather than duplicating the fetch/upsert logic. The
  existing manual "Синхронизировать базу героев" admin button still
  calls them with neither argument, unchanged. Draft Trainer,
  Tournaments, and AI Coach all read `Hero`/`Item` directly — once a
  sync commits, they're automatically current with no separate sync
  step needed for them.
- `Hero.dataPatch`/`Item.dataPatch` — which patch a row's data was
  fetched under, satisfying requirement 6 ("нельзя допускать ситуацию
  когда герой уже обновлён, а предметы нет") via the transaction's
  atomicity rather than needing a separate reconciliation check.
- **Honest limitation on rollback** (the spec's own wording was
  "желательно" — explicitly a nice-to-have): `Hero`/`Item` rows are
  upserted in place, not kept as versioned historical snapshots.
  `rollback()` can only stop treating a broken patch as active and
  point `currentPatch` back at the last verified-good label — it
  cannot resurrect the actual prior stat values, since those were
  never snapshotted before being overwritten. A true full rollback
  would need a genuinely larger schema change (versioned Hero/Item
  history), not attempted here.
- **"Колесо фортуны" and mini-games** (mentioned in the spec's data
  list) don't exist anywhere in Areon yet — nothing to sync for them.
  Whenever built, they should read `Hero`/`Item` the same way
  everything else does, not a separate parallel feed.
- `GET /patch/status` — public, any logged-in user (shown on
  `/settings`). `POST /admin/patch/check-now` and
  `POST /admin/patch/rollback` — admin-only, in the panel's
  "Обслуживание" section.

## Mini Games — Techies: Minesweeper

- **"Mini Games -> Techies: Minesweeper -> future games"** structure,
  per the spec's own requirement 8: `MiniGameSession`/`MiniGameStats`
  are generic, keyed by a plain `gameType` string — a second game
  reuses both tables as-is; only the board logic
  (`minesweeper-engine.ts`, `minesweeper.service.ts`) is
  Minesweeper-specific, living in its own `src/minigames/minesweeper/`
  folder next to where a future game's folder would go.
- **Server-authoritative, same anti-exploit discipline Orion Trials
  established**: mine positions (`MiniGameSession.mineLayoutJson`) are
  never sent to the client until the game ends. The client can only
  ever request a reveal/flag by cell index; the server computes
  everything — including the flood-fill and the win check — and hands
  back only what that specific action actually revealed.
- **A real bug was caught before shipping, not after**: the client
  architecturally cannot compute a revealed cell's adjacent-mine count
  itself (it never knows mine positions) — an earlier draft of this
  feature returned only *which* cells were revealed, not their
  numbers, which would have made the game literally unplayable (no
  numbers ever shown). Fixed by adding `cellNumbersJson` to the
  session, computed and persisted by the server on every reveal.
  Caught specifically because the same "verify against real code"
  discipline used everywhere else in this project — writing the
  frontend against the actual response shape — surfaced it immediately
  rather than after the fact.
- **Verified against the real, unmodified code — 146 checks total**:
  75 on the pure engine (`generateMineLayout`'s safe-zone guarantee
  across 20 randomized trials, flood-fill correctness including the
  "does not propagate past a numbered cell" rule on a hand-built
  board, win detection), 11 on the service (Shards and Rating change
  independently — never derived from one another, per requirement 5 —
  streak resets on a loss, ownership/already-ended guards), 60
  specifically on the `cellNumbersJson` fix (every revealed cell gets
  a valid 0-8 count, persists across a simulated page reload).
- Classic Minesweeper size/mine-count triples for Easy/Normal/Hard
  (9×9/10, 16×16/40, 30×16/99) — the well-established standard
  convention, not invented. Reward numbers (Shards, Rating, streak
  bonus) are Areon's own choice, seeded once via
  `MinesweeperService.seedConfigs()` and then admin-editable in the DB
  without touching code, satisfying requirement 4's "все значения
  сделать настраиваемыми."
- `User.rating` is a genuinely separate field from `User.shardBalance`
  — verified directly (test [B] above) that the two never move
  together or derive from each other. No ledger/transaction history
  exists for rating the way `ShardTransaction` does for Shards — the
  spec didn't ask for one, only for the numbers to stay conceptually
  separate, which they are.
- No visual/audio Techies assets are reproduced from the real game —
  the bomb/flag icons are original, simple SVGs evoking the same idea
  (a danger marker, a mine), not a copy of any actual Dota 2 asset,
  consistent with this project's standing copyright policy.

## Wheel of Fate

- **Reuses the AI Coach's exact call pattern, not a second copy** — the
  only new network call this feature makes is the same
  `api.anthropic.com/v1/messages` shape `coach.service.ts` already
  uses. Requires the same `ANTHROPIC_API_KEY` (see `.env.example`).
- **The actual anti-hallucination discipline**: the AI is given the
  real `Item` catalog (internal names) as the only vocabulary it's
  allowed to use, and its response is validated in
  `wheel-prompt-builder.ts`'s `validateConcepts()` before a single row
  is persisted — a build referencing even ONE invented item name is
  dropped **entirely**, not "fixed" by substituting something real for
  the fake entry. Verified against the real, unmodified function —
  7/7 checks, specifically including a mixed batch where one valid and
  one hallucinated concept are submitted together and only the valid
  one survives.
- **Generated once per hero, not once per spin** — an LLM call per
  spin would be slow and costly for something meant to feel instant.
  `HeroBuildConcept` caches 3 validated concepts per hero on first
  request; every later spin for that hero picks randomly from the
  existing pool. "Разные, но логичные сборки" (requirement) comes from
  this pool, not from regenerating on every click.
- Real hero portraits and item icons — no new asset work needed, reuse
  `Hero.iconUrl`/`Item.iconUrl` exactly as-is (the same Steam CDN URLs
  already used everywhere else in Areon).
- **Frontend design deviation, stated plainly**: the spec describes a
  literal circular wheel with heroes on sectors. With 120+ heroes in
  the roster, a true pie-slice wheel would make each sector illegible.
  Built as a horizontal slot-machine reel instead — the standard,
  readable way this exact "spin and land on one of many items" UI
  pattern is built at this scale — while keeping the "SPIN THE WHEEL",
  rapid-then-decelerating motion, and landing-highlight experience the
  spec actually asked for.
- `POST /wheel-of-fate/spin` picks a uniformly random hero from the
  full synced roster (not filtered to `captainsModeAvailable` — Wheel
  of Fate isn't a competitive-drafting context, no reason to exclude
  any hero) and one random cached (or freshly generated) concept for it.

## Hall of Fame

- **Not a leaderboard — an immutable historical log**, per the spec's
  own framing. Three genuinely different record semantics, verified
  separately against the real, unmodified service — 16/16 checks:
  - `SUPERSEDING` (e.g. "наивысший рейтинг"): one current holder; a
    beaten record is preserved with `isCurrent=false`, never deleted —
    requirement 4's "история должна сохранять обоих," specifically
    verified (a losing attempt creates zero entries; a genuinely
    better one flips the old entry's `isCurrent` and adds a new one).
  - `ONE_TIME` (e.g. "первое LEGENDARY испытание"): claimed exactly
    once — verified that a second achiever of the same milestone gets
    nothing, by design.
  - `PER_EVENT` (e.g. "чемпион турнира"): every occurrence gets its
    own permanent entry, none compete — verified three tournament wins
    (two different teams, one repeat winner) all create independent,
    equally-"current" entries.
- **Automatic detectors are real, not aspirational** — wired into the
  actual event points, each fail-soft (a Hall of Fame hiccup never
  blocks the real work calling it) and each verified:
  - Minesweeper `endGame()` → rating, Plus Points balance, win streak.
  - Trials engine → first LEGENDARY completion platform-wide.
  - Tournaments → champion recorded at all three real completion
    points (single-elimination final, grand-final WB-side win,
    bracket-reset decider) — all 35 existing tournament regression
    tests re-run and still pass after adding the hook.
  - Match sync → fastest/longest real match, longest real-match win
    streak — verified specifically that the streak is computed
    correctly as the longest *contiguous* run (3), not the total win
    count (6) in a mixed W/L sequence, and that re-running against
    unchanged data creates zero duplicate entries.
- **Honestly NOT auto-detected**: "biggest comeback" — same reason AI
  Coach's own README section gives: needs parsed teamfight/gold-swing
  data most matches don't have. Its `HallOfFameRecordType` row exists
  with `isAutomatic=false` specifically so the admin panel can still
  surface it as an intentionally-manual category, not a silently
  broken automatic one.
- **Admin-created entries are architecturally immune to automatic
  interference** (requirement 9): every detector only ever queries
  and supersedes entries it itself created through `recordEvent()` —
  nothing in the automatic path ever touches a `createdByAdmin: true`
  row. Manual entries are a genuinely separate write path
  (`POST /admin/hall-of-fame/entries`), not a flag bolted onto the
  same code the detectors call.
- `GET /hall-of-fame` (grouped by category, current+pinned entries),
  `GET /hall-of-fame/record/:key` (full chronological history for the
  record detail page), `GET /hall-of-fame/me` (profile integration).

## Updates & Feedback

- **Two genuinely separate entities, not one overloaded system**:
  `Suggestion` (requirement 6's dedicated feature-request tracker, 6
  statuses, can link to the `AreonVersion` that shipped it) vs
  `SupportTicket` (requirement 5's general contact form, "Предложение"
  is just one of its categories). Conflating them would have made the
  6-stage suggestion pipeline meaningless for a one-off bug report.
- **`VersionsService`'s atomic single-current guarantee — verified,
  7/7**: creating a new version and demoting the old one happens in
  one `$transaction`, so there's never a moment with zero or two
  current versions, even checked specifically after simulating a
  rollback to an older version via `setCurrent()`. `linkSuggestion()`
  verified to record which version actually shipped a suggestion, not
  whichever happens to be current when an admin clicks the button
  later.
- **No invented changelog history** — `seedInitialVersion()` creates
  exactly one honest baseline entry ("Запуск платформы Areon") on a
  fresh install, not a fabricated multi-version backstory. Real
  changelog entries are an admin's own words going forward
  (`POST /admin/versions`), matching requirement 2's "простым
  человеческим языком" — nothing here generates that text
  automatically.
- Version numbers are opaque strings, never parsed as semver — same
  "no hardcoded version logic" discipline as `PatchSyncService`.
- `GET /versions/current` is public (any logged-in user) — the version
  badge in the header and the update-notification banner both read
  from it. The banner itself is a pure client-side comparison
  (`localStorage` last-seen version vs. the server's current one) —
  no per-user "has seen this version" server state, deliberately, since
  it's low-stakes UI polish, not something that needs to survive a
  cleared browser.
- Admin endpoints cover the full requirement 8 list: create/edit
  versions, list/answer/close support tickets, change a suggestion's
  status with an optional note, link a suggestion to the version that
  implemented it.

## Security Audit (CRITICAL findings, fixed)

Ran a real audit against the actual code (grep + manual review, not a
generic checklist) — see the conversation history for the full
CRITICAL/HIGH/MEDIUM/LOW findings. The 3 CRITICAL items are fixed here;
HIGH and below are tracked but not yet addressed in this pass.

- **No logout existed anywhere** — neither a backend endpoint nor any
  frontend UI. Fixed with a REAL invalidation, not just a cookie
  clear: `User.tokenVersion`, included in every signed JWT, checked on
  every request in `JwtStrategy.validate()` (same place `isBanned`
  already was). `POST /auth/logout` bumps it, which immediately
  invalidates every previously-issued token for that user — including
  a copy someone else might already be holding — not just the
  cookie in this one browser. Verified against the real, unmodified
  strategy — 7/7 checks, specifically confirming a token signed
  before logout is rejected after it, a fresh post-logout token still
  works, and backward compatibility holds for tokens issued before
  this feature existed.
- **Zero rate limiting anywhere on the entire API** — most concerning
  on the two endpoints that call the (billed) Anthropic API: AI Coach
  and Wheel of Fate. `@nestjs/throttler` added: a global 60 req/min
  baseline everywhere, with `@Throttle` overrides of 5/10min on Coach
  (calls the LLM on essentially every request) and 10/5min on Wheel of
  Fate (cheaper on average — concepts are cached per hero — but still
  real spend early on or for a rarely-spun hero).
- **Postgres port published to the host** in `docker-compose.yml`
  (`"5432:5432"`) — removed entirely; the backend reaches it over
  Docker's internal network via the `db` hostname, which never needed
  a host port. Found alongside this: the database password was
  hardcoded as the weak literal `areon` in two places. Both now
  require `POSTGRES_PASSWORD` from environment with **no default** —
  `docker-compose.yml` fails to start rather than silently running
  with a guessable password. See the new root `/.env.example` for
  what `docker-compose.yml` itself reads (a different file from
  `areon-backend/.env`).

### HIGH #4 — no security headers anywhere (fixed)

- Backend: `helmet()` wired into `main.ts`. Its own CSP directive is
  disabled deliberately — this is a JSON API, nothing here renders
  untrusted HTML for a CSP to defend — but every other helmet default
  (X-Content-Type-Options, X-Frame-Options, HSTS, etc.) still applies.
- Frontend (`nginx.conf`): a real CSP tailored to what this app
  actually loads, not a copy-pasted template — `script-src 'self'`
  and `object-src 'none'`/`frame-ancestors 'none'` stay tight (the
  directives that actually matter most against XSS/clickjacking),
  while `connect-src`/`img-src`/`media-src` are `'self' https:` rather
  than an exact domain allowlist, because the backend origin
  (`VITE_API_URL`) and the music provider's CDN both vary per
  deployment and aren't knowable at the time this static file is
  written. `style-src` needs `'unsafe-inline'` — this codebase uses
  React's inline `style={{...}}` extensively, which CSP treats as
  inline style attributes; removing that would mean rewriting every
  component to a nonce/class-based approach, well beyond this pass.
  Also added: HSTS, X-Content-Type-Options, X-Frame-Options,
  Referrer-Policy, Permissions-Policy.

### MEDIUM #7, #8 — Security Log & Trust and Safety (fixed)

- `SecurityLogService` — logs security-relevant events only (banned
  account still using an old token, a session used after logout, rate
  limit trips via a custom `LoggingThrottlerGuard`, sensitive admin
  actions like ban/unban). Never logs passwords, tokens, or full
  request bodies — a discipline every call site holds to, same as AI
  Coach's "never invent data" being enforced by what's handed to it.
- `PlayerReportsService` — the spec's exact 9 report categories, a
  moderation queue (`PENDING → REVIEWED → ACTION_TAKEN/DISMISSED`).
  **Verified structurally, 6/6**: a status change never touches
  `User.isBanned` — banning is always a separate, explicit admin
  action informed by a report, never a side effect of reviewing one.
  Self-reporting and invalid categories are rejected.
- Frontend: a "Пожаловаться" button + inline category/description form
  on `PlayerSearch` (the one place another player is currently visible
  in the UI — no separate player-profile page exists yet to build a
  dedicated report flow into). Admin panel gained a "Security" tab:
  report queue with one-click status changes, and a live security log
  view.
- `/settings` gained a Trust Center block with the spec's own honest
  wording style (what's actually true, not "Areon can't be hacked").

### MEDIUM #6/#28 — admin panel gets no extra protection beyond the same role check (fixed)

- A class-wide `@Throttle({ limit: 30, ttl: 60_000 })` on the entire
  `AdminController` — stricter than the global 60/min default. `AdminGuard`
  already checks a fixed `ADMIN_STEAM_ID64` server-side, not a guessable
  credential, so this isn't about slowing brute force — it's about
  bounding how much automated damage a single compromised admin
  session could do in a burst, and slowing reconnaissance against the
  admin surface even for someone who did get in.

### Audit closure summary

All 3 CRITICAL findings and both HIGH findings are fixed (HIGH #5's
core property — a session CAN be genuinely revoked — is satisfied by
`tokenVersion`; a full multi-device "Active Sessions" list remains a
nice-to-have, not a gap in the actual security property). All 4 MEDIUM
findings are fixed. The one LOW finding (theoretical prompt-injection
surface for AI Coach/Wheel of Fate) needed no code change — no
free-text user input currently reaches either LLM call, only
structured facts derived from Areon's own database — but is worth
revisiting if a free-text AI chat feature is ever added.

## Not included in this scaffold

STRATZ integration, the Match Analyzer rule engine (per-match detail +
insight generation), the daily rank-snapshot worker, and the frontend are
separate pieces we haven't built yet.
