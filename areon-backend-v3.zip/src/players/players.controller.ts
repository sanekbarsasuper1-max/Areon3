import { Controller, Get, Post, Query, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { PlayersService } from './players.service';
import { PrismaService } from '../prisma.service';

@Controller('players')
export class PlayersController {
  constructor(
    private readonly playersService: PlayersService,
    private readonly prisma: PrismaService,
  ) {}

  // Headline numbers for the profile screen (matches, wins/losses,
  // winrate, average KDA/GPM/XPM). Computed from our own stored matches,
  // not a live OpenDota call — same "read from storage" principle as
  // the matches list.
  @Get('me/summary')
  @UseGuards(JwtAuthGuard)
  async summary(@Req() req: any) {
    const matches = await this.prisma.match.findMany({
      where: { userId: req.user.sub },
    });

    if (matches.length === 0) {
      return { matches: 0, wins: 0, losses: 0, winrate: 0, avgKda: 0, avgGpm: 0, avgXpm: 0 };
    }

    let wins = 0;
    let kills = 0, deaths = 0, assists = 0, gpm = 0, xpm = 0;

    for (const m of matches) {
      const won = m.playerSlot < 128 ? m.radiantWin : !m.radiantWin;
      if (won) wins += 1;
      kills += m.kills;
      deaths += m.deaths;
      assists += m.assists;
      gpm += m.goldPerMin;
      xpm += m.xpPerMin;
    }

    const n = matches.length;
    return {
      matches: n,
      wins,
      losses: n - wins,
      winrate: Math.round((wins / n) * 1000) / 10,
      // Deaths floored at 1 so a deathless streak doesn't divide by zero.
      avgKda: Math.round(((kills + assists) / Math.max(deaths, 1)) * 10) / 10,
      avgGpm: Math.round(gpm / n),
      avgXpm: Math.round(xpm / n),
    };
  }

  // Called by the "Проверить снова" button on the onboarding screen,
  // and safe to call again any time later — the user can toggle the
  // Dota 2 setting off after months of normal use, so this is not a
  // one-time login-time check.
  @Get('me/stats-status')
  @UseGuards(JwtAuthGuard)
  async recheck(@Req() req: any): Promise<{ statsExposed: boolean }> {
    const { sub: userId, accountId32 } = req.user;

    const statsExposed = await this.playersService.checkStatsExposed(accountId32);

    await this.prisma.user.update({
      where: { id: userId },
      data: { statsExposed, statsLastCheckedAt: new Date() },
    });

    return { statsExposed };
  }

  // Called periodically by the frontend (e.g. every 20-30s) while the
  // person has the app open, so PlayersController.online() below has
  // something recent to check against. "Online" is derived, not a
  // stored flag — see the User.lastSeenAt comment in schema.prisma.
  @Post('me/heartbeat')
  @UseGuards(JwtAuthGuard)
  async heartbeat(@Req() req: any) {
    await this.prisma.user.update({
      where: { id: req.user.sub },
      data: { lastSeenAt: new Date() },
    });
    return { ok: true };
  }

  // Powers the "invite an online player" picker in Draft Trainer — this
  // is a simplification of the FIND PLAYERS system from the product
  // doc, not that system itself. There's no friends list here, just
  // "everyone currently active on the site" excluding yourself.
  @Get('online')
  @UseGuards(JwtAuthGuard)
  async online(@Req() req: any) {
    const cutoff = new Date(Date.now() - 60_000);
    const users = await this.prisma.user.findMany({
      where: { lastSeenAt: { gte: cutoff }, id: { not: req.user.sub } },
      select: { id: true, personaName: true, avatarFull: true },
      orderBy: { lastSeenAt: 'desc' },
      take: 50,
    });
    return users;
  }

  /**
   * ============================================================================
   * FIND PLAYERS — searches Areon's own registered users (people who've
   * logged in at least once), not all of Dota 2. Filters:
   *
   *  - `q` — substring match on personaName.
   *  - `minRank`/`maxRank` — raw OpenDota rank_tier range (tens digit =
   *    medal 1-8, units = star), taken from each user's latest
   *    RankSnapshot. Missing entirely for anyone whose snapshot job
   *    hasn't run yet or who has stats exposure off.
   *  - `laneRole` — 1=Safe, 2=Mid, 3=Off, 4=Jungle, matched against
   *    Match.laneRole (see the schema comment — this is lane
   *    assignment, NOT the 5-position Carry/Mid/Offlane/Soft
   *    Support/Hard Support system players actually mean by "role".
   *    Safe and Off lanes each host a core AND a support, and lane_role
   *    can't tell them apart. A user matches if ANY of their synced
   *    matches used that lane — not "primarily plays it" — a looser
   *    match kept deliberately simple rather than computing a
   *    "dominant lane" that would need a games-played threshold to be
   *    meaningful.
   *  - `heroId` — has at least one synced match on this hero.
   *  - `minMatches` — total synced match count (a mild activity signal,
   *    not real playtime — someone who never clicked "Обновить из
   *    OpenDota" will show 0 regardless of how much they actually play).
   *
   * NOT implemented: region and language — Areon never collects either;
   * Steam login doesn't reliably expose them, and no other field ever
   * asks for them. Filtering on these would mean fabricating data.
   * ============================================================================
   */
  @Get('search')
  @UseGuards(JwtAuthGuard)
  async search(
    @Req() req: any,
    @Query('q') q?: string,
    @Query('minRank') minRank?: string,
    @Query('maxRank') maxRank?: string,
    @Query('laneRole') laneRole?: string,
    @Query('heroId') heroId?: string,
    @Query('minMatches') minMatches?: string,
  ) {
    // Latest rank snapshot per user — `distinct` after `orderBy desc`
    // gives exactly one (the newest) row per userId.
    const latestSnapshots = await this.prisma.rankSnapshot.findMany({
      orderBy: { capturedAt: 'desc' },
      distinct: ['userId'],
    });
    const rankByUser = new Map(latestSnapshots.map((s) => [s.userId, s]));

    let allowedByRank: Set<string> | null = null;
    if (minRank || maxRank) {
      const min = minRank ? Number(minRank) : -Infinity;
      const max = maxRank ? Number(maxRank) : Infinity;
      allowedByRank = new Set(
        [...rankByUser.entries()]
          .filter(([, s]) => s.rankTier != null && s.rankTier >= min && s.rankTier <= max)
          .map(([userId]) => userId),
      );
    }

    let allowedByLane: Set<string> | null = null;
    if (laneRole) {
      const rows = await this.prisma.match.findMany({
        where: { laneRole: Number(laneRole) },
        select: { userId: true },
        distinct: ['userId'],
      });
      allowedByLane = new Set(rows.map((r) => r.userId));
    }

    let allowedByHero: Set<string> | null = null;
    if (heroId) {
      const rows = await this.prisma.match.findMany({
        where: { heroId: Number(heroId) },
        select: { userId: true },
        distinct: ['userId'],
      });
      allowedByHero = new Set(rows.map((r) => r.userId));
    }

    let allowedByActivity: Set<string> | null = null;
    if (minMatches) {
      const grouped = await this.prisma.match.groupBy({
        by: ['userId'],
        _count: { id: true },
        having: { id: { _count: { gte: Number(minMatches) } } },
      });
      allowedByActivity = new Set(grouped.map((g) => g.userId));
    }

    const filterSets = [allowedByRank, allowedByLane, allowedByHero, allowedByActivity].filter(
      (s): s is Set<string> => s !== null,
    );
    const allowedIds = filterSets.length > 0 ? intersectSets(filterSets) : null;

    const users = await this.prisma.user.findMany({
      where: {
        id: { not: req.user.sub },
        ...(q ? { personaName: { contains: q, mode: 'insensitive' } } : {}),
        ...(allowedIds ? { id: { in: [...allowedIds] } } : {}),
      },
      select: { id: true, personaName: true, avatarFull: true, accountId32: true },
      take: 50,
    });

    const matchCounts = await this.prisma.match.groupBy({
      by: ['userId'],
      _count: { _all: true },
      where: { userId: { in: users.map((u) => u.id) } },
    });
    const matchCountByUser = new Map(matchCounts.map((m) => [m.userId, m._count._all]));

    return users.map((u) => ({
      ...u,
      rankTier: rankByUser.get(u.id)?.rankTier ?? null,
      mmrEstimate: rankByUser.get(u.id)?.mmrEstimate ?? null,
      matchCount: matchCountByUser.get(u.id) ?? 0,
    }));
  }
}

function intersectSets(sets: Set<string>[]): Set<string> {
  return sets.reduce((a, b) => new Set([...a].filter((x) => b.has(x))));
}
