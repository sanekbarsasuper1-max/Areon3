import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { PlayersService } from './players.service';
import { PlayersController } from './players.controller';
import { PrismaService } from '../prisma.service';

@Module({
  imports: [HttpModule],
  providers: [PlayersService, PrismaService],
  controllers: [PlayersController],
  exports: [PlayersService],
})
export class PlayersModule {}
