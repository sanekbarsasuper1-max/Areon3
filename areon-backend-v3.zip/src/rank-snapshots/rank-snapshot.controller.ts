import { Controller, Get, Post, Req } from '@nestjs/common';
import { RankSnapshotService } from './rank-snapshot.service';
import { PrismaService } from '../prisma.service';

@Controller('players/me/rank-history')
export class RankSnapshotController {
  constructor(
    private readonly rankSnapshotService: RankSnapshotService,
    private readonly prisma: PrismaService,
  ) {}

  @Get()
  async history(@Req() req: any) {
    return this.prisma.rankSnapshot.findMany({
      where: { userId: req.user.sub },
      orderBy: { capturedAt: 'asc' },
    });
  }

  // Useful for testing without waiting for 3am, and for a "captured
  // today already?" style manual refresh later.
  @Post()
  async captureNow(@Req() req: any) {
    return this.rankSnapshotService.captureForUser(req.user.sub, req.user.accountId32);
  }
}
