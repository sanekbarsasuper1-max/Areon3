import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { PrismaService } from '../prisma.service';
import { OpenDotaService } from '../opendota/opendota.service';
import { RANK_SNAPSHOT_QUEUE, RankSnapshotJobData } from './rank-snapshot.queue';

@Injectable()
export class RankSnapshotService {
  private readonly logger = new Logger(RankSnapshotService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly openDota: OpenDotaService,
    @InjectQueue(RANK_SNAPSHOT_QUEUE) private readonly queue: Queue<RankSnapshotJobData>,
  ) {}

  /**
   * Runs once a day, but only to ENQUEUE — see rank-snapshot.processor.ts
   * for where the actual per-user work now happens. This is the real
   * point of the BullMQ move noted as a simplification-to-fix earlier:
   * one user's slow or failing OpenDota call used to hold up (and, if
   * unhandled, potentially abort) the whole in-process loop for every
   * other user. Now each user is an independent job, retried on its own
   * with backoff, and one failure never blocks anyone else's snapshot.
   *
   * This is the ONLY source of MMR/rank history in Areon — Valve
   * doesn't expose it retroactively, so a gap here is a permanent gap
   * in that user's chart, not something that can be backfilled later.
   * That's exactly why per-job retry (not just per-run try/catch)
   * matters here more than it would for an ordinary cache refresh.
   */
  @Cron(CronExpression.EVERY_DAY_AT_3AM)
  async enqueueAllUsers() {
    const users = await this.prisma.user.findMany({ select: { id: true, accountId32: true } });
    this.logger.log(`Enqueuing daily rank snapshot for ${users.length} users`);

    await this.queue.addBulk(
      users.map((user) => ({
        name: 'snapshot-user',
        data: { userId: user.id, accountId32: user.accountId32 },
        opts: {
          attempts: 3,
          backoff: { type: 'exponential', delay: 30_000 },
          // Same job id every day for the same user — if a previous
          // day's job for this user is somehow still queued (shouldn't
          // happen, but a stuck job is exactly the failure mode this
          // migration is meant to prevent), this avoids double-queuing
          // rather than silently stacking retries on top of retries.
          jobId: `snapshot-user:${user.id}:${new Date().toISOString().slice(0, 10)}`,
        },
      })),
    );
  }

  async captureForUser(userId: string, accountId32: number) {
    const rank = await this.openDota.getPlayerRank(accountId32);

    return this.prisma.rankSnapshot.create({
      data: {
        userId,
        rankTier: rank.rank_tier,
        mmrEstimate: rank.mmr_estimate?.estimate ?? null,
      },
    });
  }
}
