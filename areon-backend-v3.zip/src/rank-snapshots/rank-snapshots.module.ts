import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { RankSnapshotService } from './rank-snapshot.service';
import { RankSnapshotController } from './rank-snapshot.controller';
import { RankSnapshotProcessor } from './rank-snapshot.processor';
import { RANK_SNAPSHOT_QUEUE } from './rank-snapshot.queue';
import { PrismaService } from '../prisma.service';
import { OpenDotaModule } from '../opendota/opendota.module';

@Module({
  imports: [OpenDotaModule, BullModule.registerQueue({ name: RANK_SNAPSHOT_QUEUE })],
  providers: [RankSnapshotService, RankSnapshotProcessor, PrismaService],
  controllers: [RankSnapshotController],
})
export class RankSnapshotsModule {}
