export const RANK_SNAPSHOT_QUEUE = 'rank-snapshot';

export interface RankSnapshotJobData {
  userId: string;
  accountId32: number;
}
