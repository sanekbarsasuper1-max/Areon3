import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { RANK_SNAPSHOT_QUEUE, RankSnapshotJobData } from './rank-snapshot.queue';
import { RankSnapshotService } from './rank-snapshot.service';

/**
 * One job per user, not one job for the whole batch — this is the
 * actual point of moving off the in-process loop. A single user with a
 * slow or failing OpenDota response used to hold up (or, if unhandled,
 * potentially abort) the whole nightly run; now it only affects that
 * user's own job, which BullMQ retries independently with backoff,
 * while every other user's job proceeds without waiting on it.
 */
@Processor(RANK_SNAPSHOT_QUEUE)
export class RankSnapshotProcessor extends WorkerHost {
  private readonly logger = new Logger(RankSnapshotProcessor.name);

  constructor(private readonly rankSnapshotService: RankSnapshotService) {
    super();
  }

  async process(job: Job<RankSnapshotJobData>) {
    await this.rankSnapshotService.captureForUser(job.data.userId, job.data.accountId32);
  }

  // BullMQ emits these on the worker itself — logging failures here
  // (after retries are exhausted) is what replaces the old loop's
  // per-user try/catch + ok/failed tally, just per-job instead of
  // batched into one end-of-run log line.
  onFailed(job: Job<RankSnapshotJobData> | undefined, err: Error) {
    this.logger.warn(`Snapshot failed for user=${job?.data.userId} after retries: ${err.message}`);
  }
}
