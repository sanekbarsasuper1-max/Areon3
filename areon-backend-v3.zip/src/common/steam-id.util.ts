// The Dota 2 / Steam Web API game endpoints (GetMatchHistory, OpenDota, etc.)
// identify players by a 32-bit "account_id", while Steam OpenID login
// returns a 64-bit SteamID. This is a fixed, well-known offset conversion.
const STEAM_ID_64_BASE = 76561197960265728n;

export function steamId64ToAccountId32(steamId64: string): number {
  const id = BigInt(steamId64);
  return Number(id - STEAM_ID_64_BASE);
}

export function accountId32ToSteamId64(accountId32: number): string {
  return (BigInt(accountId32) + STEAM_ID_64_BASE).toString();
}
