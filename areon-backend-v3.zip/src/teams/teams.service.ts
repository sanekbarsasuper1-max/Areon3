import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { TeamRole } from '@prisma/client';

const VALID_POSITIONS = ['carry', 'mid', 'offlane', 'support', 'hard_support'];

@Injectable()
export class TeamsService {
  constructor(private readonly prisma: PrismaService) {}

  async createTeam(ownerId: string, name: string, tag?: string) {
    return this.prisma.team.create({
      data: {
        name,
        tag,
        members: { create: { userId: ownerId, role: TeamRole.OWNER } },
      },
      include: { members: { include: { user: true } } },
    });
  }

  async listMyTeams(userId: string) {
    return this.prisma.team.findMany({
      where: { members: { some: { userId } } },
      include: { members: { include: { user: true } } },
    });
  }

  async getTeam(teamId: string) {
    const team = await this.prisma.team.findUnique({
      where: { id: teamId },
      include: { members: { include: { user: true } } },
    });
    if (!team) throw new NotFoundException('Team not found');
    return team;
  }

  /**
   * Invites an existing Areon user to a team by their Dota account_id.
   *
   * Deliberate limitation: this only works if the invited person has
   * already logged into Areon at least once (we look them up by
   * accountId32 in our own User table). There's no player-search API in
   * this scaffold yet — that's the FIND PLAYERS system from the product
   * doc, not built here — so for now you can only invite people you
   * already know the Dota account_id of.
   */
  async invitePlayer(teamId: string, inviterId: string, invitedAccountId32: number) {
    await this.assertCanManage(teamId, inviterId);

    const invitedUser = await this.prisma.user.findUnique({
      where: { accountId32: invitedAccountId32 },
    });
    if (!invitedUser) {
      throw new NotFoundException(
        'No Areon account found for that Dota account_id — they need to log in at least once first',
      );
    }

    const alreadyMember = await this.prisma.teamMember.findUnique({
      where: { teamId_userId: { teamId, userId: invitedUser.id } },
    });
    if (alreadyMember) {
      throw new BadRequestException('That player is already on the team');
    }

    return this.prisma.teamInvite.create({
      data: { teamId, invitedUserId: invitedUser.id, invitedByUserId: inviterId },
    });
  }

  async respondToInvite(inviteId: string, userId: string, accept: boolean) {
    const invite = await this.prisma.teamInvite.findUnique({ where: { id: inviteId } });
    if (!invite) throw new NotFoundException('Invite not found');
    if (invite.invitedUserId !== userId) {
      throw new ForbiddenException('This invite is not addressed to you');
    }
    if (invite.status !== 'PENDING') {
      throw new BadRequestException('This invite was already answered');
    }

    if (!accept) {
      return this.prisma.teamInvite.update({
        where: { id: inviteId },
        data: { status: 'DECLINED' },
      });
    }

    // Accepting both flips the invite and adds the roster row — no
    // partial state where an "ACCEPTED" invite doesn't correspond to an
    // actual TeamMember.
    const [updatedInvite] = await this.prisma.$transaction([
      this.prisma.teamInvite.update({ where: { id: inviteId }, data: { status: 'ACCEPTED' } }),
      this.prisma.teamMember.create({
        data: { teamId: invite.teamId, userId: invite.invitedUserId, role: TeamRole.MEMBER },
      }),
    ]);
    return updatedInvite;
  }

  async listMyInvites(userId: string) {
    return this.prisma.teamInvite.findMany({
      where: { invitedUserId: userId, status: 'PENDING' },
      include: { team: true, invitedByUser: true },
    });
  }

  async updateMember(
    teamId: string,
    actingUserId: string,
    targetUserId: string,
    updates: { role?: TeamRole; position?: string },
  ) {
    // A player may always set their own position (e.g. "I mainly play
    // support") without needing captain permission — only role changes
    // and changing *someone else's* position require management rights.
    const isSelfPositionOnly =
      actingUserId === targetUserId && updates.role === undefined;
    if (!isSelfPositionOnly) {
      await this.assertCanManage(teamId, actingUserId);
    }

    if (updates.position && !VALID_POSITIONS.includes(updates.position)) {
      throw new BadRequestException(`Position must be one of: ${VALID_POSITIONS.join(', ')}`);
    }

    const member = await this.prisma.teamMember.findUnique({
      where: { teamId_userId: { teamId, userId: targetUserId } },
    });
    if (!member) throw new NotFoundException('Member not found');

    if (member.role === TeamRole.OWNER && updates.role && updates.role !== TeamRole.OWNER) {
      throw new BadRequestException('Team ownership must be transferred explicitly, not edited here');
    }

    return this.prisma.teamMember.update({
      where: { id: member.id },
      data: updates,
    });
  }

  async removeMember(teamId: string, actingUserId: string, targetUserId: string) {
    const isSelfRemoval = actingUserId === targetUserId;
    if (!isSelfRemoval) {
      await this.assertCanManage(teamId, actingUserId);
    }

    const member = await this.prisma.teamMember.findUnique({
      where: { teamId_userId: { teamId, userId: targetUserId } },
    });
    if (!member) throw new NotFoundException('Member not found');
    if (member.role === TeamRole.OWNER) {
      throw new BadRequestException('The owner cannot leave or be removed without transferring ownership first');
    }

    return this.prisma.teamMember.delete({ where: { id: member.id } });
  }

  /**
   * The fix for the exact dead end removeMember's error message above
   * points at: an OWNER couldn't leave or be removed before this
   * existed. Demotes the current owner to CAPTAIN (not removed outright
   * — they stay on the roster and can leave normally afterward via
   * removeMember, now that they're no longer OWNER) and promotes the
   * target member to OWNER, in one transaction so there's never a
   * moment with zero or two owners.
   */
  async transferOwnership(teamId: string, currentUserId: string, newOwnerUserId: string) {
    const currentMembership = await this.prisma.teamMember.findUnique({
      where: { teamId_userId: { teamId, userId: currentUserId } },
    });
    if (!currentMembership || currentMembership.role !== TeamRole.OWNER) {
      throw new ForbiddenException('Only the current owner can transfer ownership');
    }
    if (currentUserId === newOwnerUserId) {
      throw new BadRequestException('You are already the owner');
    }

    const newOwnerMembership = await this.prisma.teamMember.findUnique({
      where: { teamId_userId: { teamId, userId: newOwnerUserId } },
    });
    if (!newOwnerMembership) {
      throw new NotFoundException('That user is not a member of this team — invite them first');
    }

    const [oldOwner, newOwner] = await this.prisma.$transaction([
      this.prisma.teamMember.update({ where: { id: currentMembership.id }, data: { role: TeamRole.CAPTAIN } }),
      this.prisma.teamMember.update({ where: { id: newOwnerMembership.id }, data: { role: TeamRole.OWNER } }),
    ]);

    return { oldOwner, newOwner };
  }

  private async assertCanManage(teamId: string, userId: string) {
    const member = await this.prisma.teamMember.findUnique({
      where: { teamId_userId: { teamId, userId } },
    });
    if (!member || (member.role !== TeamRole.OWNER && member.role !== TeamRole.CAPTAIN)) {
      throw new ForbiddenException('Only the team owner or a captain can do this');
    }
  }
}
