import { Body, Controller, Delete, Get, Param, Patch, Post, Req } from '@nestjs/common';
import { TeamsService } from './teams.service';
import { TeamRole } from '@prisma/client';

@Controller('teams')
export class TeamsController {
  constructor(private readonly teamsService: TeamsService) {}

  @Post()
  create(@Req() req: any, @Body() body: { name: string; tag?: string }) {
    return this.teamsService.createTeam(req.user.sub, body.name, body.tag);
  }

  @Get('me')
  listMine(@Req() req: any) {
    return this.teamsService.listMyTeams(req.user.sub);
  }

  @Get('me/invites')
  listMyInvites(@Req() req: any) {
    return this.teamsService.listMyInvites(req.user.sub);
  }

  @Get(':id')
  get(@Param('id') id: string) {
    return this.teamsService.getTeam(id);
  }

  @Post(':id/invites')
  invite(
    @Req() req: any,
    @Param('id') teamId: string,
    @Body() body: { accountId32: number },
  ) {
    return this.teamsService.invitePlayer(teamId, req.user.sub, body.accountId32);
  }

  @Post('invites/:inviteId/accept')
  acceptInvite(@Req() req: any, @Param('inviteId') inviteId: string) {
    return this.teamsService.respondToInvite(inviteId, req.user.sub, true);
  }

  @Post('invites/:inviteId/decline')
  declineInvite(@Req() req: any, @Param('inviteId') inviteId: string) {
    return this.teamsService.respondToInvite(inviteId, req.user.sub, false);
  }

  @Patch(':id/members/:userId')
  updateMember(
    @Req() req: any,
    @Param('id') teamId: string,
    @Param('userId') targetUserId: string,
    @Body() body: { role?: TeamRole; position?: string },
  ) {
    return this.teamsService.updateMember(teamId, req.user.sub, targetUserId, body);
  }

  @Delete(':id/members/:userId')
  removeMember(
    @Req() req: any,
    @Param('id') teamId: string,
    @Param('userId') targetUserId: string,
  ) {
    return this.teamsService.removeMember(teamId, req.user.sub, targetUserId);
  }

  @Post(':id/transfer-ownership')
  transferOwnership(
    @Req() req: any,
    @Param('id') teamId: string,
    @Body() body: { newOwnerUserId: string },
  ) {
    return this.teamsService.transferOwnership(teamId, req.user.sub, body.newOwnerUserId);
  }
}
