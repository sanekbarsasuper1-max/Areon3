import { Module } from '@nestjs/common';
import { TournamentsService } from './tournaments.service';
import { TournamentsController } from './tournaments.controller';
import { PrismaService } from '../prisma.service';
import { HallOfFameModule } from '../hall-of-fame/hall-of-fame.module';

@Module({
  imports: [HallOfFameModule],
  providers: [TournamentsService, PrismaService],
  controllers: [TournamentsController],
  exports: [TournamentsService],
})
export class TournamentsModule {}
