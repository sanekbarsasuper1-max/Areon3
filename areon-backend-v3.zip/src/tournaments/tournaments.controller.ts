import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common';
import { TournamentsService } from './tournaments.service';

@Controller('tournaments')
export class TournamentsController {
  constructor(private readonly tournamentsService: TournamentsService) {}

  @Post()
  create(
    @Req() req: any,
    @Body() body: { name: string; description?: string; teamSize?: number; matchFormat?: string; bracketFormat?: string; maxTeams: number },
  ) {
    return this.tournamentsService.create(req.user.sub, body);
  }

  @Get()
  list() {
    return this.tournamentsService.list();
  }

  @Get(':id')
  get(@Param('id') id: string) {
    return this.tournamentsService.get(id);
  }

  @Post(':id/register')
  register(@Req() req: any, @Param('id') id: string, @Body() body: { teamId: string }) {
    return this.tournamentsService.register(id, req.user.sub, body.teamId);
  }

  @Post(':id/generate-bracket')
  generateBracket(@Req() req: any, @Param('id') id: string) {
    return this.tournamentsService.generateBracket(id, req.user.sub);
  }

  @Post(':id/matches/:matchId/result')
  reportResult(
    @Req() req: any,
    @Param('id') id: string,
    @Param('matchId') matchId: string,
    @Body() body: { winnerTeamId: string; scoreA: number; scoreB: number },
  ) {
    return this.tournamentsService.reportResult(
      id,
      matchId,
      req.user.sub,
      body.winnerTeamId,
      body.scoreA,
      body.scoreB,
    );
  }
}
