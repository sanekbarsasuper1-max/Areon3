import { TournamentsService } from './tournaments.service';

/**
 * Minimal in-memory Prisma double, same pattern (and same caveats) as
 * draft-trainer.service.spec.ts's — schema-level @default() values
 * (TournamentMatch.status defaults to PENDING) have to be replicated
 * manually here, and `include: {registrations, matches}` has to be
 * handled by hand since this stub has no real relation-following.
 */
type Where = Record<string, any>;

function matchesWhere(record: any, where: Where): boolean {
  for (const key of Object.keys(where)) {
    const cond = where[key];
    if (cond && typeof cond === 'object' && !Array.isArray(cond) && 'not' in cond) {
      if (record[key] === cond.not) return false;
      continue;
    }
    if (record[key] !== cond) return false;
  }
  return true;
}

function isCompoundKeyWrapper(where: Where): boolean {
  const keys = Object.keys(where);
  if (keys.length !== 1 || 'id' in where) return false;
  const value = where[keys[0]];
  return value && typeof value === 'object' && !Array.isArray(value) && !('not' in value);
}

class InMemoryTable<T extends { id: string }> {
  rows = new Map<string, T>();
  private nextId = 1;

  async create({ data }: { data: Partial<T> }): Promise<T> {
    const id = (data as any).id ?? `t-${this.nextId++}`;
    const row = { ...data, id } as T;
    this.rows.set(id, row);
    return row;
  }
  async findUnique({ where }: { where: any }): Promise<T | null> {
    if (where.id) return this.rows.get(where.id) ?? null;
    const flat = isCompoundKeyWrapper(where) ? Object.values(where)[0] as Where : where;
    return [...this.rows.values()].find((r) => matchesWhere(r, flat)) ?? null;
  }
  async findMany({ where }: { where?: Where } = {}): Promise<T[]> {
    return where ? [...this.rows.values()].filter((r) => matchesWhere(r, where)) : [...this.rows.values()];
  }
  async count(args: { where?: Where } = {}) {
    return (await this.findMany(args)).length;
  }
  async update({ where, data }: { where: any; data: Partial<T> }): Promise<T> {
    const existing = await this.findUnique({ where });
    if (!existing) throw new Error(`No row matching ${JSON.stringify(where)}`);
    const updated = { ...existing, ...data } as T;
    this.rows.set((existing as any).id, updated);
    return updated;
  }
}

function createInMemoryPrisma() {
  const tournament = new InMemoryTable<any>();
  const tournamentMatch = new InMemoryTable<any>();
  const tournamentRegistration = new InMemoryTable<any>();
  const teamMember = new InMemoryTable<any>();

  // @default(PENDING) on TournamentMatch.status — the real service
  // never sets it explicitly on create().
  const originalMatchCreate = tournamentMatch.create.bind(tournamentMatch);
  tournamentMatch.create = (async (args: any) =>
    originalMatchCreate({ data: { status: 'PENDING', bracket: 'winners', ...args.data } })) as any;

  // Manual `include` handling — this stub has no real relations.
  const originalTournamentFindUnique = tournament.findUnique.bind(tournament);
  (tournament as any).findUnique = async (args: any) => {
    const row = await originalTournamentFindUnique(args);
    if (!row || !args.include) return row;
    const result: any = { ...row };
    if (args.include.registrations) {
      result.registrations = await tournamentRegistration.findMany({ where: { tournamentId: row.id } });
    }
    if (args.include.matches) {
      result.matches = await tournamentMatch.findMany({ where: { tournamentId: row.id } });
    }
    return result;
  };

  return {
    tournament,
    tournamentMatch,
    tournamentRegistration,
    teamMember,
    async $transaction(arg: any) {
      return typeof arg === 'function' ? arg(this) : Promise.all(arg);
    },
  };
}

async function makeTournamentWithTeams(
  svc: TournamentsService,
  prisma: ReturnType<typeof createInMemoryPrisma>,
  teamCount: number,
  bracketFormat?: string,
) {
  const tournament = await svc.create('organizer', { name: 'T', maxTeams: teamCount, bracketFormat });
  for (let i = 1; i <= teamCount; i++) {
    await prisma.tournamentRegistration.create({ data: { tournamentId: tournament.id, teamId: `team${i}` } });
  }
  return tournament;
}

/** Always resolves a match by "lowest numbered team id wins" — deterministic. */
async function playAllPending(svc: TournamentsService, prisma: ReturnType<typeof createInMemoryPrisma>, tournamentId: string) {
  for (let guard = 0; guard < 200; guard++) {
    const pending = (await prisma.tournamentMatch.findMany({ where: { tournamentId, status: 'PENDING' } }))
      .filter((m: any) => m.teamAId && m.teamBId);
    if (pending.length === 0) return;
    for (const m of pending) {
      const numA = Number(m.teamAId.replace('team', ''));
      const numB = Number(m.teamBId.replace('team', ''));
      await svc.reportResult(tournamentId, m.id, 'organizer', numA < numB ? m.teamAId : m.teamBId, 1, 0);
    }
  }
  throw new Error('playAllPending did not converge — likely a stuck match');
}

describe('TournamentsService — single elimination bye distribution', () => {
  // Regression coverage: the original bye-padding scheme could produce
  // a round-1 match with BOTH slots empty (e.g. 5 or 6 teams padded to
  // a bracket of 8), which could never be played and left everything
  // downstream of it permanently stuck. Every one of these counts needs
  // more than one bye, which is exactly the condition that triggered it.
  it.each([3, 5, 6, 7, 9, 12])('completes cleanly with %i registered teams', async (n) => {
    const prisma = createInMemoryPrisma();
    const svc = new TournamentsService(prisma as any, { recordEvent: async () => null } as any);
    const t = await makeTournamentWithTeams(svc, prisma, n);
    await svc.generateBracket(t.id, 'organizer');

    const round1 = await prisma.tournamentMatch.findMany({ where: { tournamentId: t.id, bracket: 'winners', round: 1 } });
    expect(round1.some((m: any) => !m.teamAId && !m.teamBId)).toBe(false);

    await playAllPending(svc, prisma, t.id);
    const final = await prisma.tournament.findUnique({ where: { id: t.id } });
    expect(final.status).toBe('COMPLETED');
  });
});

describe('TournamentsService — double elimination', () => {
  it('builds the correct bracket shape and routes teams correctly for 4 teams', async () => {
    const prisma = createInMemoryPrisma();
    const svc = new TournamentsService(prisma as any, { recordEvent: async () => null } as any);
    const t = await makeTournamentWithTeams(svc, prisma, 4, 'double_elimination');
    await svc.generateBracket(t.id, 'organizer');

    expect(await prisma.tournamentMatch.findMany({ where: { tournamentId: t.id, bracket: 'winners' } })).toHaveLength(3);
    expect(await prisma.tournamentMatch.findMany({ where: { tournamentId: t.id, bracket: 'losers' } })).toHaveLength(2);
    expect(await prisma.tournamentMatch.findMany({ where: { tournamentId: t.id, bracket: 'grand_final' } })).toHaveLength(1);

    await playAllPending(svc, prisma, t.id);

    const final = await prisma.tournament.findUnique({ where: { id: t.id } });
    const gf = (await prisma.tournamentMatch.findMany({ where: { tournamentId: t.id, bracket: 'grand_final' } }))[0];

    expect(final.status).toBe('COMPLETED');
    expect(gf.winnerTeamId).toBe('team1'); // undefeated through the winners bracket
    expect(gf.teamAId).toBe('team1');
    expect(gf.teamBId).toBe('team2'); // correct losers-bracket champion
    expect(await prisma.tournamentMatch.findMany({ where: { tournamentId: t.id, bracket: 'bracket_reset' } })).toHaveLength(0);
  });

  it('triggers a bracket reset when the losers-bracket finalist wins the grand final', async () => {
    const prisma = createInMemoryPrisma();
    const svc = new TournamentsService(prisma as any, { recordEvent: async () => null } as any);
    const t = await makeTournamentWithTeams(svc, prisma, 4, 'double_elimination');
    await svc.generateBracket(t.id, 'organizer');

    for (let guard = 0; guard < 200; guard++) {
      const pending = (await prisma.tournamentMatch.findMany({ where: { tournamentId: t.id, status: 'PENDING' } }))
        .filter((m: any) => m.bracket !== 'grand_final' && m.teamAId && m.teamBId);
      if (pending.length === 0) break;
      for (const m of pending) {
        const numA = Number(m.teamAId.replace('team', ''));
        const numB = Number(m.teamBId.replace('team', ''));
        await svc.reportResult(t.id, m.id, 'organizer', numA < numB ? m.teamAId : m.teamBId, 1, 0);
      }
    }

    const gf = (await prisma.tournamentMatch.findMany({ where: { tournamentId: t.id, bracket: 'grand_final' } }))[0];
    await svc.reportResult(t.id, gf.id, 'organizer', gf.teamBId, 1, 0); // force the LB side to win

    expect((await prisma.tournament.findUnique({ where: { id: t.id } })).status).toBe('IN_PROGRESS');

    const reset = (await prisma.tournamentMatch.findMany({ where: { tournamentId: t.id, bracket: 'bracket_reset' } }))[0];
    expect(reset).toBeTruthy();
    expect(reset.teamAId).toBe(gf.teamAId);
    expect(reset.teamBId).toBe(gf.teamBId);
    expect(reset.status).toBe('PENDING');

    await svc.reportResult(t.id, reset.id, 'organizer', reset.teamAId, 1, 0);
    expect((await prisma.tournament.findUnique({ where: { id: t.id } })).status).toBe('COMPLETED');
  });

  it('matches the well-known 2N-2 total-match formula for 8 teams and leaves nothing stuck', async () => {
    const prisma = createInMemoryPrisma();
    const svc = new TournamentsService(prisma as any, { recordEvent: async () => null } as any);
    const t = await makeTournamentWithTeams(svc, prisma, 8, 'double_elimination');
    await svc.generateBracket(t.id, 'organizer');

    const winners = await prisma.tournamentMatch.findMany({ where: { tournamentId: t.id, bracket: 'winners' } });
    const losers = await prisma.tournamentMatch.findMany({ where: { tournamentId: t.id, bracket: 'losers' } });
    expect(winners).toHaveLength(7);
    expect(losers).toHaveLength(6);
    expect(winners.length + losers.length + 1).toBe(14); // 2*8 - 2

    await playAllPending(svc, prisma, t.id);

    const final = await prisma.tournament.findUnique({ where: { id: t.id } });
    expect(final.status).toBe('COMPLETED');

    const allMatches = await prisma.tournamentMatch.findMany({ where: { tournamentId: t.id } });
    expect(allMatches.every((m: any) => m.status === 'COMPLETED')).toBe(true);
  });

  it('rejects a non-power-of-two team count outright', async () => {
    const prisma = createInMemoryPrisma();
    const svc = new TournamentsService(prisma as any, { recordEvent: async () => null } as any);
    const t = await makeTournamentWithTeams(svc, prisma, 6, 'double_elimination');
    await expect(svc.generateBracket(t.id, 'organizer')).rejects.toThrow();
  });
});
