import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { TournamentStatus, MatchStatus, TeamRole } from '@prisma/client';
import { HallOfFameService } from '../hall-of-fame/hall-of-fame.service';

const VALID_FORMATS = ['BO1', 'BO3', 'BO5'];
const VALID_BRACKET_FORMATS = ['single_elimination', 'double_elimination'];

@Injectable()
export class TournamentsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly hallOfFame: HallOfFameService,
  ) {}

  async create(userId: string, input: {
    name: string;
    description?: string;
    teamSize?: number;
    matchFormat?: string;
    bracketFormat?: string;
    maxTeams: number;
  }) {
    const matchFormat = input.matchFormat ?? 'BO1';
    if (!VALID_FORMATS.includes(matchFormat)) {
      throw new BadRequestException(`matchFormat must be one of: ${VALID_FORMATS.join(', ')}`);
    }
    const bracketFormat = input.bracketFormat ?? 'single_elimination';
    if (!VALID_BRACKET_FORMATS.includes(bracketFormat)) {
      throw new BadRequestException(`bracketFormat must be one of: ${VALID_BRACKET_FORMATS.join(', ')}`);
    }
    if (input.maxTeams < 2) {
      throw new BadRequestException('A tournament needs at least 2 teams');
    }
    if (bracketFormat === 'double_elimination' && input.maxTeams < 4) {
      throw new BadRequestException('Double elimination needs at least 4 teams');
    }

    return this.prisma.tournament.create({
      data: {
        name: input.name,
        description: input.description,
        teamSize: input.teamSize ?? 5,
        matchFormat,
        bracketFormat,
        maxTeams: input.maxTeams,
        createdByUserId: userId,
        status: TournamentStatus.REGISTRATION_OPEN,
      },
    });
  }

  async list() {
    return this.prisma.tournament.findMany({
      include: { registrations: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  async get(id: string) {
    const tournament = await this.prisma.tournament.findUnique({
      where: { id },
      include: {
        registrations: { include: { team: true } },
        matches: { orderBy: [{ bracket: 'asc' }, { round: 'asc' }, { position: 'asc' }] },
      },
    });
    if (!tournament) throw new NotFoundException('Tournament not found');
    return tournament;
  }

  /**
   * Registers a team. Only that team's OWNER/CAPTAIN can register it —
   * an arbitrary member shouldn't be able to commit the whole roster to
   * a tournament unilaterally.
   */
  async register(tournamentId: string, userId: string, teamId: string) {
    const tournament = await this.prisma.tournament.findUnique({ where: { id: tournamentId } });
    if (!tournament) throw new NotFoundException('Tournament not found');
    if (tournament.status !== TournamentStatus.REGISTRATION_OPEN) {
      throw new BadRequestException('Registration is not open for this tournament');
    }

    const membership = await this.prisma.teamMember.findUnique({
      where: { teamId_userId: { teamId, userId } },
    });
    if (!membership || (membership.role !== TeamRole.OWNER && membership.role !== TeamRole.CAPTAIN)) {
      throw new ForbiddenException('Only the team owner or a captain can register it');
    }

    const currentCount = await this.prisma.tournamentRegistration.count({ where: { tournamentId } });
    if (currentCount >= tournament.maxTeams) {
      throw new BadRequestException('Tournament is full');
    }

    return this.prisma.tournamentRegistration.create({ data: { tournamentId, teamId } });
  }

  async generateBracket(tournamentId: string, requestingUserId: string) {
    const tournament = await this.prisma.tournament.findUnique({
      where: { id: tournamentId },
      include: { registrations: true },
    });
    if (!tournament) throw new NotFoundException('Tournament not found');
    if (tournament.createdByUserId !== requestingUserId) {
      throw new ForbiddenException('Only the tournament creator can generate the bracket');
    }
    if (tournament.registrations.length < 2) {
      throw new BadRequestException('Need at least 2 registered teams to generate a bracket');
    }

    const teamIds = tournament.registrations.map((r) => r.teamId);

    if (tournament.bracketFormat === 'double_elimination') {
      await this.generateDoubleEliminationBracket(tournamentId, teamIds);
    } else {
      await this.generateSingleEliminationBracket(tournamentId, teamIds);
    }

    await this.prisma.tournament.update({
      where: { id: tournamentId },
      data: { status: TournamentStatus.IN_PROGRESS },
    });

    return this.get(tournamentId);
  }

  /**
   * Seeded purely by registration order — no skill-based seeding. Byes
   * go to whichever teams land in an incomplete pairing when the field
   * isn't a power of two; that's a registration-order artifact, not a
   * deliberate seeding decision, and should be called out as such to
   * organizers rather than presented as fair seeding.
   */
  private async generateSingleEliminationBracket(tournamentId: string, teamIds: string[]) {
    const bracketSize = nextPowerOfTwo(teamIds.length);
    const totalRounds = Math.log2(bracketSize);

    // Byes go to the first `byeCount` registered teams, one bye per
    // match, spread across separate round-1 matches rather than
    // clustered at the end. Clustering (the original approach: pad the
    // team list with nulls and pair sequentially) can produce a match
    // with BOTH slots empty whenever more than one bye is needed (e.g.
    // 5 or 6 teams padded to a bracket of 8) — that match can never be
    // played, and nothing downstream of it can ever be filled in either.
    // Since bracketSize is always the *smallest* power of two >= the
    // team count, byeCount is mathematically guaranteed to be smaller
    // than the number of round-1 matches, so one-bye-per-match is
    // always achievable.
    const byeCount = bracketSize - teamIds.length;
    const round1Pairs: [string | null, string | null][] = [];
    for (let i = 0; i < byeCount; i++) {
      round1Pairs.push([teamIds[i], null]);
    }
    for (let i = byeCount; i < bracketSize / 2; i++) {
      const idx = byeCount + (i - byeCount) * 2;
      round1Pairs.push([teamIds[idx] ?? null, teamIds[idx + 1] ?? null]);
    }

    const created = await this.prisma.$transaction(async (tx) => {
      const matches = [];
      for (let round = 1; round <= totalRounds; round++) {
        const matchesInRound = bracketSize / Math.pow(2, round);
        for (let position = 0; position < matchesInRound; position++) {
          const [teamAId, teamBId] = round === 1 ? round1Pairs[position] : [null, null];
          matches.push(
            await tx.tournamentMatch.create({
              data: { tournamentId, bracket: 'winners', round, position, teamAId, teamBId },
            }),
          );
        }
      }
      return matches;
    });

    for (const match of created.filter((m) => m.round === 1)) {
      const hasBye = (match.teamAId && !match.teamBId) || (!match.teamAId && match.teamBId);
      if (hasBye) {
        const winnerTeamId = (match.teamAId ?? match.teamBId) as string;
        await this.completeMatch(match.id, winnerTeamId, null, null, /* isBye */ true);
      }
    }
  }

  /**
   * ============================================================================
   * DOUBLE ELIMINATION — only supported for an exact power-of-two team count
   * (4/8/16/32). Single elimination handles any count via byes (a lone
   * team in an incomplete pairing auto-advances); there's no equally
   * simple bye equivalent for double elimination, since a bye would need
   * to propagate through BOTH the winners and losers brackets
   * consistently, and getting that wrong silently produces an unfair or
   * broken bracket rather than a loud error. Rejecting non-power-of-two
   * counts outright is safer than guessing.
   *
   * Structure (k = log2(teamCount), so a WB with k rounds):
   *  - Winners bracket (WB): identical in shape to single elimination.
   *  - Losers bracket (LB): 2*(k-1) rounds, alternating:
   *      - "minor" rounds (odd LB round index) pair up LB survivors
   *        against each other, no new entrants.
   *      - "major" rounds (even LB round index) pair each LB survivor
   *        against a fresh loser dropping in from the winners bracket.
   *    LB round 1 is a special case of "minor": it has no prior LB
   *    survivors, so it's populated entirely from WB round 1's losers.
   *  - Grand final: WB champion (teamA) vs LB champion (teamB).
   *  - Bracket reset: only created if the LB-side team wins the grand
   *    final — at that point both finalists have exactly one loss, so a
   *    single decisive match is needed. If the WB-side team wins the
   *    grand final instead, the tournament ends there; no reset needed.
   *
   * This structure was derived by hand and cross-checked against the
   * well-known "double elimination needs 2N-2 (or 2N-1 with a reset)
   * total matches" formula for both N=4 and N=8 — it is NOT validated
   * against any specific external bracket-generator's exact seeding
   * convention (e.g. Challonge), the way single elimination's "byes go
   * to registration order" is at least a documented choice rather than
   * a guess. The overall shape (round counts, advancement logic) is
   * sound; which specific losers face each other first in a given LB
   * round is this implementation's own deterministic convention.
   * ============================================================================
   */
  private async generateDoubleEliminationBracket(tournamentId: string, teamIds: string[]) {
    if (Math.pow(2, Math.round(Math.log2(teamIds.length))) !== teamIds.length) {
      throw new BadRequestException(
        `Double elimination needs an exact power-of-two number of registered teams (4, 8, 16, 32...) — got ${teamIds.length}`,
      );
    }

    const n = teamIds.length;
    const k = Math.log2(n);
    const lbRounds = 2 * (k - 1);

    await this.prisma.$transaction(async (tx) => {
      // Winners bracket — same shape as single elimination, no byes needed.
      for (let round = 1; round <= k; round++) {
        const matchesInRound = n / Math.pow(2, round);
        for (let position = 0; position < matchesInRound; position++) {
          const [teamAId, teamBId] =
            round === 1 ? [teamIds[position * 2], teamIds[position * 2 + 1]] : [null, null];
          await tx.tournamentMatch.create({
            data: { tournamentId, bracket: 'winners', round, position, teamAId, teamBId },
          });
        }
      }

      // Losers bracket — empty shells now, populated via winner/loser
      // routing as WB and LB matches complete. See matchesInLbRound()
      // for the size derivation.
      for (let lbRound = 1; lbRound <= lbRounds; lbRound++) {
        const matchesInRound = matchesInLbRound(n, lbRound);
        for (let position = 0; position < matchesInRound; position++) {
          await tx.tournamentMatch.create({
            data: { tournamentId, bracket: 'losers', round: lbRound, position, teamAId: null, teamBId: null },
          });
        }
      }

      // Grand final — both slots filled later by advanceWinner as the
      // WB and LB finals complete.
      await tx.tournamentMatch.create({
        data: { tournamentId, bracket: 'grand_final', round: 1, position: 0, teamAId: null, teamBId: null },
      });
    });
  }

  async reportResult(
    tournamentId: string,
    matchId: string,
    requestingUserId: string,
    winnerTeamId: string,
    scoreA: number,
    scoreB: number,
  ) {
    const tournament = await this.prisma.tournament.findUnique({ where: { id: tournamentId } });
    if (!tournament) throw new NotFoundException('Tournament not found');
    if (tournament.createdByUserId !== requestingUserId) {
      throw new ForbiddenException('Only the tournament creator can report results');
    }

    return this.completeMatch(matchId, winnerTeamId, scoreA, scoreB, false);
  }

  /**
   * Support action: closes a tournament regardless of its current state
   * (stuck mid-bracket, organizer unresponsive, etc.), without touching
   * whatever matches were still pending — those stay exactly as they
   * were, just no longer reachable through the normal flow since the
   * tournament itself is CANCELLED.
   */
  async adminForceClose(tournamentId: string) {
    const tournament = await this.prisma.tournament.findUnique({ where: { id: tournamentId } });
    if (!tournament) throw new NotFoundException('Tournament not found');
    return this.prisma.tournament.update({
      where: { id: tournamentId },
      data: { status: TournamentStatus.CANCELLED },
    });
  }

  /**
   * Support action: forces a specific match's result the same way
   * reportResult does, but without requiring the caller to be the
   * tournament's organizer — for when an organizer is unreachable and a
   * bracket is stuck waiting on a result nobody can enter.
   */
  async adminForceResult(matchId: string, winnerTeamId: string, scoreA: number, scoreB: number) {
    return this.completeMatch(matchId, winnerTeamId, scoreA, scoreB, false);
  }

  private async completeMatch(
    matchId: string,
    winnerTeamId: string,
    scoreA: number | null,
    scoreB: number | null,
    isBye: boolean,
  ) {
    const match = await this.prisma.tournamentMatch.findUnique({ where: { id: matchId } });
    if (!match) throw new NotFoundException('Match not found');
    if (match.status === MatchStatus.COMPLETED) {
      throw new BadRequestException('This match already has a result');
    }
    if (!isBye && winnerTeamId !== match.teamAId && winnerTeamId !== match.teamBId) {
      throw new BadRequestException('winnerTeamId must be one of the two teams in this match');
    }
    const loserTeamId = winnerTeamId === match.teamAId ? match.teamBId : match.teamAId;

    const updated = await this.prisma.tournamentMatch.update({
      where: { id: matchId },
      data: { winnerTeamId, scoreA, scoreB, status: MatchStatus.COMPLETED },
    });

    if (match.bracket === 'bracket_reset') {
      // The one match that unconditionally ends the tournament — both
      // finalists already had one loss each going in, so this decides
      // the second and final one either way.
      await this.prisma.tournament.update({
        where: { id: match.tournamentId },
        data: { status: TournamentStatus.COMPLETED },
      });
      await this.recordChampion(match.tournamentId, winnerTeamId);
      return updated;
    }

    if (match.bracket === 'grand_final') {
      if (winnerTeamId === match.teamAId) {
        // The WB-side finalist (zero prior losses) won outright.
        await this.prisma.tournament.update({
          where: { id: match.tournamentId },
          data: { status: TournamentStatus.COMPLETED },
        });
        await this.recordChampion(match.tournamentId, winnerTeamId);
      } else {
        // The LB-side finalist won — both now have exactly one loss.
        // A single decisive bracket-reset match is required.
        await this.prisma.tournamentMatch.create({
          data: {
            tournamentId: match.tournamentId,
            bracket: 'bracket_reset',
            round: 1,
            position: 0,
            teamAId: match.teamAId,
            teamBId: match.teamBId,
          },
        });
      }
      return updated;
    }

    const tournament = await this.prisma.tournament.findUnique({ where: { id: match.tournamentId } });

    if (tournament?.bracketFormat === 'double_elimination') {
      await this.advanceDoubleElimination(match, winnerTeamId, loserTeamId);
    } else {
      await this.advanceWinner(updated);
      const nextRoundCount = await this.prisma.tournamentMatch.count({
        where: { tournamentId: match.tournamentId, bracket: 'winners', round: match.round + 1 },
      });
      if (nextRoundCount === 0) {
        await this.prisma.tournament.update({
          where: { id: match.tournamentId },
          data: { status: TournamentStatus.COMPLETED },
        });
        await this.recordChampion(match.tournamentId, winnerTeamId);
      }
    }

    return updated;
  }

  private async recordChampion(tournamentId: string, winnerTeamId: string) {
    try {
      const [tournament, team] = await Promise.all([
        this.prisma.tournament.findUnique({ where: { id: tournamentId } }),
        this.prisma.team.findUnique({ where: { id: winnerTeamId } }),
      ]);
      await this.hallOfFame.recordEvent({
        key: 'tournament_champion',
        teamId: winnerTeamId,
        value: `Чемпион "${tournament?.name ?? 'турнира'}"`,
        description: team?.name,
        relatedTournamentId: tournamentId,
      });
    } catch (e: any) {
      // Fail soft — a Hall of Fame hiccup should never make a
      // tournament fail to actually complete.
      console.warn(`Hall of Fame check failed after a tournament completion: ${e.message}`);
    }
  }

  /** Single-elimination winner routing — unchanged logic, now bracket-scoped. */
  private async advanceWinner(match: {
    tournamentId: string;
    bracket: string;
    round: number;
    position: number;
    winnerTeamId: string | null;
  }) {
    const nextMatch = await this.prisma.tournamentMatch.findUnique({
      where: {
        tournamentId_bracket_round_position: {
          tournamentId: match.tournamentId,
          bracket: match.bracket,
          round: match.round + 1,
          position: Math.floor(match.position / 2),
        },
      },
    });
    if (!nextMatch) return;

    const slot = match.position % 2 === 0 ? 'teamAId' : 'teamBId';
    await this.prisma.tournamentMatch.update({ where: { id: nextMatch.id }, data: { [slot]: match.winnerTeamId } });
  }

  /**
   * Double-elimination routing for a just-completed match — sends the
   * winner (and, for winners-bracket matches, the loser too) to their
   * next slot. See the class-level comment on
   * generateDoubleEliminationBracket for the structural rules this
   * implements.
   */
  private async advanceDoubleElimination(
    match: { tournamentId: string; bracket: string; round: number; position: number },
    winnerTeamId: string,
    loserTeamId: string | null,
  ) {
    const tournament = await this.prisma.tournament.findUnique({ where: { id: match.tournamentId } });
    const totalTeams = tournament!.maxTeams; // registration is closed by the time a bracket exists
    const k = Math.log2(nextPowerOfTwo(totalTeams));
    const lbRounds = 2 * (k - 1);

    const setSlot = async (bracket: string, round: number, position: number, slot: 'teamAId' | 'teamBId', teamId: string | null) => {
      const target = await this.prisma.tournamentMatch.findUnique({
        where: { tournamentId_bracket_round_position: { tournamentId: match.tournamentId, bracket, round, position } },
      });
      if (!target) return;
      await this.prisma.tournamentMatch.update({ where: { id: target.id }, data: { [slot]: teamId } });
    };

    if (match.bracket === 'winners') {
      // Winner: normal WB advancement, or into the grand final if this
      // was the WB final.
      if (match.round === k) {
        await setSlot('grand_final', 1, 0, 'teamAId', winnerTeamId);
      } else {
        await setSlot('winners', match.round + 1, Math.floor(match.position / 2), match.position % 2 === 0 ? 'teamAId' : 'teamBId', winnerTeamId);
      }

      // Loser: drops into the losers bracket at the round this WB round
      // feeds — round 1 directly, later rounds into a "major" round.
      const targetLbRound = match.round === 1 ? 1 : 2 * (match.round - 1);
      if (match.round === 1) {
        await setSlot('losers', targetLbRound, Math.floor(match.position / 2), match.position % 2 === 0 ? 'teamAId' : 'teamBId', loserTeamId);
      } else {
        // Survivors occupy teamAId in a major round; the freshly-dropped
        // WB loser always fills teamBId, at the same position number
        // (major-round match counts equal the WB round's match count).
        await setSlot('losers', targetLbRound, match.position, 'teamBId', loserTeamId);
      }
      return;
    }

    // match.bracket === 'losers'
    const isLastLbRound = match.round === lbRounds;
    if (isLastLbRound) {
      await setSlot('grand_final', 1, 0, 'teamBId', winnerTeamId);
      return;
    }

    const isMinorRound = match.round % 2 === 1;
    if (isMinorRound) {
      // Minor round winner -> next (major) round, same position, teamAId.
      await setSlot('losers', match.round + 1, match.position, 'teamAId', winnerTeamId);
    } else {
      // Major round winner -> next (minor) round, halved position.
      await setSlot('losers', match.round + 1, Math.floor(match.position / 2), match.position % 2 === 0 ? 'teamAId' : 'teamBId', winnerTeamId);
    }
  }
}

function nextPowerOfTwo(n: number): number {
  return Math.pow(2, Math.ceil(Math.log2(n)));
}

/**
 * Match count for losers-bracket round `lbRound` out of a bracket for
 * `n` teams (n a power of two). See the derivation in the comment on
 * generateDoubleEliminationBracket — this walks the same
 * survivors/new-entrants tracking rather than a closed-form formula,
 * since the alternating minor/major halving pattern isn't a simple
 * single expression.
 */
function matchesInLbRound(n: number, lbRound: number): number {
  let survivors = n / 2; // WB round 1's loser count, used directly by LB round 1
  let wbLoserRoundIndex = 1;
  let matches = 0;

  for (let round = 1; round <= lbRound; round++) {
    const isMinor = round % 2 === 1;
    let participants: number;
    if (round === 1) {
      participants = survivors;
    } else if (isMinor) {
      participants = survivors;
    } else {
      wbLoserRoundIndex += 1;
      const newEntrants = n / Math.pow(2, wbLoserRoundIndex);
      participants = survivors + newEntrants;
    }
    matches = participants / 2;
    survivors = matches;
  }
  return matches;
}
