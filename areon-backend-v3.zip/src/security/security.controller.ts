import { Body, Controller, Post, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { PlayerReportsService } from './player-reports.service';

@Controller('security')
@UseGuards(JwtAuthGuard)
export class SecurityController {
  constructor(private readonly reports: PlayerReportsService) {}

  @Post('reports')
  createReport(@Req() req: any, @Body() body: { reportedId: string; category: string; description: string }) {
    return this.reports.create(req.user.sub, body.reportedId, body.category, body.description);
  }
}
