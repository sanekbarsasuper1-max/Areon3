import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

export type SecurityEventType =
  | 'BANNED_ACCESS_ATTEMPT'
  | 'SESSION_INVALIDATED_ACCESS'
  | 'RATE_LIMITED'
  | 'ADMIN_ACTION'
  | 'STEAM_LOGIN_FAILED';

/**
 * Deliberately narrow — this logs security-RELEVANT events, not a
 * general activity log. `metadata` must never contain a password,
 * token, cookie value, or full request body — only small, structured,
 * non-secret context. Nothing here enforces that at the type level;
 * it's a discipline every call site has to hold to.
 */
@Injectable()
export class SecurityLogService {
  constructor(private readonly prisma: PrismaService) {}

  async log(type: SecurityEventType, opts: { userId?: string; ip?: string; metadata?: Record<string, any> } = {}) {
    try {
      await this.prisma.securityEvent.create({
        data: { type, userId: opts.userId, ip: opts.ip, metadata: opts.metadata as any },
      });
    } catch {
      // Logging must never be able to break the request it's
      // observing — same fail-soft reasoning as every other
      // side-effect hook added across this project.
    }
  }

  async listRecent(limit = 200) {
    return this.prisma.securityEvent.findMany({
      include: { user: true },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
  }
}
