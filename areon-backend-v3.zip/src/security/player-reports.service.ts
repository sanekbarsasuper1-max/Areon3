import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

export const REPORT_CATEGORIES = [
  'Scam', 'Phishing', 'Harassment', 'Spam', 'FakeAccount', 'TournamentAbuse', 'Cheating', 'Suspicious', 'Other',
] as const;

@Injectable()
export class PlayerReportsService {
  constructor(private readonly prisma: PrismaService) {}

  async create(reporterId: string, reportedId: string, category: string, description: string) {
    if (reporterId === reportedId) {
      throw new BadRequestException('Cannot report yourself');
    }
    if (!REPORT_CATEGORIES.includes(category as any)) {
      throw new BadRequestException(`Invalid category "${category}"`);
    }
    return this.prisma.playerReport.create({
      data: { reporterId, reportedId, category, description, status: 'PENDING' },
    });
  }

  async listQueue() {
    return this.prisma.playerReport.findMany({
      include: { reporter: true, reported: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Explicit admin action, never automatic — "не банить автоматически
   * только на основании одной жалобы" is enforced structurally: this
   * changes the REPORT's status, it never itself touches
   * User.isBanned. An admin who decides to actually ban someone does
   * that as its own separate action, informed by this review, not
   * triggered by it.
   */
  async setStatus(id: string, status: string, adminNote?: string) {
    const existing = await this.prisma.playerReport.findUnique({ where: { id } });
    if (!existing) throw new NotFoundException('Report not found');
    return this.prisma.playerReport.update({
      where: { id },
      data: { status, adminNote: adminNote ?? existing.adminNote, reviewedAt: new Date() },
    });
  }
}
