import { Module } from '@nestjs/common';
import { SecurityController } from './security.controller';
import { SecurityLogService } from './security-log.service';
import { PlayerReportsService } from './player-reports.service';
import { PrismaService } from '../prisma.service';

@Module({
  controllers: [SecurityController],
  providers: [SecurityLogService, PlayerReportsService, PrismaService],
  exports: [SecurityLogService, PlayerReportsService],
})
export class SecurityModule {}
