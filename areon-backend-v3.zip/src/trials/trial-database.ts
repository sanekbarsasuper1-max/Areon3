/**
 * ============================================================================
 * TRIAL_DATABASE — seed templates for Orion Trials.
 *
 * SCOPE DECISION, stated plainly: the original spec's ABILITY category
 * ("5 kills with Finger of Death") and precise multi-kill COMBAT
 * detection (double/triple kill, Rampage) are NOT included here. Both
 * need per-event data (kills_log, killstreak detection) that only
 * exists on PARSED match replays — confirmed via multiple independent
 * sources that only ~5% of matches get parsed by default, parsing is
 * requested per-match and takes 1-5 minutes, and isn't guaranteed to
 * succeed for old/private matches. Per the spec's own requirement 18
 * ("если конкретное действие невозможно определить по доступным
 * данным, такое испытание нельзя выпускать в активный пул"), taken
 * literally: these categories are excluded from the active pool, not
 * approximated with a worse signal.
 *
 * Ward-count SUPPORT trials (obs_placed/sen_placed) are ALSO excluded —
 * not because they're confirmed parse-only (evidence was genuinely
 * mixed across sources), but because it wasn't confirmed *safe*
 * either, and the honest move when unsure is to leave it out rather
 * than guess. hero_healing-based SUPPORT trials ARE included — that
 * field was confirmed present in the same lightweight sync endpoint
 * multiple independent client libraries agree on.
 *
 * `code` is which evaluator in trial-evaluators.ts this template uses —
 * DELIBERATELY not unique. Many templates share one evaluator at
 * different difficulty/parameter tiers (e.g. "win 2 matches" COMMON
 * and "win 3 matches" RARE both use win_n_matches). `seedKey` is the
 * real unique identifier for idempotent seeding.
 *
 * POOL SIZE PER DIFFICULTY MATTERS: the generator draws 4 COMMON /
 * 3 RARE / 2 EPIC / 1 LEGENDARY per cycle and avoids repeating a
 * template used in the last 2 cycles where the pool allows it. A pool
 * exactly equal to (or smaller than) the per-cycle draw count means
 * EVERY cycle repeats — this is why COMMON and LEGENDARY were
 * deliberately grown well past their per-cycle draw size, not just
 * padded arbitrarily.
 * ============================================================================
 */

import { TrialCategory, TrialDifficulty } from '@prisma/client';

export interface TrialTemplateSeed {
  seedKey: string;
  code: string;
  category: TrialCategory;
  difficulty: TrialDifficulty;
  title: string;
  description: string;
  conditionJson: Record<string, any>;
  targetValue: number;
  rewardShards: number;
}

const REWARDS: Record<TrialDifficulty, number> = {
  COMMON: 50,
  RARE: 100,
  EPIC: 150,
  LEGENDARY: 300,
};

export const TRIAL_DATABASE: TrialTemplateSeed[] = [
  // ============================== COMMON ==============================
  {
    seedKey: 'play_3_matches',
    code: 'play_n_matches',
    category: 'MATCH',
    difficulty: 'COMMON',
    title: 'В деле',
    description: 'Сыграйте {n} матчей.',
    conditionJson: { n: 3 },
    targetValue: 3,
    rewardShards: REWARDS.COMMON,
  },
  {
    seedKey: 'win_2_matches_common',
    code: 'win_n_matches',
    category: 'MATCH',
    difficulty: 'COMMON',
    title: 'Победная серия',
    description: 'Выиграйте {n} матча(ей).',
    conditionJson: { n: 2 },
    targetValue: 2,
    rewardShards: REWARDS.COMMON,
  },
  {
    seedKey: 'match_assists_15_common',
    code: 'match_assists_threshold',
    category: 'MATCH',
    difficulty: 'COMMON',
    title: 'Командный игрок',
    description: 'Совершите {n} assists за один матч.',
    conditionJson: { n: 15 },
    targetValue: 15,
    rewardShards: REWARDS.COMMON,
  },
  {
    seedKey: 'hero_matches_2_common',
    code: 'hero_matches_played',
    category: 'HERO',
    difficulty: 'COMMON',
    title: 'Знакомство',
    description: 'Сыграйте {n} матч(а) на герое {heroName}.',
    conditionJson: { n: 2, heroId: null },
    targetValue: 2,
    rewardShards: REWARDS.COMMON,
  },
  {
    seedKey: 'match_kills_5_common',
    code: 'match_kills_threshold',
    category: 'MATCH',
    difficulty: 'COMMON',
    title: 'Первая кровь',
    description: 'Сделайте {n} убийств за один матч.',
    conditionJson: { n: 5 },
    targetValue: 5,
    rewardShards: REWARDS.COMMON,
  },
  {
    seedKey: 'match_last_hits_100_common',
    code: 'match_last_hits_threshold',
    category: 'FARM',
    difficulty: 'COMMON',
    title: 'На линии',
    description: 'Наберите {n} last hits за один матч.',
    conditionJson: { n: 100 },
    targetValue: 100,
    rewardShards: REWARDS.COMMON,
  },
  {
    seedKey: 'match_duration_25_common',
    code: 'match_duration_over',
    category: 'MATCH',
    difficulty: 'COMMON',
    title: 'Затяжной бой',
    description: 'Сыграйте матч продолжительностью более {minutes} минут.',
    conditionJson: { minutes: 25 },
    targetValue: 25,
    rewardShards: REWARDS.COMMON,
  },
  {
    seedKey: 'match_gpm_350_common',
    code: 'match_gpm_threshold',
    category: 'FARM',
    difficulty: 'COMMON',
    title: 'Стабильный доход',
    description: 'Наберите {n} GPM за один матч.',
    conditionJson: { n: 350 },
    targetValue: 350,
    rewardShards: REWARDS.COMMON,
  },
  {
    seedKey: 'match_max_deaths_8_common',
    code: 'match_max_deaths',
    category: 'SURVIVAL',
    difficulty: 'COMMON',
    title: 'Не разбрасывайтесь',
    description: 'Сыграйте матч и умрите не более {maxDeaths} раз(а).',
    conditionJson: { maxDeaths: 8 },
    targetValue: 1,
    rewardShards: REWARDS.COMMON,
  },
  {
    seedKey: 'match_healing_1500_common',
    code: 'match_healing_threshold',
    category: 'SUPPORT',
    difficulty: 'COMMON',
    title: 'Первая помощь',
    description: 'Обеспечьте {n} лечения союзникам за один матч.',
    conditionJson: { n: 1500 },
    targetValue: 1500,
    rewardShards: REWARDS.COMMON,
  },

  // ================================ RARE ================================
  {
    seedKey: 'match_kills_10_rare',
    code: 'match_kills_threshold',
    category: 'MATCH',
    difficulty: 'RARE',
    title: 'Мясник',
    description: 'Сделайте {n} убийств за один матч.',
    conditionJson: { n: 10 },
    targetValue: 10,
    rewardShards: REWARDS.RARE,
  },
  {
    seedKey: 'match_duration_45_rare',
    code: 'match_duration_over',
    category: 'MATCH',
    difficulty: 'RARE',
    title: 'Марафон',
    description: 'Сыграйте матч продолжительностью более {minutes} минут.',
    conditionJson: { minutes: 45 },
    targetValue: 45,
    rewardShards: REWARDS.RARE,
  },
  {
    seedKey: 'hero_win_rare',
    code: 'hero_win',
    category: 'HERO',
    difficulty: 'RARE',
    title: 'Победа за героя',
    description: 'Выиграйте матч на герое {heroName}.',
    conditionJson: { heroId: null },
    targetValue: 1,
    rewardShards: REWARDS.RARE,
  },
  {
    seedKey: 'hero_rarely_played_rare',
    code: 'hero_rarely_played',
    category: 'SPECIAL',
    difficulty: 'RARE',
    title: 'Выход из зоны комфорта',
    description: 'Сыграйте одну игру на герое, которого вы редко используете.',
    conditionJson: { heroId: null },
    targetValue: 1,
    rewardShards: REWARDS.RARE,
  },
  {
    seedKey: 'match_max_deaths_5_rare',
    code: 'match_max_deaths',
    category: 'SURVIVAL',
    difficulty: 'RARE',
    title: 'Осторожная игра',
    description: 'Сыграйте матч и умрите не более {maxDeaths} раз(а).',
    conditionJson: { maxDeaths: 5 },
    targetValue: 1,
    rewardShards: REWARDS.RARE,
  },
  {
    seedKey: 'match_last_hits_250_rare',
    code: 'match_last_hits_threshold',
    category: 'FARM',
    difficulty: 'RARE',
    title: 'Крипоед',
    description: 'Наберите {n} last hits за один матч.',
    conditionJson: { n: 250 },
    targetValue: 250,
    rewardShards: REWARDS.RARE,
  },
  {
    seedKey: 'match_healing_5000_rare',
    code: 'match_healing_threshold',
    category: 'SUPPORT',
    difficulty: 'RARE',
    title: 'Полевой медик',
    description: 'Обеспечьте {n} лечения союзникам за один матч.',
    conditionJson: { n: 5000 },
    targetValue: 5000,
    rewardShards: REWARDS.RARE,
  },
  {
    seedKey: 'win_3_matches_rare',
    code: 'win_n_matches',
    category: 'MATCH',
    difficulty: 'RARE',
    title: 'Уверенная рука',
    description: 'Выиграйте {n} матча(ей).',
    conditionJson: { n: 3 },
    targetValue: 3,
    rewardShards: REWARDS.RARE,
  },
  {
    seedKey: 'hero_matches_3_rare',
    code: 'hero_matches_played',
    category: 'HERO',
    difficulty: 'RARE',
    title: 'Хорошее знакомство',
    description: 'Сыграйте {n} матч(а) на герое {heroName}.',
    conditionJson: { n: 3, heroId: null },
    targetValue: 3,
    rewardShards: REWARDS.RARE,
  },
  {
    seedKey: 'match_assists_25_rare',
    code: 'match_assists_threshold',
    category: 'MATCH',
    difficulty: 'RARE',
    title: 'Душа команды',
    description: 'Совершите {n} assists за один матч.',
    conditionJson: { n: 25 },
    targetValue: 25,
    rewardShards: REWARDS.RARE,
  },

  // ================================ EPIC ================================
  {
    seedKey: 'match_hero_damage_30000_epic',
    code: 'match_hero_damage_threshold',
    category: 'MATCH',
    difficulty: 'EPIC',
    title: 'Разрушитель',
    description: 'Нанесите {n} урона героям за один матч.',
    conditionJson: { n: 30000 },
    targetValue: 30000,
    rewardShards: REWARDS.EPIC,
  },
  {
    seedKey: 'win_max_deaths_3_epic',
    code: 'win_with_max_deaths',
    category: 'SURVIVAL',
    difficulty: 'EPIC',
    title: 'Хладнокровие',
    description: 'Выиграйте матч, умерев не более {maxDeaths} раз(а).',
    conditionJson: { maxDeaths: 3 },
    targetValue: 1,
    rewardShards: REWARDS.EPIC,
  },
  {
    seedKey: 'match_gpm_600_epic',
    code: 'match_gpm_threshold',
    category: 'FARM',
    difficulty: 'EPIC',
    title: 'Золотая лихорадка',
    description: 'Наберите {n} GPM за один матч.',
    conditionJson: { n: 600 },
    targetValue: 600,
    rewardShards: REWARDS.EPIC,
  },
  {
    seedKey: 'win_streak_2_epic',
    code: 'win_streak',
    category: 'STREAK',
    difficulty: 'EPIC',
    title: 'Не остановить',
    description: 'Выиграйте {n} матча(ей) подряд.',
    conditionJson: { n: 2 },
    targetValue: 2,
    rewardShards: REWARDS.EPIC,
  },
  {
    seedKey: 'match_kills_15_epic',
    code: 'match_kills_threshold',
    category: 'MATCH',
    difficulty: 'EPIC',
    title: 'Кровавая жатва',
    description: 'Сделайте {n} убийств за один матч.',
    conditionJson: { n: 15 },
    targetValue: 15,
    rewardShards: REWARDS.EPIC,
  },
  {
    seedKey: 'match_last_hits_350_epic',
    code: 'match_last_hits_threshold',
    category: 'FARM',
    difficulty: 'EPIC',
    title: 'Фермер',
    description: 'Наберите {n} last hits за один матч.',
    conditionJson: { n: 350 },
    targetValue: 350,
    rewardShards: REWARDS.EPIC,
  },
  {
    seedKey: 'match_healing_8000_epic',
    code: 'match_healing_threshold',
    category: 'SUPPORT',
    difficulty: 'EPIC',
    title: 'Спаситель',
    description: 'Обеспечьте {n} лечения союзникам за один матч.',
    conditionJson: { n: 8000 },
    targetValue: 8000,
    rewardShards: REWARDS.EPIC,
  },

  // ============================== LEGENDARY ==============================
  {
    seedKey: 'win_without_dying_legendary',
    code: 'win_without_dying',
    category: 'SURVIVAL',
    difficulty: 'LEGENDARY',
    title: 'Неприкасаемый',
    description: 'Выиграйте матч, ни разу не умерев.',
    conditionJson: {},
    targetValue: 1,
    rewardShards: REWARDS.LEGENDARY,
  },
  {
    seedKey: 'win_streak_5_legendary',
    code: 'win_streak_legendary',
    category: 'STREAK',
    difficulty: 'LEGENDARY',
    title: 'Доминация',
    description: 'Выиграйте {n} матчей подряд.',
    conditionJson: { n: 5 },
    targetValue: 5,
    rewardShards: REWARDS.LEGENDARY,
  },
  {
    seedKey: 'match_kills_25_legendary',
    code: 'match_kills_threshold',
    category: 'MATCH',
    difficulty: 'LEGENDARY',
    title: 'Кровавая баня',
    description: 'Сделайте {n} убийств за один матч.',
    conditionJson: { n: 25 },
    targetValue: 25,
    rewardShards: REWARDS.LEGENDARY,
  },
  {
    seedKey: 'match_hero_damage_50000_legendary',
    code: 'match_hero_damage_threshold',
    category: 'MATCH',
    difficulty: 'LEGENDARY',
    title: 'Опустошитель',
    description: 'Нанесите {n} урона героям за один матч.',
    conditionJson: { n: 50000 },
    targetValue: 50000,
    rewardShards: REWARDS.LEGENDARY,
  },
  {
    seedKey: 'match_gpm_800_legendary',
    code: 'match_gpm_threshold',
    category: 'FARM',
    difficulty: 'LEGENDARY',
    title: 'Экономическое чудо',
    description: 'Наберите {n} GPM за один матч.',
    conditionJson: { n: 800 },
    targetValue: 800,
    rewardShards: REWARDS.LEGENDARY,
  },
];
