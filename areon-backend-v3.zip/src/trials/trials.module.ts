import { Module } from '@nestjs/common';
import { TrialsController } from './trials.controller';
import { TrialsService } from './trials.service';
import { TrialGeneratorService } from './trial-generator.service';
import { TrialEngineService } from './trial-engine.service';
import { ShardsService } from './shards.service';
import { PrismaService } from '../prisma.service';
import { HallOfFameModule } from '../hall-of-fame/hall-of-fame.module';

@Module({
  imports: [HallOfFameModule],
  providers: [TrialsService, TrialGeneratorService, TrialEngineService, ShardsService, PrismaService],
  controllers: [TrialsController],
  // TrialEngineService: consumed by MatchesModule right after every
  // sync. TrialGeneratorService + ShardsService: consumed by
  // AdminModule for Trial Management (requirement 22).
  exports: [TrialEngineService, TrialGeneratorService, ShardsService],
})
export class TrialsModule {}
