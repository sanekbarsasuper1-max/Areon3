import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { EVALUATORS, MatchForEvaluation } from './trial-evaluators';
import { HallOfFameService } from '../hall-of-fame/hall-of-fame.service';

@Injectable()
export class TrialEngineService {
  private readonly logger = new Logger(TrialEngineService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly hallOfFame: HallOfFameService,
  ) {}

  /**
   * Called by MatchesService right after every sync — see the call
   * site there for why this is "after any sync happens" rather than a
   * true real-time push: OpenDota/Steam don't offer a webhook for "a
   * match just ended," so this scaffold's freshness is bounded by how
   * often the user (or a future periodic job) triggers a sync, not by
   * the match's actual end time. Documented as a real gap, not hidden.
   *
   * Idempotency: only ever processes Match rows where
   * trialsProcessedAt is still null, and marks them processed
   * unconditionally at the end of this pass (even if the user had no
   * active trials to check them against) — so a match is evaluated
   * against Orion Trials exactly once, full stop, regardless of how
   * many times sync gets called afterward.
   *
   * KNOWN SIMPLIFICATION: the whole backlog for one user is processed
   * inside a single Prisma $transaction. Fine at the scale of a
   * person's own match history; a real production rollout with users
   * who haven't synced in months (hundreds of backlogged matches)
   * would want this chunked instead of one long transaction.
   */
  async processUnevaluatedMatchesForUser(userId: string) {
    const unprocessed = await this.prisma.match.findMany({
      where: { userId, trialsProcessedAt: null },
      orderBy: { startTime: 'asc' }, // chronological order matters for STREAK trials
    });
    if (unprocessed.length === 0) return { processed: 0, completedTrials: 0 };

    let completedCount = 0;
    const legendaryCompletions: { userId: string; title: string }[] = [];

    await this.prisma.$transaction(async (tx) => {
      for (const match of unprocessed) {
        const cycle = await tx.userTrialCycle.findFirst({
          where: { userId, status: 'ACTIVE' },
        });

        if (cycle) {
          const activeTrials = await tx.userTrial.findMany({
            where: { cycleId: cycle.id, status: 'ACTIVE' },
            include: { template: true },
          });

          const matchForEval: MatchForEvaluation = {
            heroId: match.heroId,
            kills: match.kills,
            deaths: match.deaths,
            assists: match.assists,
            goldPerMin: match.goldPerMin,
            durationSec: match.durationSec,
            radiantWin: match.radiantWin,
            playerSlot: match.playerSlot,
            heroDamage: match.heroDamage,
            heroHealing: match.heroHealing,
            lastHits: match.lastHits,
          };

          for (const trial of activeTrials) {
            const evaluator = EVALUATORS[trial.template.code];
            if (!evaluator) {
              this.logger.warn(`No evaluator registered for trial code "${trial.template.code}" — skipping`);
              continue;
            }

            const condition = {
              ...(trial.template.conditionJson as any),
              ...((trial.resolvedConditionJson as any) ?? {}),
            };
            const result = evaluator(matchForEval, condition, (trial.progressJson as any) ?? {});

            if (!result.completed) {
              if (JSON.stringify(result.progress) !== JSON.stringify(trial.progressJson)) {
                await tx.userTrial.update({
                  where: { id: trial.id },
                  data: { progressJson: result.progress as any },
                });
              }
              continue;
            }

            // Completed — reward atomically in the same transaction as
            // marking it complete, so there's never a state where a
            // trial shows COMPLETED but no ShardTransaction exists, or
            // vice versa.
            const user = await tx.user.findUnique({ where: { id: userId } });
            const newBalance = (user?.shardBalance ?? 0) + trial.template.rewardShards;

            await tx.userTrial.update({
              where: { id: trial.id },
              data: {
                status: 'COMPLETED',
                completedAt: new Date(),
                completedByMatchId: match.id,
                progressJson: result.progress as any,
              },
            });
            await tx.shardTransaction.create({
              data: {
                userId,
                amount: trial.template.rewardShards,
                type: 'TRIAL_REWARD',
                reason: trial.template.title,
                relatedUserTrialId: trial.id,
                balanceAfter: newBalance,
              },
            });
            await tx.user.update({ where: { id: userId }, data: { shardBalance: newBalance } });

            if (trial.template.difficulty === 'LEGENDARY') {
              legendaryCompletions.push({ userId, title: trial.template.title });
            }

            completedCount += 1;
          }
        }

        await tx.match.update({ where: { id: match.id }, data: { trialsProcessedAt: new Date() } });
      }
    });

    // Outside the transaction — same "fail soft, never block the real
    // reward" reasoning as Minesweeper's identical hook.
    for (const c of legendaryCompletions) {
      try {
        await this.hallOfFame.recordEvent({
          key: 'first_legendary_trial',
          userId: c.userId,
          value: c.title,
          description: 'Первое выполненное испытание сложности LEGENDARY на платформе',
        });
      } catch (e: any) {
        this.logger.warn(`Hall of Fame check failed after a LEGENDARY trial completion: ${e.message}`);
      }
    }

    return { processed: unprocessed.length, completedTrials: completedCount };
  }
}
