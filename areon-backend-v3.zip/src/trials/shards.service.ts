import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

@Injectable()
export class ShardsService {
  constructor(private readonly prisma: PrismaService) {}

  async getBalance(userId: string): Promise<number> {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    return user?.shardBalance ?? 0;
  }

  async getHistory(userId: string) {
    return this.prisma.shardTransaction.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
  }

  /**
   * Admin-only path (see AdminController) for manual corrections —
   * e.g. compensating a user for a bug. Goes through the exact same
   * append-only-ledger + atomic-balance-update pattern as a real trial
   * reward, never a direct write to User.shardBalance alone.
   */
  async adminAdjust(userId: string, amount: number, reason: string) {
    return this.prisma.$transaction(async (tx) => {
      const user = await tx.user.findUnique({ where: { id: userId } });
      const newBalance = (user?.shardBalance ?? 0) + amount;
      await tx.user.update({ where: { id: userId }, data: { shardBalance: newBalance } });
      return tx.shardTransaction.create({
        data: { userId, amount, type: 'ADMIN_ADJUST', reason, balanceAfter: newBalance },
      });
    });
  }
}
