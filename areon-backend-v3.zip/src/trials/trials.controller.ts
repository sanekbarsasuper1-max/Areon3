import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { PrismaService } from '../prisma.service';
import { TrialsService } from './trials.service';
import { ShardsService } from './shards.service';

@Controller()
@UseGuards(JwtAuthGuard)
export class TrialsController {
  constructor(
    private readonly trialsService: TrialsService,
    private readonly shardsService: ShardsService,
    private readonly prisma: PrismaService,
  ) {}

  @Get('trials/me')
  async getMyCycle(@Req() req: any) {
    const cycle = await this.trialsService.getCurrentCycle(req.user.sub);
    return cycle ? this.formatCycle(cycle) : null;
  }

  @Get('trials/history')
  async getHistory(@Req() req: any) {
    const cycles = await this.trialsService.getCycleHistory(req.user.sub);
    return Promise.all(cycles.map((c) => this.formatCycle(c)));
  }

  @Get('shards/balance')
  async getBalance(@Req() req: any) {
    return { balance: await this.shardsService.getBalance(req.user.sub) };
  }

  @Get('shards/history')
  async getShardHistory(@Req() req: any) {
    return this.shardsService.getHistory(req.user.sub);
  }

  /**
   * Resolves {n}/{heroName}/{maxDeaths}/{minutes} placeholders in a
   * template's description using its (possibly per-user-resolved)
   * condition — the frontend never sees raw conditionJson or has to
   * know these evaluator-specific parameter names itself.
   */
  private async formatCycle(cycle: any) {
    const heroIds = cycle.trials
      .map((t: any) => (t.resolvedConditionJson as any)?.heroId ?? (t.template.conditionJson as any)?.heroId)
      .filter((id: any) => id != null);
    const heroes = heroIds.length
      ? await this.prisma.hero.findMany({ where: { id: { in: heroIds } } })
      : [];
    const heroNameById = new Map(heroes.map((h) => [h.id, h.localizedName]));

    return {
      ...cycle,
      trials: cycle.trials.map((t: any) => {
        const condition = { ...(t.template.conditionJson as any), ...((t.resolvedConditionJson as any) ?? {}) };
        const description = t.template.description
          .replace('{n}', String(condition.n ?? ''))
          .replace('{maxDeaths}', String(condition.maxDeaths ?? ''))
          .replace('{minutes}', String(condition.minutes ?? ''))
          .replace('{heroName}', condition.heroId != null ? heroNameById.get(condition.heroId) ?? '?' : '');
        return { ...t, description };
      }),
    };
  }
}
