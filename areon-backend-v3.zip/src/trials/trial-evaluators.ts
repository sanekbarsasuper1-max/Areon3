/**
 * One evaluator function per TrialTemplate.code. Each is a pure
 * function: (match, condition, progress) -> { progress, completed }.
 * Kept pure and separate from TrialEngineService's DB/transaction
 * logic specifically so they're testable in isolation — see
 * trial-evaluators.spec.ts.
 */

export interface MatchForEvaluation {
  heroId: number;
  kills: number;
  deaths: number;
  assists: number;
  goldPerMin: number;
  durationSec: number;
  radiantWin: boolean;
  playerSlot: number;
  heroDamage: number | null;
  heroHealing: number | null;
  lastHits: number | null;
}

export interface EvaluationResult {
  progress: Record<string, any>;
  completed: boolean;
}

type Evaluator = (
  match: MatchForEvaluation,
  condition: Record<string, any>,
  progress: Record<string, any>,
) => EvaluationResult;

export function isWin(match: MatchForEvaluation): boolean {
  const isRadiant = match.playerSlot < 128;
  return isRadiant ? match.radiantWin : !match.radiantWin;
}

/** Counts up toward `condition.n`, never resets — used by any
 * "do X, N times across the cycle" style trial. */
function counting(matches: boolean | ((m: MatchForEvaluation) => boolean)): Evaluator {
  return (match, condition, progress) => {
    const qualifies = typeof matches === 'function' ? matches(match) : matches;
    const count = (progress.count ?? 0) + (qualifies ? 1 : 0);
    return { progress: { count }, completed: count >= condition.n };
  };
}

/** Single-match threshold check — completes the instant one match
 * clears the bar, tracks the best attempt for progress display even
 * when not yet cleared. */
function singleMatchThreshold(getValue: (m: MatchForEvaluation) => number | null): Evaluator {
  return (match, condition, progress) => {
    const value = getValue(match);
    if (value == null) return { progress, completed: false }; // field absent on this match — can't judge it, not a fail
    const best = Math.max(progress.best ?? 0, value);
    return { progress: { best }, completed: value >= condition.n };
  };
}

export const EVALUATORS: Record<string, Evaluator> = {
  play_n_matches: counting(true),
  win_n_matches: counting((m) => isWin(m)),

  match_kills_threshold: singleMatchThreshold((m) => m.kills),
  match_assists_threshold: singleMatchThreshold((m) => m.assists),
  match_duration_over: (match, condition, progress) => {
    const minutes = match.durationSec / 60;
    return { progress, completed: minutes >= condition.minutes };
  },
  match_hero_damage_threshold: singleMatchThreshold((m) => m.heroDamage),

  hero_matches_played: (match, condition, progress) => {
    if (match.heroId !== condition.heroId) return { progress, completed: false };
    const count = (progress.count ?? 0) + 1;
    return { progress: { count }, completed: count >= condition.n };
  },
  hero_win: (match, condition, progress) => {
    if (match.heroId !== condition.heroId) return { progress, completed: false };
    return { progress, completed: isWin(match) };
  },
  hero_rarely_played: (match, condition, progress) => {
    if (match.heroId !== condition.heroId) return { progress, completed: false };
    return { progress, completed: true };
  },

  match_max_deaths: (match, condition, progress) => ({
    progress,
    completed: match.deaths <= condition.maxDeaths,
  }),
  win_with_max_deaths: (match, condition, progress) => ({
    progress,
    completed: isWin(match) && match.deaths <= condition.maxDeaths,
  }),
  win_without_dying: (match, condition, progress) => ({
    progress,
    completed: isWin(match) && match.deaths === 0,
  }),

  match_last_hits_threshold: singleMatchThreshold((m) => m.lastHits),
  match_gpm_threshold: singleMatchThreshold((m) => m.goldPerMin),
  match_healing_threshold: singleMatchThreshold((m) => m.heroHealing),

  // Streak trials never "fail" a trial outright on a loss — they just
  // reset the running counter and keep going for the rest of the
  // cycle, same as a real winstreak would.
  win_streak: (match, condition, progress) => {
    const streak = isWin(match) ? (progress.currentStreak ?? 0) + 1 : 0;
    return { progress: { currentStreak: streak }, completed: streak >= condition.n };
  },
  win_streak_legendary: (match, condition, progress) => {
    const streak = isWin(match) ? (progress.currentStreak ?? 0) + 1 : 0;
    return { progress: { currentStreak: streak }, completed: streak >= condition.n };
  },
};
