import { Module } from '@nestjs/common';
import { CoachController } from './coach.controller';
import { CoachService } from './coach.service';
import { PrismaService } from '../prisma.service';
import { OpenDotaModule } from '../opendota/opendota.module';

@Module({
  imports: [OpenDotaModule],
  controllers: [CoachController],
  providers: [CoachService, PrismaService],
})
export class CoachModule {}
