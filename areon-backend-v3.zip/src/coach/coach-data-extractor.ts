import { OpenDotaMatchDetail, OpenDotaMatchPlayer } from '../opendota/opendota.service';

/**
 * Every field here is either read directly from OpenDota's parsed
 * response or a straightforward derived computation (sums, deltas,
 * time-bucketing) — nothing here is a judgment call or a guess. This
 * is the layer that enforces requirement 26 structurally: the AI
 * Coach service (coach.service.ts) is only ever handed objects shaped
 * like these, never raw match JSON, so it has nothing to invent facts
 * FROM even if it wanted to — only these pre-verified facts to reason
 * ABOUT.
 */

export interface ItemPurchase {
  timeSec: number;
  itemKey: string; // internal item name — resolved to a display name by the caller via the Item table
}

export interface AbilityUpgrade {
  level: number; // hero level at which this upgrade happened (1-indexed by position in the array)
  abilityId: number;
}

export interface TeamfightSummary {
  startSec: number;
  endSec: number;
  totalDeaths: number;
  // Per-player deltas for the analyzed user's own match only — kept
  // narrow rather than dumping all 10 players' raw teamfight blocks,
  // since the coach report is written from one player's perspective.
  players: {
    playerSlot: number;
    heroId: number;
    damage: number;
    healing: number;
    goldDelta: number;
    xpDelta: number;
    deaths: number;
    killedOpponentSlots: number[]; // which enemy player_slots this player got credit for killing, in this fight
  }[];
}

export interface GamePhaseStats {
  phase: 'laning' | 'mid' | 'late';
  startSec: number;
  endSec: number;
  // Deltas WITHIN this phase window, not cumulative totals — computed
  // from gold_t/xp_t sampled at the phase boundaries (those arrays are
  // confirmed present on the standard, non-parse-only response, so
  // this part works even if teamfights/purchase_log can't be trusted).
  goldGained: number;
  xpGained: number;
}

export interface MatchFacts {
  matchId: number;
  durationSec: number;
  won: boolean;
  patch: string | null; // "Data unavailable" territory if OpenDota didn't return a patch id — surfaced as null, not guessed
  yourHeroId: number;
  yourTeamHeroIds: number[];
  enemyTeamHeroIds: number[];
  itemPurchases: ItemPurchase[];
  abilityUpgrades: AbilityUpgrade[];
  teamfights: TeamfightSummary[] | null; // null = match wasn't parsed deeply enough for this, not "no fights happened"
  phases: GamePhaseStats[];
  finalStats: { kills: number; deaths: number; assists: number; lastHits: number; heroDamage: number | null; heroHealing: number | null };
}

const LANING_END_SEC = 10 * 60;
const MID_END_SEC = 25 * 60;

export function extractMatchFacts(match: OpenDotaMatchDetail, forPlayerSlot: number, patchLabel: string | null): MatchFacts {
  const you = match.players.find((p) => p.player_slot === forPlayerSlot);
  if (!you) throw new Error(`Player slot ${forPlayerSlot} not found in match ${match.match_id}`);

  const isRadiant = (slot: number) => slot < 128;
  const won = isRadiant(forPlayerSlot) ? match.radiant_win : !match.radiant_win;
  const yourTeamHeroIds = match.players.filter((p) => isRadiant(p.player_slot) === isRadiant(forPlayerSlot)).map((p) => p.hero_id);
  const enemyTeamHeroIds = match.players.filter((p) => isRadiant(p.player_slot) !== isRadiant(forPlayerSlot)).map((p) => p.hero_id);

  return {
    matchId: match.match_id,
    durationSec: match.duration,
    won,
    patch: patchLabel,
    yourHeroId: you.hero_id,
    yourTeamHeroIds,
    enemyTeamHeroIds,
    itemPurchases: (you.purchase_log ?? []).map((p) => ({ timeSec: p.time, itemKey: p.key })),
    abilityUpgrades: (you.ability_upgrades_arr ?? []).map((abilityId, i) => ({ level: i + 1, abilityId })),
    teamfights: extractTeamfights(match, forPlayerSlot),
    phases: extractPhases(you, match.duration),
    finalStats: {
      kills: you.kills,
      deaths: you.deaths,
      assists: you.assists,
      lastHits: you.last_hits,
      heroDamage: you.hero_damage ?? null,
      heroHealing: you.hero_healing ?? null,
    },
  };
}

function extractTeamfights(match: OpenDotaMatchDetail, forPlayerSlot: number): TeamfightSummary[] | null {
  // teamfights isn't part of the typed OpenDotaMatchDetail shape used
  // elsewhere (it's parse-only and large) — read defensively rather
  // than assuming it's there, exactly the "Data unavailable, don't
  // guess" discipline requirement 26 asked for.
  const raw = (match as any).teamfights as
    | { start: number; end: number; deaths: number; players: any[] }[]
    | undefined;
  if (!raw) return null;

  const playerIndex = match.players.findIndex((p) => p.player_slot === forPlayerSlot);
  if (playerIndex === -1) return null;

  return raw.map((fight) => ({
    startSec: fight.start,
    endSec: fight.end,
    totalDeaths: fight.deaths,
    players: fight.players.map((fp: any, i: number) => {
      const matchPlayer = match.players[i];
      const killedOpponentSlots = Object.entries(fp.killed ?? {})
        .filter(([, count]) => Number(count) > 0)
        .map(([slot]) => Number(slot));
      return {
        playerSlot: matchPlayer.player_slot,
        heroId: matchPlayer.hero_id,
        damage: fp.damage ?? 0,
        healing: fp.healing ?? 0,
        goldDelta: fp.gold_delta ?? 0,
        xpDelta: fp.xp_delta ?? 0,
        deaths: fp.deaths ?? 0,
        killedOpponentSlots,
      };
    }),
  }));
}

function extractPhases(you: OpenDotaMatchPlayer, durationSec: number): GamePhaseStats[] {
  const goldT = you.gold_t ?? [];
  const xpT = you.xp_t ?? [];
  // gold_t/xp_t are sampled roughly once per minute — index ≈ minute.
  const at = (arr: number[], sec: number) => arr[Math.min(arr.length - 1, Math.floor(sec / 60))] ?? 0;

  const laningEnd = Math.min(LANING_END_SEC, durationSec);
  const midEnd = Math.min(MID_END_SEC, durationSec);

  const phases: GamePhaseStats[] = [
    { phase: 'laning', startSec: 0, endSec: laningEnd, goldGained: at(goldT, laningEnd) - at(goldT, 0), xpGained: at(xpT, laningEnd) - at(xpT, 0) },
  ];
  if (durationSec > LANING_END_SEC) {
    phases.push({
      phase: 'mid',
      startSec: laningEnd,
      endSec: midEnd,
      goldGained: at(goldT, midEnd) - at(goldT, laningEnd),
      xpGained: at(xpT, midEnd) - at(xpT, laningEnd),
    });
  }
  if (durationSec > MID_END_SEC) {
    phases.push({
      phase: 'late',
      startSec: midEnd,
      endSec: durationSec,
      goldGained: at(goldT, durationSec) - at(goldT, midEnd),
      xpGained: at(xpT, durationSec) - at(xpT, midEnd),
    });
  }
  return phases;
}
