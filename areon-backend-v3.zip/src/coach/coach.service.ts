import { BadRequestException, ForbiddenException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { OpenDotaService } from '../opendota/opendota.service';
import { extractMatchFacts } from './coach-data-extractor';
import { buildCoachPrompt, CoachDepth, DraftContext, ResolvedNames } from './coach-prompt-builder';

// Bounded polling, not an indefinite wait — a request/response HTTP
// handler blocking for minutes is a bad pattern regardless of how
// patient the client is. If parsing isn't done within this budget,
// callers get a clear "still processing" response and are expected to
// retry shortly, rather than the request hanging.
const PARSE_POLL_ATTEMPTS = 6;
const PARSE_POLL_DELAY_MS = 10_000;

@Injectable()
export class CoachService {
  private readonly logger = new Logger(CoachService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly openDota: OpenDotaService,
  ) {}

  async generateReport(userId: string, matchRowId: string, depth: CoachDepth) {
    const match = await this.prisma.match.findUnique({ where: { id: matchRowId } });
    if (!match) throw new NotFoundException('Match not found');
    if (match.userId !== userId) throw new ForbiddenException('This is not your match');

    const cached = await this.prisma.coachReport.findUnique({
      where: { matchRowId_userId_depth: { matchRowId, userId, depth } },
    });
    if (cached) return cached;

    const parseResult = await this.ensureParsed(match.id, match.matchId);
    if (parseResult.status === 'processing') {
      return { status: 'processing' as const, message: 'Матч ещё разбирается — попробуйте через минуту.' };
    }

    const fullMatch = await this.openDota.getMatch(Number(match.matchId));
    const facts = extractMatchFacts(fullMatch, match.playerSlot, parseResult.patchLabel);

    const [names, draft] = await Promise.all([this.resolveNames(facts), this.buildDraftContext(facts)]);

    const { system, user } = buildCoachPrompt(facts, names, draft, depth);
    const reportBody = await this.callClaude(system, user);

    return this.prisma.coachReport.create({
      data: { matchRowId, userId, depth, reportJson: { facts, narrative: reportBody } as any },
    });
  }

  /**
   * Requests a parse if the match hasn't been parsed yet, then polls a
   * bounded number of times. Genuinely fails (not "processing forever")
   * for old or private-lobby matches whose replay no longer exists.
   */
  private async ensureParsed(
    matchRowId: string,
    matchIdBigInt: bigint,
  ): Promise<{ status: 'ready'; patchLabel: string | null } | { status: 'processing' }> {
    const existing = await this.prisma.matchDetail.findUnique({ where: { matchRowId } });
    if (existing?.isParsed) return { status: 'ready', patchLabel: existing.patch };

    const matchId = Number(matchIdBigInt);
    await this.openDota.requestParse(matchId).catch((e) => {
      this.logger.warn(`Parse request failed for match ${matchId}: ${e.message}`);
    });

    for (let attempt = 0; attempt < PARSE_POLL_ATTEMPTS; attempt++) {
      await new Promise((r) => setTimeout(r, PARSE_POLL_DELAY_MS));
      const full = await this.openDota.getMatch(matchId);
      const isParsed = full.players.some((p) => p.purchase_log != null) || (full as any).teamfights != null;
      if (isParsed) {
        const patchLabel = full.patch != null ? String(full.patch) : null;
        await this.prisma.matchDetail.upsert({
          where: { matchRowId },
          create: {
            matchRowId,
            heroDamage: 0, towerDamage: 0, heroHealing: 0, lastHits: 0, denies: 0, goldT: [], xpT: [], insights: [],
            isParsed: true,
            patch: patchLabel,
            parsedAt: new Date(),
          },
          update: { isParsed: true, patch: patchLabel, parsedAt: new Date() },
        });
        return { status: 'ready', patchLabel };
      }
    }
    return { status: 'processing' };
  }

  private async resolveNames(facts: {
    yourTeamHeroIds: number[];
    enemyTeamHeroIds: number[];
    itemPurchases: { itemKey: string }[];
  }): Promise<ResolvedNames> {
    const heroIds = [...facts.yourTeamHeroIds, ...facts.enemyTeamHeroIds];
    const itemKeys = [...new Set(facts.itemPurchases.map((p) => p.itemKey))];

    const [heroes, items] = await Promise.all([
      this.prisma.hero.findMany({ where: { id: { in: heroIds } } }),
      this.prisma.item.findMany({ where: { name: { in: itemKeys } } }),
    ]);

    return {
      heroNames: Object.fromEntries(heroes.map((h) => [h.id, h.localizedName])),
      itemNames: Object.fromEntries(items.map((i) => [i.name, i.dname])),
    };
  }

  /**
   * Reuses Hero.countersJson — the same real, OpenDota-matchup-derived
   * data Draft Trainer's rating already computes from. No new data
   * source, no invented "this hero is scary" judgment without a real
   * winrate behind it.
   */
  private async buildDraftContext(facts: { yourHeroId: number; enemyTeamHeroIds: number[] }): Promise<DraftContext> {
    const yourHero = await this.prisma.hero.findUnique({ where: { id: facts.yourHeroId } });
    const enemyHeroes = await this.prisma.hero.findMany({ where: { id: { in: facts.enemyTeamHeroIds } } });

    const yourHeroCounters = ((yourHero?.countersJson as any)?.weakAgainst ?? [])
      .filter((c: any) => facts.enemyTeamHeroIds.includes(c.heroId))
      .map((c: any) => ({ heroId: c.heroId, winrateAgainstYou: c.winrate }));

    const enemyWeaknesses: { heroId: number; yourWinrateAgainst: number }[] = [];
    for (const enemy of enemyHeroes) {
      const goodAgainst = (enemy.countersJson as any)?.goodAgainst ?? [];
      const match = goodAgainst.find((c: any) => c.heroId === facts.yourHeroId);
      if (match) enemyWeaknesses.push({ heroId: enemy.id, yourWinrateAgainst: 1 - match.winrate });
    }

    return { yourHeroCounters, enemyWeaknesses };
  }

  /**
   * NOT executable/tested in this sandbox — no network access to
   * actually call the Anthropic API here. Reviewed, not run, same
   * honesty flag as the BullMQ/Docker/Jamendo integrations elsewhere
   * in this project. Verify the exact current model string against
   * https://docs.claude.com before relying on this — model slugs
   * change, and this file shouldn't be the source of truth for that.
   */
  private async callClaude(system: string, user: string): Promise<string> {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      throw new BadRequestException('ANTHROPIC_API_KEY is not set — AI Coach cannot generate a report without it. See FIRST_LAUNCH.md.');
    }
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL ?? 'claude-sonnet-4-6', // confirm current slug in Anthropic's docs — not hardcoded confidently
        max_tokens: 4000,
        system,
        messages: [{ role: 'user', content: user }],
      }),
    });
    if (!res.ok) {
      throw new Error(`Anthropic API call failed: ${res.status} ${await res.text()}`);
    }
    const data = await res.json();
    return data.content?.map((block: any) => block.text ?? '').join('\n') ?? '';
  }
}
