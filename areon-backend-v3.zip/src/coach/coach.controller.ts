import { Controller, Get, Param, Query, Req, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CoachService } from './coach.service';
import { CoachDepth } from './coach-prompt-builder';

@Controller('matches')
@UseGuards(JwtAuthGuard)
export class CoachController {
  constructor(private readonly coachService: CoachService) {}

  // GET, not POST, even though this can trigger real work (a parse
  // request + an LLM call) — deliberately idempotent from the caller's
  // side: calling it again just returns the same cached CoachReport
  // once generated, or re-polls parse status if still processing.
  // A real "start analysis" action button on the frontend, not an
  // automatic background job for every match.
  //
  // 5 requests per 10 minutes per IP — this calls a real, billed
  // Anthropic API request once a match is parsed; the global 60/min
  // default would let someone run up real API costs very quickly
  // otherwise. Found in the security audit's CRITICAL #2.
  @Throttle({ default: { limit: 5, ttl: 600_000 } })
  @Get(':id/coach-analysis')
  getCoachAnalysis(@Req() req: any, @Param('id') matchRowId: string, @Query('depth') depth?: string) {
    const validDepth: CoachDepth = depth === 'quick' || depth === 'coach' ? depth : 'full';
    return this.coachService.generateReport(req.user.sub, matchRowId, validDepth);
  }
}
