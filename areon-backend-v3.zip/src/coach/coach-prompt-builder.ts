import { MatchFacts } from './coach-data-extractor';

export type CoachDepth = 'quick' | 'full' | 'coach';

export interface ResolvedNames {
  heroNames: Record<number, string>;
  itemNames: Record<string, string>; // keyed by internal item name (purchase_log's `key`)
}

export interface DraftContext {
  // From our existing Hero.countersJson — the same real, OpenDota-matchup-
  // derived data Draft Trainer's rating already uses. No new data
  // source needed for "main threats."
  yourHeroCounters: { heroId: number; winrateAgainstYou: number }[];
  enemyWeaknesses: { heroId: number; yourWinrateAgainst: number }[];
}

/**
 * The system prompt is where requirement 26's discipline actually gets
 * enforced — not by re-validating the model's output afterward, but by
 * being explicit up front about what it's allowed to do with the data
 * it's given.
 */
const SYSTEM_PROMPT = `Ты — AI Coach в Areon, платформе для Dota 2. Тебе дают СТРУКТУРИРОВАННЫЕ, уже проверенные факты о конкретном матче — не сырые данные игры, а предобработанный набор фактов.

СТРОГИЕ ПРАВИЛА:
1. Никогда не выдумывай данные, которых нет в предоставленных фактах — ни числа, ни события, ни тайминги.
2. Каждое своё заключение помечай явно:
   - "Confirmed" — если это прямо следует из данных.
   - "Likely" — если это твоя интерпретация/рекомендация на основе данных, не факт сам по себе.
3. Если для ответа на какой-то аспект не хватает данных — прямо напиши "Data unavailable", не пытайся заполнить пробел правдоподобным предположением.
4. Никогда не утверждай, что есть единственно верное решение — предлагай Recommended и Alternative с объяснением компромисса, когда уместно.
5. Учитывай, что ability_upgrades_arr и kills_log иногда содержат неточности в исходных данных OpenDota (задокументированный факт) — если вывод строится на этих полях и выглядит сомнительно, отметь это.
6. Пиши на русском, по делу, без "Great game!" и общих фраз без опоры на конкретные факты этого матча.`;

export function buildCoachPrompt(
  facts: MatchFacts,
  names: ResolvedNames,
  draft: DraftContext,
  depth: CoachDepth,
): { system: string; user: string } {
  const depthInstruction: Record<CoachDepth, string> = {
    quick: 'Дай QUICK ANALYSIS: 3-5 предложений по игре в целом, без разбора по драфтам/дракам, плюс "ONE THING TO FIX NEXT GAME".',
    full: 'Дай FULL ANALYSIS: разбор состава, предметов, способностей, фаз игры, почему победа/поражение, "YOUR 3 BIGGEST LESSONS".',
    coach: 'Дай COACH MODE: максимально подробный разбор, включая каждую значимую командную драку отдельно (TARGET PRIORITY по каждой), альтернативные варианты сборки и прокачки с объяснением компромисса, "IF I WERE YOUR COACH".',
  };

  const factsPayload = {
    matchId: facts.matchId,
    durationSec: facts.durationSec,
    result: facts.won ? 'WIN' : 'LOSS',
    patch: facts.patch ?? 'Data unavailable',
    yourHero: names.heroNames[facts.yourHeroId] ?? `hero_${facts.yourHeroId}`,
    yourTeam: facts.yourTeamHeroIds.map((id) => names.heroNames[id] ?? `hero_${id}`),
    enemyTeam: facts.enemyTeamHeroIds.map((id) => names.heroNames[id] ?? `hero_${id}`),
    finalStats: facts.finalStats,
    itemPurchases: facts.itemPurchases.map((p) => ({ timeSec: p.timeSec, item: names.itemNames[p.itemKey] ?? p.itemKey })),
    abilityUpgrades: facts.abilityUpgrades,
    teamfights: facts.teamfights === null ? 'Data unavailable — match was not parsed deeply enough for teamfight-level detail' : facts.teamfights,
    phases: facts.phases,
    draftContext: {
      mainThreatCandidates: draft.yourHeroCounters,
      favorableMatchups: draft.enemyWeaknesses,
    },
  };

  return {
    system: SYSTEM_PROMPT,
    user: `${depthInstruction[depth]}\n\nФакты матча (JSON, уже проверенные, ничего не выдумывай сверх этого):\n${JSON.stringify(factsPayload, null, 2)}`,
  };
}
