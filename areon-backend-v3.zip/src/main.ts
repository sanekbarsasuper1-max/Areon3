import { NestFactory } from '@nestjs/core';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.use(cookieParser());
  app.use(
    helmet({
      // This is a JSON API, not an HTML-serving app — no page here
      // ever renders untrusted content that a CSP would be defending
      // against. The frontend (a separate service) has its own CSP,
      // tailored to what it actually loads — see its nginx.conf.
      // Every other helmet default (X-Content-Type-Options,
      // X-Frame-Options, Strict-Transport-Security, etc.) still
      // applies and is genuinely useful for an API too.
      contentSecurityPolicy: false,
    }),
  );
  app.enableCors({ origin: process.env.FRONTEND_URL, credentials: true });
  await app.listen(3000);
}
bootstrap();
