import { DraftTrainerService } from './draft-trainer.service';
import { PrismaService } from '../prisma.service';
import { OpenDotaService } from '../opendota/opendota.service';
import { DraftGateway } from './draft.gateway';

/**
 * A minimal in-memory stand-in for Prisma, covering only the calls
 * DraftTrainerService actually makes (draftSession/hero/user
 * create/update/findUnique/findMany). This is deliberately not a full
 * Prisma mock — it exists so these tests can run without a live
 * Postgres in CI, not to validate the schema or migrations.
 *
 * IMPORTANT: Prisma applies schema-level @default() values (e.g.
 * DraftSession.reserveFirstSec/reserveSecondSec default to 130) that
 * this stub has to replicate manually in create() — the real service
 * never sets those fields explicitly, relying on the database to fill
 * them in. Forgetting this here silently produces `undefined`/`NaN`
 * bugs in the *test*, not in the real service — worth remembering if
 * this stub is extended for other models later.
 */
type Where = Record<string, any>;

function matchesField(value: any, condition: any): boolean {
  if (condition && typeof condition === 'object' && !Array.isArray(condition)) {
    if ('not' in condition) return value !== condition.not;
    if ('in' in condition) return condition.in.includes(value);
    if ('notIn' in condition) return !condition.notIn.includes(value);
    if ('gte' in condition) return value >= condition.gte;
  }
  return value === condition;
}

function matchesWhere(record: any, where: Where): boolean {
  for (const key of Object.keys(where)) {
    if (key === 'OR') {
      if (!where.OR.some((sub: Where) => matchesWhere(record, sub))) return false;
      continue;
    }
    if (!matchesField(record[key], where[key])) return false;
  }
  return true;
}

class InMemoryTable<T extends { id: string | number }> {
  rows = new Map<string | number, T>();
  private nextId = 1;
  constructor(private defaults: Partial<T> = {}) {}

  async create({ data }: { data: Partial<T> }): Promise<T> {
    const id = (data as any).id ?? `test-${this.nextId++}`;
    const row = { ...this.defaults, ...data, id } as T;
    this.rows.set(id, row);
    return row;
  }

  async findUnique({ where }: { where: Where }): Promise<T | null> {
    if (where.id !== undefined) return this.rows.get(where.id) ?? null;
    return [...this.rows.values()].find((r) => matchesWhere(r, where)) ?? null;
  }

  async findMany({ where, distinct }: { where?: Where; distinct?: string[] } = {}): Promise<T[]> {
    let results = [...this.rows.values()];
    if (where) results = results.filter((r) => matchesWhere(r, where));
    if (distinct) {
      const seen = new Set<any>();
      results = results.filter((r) => {
        const key = distinct.map((f) => (r as any)[f]).join('|');
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
    }
    return results;
  }

  async update({ where, data }: { where: Where; data: Partial<T> }): Promise<T> {
    const existing = await this.findUnique({ where });
    if (!existing) throw new Error(`No row matching ${JSON.stringify(where)}`);
    const updated = { ...existing, ...data } as T;
    this.rows.set((existing as any).id, updated);
    return updated;
  }
}

function createInMemoryPrisma() {
  return {
    // Mirrors schema.prisma's @default(130) — see the class comment above.
    draftSession: new InMemoryTable<any>({ reserveFirstSec: 130, reserveSecondSec: 130 }),
    hero: new InMemoryTable<any>(),
    user: new InMemoryTable<any>(),
  };
}

describe('DraftTrainerService (real service, in-memory Prisma double)', () => {
  let prisma: ReturnType<typeof createInMemoryPrisma>;
  let svc: DraftTrainerService;
  let openDota: jest.Mocked<Pick<OpenDotaService, 'getMatch' | 'getProMatches'>>;
  let gateway: { emitUpdate: jest.Mock };

  async function lowestAvailable(session: any): Promise<number> {
    const used = new Set(session.actions.filter((a: any) => a.heroId != null).map((a: any) => a.heroId));
    for (let id = 1; id <= 24; id++) if (!used.has(id)) return id;
    throw new Error('ran out of test heroes');
  }

  beforeEach(async () => {
    // Real Math.random is restored in afterEach — forcing it to 0 makes
    // the bot's "pick among tied candidates" and "random ban" behavior
    // deterministic (always the lowest available hero id), which is
    // what makes the counter-pick assertion below exact rather than
    // probabilistic.
    jest.spyOn(Math, 'random').mockReturnValue(0);

    prisma = createInMemoryPrisma();
    openDota = { getMatch: jest.fn(), getProMatches: jest.fn().mockResolvedValue([]) };
    gateway = { emitUpdate: jest.fn() };
    svc = new DraftTrainerService(prisma as any, openDota as any, gateway as any);

    for (let id = 1; id <= 24; id++) {
      await prisma.hero.create({
        data: { id, localizedName: `Hero${id}`, captainsModeAvailable: true, countersJson: null },
      });
    }
    // The only hero in the pool that counters Hero 8 — used below to
    // verify the bot's pick logic isn't just picking randomly.
    await prisma.hero.update({
      where: { id: 24 },
      data: { countersJson: { goodAgainst: [{ heroId: 8, winrate: 0.65 }] } },
    });
    await prisma.user.create({ data: { id: 'u1' } });
    await prisma.user.create({ data: { id: 'u2' } });
    await prisma.user.create({ data: { id: 'admin1', isAdmin: true } });
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('plays a full solo draft to completion in the confirmed 7.40 ban order', async () => {
    let session = await svc.createFreeDraft('u1');
    while (session.status === 'in_progress') {
      session = await svc.performAction(session.id, 'u1', await lowestAvailable(session));
    }

    expect(session.status).toBe('completed');
    expect(session.actions).toHaveLength(24);

    const banPhase1 = session.actions.slice(0, 7).map((a: any) => a.side[0]).join('');
    expect(banPhase1).toBe('FFSSFSS'); // official 7.40 patch note, quoted in draft-trainer.service.ts

    const banPhase3 = session.actions.slice(18, 22).map((a: any) => a.side[0]).join('');
    expect(banPhase3).toBe('FSFS'); // official 7.40 patch note
  });

  describe('timeout handling', () => {
    it('rejects a timeout call before time has actually run out', async () => {
      const session = await svc.createFreeDraft('u2');
      await expect(svc.performTimeout(session.id, 'u2')).rejects.toThrow();
    });

    it('skips the ban and drains exactly the available reserve on a forced ban timeout', async () => {
      const session = await svc.createFreeDraft('u2');
      const stale = new Date(Date.now() - 200_000); // main timer (15s) + reserve (130s) both exhausted
      await prisma.draftSession.update({ where: { id: session.id }, data: { currentStepStartedAt: stale } });

      const updated = await svc.performTimeout(session.id, 'u2');
      const firstAction = updated.actions[0];

      expect(firstAction.heroId).toBeNull();
      expect(firstAction.timedOut).toBe(true);
      expect(updated.reserveFirstSec).toBe(0);
      expect(firstAction.reserveSpent).toBe(130);
    });

    it('auto-assigns a real, unused hero on a forced pick timeout', async () => {
      let session = await svc.createFreeDraft('u2');
      while (session.sequence[session.actions.length].action !== 'pick') {
        session = await svc.performAction(session.id, 'u2', await lowestAvailable(session));
      }
      const stale = new Date(Date.now() - 200_000);
      await prisma.draftSession.update({ where: { id: session.id }, data: { currentStepStartedAt: stale } });

      const updated = await svc.performTimeout(session.id, 'u2');
      const pickAction = updated.actions[updated.actions.length - 1];

      expect(pickAction.heroId).not.toBeNull();
      expect(pickAction.timedOut).toBe(true);
    });
  });

  it('admin undo refunds exactly the reserve the undone action spent', async () => {
    let session = await svc.createFreeDraft('u1');
    const stale = new Date(Date.now() - 200_000);
    await prisma.draftSession.update({ where: { id: session.id }, data: { currentStepStartedAt: stale } });
    session = await svc.performTimeout(session.id, 'u1'); // burns all 130 reserve

    expect(session.reserveFirstSec).toBe(0);
    const lengthBefore = session.actions.length;

    session = await svc.adminUndo(session.id);

    expect(session.actions).toHaveLength(lengthBefore - 1);
    expect(session.status).toBe('in_progress');
    expect(session.reserveFirstSec).toBe(130);
  });

  it('resolves the AI bot synchronously and picks the hero that counters the human\'s pick', async () => {
    let session = await svc.createAiDraft('u1', { botSide: 'SECOND_PICK' });
    expect(session.actions).toHaveLength(0); // human (FIRST_PICK) goes first

    session = await svc.performAction(session.id, 'u1', await lowestAvailable(session)); // step 0
    session = await svc.performAction(session.id, 'u1', await lowestAvailable(session)); // step 1 -> bot resolves 2,3
    expect(session.actions).toHaveLength(4);
    expect(session.actions[2].side).toBe('SECOND_PICK');
    expect(session.actions[3].side).toBe('SECOND_PICK');

    session = await svc.performAction(session.id, 'u1', await lowestAvailable(session)); // step 4 -> bot resolves 5,6
    expect(session.actions).toHaveLength(7); // ban phase 1 fully resolved

    const humanPick = await lowestAvailable(session);
    expect(humanPick).toBe(8); // 1-7 are banned in this deterministic run
    session = await svc.performAction(session.id, 'u1', humanPick);

    const botPick = session.actions[8];
    expect(botPick.side).toBe('SECOND_PICK');
    expect(botPick.action).toBe('pick');
    expect(botPick.heroId).toBe(24); // the only hero in the pool that counters hero 8
  });

  it('only lets the correct side act in a two-player friend draft', async () => {
    let session = await svc.inviteFriend('u1', 'u2');
    expect(session.status).toBe('waiting_for_opponent');

    session = await svc.joinFriendDraft(session.id, 'u2');
    expect(session.status).toBe('in_progress');

    const firstSide = session.sequence[0].side;
    const firstUser = firstSide === 'FIRST_PICK' ? 'u1' : 'u2';
    const wrongUser = firstUser === 'u1' ? 'u2' : 'u1';

    await expect(svc.performAction(session.id, wrongUser, await lowestAvailable(session))).rejects.toThrow();

    const updated = await svc.performAction(session.id, firstUser, await lowestAvailable(session));
    expect(updated.actions).toHaveLength(1);
  });

  describe('viewing privacy', () => {
    it('blocks a random user but allows an admin to view an in-progress draft', async () => {
      const session = await svc.createFreeDraft('u1');

      await expect(svc.getSessionForViewer(session.id, 'u2')).rejects.toThrow();
      await expect(svc.getSessionForViewer(session.id, 'admin1')).resolves.toBeTruthy();
    });

    it('allows any logged-in user to view a completed draft (Share Draft)', async () => {
      let session = await svc.createFreeDraft('u1');
      while (session.status === 'in_progress') {
        session = await svc.performAction(session.id, 'u1', await lowestAvailable(session));
      }
      await expect(svc.getSessionForViewer(session.id, 'u2')).resolves.toBeTruthy();
    });
  });
});
