import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { OpenDotaService } from '../opendota/opendota.service';
import { DraftGateway } from './draft.gateway';

export type DraftSide = 'FIRST_PICK' | 'SECOND_PICK';
export type DraftAction = 'ban' | 'pick';

export interface DraftStep {
  step: number; // 1-indexed, matches the product doc's "STEP 13 / 24"
  side: DraftSide;
  action: DraftAction;
  timeLimitSec: number;
}

export interface DraftEvent extends DraftStep {
  heroId: number | null; // null only for a timed-out ban (skipped, nobody banned)
  timedOut: boolean;
  // How much of the acting side's reserve pool this specific action
  // consumed (0 for anything that finished within the main per-action
  // allowance). Stored per-action specifically so admin undo can refund
  // exactly this much, rather than the earlier version of this file
  // which only kept a running total and couldn't roll one action back
  // precisely.
  reserveSpent: number;
}

/**
 * ============================================================================
 * CAPTAIN'S MODE DRAFT RULES - config, not hardcoded UI branches (per the
 * doc's requirement 5). Sides are logical (FIRST_PICK / SECOND_PICK), never
 * Radiant/Dire directly - DraftSession.radiantSide is the only mapping
 * applied at render/report time, never baked in here.
 *
 * CONFIRMED against official Valve patch notes (dota2.com/patches/7.40,
 * mirrored by Liquipedia's Version 7.40 page):
 *   "Changed order of the first and the third ban phases.
 *    First Ban Phase: OLD First-Second-Second-First-Second-Second-First
 *                      NEW First-First-Second-Second-First-Second-Second
 *    Third Ban Phase: OLD First-Second-Second-First
 *                      NEW First-Second-First-Second"
 * Patch 7.40 (Dec 2025) changed ONLY the intra-phase order of ban phases
 * 1 and 3 — it did not change the ban COUNTS (still 7 and 4), and nothing
 * in the official notes touches the pick phases. No later patch (7.40b/c,
 * 7.41 and its point releases) has been found changing this further as of
 * this writing — 7.40c's only CM-relevant change was adding a new hero
 * (Largo) to the CM pool, not a draft-order change.
 *
 * Also confirmed (Liquipedia's Game Modes page): ban-phase TOTALS 7/3/4
 * split 3-2-2 (first pick) vs 4-1-2 (second pick), pick-phase totals 2/6/2
 * split 1-3-1 for both sides, 24 actions total, 15s per ban in the first
 * ban phase, 30s for every other action, 130s total reserve time per side,
 * and timeout behavior (ban timeout = skipped, pick timeout = random hero).
 *
 * STILL NOT independently confirmed: the exact intra-phase order of ban
 * phase 2 and all three pick phases — no official patch note or wiki table
 * was found spelling those out turn-by-turn, only the totals above. Those
 * remain a reasonable, symmetric reconstruction, clearly marked as such
 * below — not verified against an official source the way phases 1 and 3
 * now are.
 * ============================================================================
 */
const BAN_PHASE_1_TIME = 15;
const OTHER_TIME = 30;

function phase(
  steps: { side: DraftSide; action: DraftAction }[],
  timeLimitSec: number,
): { side: DraftSide; action: DraftAction; timeLimitSec: number }[] {
  return steps.map((s) => ({ ...s, timeLimitSec }));
}

const F: DraftSide = 'FIRST_PICK';
const S: DraftSide = 'SECOND_PICK';
const ban = (side: DraftSide) => ({ side, action: 'ban' as DraftAction });
const pick = (side: DraftSide) => ({ side, action: 'pick' as DraftAction });

const RAW_SEQUENCE = [
  // Ban phase 1 - 7 total (F:3, S:4) - order per official 7.40 patch note.
  ...phase([ban(F), ban(F), ban(S), ban(S), ban(F), ban(S), ban(S)], BAN_PHASE_1_TIME),
  // Pick phase 1 - 1 each. NOT independently confirmed intra-order.
  ...phase([pick(F), pick(S)], OTHER_TIME),
  // Ban phase 2 - 3 total (F:2, S:1). NOT independently confirmed intra-order.
  ...phase([ban(S), ban(F), ban(F)], OTHER_TIME),
  // Pick phase 2 - 3 each. NOT independently confirmed intra-order.
  ...phase([pick(S), pick(F), pick(F), pick(S), pick(S), pick(F)], OTHER_TIME),
  // Ban phase 3 - 4 total (F:2, S:2) - order per official 7.40 patch note.
  ...phase([ban(F), ban(S), ban(F), ban(S)], OTHER_TIME),
  // Pick phase 3 - 1 each. NOT independently confirmed intra-order.
  ...phase([pick(S), pick(F)], OTHER_TIME),
];

export function buildCaptainsModeSequence(): DraftStep[] {
  return RAW_SEQUENCE.map((s, i) => ({ ...s, step: i + 1 }));
}

@Injectable()
export class DraftTrainerService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly openDota: OpenDotaService,
    private readonly draftGateway: DraftGateway,
  ) {}

  /**
   * `radiantSide` is a coin flip (or explicit choice) independent of turn
   * order — FIRST_PICK always acts first structurally, but that says
   * nothing about who's Radiant. This one field is what makes "Radiant
   * First Pick", "Radiant Second Pick", "Dire First Pick" and "Dire
   * Second Pick" all representable, per the product requirement.
   *
   * Solo only — 'self' mode, the creator plays both sides. Playing
   * against a specific person goes through inviteFriend(); playing
   * against whoever's next in the queue goes through searchMatch().
   */
  async createFreeDraft(userId: string, options?: { radiantSide?: DraftSide }) {
    const radiantSide = options?.radiantSide ?? (Math.random() < 0.5 ? 'FIRST_PICK' : 'SECOND_PICK');

    return this.prisma.draftSession.create({
      data: {
        createdByUserId: userId,
        mode: 'free',
        opponentType: 'self',
        sequence: buildCaptainsModeSequence() as any,
        actions: [] as any,
        status: 'in_progress',
        radiantSide,
        currentStepStartedAt: new Date(),
        rulesVersion: 'cm-7.40-ban-phase-1-3-reorder',
      },
    });
  }

  /**
   * Starts a session against the heuristic bot. `botSide` defaults to a
   * coin flip if not given. The bot resolves its own turns synchronously
   * inside this call and inside performAction/performTimeout — the
   * session returned to the frontend is always already sitting at the
   * human's next turn (or completed), never mid-bot-turn, so there's
   * nothing for the client to poll for.
   *
   * See resolveBotTurns() for exactly what the bot does — it's a fixed
   * heuristic (random bans, counter-pick-scored picks using already-
   * synced Hero.countersJson data), not a trained model. Calling it
   * "AI" in the UI is the product's chosen label, not a claim about the
   * underlying technique.
   */
  async createAiDraft(userId: string, options?: { radiantSide?: DraftSide; botSide?: DraftSide }) {
    const radiantSide = options?.radiantSide ?? (Math.random() < 0.5 ? 'FIRST_PICK' : 'SECOND_PICK');
    const aiSide = options?.botSide ?? (Math.random() < 0.5 ? 'FIRST_PICK' : 'SECOND_PICK');

    const session = await this.prisma.draftSession.create({
      data: {
        createdByUserId: userId,
        mode: 'free',
        opponentType: 'ai',
        aiSide,
        sequence: buildCaptainsModeSequence() as any,
        actions: [] as any,
        status: 'in_progress',
        radiantSide,
        currentStepStartedAt: new Date(),
        rulesVersion: 'cm-7.40-ban-phase-1-3-reorder',
      },
    });

    return this.resolveBotTurns(session.id);
  }

  /**
   * Sends an on-site invite to a specific user — no link to share, the
   * invited person just sees it appear next time they check
   * `listPendingInvites`. Deliberately only offered against users the
   * `/players/online` picker already surfaced (i.e. active in the last
   * minute) — inviting someone who isn't even online would just create
   * a lobby nobody ever sees.
   */
  async inviteFriend(userId: string, invitedUserId: string, radiantSide?: DraftSide) {
    if (invitedUserId === userId) {
      throw new BadRequestException("You can't invite yourself");
    }
    const invitedUser = await this.prisma.user.findUnique({ where: { id: invitedUserId } });
    if (!invitedUser) throw new NotFoundException('That user does not exist');

    const resolvedRadiantSide = radiantSide ?? (Math.random() < 0.5 ? 'FIRST_PICK' : 'SECOND_PICK');

    return this.prisma.draftSession.create({
      data: {
        createdByUserId: userId,
        mode: 'free',
        opponentType: 'friend',
        invitedUserId,
        sequence: buildCaptainsModeSequence() as any,
        actions: [] as any,
        status: 'waiting_for_opponent',
        radiantSide: resolvedRadiantSide,
        currentStepStartedAt: new Date(),
        rulesVersion: 'cm-7.40-ban-phase-1-3-reorder',
      },
    });
  }

  async listPendingInvites(userId: string) {
    return this.prisma.draftSession.findMany({
      where: { invitedUserId: userId, status: 'waiting_for_opponent' },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Accepts a pending invite (opponentType 'friend') or claims an open
   * matchmaking seat (opponentType 'matchmaking', called internally by
   * searchMatch — see there for why matchmaking mostly doesn't reach
   * this method directly). Starts the clock fresh at the moment of
   * joining, not at lobby/invite creation.
   */
  async joinFriendDraft(sessionId: string, userId: string) {
    const session = await this.getSession(sessionId);

    if (session.opponentType !== 'friend' && session.opponentType !== 'matchmaking') {
      throw new BadRequestException('This session cannot be joined');
    }
    if (session.status !== 'waiting_for_opponent') {
      throw new BadRequestException('This lobby is not waiting for an opponent');
    }
    if (session.createdByUserId === userId) {
      throw new BadRequestException("You can't join your own lobby as the opponent");
    }
    if (session.opponentType === 'friend' && session.invitedUserId && session.invitedUserId !== userId) {
      throw new ForbiddenException('This invite was not addressed to you');
    }
    if (session.participantSecondUserId) {
      throw new BadRequestException('This lobby already has an opponent');
    }

    const updated = await this.prisma.draftSession.update({
      where: { id: sessionId },
      data: {
        participantSecondUserId: userId,
        status: 'in_progress',
        currentStepStartedAt: new Date(),
      },
    });

    // The creator has been sitting in the waiting room possibly for a
    // while — this is what tells their screen an opponent just showed
    // up, without waiting on a poll interval.
    this.draftGateway.emitUpdate(sessionId, updated);
    return updated;
  }

  /**
   * Matchmaking queue: if someone else is already waiting, join them
   * immediately; otherwise become the one waiting. The DB row itself
   * IS the queue — no separate in-memory or ticket table.
   *
   * KNOWN SIMPLIFICATION: the "find an existing waiter, else create
   * one" check isn't wrapped in a strict row lock, so two people
   * searching in the exact same instant could theoretically both end
   * up creating a fresh waiting session instead of matching each
   * other. They'd each just end up waiting for the next searcher
   * (self-correcting on the following poll), not stuck — a real
   * production queue would want proper locking to close even that
   * narrow window, but it's a low-stakes race for a training tool.
   */
  async searchMatch(userId: string) {
    const existingSearch = await this.prisma.draftSession.findFirst({
      where: { createdByUserId: userId, opponentType: 'matchmaking', status: 'waiting_for_opponent' },
    });
    if (existingSearch) return existingSearch;

    const waitingOpponent = await this.prisma.draftSession.findFirst({
      where: {
        opponentType: 'matchmaking',
        status: 'waiting_for_opponent',
        createdByUserId: { not: userId },
      },
      orderBy: { createdAt: 'asc' },
    });

    if (waitingOpponent) {
      return this.joinFriendDraft(waitingOpponent.id, userId);
    }

    const radiantSide: DraftSide = Math.random() < 0.5 ? 'FIRST_PICK' : 'SECOND_PICK';
    return this.prisma.draftSession.create({
      data: {
        createdByUserId: userId,
        mode: 'free',
        opponentType: 'matchmaking',
        sequence: buildCaptainsModeSequence() as any,
        actions: [] as any,
        status: 'waiting_for_opponent',
        radiantSide,
        currentStepStartedAt: new Date(),
        rulesVersion: 'cm-7.40-ban-phase-1-3-reorder',
      },
    });
  }

  /** Leaves the matchmaking queue / withdraws a not-yet-accepted invite. */
  async cancelWaiting(sessionId: string, userId: string) {
    const session = await this.getSession(sessionId);
    if (session.createdByUserId !== userId) {
      throw new ForbiddenException('Only the creator can cancel this');
    }
    if (session.status !== 'waiting_for_opponent') {
      throw new BadRequestException('This session is not waiting — nothing to cancel');
    }
    return this.prisma.draftSession.update({
      where: { id: sessionId },
      data: { status: 'cancelled' },
    });
  }

  async listMine(userId: string) {
    return this.prisma.draftSession.findMany({
      where: { OR: [{ createdByUserId: userId }, { participantSecondUserId: userId }] },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getSession(id: string) {
    const session = await this.prisma.draftSession.findUnique({ where: { id } });
    if (!session) throw new NotFoundException('Draft session not found');
    return session;
  }

  /**
   * The public-facing read used by the controller's GET route — unlike
   * the bare getSession() above (used internally by methods that do
   * their own authorization afterward, e.g. checking who's allowed to
   * act), this enforces who's allowed to even *view* the session.
   *
   * Completed drafts are viewable by any logged-in Areon user — that's
   * the whole point of Share Draft, a finished draft's outcome is
   * already locked in, nothing to protect. IN-PROGRESS drafts are
   * restricted to their two real participants (or an admin spectating)
   * — the actual gap worth closing is a stranger peeking at a *live*
   * friend/matchmaking draft, which could matter competitively; a
   * finished one can't be un-fairly influenced by being looked at.
   */
  async getSessionForViewer(id: string, userId: string) {
    const session = await this.getSession(id);
    if (session.status === 'completed') return session;

    const isParticipant = session.createdByUserId === userId || session.participantSecondUserId === userId;
    if (isParticipant) return session;

    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (user?.isAdmin) return session;

    throw new ForbiddenException(
      'This draft is still in progress — only its participants or an admin can view it',
    );
  }

  /**
   * Every 'free'-mode draft currently in progress or waiting — for the
   * admin panel's "watch any game" list. Not scoped to the requesting
   * admin's own games at all, on purpose.
   */
  async adminListActiveSessions() {
    return this.prisma.draftSession.findMany({
      where: { mode: 'free', status: { in: ['waiting_for_opponent', 'in_progress'] } },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Admin-only, and only this — there is no player-facing undo. Pops
   * the last action off the session and reopens it for that step to be
   * replayed, refunding exactly the reserve time that action consumed
   * (tracked per-action via DraftEvent.reserveSpent) rather than
   * leaving it permanently spent.
   */
  async adminUndo(sessionId: string) {
    const session = await this.getSession(sessionId);
    const actions = session.actions as unknown as DraftEvent[];
    if (actions.length === 0) {
      throw new BadRequestException('Nothing to undo — no actions taken yet');
    }

    const undoneAction = actions[actions.length - 1];
    const newActions = actions.slice(0, -1);
    const isFirst = undoneAction.side === 'FIRST_PICK';
    const refund = undoneAction.reserveSpent ?? 0;

    const updated = await this.prisma.draftSession.update({
      where: { id: sessionId },
      data: {
        actions: newActions as any,
        status: 'in_progress',
        currentStepStartedAt: new Date(),
        ...(isFirst
          ? { reserveFirstSec: session.reserveFirstSec + refund }
          : { reserveSecondSec: session.reserveSecondSec + refund }),
      },
    });

    this.draftGateway.emitUpdate(sessionId, updated);
    return updated;
  }

  async performAction(sessionId: string, userId: string, heroId: number) {
    const session = await this.getSession(sessionId);
    const sequence = session.sequence as unknown as DraftStep[];
    const actions = session.actions as unknown as DraftEvent[];
    const nextStep = sequence[actions.length];
    this.assertMutable(session, userId, nextStep, { requireTurnOwner: true });

    const hero = await this.prisma.hero.findUnique({ where: { id: heroId } });
    if (!hero) throw new BadRequestException('Unknown hero');
    if (!hero.captainsModeAvailable) {
      throw new BadRequestException(`${hero.localizedName} is not available in Captain's Mode`);
    }

    const usedHeroIds = new Set(actions.filter((a) => a.heroId != null).map((a) => a.heroId));
    if (usedHeroIds.has(heroId)) {
      throw new BadRequestException('That hero is already picked or banned');
    }

    // A manual action can still land after the main per-action timer ran
    // out, as long as the side hadn't fully burned through its reserve
    // yet — that overflow needs to come out of the reserve pool, same as
    // it would in the real client, or the next step would get a full
    // fresh allowance for free.
    const elapsedSec = (Date.now() - session.currentStepStartedAt.getTime()) / 1000;
    return this.appendAction(session, nextStep, { heroId, timedOut: false }, elapsedSec).then((s) =>
      this.resolveBotTurns(s.id),
    );
  }

  /**
   * Called by the client when its local countdown (main timer, then
   * reserve) hits zero. Re-checks elapsed time AND reserve server-side
   * against currentStepStartedAt rather than trusting the client
   * outright - a client clock can't force a timeout to finalize early.
   *
   * Per the confirmed mechanic: the main per-action timer does not carry
   * over; once it's spent, the side automatically starts drawing down
   * its 130s reserve pool instead. Only once BOTH are exhausted does the
   * forced outcome (skipped ban / random pick) actually happen — before
   * that, this just rejects and the client keeps counting down locally
   * using the reserve value already in the session.
   */
  async performTimeout(sessionId: string, userId: string) {
    const session = await this.getSession(sessionId);
    this.assertMutable(session, userId);

    const sequence = session.sequence as unknown as DraftStep[];
    const actions = session.actions as unknown as DraftEvent[];
    const nextStep = sequence[actions.length];

    const elapsedSec = (Date.now() - session.currentStepStartedAt.getTime()) / 1000;
    const overflowSec = elapsedSec - nextStep.timeLimitSec;
    const currentReserve = nextStep.side === 'FIRST_PICK' ? session.reserveFirstSec : session.reserveSecondSec;

    if (overflowSec < currentReserve) {
      throw new BadRequestException(
        'Main time is up but reserve time is not exhausted yet — the client should keep counting down using reserve, not call timeout',
      );
    }

    if (nextStep.action === 'ban') {
      // Per the confirmed rule: a ban timeout skips the ban entirely.
      return this.appendAction(session, nextStep, { heroId: null, timedOut: true }, elapsedSec).then((s) =>
        this.resolveBotTurns(s.id),
      );
    }

    // Pick timeout: auto-assign a random available, CM-eligible hero.
    const usedHeroIds = new Set(actions.filter((a) => a.heroId != null).map((a) => a.heroId));
    const candidates = await this.prisma.hero.findMany({
      where: { captainsModeAvailable: true, id: { notIn: [...usedHeroIds] as number[] } },
    });
    if (candidates.length === 0) {
      throw new BadRequestException('No available heroes left to auto-pick - hero database may be empty/unsynced');
    }
    const randomHero = candidates[Math.floor(Math.random() * candidates.length)];
    return this.appendAction(session, nextStep, { heroId: randomHero.id, timedOut: true }, elapsedSec).then((s) =>
      this.resolveBotTurns(s.id),
    );
  }

  /**
   * Runs the bot's turn(s) until it's the human's turn again, the
   * session completes, or the session isn't actually an AI game.
   * Bot actions are timestamped as instant (elapsedSec 0) — the bot
   * doesn't have a reaction-time concept, so no reserve gets deducted
   * for its moves.
   */
  private async resolveBotTurns(sessionId: string) {
    let session = await this.getSession(sessionId);
    if (session.opponentType !== 'ai') return session;

    while (session.status === 'in_progress') {
      const sequence = session.sequence as unknown as DraftStep[];
      const actions = session.actions as unknown as DraftEvent[];
      const nextStep = sequence[actions.length];
      if (!nextStep || nextStep.side !== session.aiSide) break;

      const heroId = await this.pickBotHero(session, nextStep);
      session = (await this.appendAction(session, nextStep, { heroId, timedOut: false }, 0)) as any;
    }

    return session;
  }

  /**
   * Fixed heuristic, not a trained model:
   *  - BAN: uniformly random among available Captain's-Mode-eligible
   *    heroes. No attempt to model "which heroes are strong" — that
   *    would need pick/win-rate data this scaffold doesn't store yet.
   *  - PICK: scores each available hero by how many of the human's
   *    already-picked heroes appear in that hero's `countersJson.goodAgainst`
   *    list (real per-matchup win-rate data from OpenDota, synced via
   *    HeroesService.syncMatchups — see the hero-database README notes).
   *    Highest score wins, ties broken randomly. If the human hasn't
   *    picked anything yet, or none of the candidates have synced
   *    matchup data, this degrades to a random pick — not a silent
   *    wrong answer, just an honest "no signal available yet".
   */
  private async pickBotHero(
    session: { actions: any; aiSide: string | null },
    step: DraftStep,
  ): Promise<number> {
    const actions = session.actions as unknown as DraftEvent[];
    const usedHeroIds = [...new Set(actions.filter((a) => a.heroId != null).map((a) => a.heroId!))];

    const candidates = await this.prisma.hero.findMany({
      where: { captainsModeAvailable: true, id: { notIn: usedHeroIds } },
    });
    if (candidates.length === 0) {
      throw new BadRequestException('No available heroes left for the bot — hero database may be empty/unsynced');
    }

    if (step.action === 'ban') {
      return candidates[Math.floor(Math.random() * candidates.length)].id;
    }

    const enemyPickedIds = new Set(
      actions.filter((a) => a.action === 'pick' && a.side !== session.aiSide && a.heroId != null).map((a) => a.heroId),
    );

    let best: { id: number; score: number }[] = [];
    let bestScore = -1;
    for (const c of candidates) {
      const counters = c.countersJson as unknown as { goodAgainst?: { heroId: number }[] } | null;
      const score = counters?.goodAgainst?.filter((g) => enemyPickedIds.has(g.heroId)).length ?? 0;
      if (score > bestScore) {
        bestScore = score;
        best = [{ id: c.id, score }];
      } else if (score === bestScore) {
        best.push({ id: c.id, score });
      }
    }

    return best[Math.floor(Math.random() * best.length)].id;
  }

  /**
   * Resolves who's allowed to act for a given logical side. 'self' mode
   * keeps the original behaviour (creator controls both sides). 'ai'
   * mode returns null for the bot's side — nobody human ever owns it.
   * 'friend'/'matchmaking' split control across the two real
   * participants.
   */
  private participantForSide(
    session: { opponentType: string; createdByUserId: string; participantSecondUserId: string | null; aiSide?: string | null },
    side: DraftSide,
  ): string | null {
    if (session.opponentType === 'ai') {
      return side === session.aiSide ? null : session.createdByUserId;
    }
    const isTwoPlayerMode = session.opponentType === 'friend' || session.opponentType === 'matchmaking';
    if (!isTwoPlayerMode) return session.createdByUserId;
    return side === 'FIRST_PICK' ? session.createdByUserId : session.participantSecondUserId;
  }

  /**
   * `requireTurnOwner`: performAction needs the caller to be the exact
   * side whose turn it is. performTimeout does not — the whole point of
   * calling timeout is usually to report that the OTHER participant let
   * their clock run out, so it only needs to check that the caller is
   * one of the two real participants in this session at all.
   */
  private assertMutable(
    session: {
      createdByUserId: string;
      participantSecondUserId: string | null;
      opponentType: string;
      status: string;
      mode: string;
    },
    userId: string,
    nextStep?: DraftStep,
    options?: { requireTurnOwner?: boolean },
  ) {
    if (session.mode !== 'free') throw new BadRequestException('Only free-draft sessions accept actions');
    if (session.status === 'waiting_for_opponent') {
      throw new BadRequestException('This lobby is still waiting for an opponent to join');
    }
    if (session.status !== 'in_progress') throw new BadRequestException('This draft is already finished');

    const isParticipant = userId === session.createdByUserId || userId === session.participantSecondUserId;
    if (!isParticipant) throw new ForbiddenException('Not a participant in this draft session');

    if (options?.requireTurnOwner && nextStep) {
      const turnUser = this.participantForSide(session, nextStep.side);
      if (turnUser !== userId) throw new ForbiddenException('Not your turn');
    }
  }

  private async appendAction(
    session: {
      id: string;
      sequence: any;
      actions: any;
      reserveFirstSec: number;
      reserveSecondSec: number;
    },
    step: DraftStep,
    outcome: { heroId: number | null; timedOut: boolean },
    elapsedSec: number,
  ) {
    const sequence = session.sequence as unknown as DraftStep[];
    const actions = session.actions as unknown as DraftEvent[];

    // Deduct any overflow beyond the main per-action allowance from that
    // side's reserve pool, floored at 0. On a genuine forced timeout this
    // drains it to exactly 0 (by construction, since performTimeout only
    // gets here once overflow >= currentReserve); on a manual action that
    // just ran a little long, it's a partial deduction.
    const overflowSec = Math.max(0, elapsedSec - step.timeLimitSec);
    const isFirst = step.side === 'FIRST_PICK';
    const reserveBefore = isFirst ? session.reserveFirstSec : session.reserveSecondSec;
    const reserveAfter = Math.max(0, Math.round(reserveBefore - overflowSec));
    // The actual amount deducted, which can be less than overflowSec if
    // the side didn't have that much reserve left to give (reserveAfter
    // floors at 0 rather than going negative) — this exact number, not
    // overflowSec, is what a later undo needs to hand back.
    const reserveSpent = reserveBefore - reserveAfter;

    const newActions = [...actions, { ...step, ...outcome, reserveSpent }];
    const isComplete = newActions.length === sequence.length;

    const updated = await this.prisma.draftSession.update({
      where: { id: session.id },
      data: {
        actions: newActions as any,
        status: isComplete ? 'completed' : 'in_progress',
        currentStepStartedAt: new Date(),
        ...(isFirst ? { reserveFirstSec: reserveAfter } : { reserveSecondSec: reserveAfter }),
      },
    });

    this.draftGateway.emitUpdate(session.id, updated);
    return updated;
  }

  async listProMatches() {
    return this.openDota.getProMatches();
  }

  /**
   * ============================================================================
   * DRAFT RATING — deterministic composition heuristics, NOT a win-probability
   * prediction. This scores structural properties of a finished draft
   * (role coverage, attribute spread, counter-awareness), not "who's going
   * to win" — that would need real match outcome data trained against
   * thousands of games, which this scaffold doesn't have. Three
   * components, each out of a fixed weight, summing to 100:
   *
   *  - Role coverage (40 pts): does the 5-hero lineup cover the five
   *    OpenDota-tagged roles that matter most for a functional team
   *    (Carry, Support, Disabler, Durable, Nuker)? Missing categories
   *    just lower this component — it's not a claim that every team
   *    needs exactly one of each, just a rough completeness check.
   *  - Attribute diversity (20 pts): how many distinct primary
   *    attributes (str/agi/int/universal) appear among the 5 picks.
   *    A team stacked on one attribute is more vulnerable to a single
   *    counter-strategy (e.g. all-intelligence low-HP lineups dying to
   *    burst) — a real but rough signal, not a hard rule.
   *  - Counter-awareness (40 pts): of the picks made after at least one
   *    enemy hero was already visible, what fraction appear in that
   *    hero's own `countersJson.goodAgainst` list against an enemy pick
   *    already on the board? Reuses the exact same real per-matchup
   *    data the AI bot uses to pick — see pickBotHero. Picks made
   *    before the enemy had shown anyone aren't counted against this
   *    score at all (there was nothing to counter yet).
   * ============================================================================
   */
  async computeDraftRating(sessionId: string) {
    const session = await this.getSession(sessionId);
    if (session.status !== 'completed') {
      throw new BadRequestException('Rating is only available once the draft is complete');
    }

    const actions = session.actions as unknown as DraftEvent[];
    const radiantSide = session.radiantSide as DraftSide;
    const direSide: DraftSide = radiantSide === 'FIRST_PICK' ? 'SECOND_PICK' : 'FIRST_PICK';

    const [radiant, dire] = await Promise.all([
      this.scoreComposition(actions, radiantSide),
      this.scoreComposition(actions, direSide),
    ]);

    // Cross-team counter pairs — computed once, then shown from each
    // side's point of view. Only reports a pair when the picked hero
    // actually has synced countersJson (see hero-database README) —
    // heroes nobody ran syncMatchups on simply won't show up here,
    // which the frontend surfaces as "нет данных", not silence-as-zero.
    const counterPairs = await this.findCounterPairs(actions, radiantSide, direSide);

    return {
      radiant,
      dire,
      counterPairs,
      // Not implemented: ally synergy (no confirmed OpenDota data
      // source for it — see the hero-database README) and item
      // recommendations (the data exists in principle via
      // /heroes/{id}/matches + per-match item slots, but computing it
      // needs a real background aggregation pipeline this scaffold
      // doesn't have; not something to fake with a handful of live
      // calls per draft completion).
      notes: {
        synergiesAvailable: false,
        itemRecommendationsAvailable: false,
      },
    };
  }

  /**
   * For every (my pick, enemy pick) pair, checks both directions using
   * each hero's own `countersJson.goodAgainst` list — real per-matchup
   * win rates from OpenDota, same data the bot and the rating score
   * use. A pair only appears if at least one direction has data.
   */
  private async findCounterPairs(actions: DraftEvent[], radiantSide: DraftSide, direSide: DraftSide) {
    const radiantPicks = actions.filter((a) => a.action === 'pick' && a.side === radiantSide && a.heroId != null).map((a) => a.heroId!);
    const direPicks = actions.filter((a) => a.action === 'pick' && a.side === direSide && a.heroId != null).map((a) => a.heroId!);
    const allIds = [...radiantPicks, ...direPicks];
    const heroes = await this.prisma.hero.findMany({ where: { id: { in: allIds } } });
    const byId = new Map(heroes.map((h) => [h.id, h]));

    type Pair = { radiantHeroId: number; direHeroId: number; favors: 'radiant' | 'dire' };
    const pairs: Pair[] = [];

    for (const rId of radiantPicks) {
      for (const dId of direPicks) {
        const rHero = byId.get(rId);
        const dHero = byId.get(dId);
        const rGoodAgainstD = (rHero?.countersJson as any)?.goodAgainst?.some((g: any) => g.heroId === dId);
        const dGoodAgainstR = (dHero?.countersJson as any)?.goodAgainst?.some((g: any) => g.heroId === rId);
        if (rGoodAgainstD) pairs.push({ radiantHeroId: rId, direHeroId: dId, favors: 'radiant' });
        if (dGoodAgainstR) pairs.push({ radiantHeroId: rId, direHeroId: dId, favors: 'dire' });
      }
    }
    return pairs;
  }

  private async scoreComposition(actions: DraftEvent[], side: DraftSide) {
    const ROLE_CATEGORIES = ['Carry', 'Support', 'Disabler', 'Durable', 'Nuker'];
    const ROLE_HINTS: Record<string, string> = {
      Carry: 'слабый скейлинг в позднюю игру',
      Support: 'проблемы с хилом/контролем на линиях',
      Disabler: 'нечем обездвижить вражеских кор-героев в решающий момент',
      Durable: 'команда может не выдерживать размены в файтах',
      Nuker: 'мало бурст-урона, чтобы быстро снять цель',
    };

    const myPicks = actions.filter((a) => a.action === 'pick' && a.side === side && a.heroId != null);
    const enemyPicks = actions.filter((a) => a.action === 'pick' && a.side !== side && a.heroId != null);
    const heroIds = myPicks.map((p) => p.heroId!);
    const heroes = await this.prisma.hero.findMany({ where: { id: { in: heroIds } } });
    const heroesById = new Map(heroes.map((h) => [h.id, h]));

    // Role coverage
    const rolesPresent = new Set<string>();
    for (const h of heroes) (h.roles ?? []).forEach((r) => rolesPresent.add(r));
    const coveredCategories = ROLE_CATEGORIES.filter((r) => rolesPresent.has(r));
    const missingRoles = ROLE_CATEGORIES.filter((r) => !rolesPresent.has(r));
    const roleCoverage = Math.round((coveredCategories.length / ROLE_CATEGORIES.length) * 40);

    // Attribute diversity
    const attrs = new Set(heroes.map((h) => h.primaryAttr));
    const attributeDiversity = Math.round((Math.min(attrs.size, 4) / 4) * 20);

    // Counter-awareness — same scoring as the bot's pick heuristic,
    // applied retroactively to what was actually picked.
    let eligiblePicks = 0;
    let counterAwarePicks = 0;
    for (const action of actions) {
      if (action.action !== 'pick' || action.side !== side || action.heroId == null) continue;

      const enemyPickedBefore = actions
        .slice(0, actions.indexOf(action))
        .filter((a) => a.action === 'pick' && a.side !== side && a.heroId != null)
        .map((a) => a.heroId!);
      if (enemyPickedBefore.length === 0) continue; // nothing to counter yet

      eligiblePicks += 1;
      const hero = heroesById.get(action.heroId);
      const counters = hero?.countersJson as unknown as { goodAgainst?: { heroId: number }[] } | null;
      const countersAnyEnemy = counters?.goodAgainst?.some((g) => enemyPickedBefore.includes(g.heroId));
      if (countersAnyEnemy) counterAwarePicks += 1;
    }
    const counterAwareness =
      eligiblePicks > 0 ? Math.round((counterAwarePicks / eligiblePicks) * 40) : 0;
    const counterAwareRatio = eligiblePicks > 0 ? counterAwarePicks / eligiblePicks : null;

    // "Кого стоило забанить лучше" — among every hero nobody used
    // (banned or picked) this game, which one has the strongest synced
    // matchup against THIS side's final picks? Only meaningful for
    // heroes that have had syncMatchups run on them — most won't, so
    // this frequently comes back null, which the frontend shows as
    // "недостаточно данных", not a false "nobody was dangerous".
    const usedIds = new Set(actions.filter((a) => a.heroId != null).map((a) => a.heroId));
    const unusedHeroes = await this.prisma.hero.findMany({
      where: { captainsModeAvailable: true, id: { notIn: [...usedIds] as number[] } },
    });
    let mostDangerousUnbanned: { heroId: number; score: number } | null = null;
    for (const h of unusedHeroes) {
      const counters = h.countersJson as unknown as { goodAgainst?: { heroId: number }[] } | null;
      const score = counters?.goodAgainst?.filter((g) => heroIds.includes(g.heroId)).length ?? 0;
      if (score > 0 && (!mostDangerousUnbanned || score > mostDangerousUnbanned.score)) {
        mostDangerousUnbanned = { heroId: h.id, score };
      }
    }

    // Plain-language reasons, generated from the numbers above rather
    // than a separate opinion — every sentence traces back to a
    // specific field also returned in this same response.
    const reasons: string[] = [];
    if (missingRoles.length > 0) {
      reasons.push(`Не хватает ролей: ${missingRoles.join(', ')} — ${missingRoles.map((r) => ROLE_HINTS[r]).join('; ')}.`);
    }
    if (attrs.size <= 2) {
      reasons.push(`Состав сосредоточен на ${attrs.size} атрибуте(ах) (${[...attrs].join('/')}) — уязвим к одной стратегии контригры (например, магический бурст против интеллекта или физический — против ловкости).`);
    }
    if (counterAwareRatio != null) {
      if (counterAwareRatio >= 0.6) {
        reasons.push('Пики хорошо реагировали на выбор соперника — большинство поздних героев контрят уже видимые пики врага.');
      } else if (counterAwareRatio < 0.3 && eligiblePicks > 0) {
        reasons.push('Пики слабо учитывали состав соперника — часть героев можно было выбрать точнее против уже открытых пиков врага.');
      }
    }
    if (mostDangerousUnbanned) {
      reasons.push(`Герой #${mostDangerousUnbanned.heroId} остался незабаненным и по статистике хорошо играет против части вашего состава — его стоило рассмотреть для бана.`);
    }

    return {
      total: roleCoverage + attributeDiversity + counterAwareness,
      roleCoverage,
      attributeDiversity,
      counterAwareness,
      coveredRoles: coveredCategories,
      missingRoles,
      distinctAttributes: attrs.size,
      counterAwareEligiblePicks: eligiblePicks,
      // Null (not 0) when there was no opportunity to counter-pick at
      // all, so the frontend can show "n/a" instead of implying a bad
      // score for something structurally impossible to earn.
      counterAwareRatio,
      mostDangerousUnbanned,
      reasons,
    };
  }

  /**
   * Imports a real pro match's draft as a read-only, already-completed
   * session - "study a real draft", not "practice your own". Only works
   * for Captain's Mode matches; anything without a `picks_bans` array
   * (All Pick, Turbo, etc.) will fail here rather than fabricate one.
   */
  async startProReplay(userId: string, matchId: number) {
    const match = await this.openDota.getMatch(matchId);
    if (!match.picks_bans || match.picks_bans.length === 0) {
      throw new NotFoundException(
        `Match ${matchId} has no picks_bans data - likely not a Captain's Mode game`,
      );
    }

    const sorted = [...match.picks_bans].sort((a, b) => a.order - b.order);
    // Convention for replay display only: team 0 (Radiant) is labeled
    // FIRST_PICK, team 1 (Dire) SECOND_PICK — real Radiant/Dire is known
    // directly from OpenDota here, no guessing needed for this mode.
    const events: DraftEvent[] = sorted.map((pb, i) => ({
      step: i + 1,
      side: pb.team === 0 ? 'FIRST_PICK' : 'SECOND_PICK',
      action: pb.is_pick ? 'pick' : 'ban',
      heroId: pb.hero_id,
      timedOut: false,
      timeLimitSec: 0,
      reserveSpent: 0,
    }));

    return this.prisma.draftSession.create({
      data: {
        createdByUserId: userId,
        mode: 'pro_replay',
        sequence: events.map(({ step, side, action, timeLimitSec }) => ({ step, side, action, timeLimitSec })) as any,
        actions: events as any,
        status: 'completed',
        radiantSide: 'FIRST_PICK',
        sourceProMatchId: BigInt(matchId),
      },
    });
  }
}
