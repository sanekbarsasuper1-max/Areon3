import { Module } from '@nestjs/common';
import { PatchSyncService } from './patch-sync.service';
import { PatchController } from './patch.controller';
import { PrismaService } from '../prisma.service';
import { OpenDotaModule } from '../opendota/opendota.module';
import { HeroesModule } from '../heroes/heroes.module';

@Module({
  imports: [OpenDotaModule, HeroesModule],
  controllers: [PatchController],
  providers: [PatchSyncService, PrismaService],
  exports: [PatchSyncService],
})
export class PatchModule {}
