import { Controller, Get } from '@nestjs/common';
import { PatchSyncService } from './patch-sync.service';

@Controller('patch')
export class PatchController {
  constructor(private readonly patchSync: PatchSyncService) {}

  // Public (any logged-in user, not admin-only) — exactly the "Areon
  // version / Dota patch / last sync / status" display requirement 1
  // asked for; no reason a regular user shouldn't see it.
  @Get('status')
  async getStatus() {
    await this.patchSync.ensureInitialized();
    return this.patchSync.getStatus();
  }
}
