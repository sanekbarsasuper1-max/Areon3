import { Module } from '@nestjs/common';
import { HeroesService } from './heroes.service';
import { HeroesController, ItemsController } from './heroes.controller';
import { PrismaService } from '../prisma.service';
import { OpenDotaModule } from '../opendota/opendota.module';

@Module({
  imports: [OpenDotaModule],
  providers: [HeroesService, PrismaService],
  controllers: [HeroesController, ItemsController],
  exports: [HeroesService],
})
export class HeroesModule {}
