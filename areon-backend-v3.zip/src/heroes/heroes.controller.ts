import { Controller, Get, Param, ParseIntPipe, UseGuards } from '@nestjs/common';
import { HeroesService } from './heroes.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

// Guarded even though hero reference data isn't personal, per the
// explicit "полностью закрыто без исключений" access-model decision —
// see the product discussion. Revisit this only if that decision changes.
//
// Sync routes (POST sync, POST :id/sync-matchups) moved to
// AdminController — triggering a full hero-database resync or a
// per-hero matchup recompute is a global, moderately expensive action
// that shouldn't be one click away for every logged-in user.
@Controller('heroes')
@UseGuards(JwtAuthGuard)
export class HeroesController {
  constructor(private readonly heroesService: HeroesService) {}

  @Get()
  list() {
    return this.heroesService.listHeroes();
  }

  @Get(':id')
  get(@Param('id', ParseIntPipe) id: number) {
    return this.heroesService.getHero(id);
  }
}

// Same controller-level rationale as HeroesController above: item
// reference data isn't personal either, but the platform is closed
// without exceptions, so this stays behind the standard login guard too.
@Controller('items')
@UseGuards(JwtAuthGuard)
export class ItemsController {
  constructor(private readonly heroesService: HeroesService) {}

  @Get()
  list() {
    return this.heroesService.listItems();
  }
}
