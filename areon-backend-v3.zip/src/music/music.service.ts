import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

@Injectable()
export class MusicService {
  constructor(private readonly prisma: PrismaService) {}

  async listFavorites(userId: string) {
    return this.prisma.favoriteTrack.findMany({ where: { userId }, orderBy: { createdAt: 'desc' } });
  }

  async addFavorite(userId: string, track: { providerTrackId: string; name: string; artist: string; imageUrl?: string }) {
    // Upsert-by-hand rather than a real upsert — same effect, and this
    // codebase already leans on findUnique-then-create in a few places
    // (e.g. rank snapshots) for the same "don't error on a harmless
    // double-click" reasoning.
    const existing = await this.prisma.favoriteTrack.findUnique({
      where: { userId_provider_providerTrackId: { userId, provider: 'jamendo', providerTrackId: track.providerTrackId } },
    });
    if (existing) return existing;
    return this.prisma.favoriteTrack.create({
      data: { userId, provider: 'jamendo', ...track },
    });
  }

  async removeFavorite(userId: string, providerTrackId: string) {
    const existing = await this.prisma.favoriteTrack.findUnique({
      where: { userId_provider_providerTrackId: { userId, provider: 'jamendo', providerTrackId } },
    });
    if (!existing) return { deleted: false };
    await this.prisma.favoriteTrack.delete({ where: { id: existing.id } });
    return { deleted: true };
  }
}
