import { Body, Controller, Delete, Get, Param, Post, Req } from '@nestjs/common';
import { MusicService } from './music.service';

@Controller('music')
export class MusicController {
  constructor(private readonly musicService: MusicService) {}

  @Get('favorites')
  list(@Req() req: any) {
    return this.musicService.listFavorites(req.user.sub);
  }

  @Post('favorites')
  add(@Req() req: any, @Body() body: { providerTrackId: string; name: string; artist: string; imageUrl?: string }) {
    return this.musicService.addFavorite(req.user.sub, body);
  }

  @Delete('favorites/:providerTrackId')
  remove(@Req() req: any, @Param('providerTrackId') providerTrackId: string) {
    return this.musicService.removeFavorite(req.user.sub, providerTrackId);
  }
}
