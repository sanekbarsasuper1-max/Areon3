import { Module } from '@nestjs/common';
import { UpdatesController } from './updates.controller';
import { VersionsService } from './versions.service';
import { SuggestionsService } from './suggestions.service';
import { SupportService } from './support.service';
import { PrismaService } from '../prisma.service';

@Module({
  controllers: [UpdatesController],
  providers: [VersionsService, SuggestionsService, SupportService, PrismaService],
  exports: [VersionsService, SuggestionsService, SupportService],
})
export class UpdatesModule {}
