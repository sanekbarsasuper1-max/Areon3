import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

export const SUPPORT_CATEGORIES = ['BUG', 'QUESTION', 'ACCOUNT', 'GAMEPLAY', 'SUGGESTION', 'OTHER'] as const;

@Injectable()
export class SupportService {
  constructor(private readonly prisma: PrismaService) {}

  async create(userId: string, category: string, message: string) {
    return this.prisma.supportTicket.create({ data: { userId, category, message, status: 'OPEN' } });
  }

  async listMine(userId: string) {
    return this.prisma.supportTicket.findMany({ where: { userId }, orderBy: { createdAt: 'desc' } });
  }

  async listAll() {
    return this.prisma.supportTicket.findMany({ include: { user: true }, orderBy: { createdAt: 'desc' } });
  }

  async reply(id: string, adminReply: string) {
    const existing = await this.prisma.supportTicket.findUnique({ where: { id } });
    if (!existing) throw new NotFoundException('Ticket not found');
    return this.prisma.supportTicket.update({ where: { id }, data: { adminReply, repliedAt: new Date() } });
  }

  async close(id: string) {
    return this.prisma.supportTicket.update({ where: { id }, data: { status: 'CLOSED', closedAt: new Date() } });
  }
}
