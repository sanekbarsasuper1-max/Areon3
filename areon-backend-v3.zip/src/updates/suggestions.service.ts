import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

export const SUGGESTION_STATUSES = ['RECEIVED', 'UNDER_REVIEW', 'PLANNED', 'IN_PROGRESS', 'IMPLEMENTED', 'REJECTED'] as const;

@Injectable()
export class SuggestionsService {
  constructor(private readonly prisma: PrismaService) {}

  async create(userId: string, title: string, description: string) {
    return this.prisma.suggestion.create({ data: { userId, title, description, status: 'RECEIVED' } });
  }

  async listMine(userId: string) {
    return this.prisma.suggestion.findMany({ where: { userId }, orderBy: { createdAt: 'desc' } });
  }

  /** Public feed — every player's suggestions are visible to everyone
   * (transparency is the point of requirement 10's "увидеть её
   * статус... увидеть её реализацию"), not just the author. */
  async listAll() {
    return this.prisma.suggestion.findMany({
      include: { user: true, implementedInVersion: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  async updateStatus(id: string, status: string, adminNote?: string) {
    if (!SUGGESTION_STATUSES.includes(status as any)) {
      throw new ForbiddenException(`Invalid status "${status}"`);
    }
    const existing = await this.prisma.suggestion.findUnique({ where: { id } });
    if (!existing) throw new NotFoundException('Suggestion not found');
    return this.prisma.suggestion.update({
      where: { id },
      data: { status, adminNote: adminNote ?? existing.adminNote },
    });
  }
}
