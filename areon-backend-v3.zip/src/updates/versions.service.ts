import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

export interface VersionInput {
  version: string;
  added?: string[];
  fixed?: string[];
  improved?: string[];
  addressed?: string[];
  knownIssues?: string[];
}

@Injectable()
export class VersionsService {
  constructor(private readonly prisma: PrismaService) {}

  async listAll() {
    return this.prisma.areonVersion.findMany({ orderBy: { releasedAt: 'desc' } });
  }

  async getCurrent() {
    return this.prisma.areonVersion.findFirst({ where: { isCurrent: true } });
  }

  async getByVersion(version: string) {
    const row = await this.prisma.areonVersion.findUnique({ where: { version } });
    if (!row) throw new NotFoundException('Version not found');
    return row;
  }

  /**
   * Creates a new version and makes it current — atomically flips the
   * old current version's isCurrent to false in the same transaction,
   * so there is never a moment with zero or two current versions, even
   * under concurrent admin requests.
   */
  async createVersion(input: VersionInput) {
    return this.prisma.$transaction(async (tx) => {
      const previous = await tx.areonVersion.findFirst({ where: { isCurrent: true } });
      if (previous) {
        await tx.areonVersion.update({ where: { id: previous.id }, data: { isCurrent: false } });
      }
      return tx.areonVersion.create({
        data: {
          version: input.version,
          added: input.added ?? [],
          fixed: input.fixed ?? [],
          improved: input.improved ?? [],
          addressed: input.addressed ?? [],
          knownIssues: input.knownIssues ?? [],
          isCurrent: true,
        },
      });
    });
  }

  async updateVersion(id: string, input: Partial<VersionInput>) {
    return this.prisma.areonVersion.update({ where: { id }, data: input });
  }

  /** Admin can also re-flag an OLDER version as current, e.g. after
   * rolling back a broken release — same atomic guarantee. */
  async setCurrent(id: string) {
    return this.prisma.$transaction(async (tx) => {
      const previous = await tx.areonVersion.findFirst({ where: { isCurrent: true } });
      if (previous && previous.id !== id) {
        await tx.areonVersion.update({ where: { id: previous.id }, data: { isCurrent: false } });
      }
      return tx.areonVersion.update({ where: { id }, data: { isCurrent: true } });
    });
  }

  /** Links an already-implemented Suggestion to the version that
   * shipped it — requirement 7. */
  async linkSuggestion(versionId: string, suggestionId: string) {
    return this.prisma.suggestion.update({
      where: { id: suggestionId },
      data: { status: 'IMPLEMENTED', implementedInVersionId: versionId },
    });
  }

  /**
   * Idempotent — only runs if literally zero versions exist yet. Does
   * NOT fabricate a detailed changelog history (no invented past
   * entries) — just a real, honest baseline so the version display and
   * update-notification banner have something to show on a fresh
   * install, before an admin has written a real first changelog entry.
   */
  async seedInitialVersion() {
    const existing = await this.prisma.areonVersion.count();
    if (existing > 0) return { created: false };
    await this.createVersion({
      version: '1.0.0',
      added: ['Запуск платформы Areon'],
    });
    return { created: true };
  }
}
