import { Controller, Get, Param, Post, Query, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { MatchesService } from './matches.service';

@Controller('players/me/matches')
@UseGuards(JwtAuthGuard)
export class MatchesController {
  constructor(private readonly matchesService: MatchesService) {}

  // Powers the "Все матчи" screen's filter bar: hero, result, period.
  // All filtering happens against our own Postgres copy, not a live
  // OpenDota call — see the architecture note in matches.service.ts.
  @Get()
  async list(
    @Req() req: any,
    @Query('heroId') heroId?: string,
    @Query('result') result?: 'win' | 'loss',
    @Query('days') days?: string,
    @Query('page') page?: string,
  ) {
    return this.matchesService.listMatches(req.user.sub, {
      heroId: heroId ? Number(heroId) : undefined,
      result,
      days: days ? Number(days) : undefined,
      page: page ? Number(page) : undefined,
    });
  }

  // Match Analyzer's detail view — heavier fetch, cached after first hit.
  @Get(':id/detail')
  async detail(@Req() req: any, @Param('id') id: string) {
    return this.matchesService.getOrFetchDetail(req.user.sub, req.user.accountId32, id);
  }

  // Manual trigger for now — the daily background worker that calls this
  // automatically is the next piece, not built in this slice.
  @Post('sync')
  async sync(@Req() req: any) {
    return this.matchesService.syncRecentMatches(
      req.user.sub,
      req.user.accountId32,
    );
  }
}
