import { Injectable } from '@nestjs/common';
import { OpenDotaMatchPlayer, OpenDotaBenchmarks } from '../opendota/opendota.service';

export interface Insight {
  tone: 'positive' | 'negative' | 'neutral';
  message: string;
}

@Injectable()
export class MatchAnalyzerService {
  /**
   * "Cheap tier" rules only — everything here reads fields OpenDota's
   * documented endpoints actually return. The death-clustering and
   * "solo death" rules from the product design ("обе смерти произошли
   * между 18 и 22 минутой без союзников рядом") need positional data
   * from a deeper replay parse that isn't in the standard match
   * response — those are intentionally NOT implemented here rather than
   * faked from data that doesn't support them.
   */
  buildInsights(player: OpenDotaMatchPlayer, benchmarks: OpenDotaBenchmarks): Insight[] {
    const insights: Insight[] = [];

    insights.push(...this.benchmarkInsights(player, benchmarks));
    insights.push(...this.netWorthTrendInsight(player));

    // Rank by how far a metric sits from the median (bigger deviation =
    // more worth surfacing), then cap at 3 so the screen doesn't turn
    // back into the giant table of numbers the product brief explicitly
    // didn't want.
    return insights.slice(0, 3);
  }

  private benchmarkInsights(
    player: OpenDotaMatchPlayer,
    benchmarks: OpenDotaBenchmarks,
  ): Insight[] {
    const checks: { metric: keyof OpenDotaMatchPlayer; label: string; benchmarkKey: string }[] = [
      { metric: 'gold_per_min', label: 'GPM', benchmarkKey: 'gold_per_min' },
      { metric: 'hero_damage', label: 'урон героям', benchmarkKey: 'hero_damage_per_min' },
    ];

    const out: Insight[] = [];
    for (const check of checks) {
      const series = benchmarks.result[check.benchmarkKey];
      if (!series) continue;

      // OpenDota returns percentile buckets; find the closest one to
      // this player's value to say roughly where they land.
      const value = Number(player[check.metric]);
      const median = series.find((p) => p.percentile === 0.5)?.value;
      if (median == null) continue;

      const diffPct = ((value - median) / median) * 100;
      if (Math.abs(diffPct) < 15) continue; // not worth mentioning

      out.push({
        tone: diffPct > 0 ? 'positive' : 'negative',
        message:
          diffPct > 0
            ? `${check.label} на ${Math.round(diffPct)}% выше медианы для этого героя`
            : `${check.label} на ${Math.round(Math.abs(diffPct))}% ниже медианы для этого героя`,
      });
    }
    return out;
  }

  private netWorthTrendInsight(player: OpenDotaMatchPlayer): Insight[] {
    const series = player.gold_t;
    if (!series || series.length < 10) return [];

    const third = Math.floor(series.length / 3);
    const early = series[third] - series[0];
    const late = series[series.length - 1] - series[series.length - 1 - third];

    // Comparing gold gained per minute-bucket in the first third vs the
    // last third — a purely descriptive read of the curve's shape, not a
    // claim about what caused it.
    const earlyRate = early / third;
    const lateRate = late / third;
    if (lateRate <= 0 || earlyRate <= 0) return [];

    const ratio = lateRate / earlyRate;
    if (ratio > 1.4) {
      return [{ tone: 'positive', message: 'фарм ускорился к концу игры относительно старта' }];
    }
    if (ratio < 0.7) {
      return [{ tone: 'negative', message: 'фарм замедлился к концу игры относительно старта' }];
    }
    return [];
  }
}
