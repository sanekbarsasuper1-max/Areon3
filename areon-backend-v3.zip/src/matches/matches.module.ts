import { Module } from '@nestjs/common';
import { MatchesService } from './matches.service';
import { MatchesController } from './matches.controller';
import { MatchAnalyzerService } from './match-analyzer.service';
import { PrismaService } from '../prisma.service';
import { OpenDotaModule } from '../opendota/opendota.module';
import { TrialsModule } from '../trials/trials.module';
import { HallOfFameModule } from '../hall-of-fame/hall-of-fame.module';

@Module({
  imports: [OpenDotaModule, TrialsModule, HallOfFameModule],
  providers: [MatchesService, MatchAnalyzerService, PrismaService],
  controllers: [MatchesController],
})
export class MatchesModule {}
