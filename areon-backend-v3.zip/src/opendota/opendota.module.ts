import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { OpenDotaService } from './opendota.service';

@Module({
  imports: [HttpModule],
  providers: [OpenDotaService],
  exports: [OpenDotaService],
})
export class OpenDotaModule {}
