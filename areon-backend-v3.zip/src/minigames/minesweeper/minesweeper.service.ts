import { BadRequestException, ForbiddenException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma.service';
import { generateMineLayout, revealCell, isWon, adjacentMineCount, BoardConfig } from './minesweeper-engine';
import { HallOfFameService } from '../../hall-of-fame/hall-of-fame.service';

// Standard, well-established Minesweeper difficulty sizes (Beginner/
// Intermediate/Expert) — not invented. Reward numbers are Areon's own
// choice and are exactly what requirement 4 asked to be configurable
// without touching this file — see seedConfigs()'s own comment on why
// they live in the DB, not here, despite being defined here as the
// seed values.
const DEFAULT_CONFIGS = [
  { difficulty: 'EASY', boardWidth: 9, boardHeight: 9, mineCount: 10, winShards: 20, lossShards: 0, winRating: 5, lossRating: -2, streakBonusShards: 10, streakBonusThreshold: 3 },
  { difficulty: 'NORMAL', boardWidth: 16, boardHeight: 16, mineCount: 40, winShards: 50, lossShards: 0, winRating: 10, lossRating: -5, streakBonusShards: 25, streakBonusThreshold: 3 },
  { difficulty: 'HARD', boardWidth: 30, boardHeight: 16, mineCount: 99, winShards: 120, lossShards: -5, winRating: 20, lossRating: -10, streakBonusShards: 60, streakBonusThreshold: 3 },
];

const GAME_TYPE = 'minesweeper';

@Injectable()
export class MinesweeperService {
  private readonly logger = new Logger(MinesweeperService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly hallOfFame: HallOfFameService,
  ) {}

  /** Idempotent — never overwrites an admin's tuned reward values on
   * restart, only fills in configs that don't exist yet (same pattern
   * as TrialGeneratorService.seedTemplates). */
  async seedConfigs() {
    let created = 0;
    for (const cfg of DEFAULT_CONFIGS) {
      const existing = await this.prisma.minesweeperConfig.findUnique({ where: { difficulty: cfg.difficulty } });
      if (existing) continue;
      await this.prisma.minesweeperConfig.create({ data: cfg });
      created += 1;
    }
    return { created };
  }

  async listConfigs() {
    return this.prisma.minesweeperConfig.findMany({ orderBy: { mineCount: 'asc' } });
  }

  async startGame(userId: string, difficulty: string) {
    const config = await this.prisma.minesweeperConfig.findUnique({ where: { difficulty } });
    if (!config || !config.active) throw new BadRequestException(`No active config for difficulty "${difficulty}"`);

    // Mine layout isn't known yet — the classic "first click is safe"
    // convention means we can't place mines until we know which cell
    // the player clicks first. Store an empty layout and generate it
    // on the very first reveal instead (see reveal() below).
    return this.prisma.miniGameSession.create({
      data: {
        userId,
        gameType: GAME_TYPE,
        difficulty,
        boardWidth: config.boardWidth,
        boardHeight: config.boardHeight,
        mineLayoutJson: [],
        status: 'IN_PROGRESS',
      },
    });
  }

  async reveal(userId: string, sessionId: string, cellIndex: number) {
    const session = await this.getOwnedActiveSession(userId, sessionId);
    const boardConfig: BoardConfig = { width: session.boardWidth, height: session.boardHeight, mineCount: (await this.getConfig(session.difficulty)).mineCount };

    let mines = new Set<number>(session.mineLayoutJson as any as number[]);
    const alreadyRevealed = new Set<number>(session.revealedJson as any as number[]);

    if (mines.size === 0 && alreadyRevealed.size === 0) {
      // First reveal of this session — generate the layout now,
      // guaranteed safe around this exact cell.
      mines = generateMineLayout(boardConfig, cellIndex);
      await this.prisma.miniGameSession.update({ where: { id: sessionId }, data: { mineLayoutJson: [...mines] as any } });
    }

    if (alreadyRevealed.has(cellIndex)) {
      return { session, revealed: [], hitMine: false }; // no-op, not an error — clicking twice shouldn't be punished
    }

    const result = revealCell(cellIndex, mines, alreadyRevealed, session.boardWidth, session.boardHeight);
    const newRevealed = new Set([...alreadyRevealed, ...result.revealed]);

    const cellNumbers: Record<number, number> = { ...(session.cellNumbersJson as any) };
    for (const idx of result.revealed) {
      cellNumbers[idx] = adjacentMineCount(idx, mines, session.boardWidth, session.boardHeight);
    }

    if (result.hitMine) {
      return this.endGame(session, 'LOST', [...newRevealed], [...mines], cellNumbers);
    }
    if (isWon(newRevealed.size, boardConfig)) {
      return this.endGame(session, 'WON', [...newRevealed], [], cellNumbers); // mines never need to be shown to the client on a win
    }

    const updated = await this.prisma.miniGameSession.update({
      where: { id: sessionId },
      data: { revealedJson: [...newRevealed] as any, cellNumbersJson: cellNumbers as any },
    });
    return { session: updated, revealed: result.revealed, hitMine: false };
  }

  async toggleFlag(userId: string, sessionId: string, cellIndex: number) {
    const session = await this.getOwnedActiveSession(userId, sessionId);
    const flagged = new Set<number>(session.flaggedJson as any as number[]);
    if (flagged.has(cellIndex)) flagged.delete(cellIndex);
    else flagged.add(cellIndex);
    return this.prisma.miniGameSession.update({ where: { id: sessionId }, data: { flaggedJson: [...flagged] as any } });
  }

  private async getOwnedActiveSession(userId: string, sessionId: string) {
    const session = await this.prisma.miniGameSession.findUnique({ where: { id: sessionId } });
    if (!session) throw new NotFoundException('Session not found');
    if (session.userId !== userId) throw new ForbiddenException('Not your game');
    if (session.status !== 'IN_PROGRESS') throw new BadRequestException('This game already ended');
    return session;
  }

  private async getConfig(difficulty: string) {
    const config = await this.prisma.minesweeperConfig.findUniqueOrThrow({ where: { difficulty } });
    return config;
  }

  /**
   * The one place Shards and Rating both get touched — atomically, in
   * one transaction, alongside marking the session ended and updating
   * MiniGameStats. Reuses the exact same
   * ledger-entry-plus-cached-balance pattern
   * TrialEngineService/ShardsService already established, not a new
   * one invented for this feature.
   */
  private async endGame(session: any, outcome: 'WON' | 'LOST', revealed: number[], mines: number[], cellNumbers: Record<number, number>) {
    const config = await this.getConfig(session.difficulty);
    const durationSec = Math.round((Date.now() - new Date(session.startedAt).getTime()) / 1000);

    const txResult = await this.prisma.$transaction(async (tx) => {
      const stats = await tx.miniGameStats.upsert({
        where: { userId_gameType: { userId: session.userId, gameType: GAME_TYPE } },
        create: { userId: session.userId, gameType: GAME_TYPE },
        update: {},
      });

      const won = outcome === 'WON';
      const newStreak = won ? stats.currentWinStreak + 1 : 0;
      const streakBonus = won && newStreak >= config.streakBonusThreshold ? config.streakBonusShards : 0;
      const shardsAwarded = (won ? config.winShards : config.lossShards) + streakBonus;
      const ratingChange = won ? config.winRating : config.lossRating;

      const user = await tx.user.findUniqueOrThrow({ where: { id: session.userId } });
      const newBalance = user.shardBalance + shardsAwarded;
      const newRating = user.rating + ratingChange;

      await tx.user.update({ where: { id: session.userId }, data: { shardBalance: newBalance, rating: newRating } });

      if (shardsAwarded !== 0) {
        await tx.shardTransaction.create({
          data: {
            userId: session.userId,
            amount: shardsAwarded,
            type: 'MINIGAME_REWARD',
            reason: `Techies: Minesweeper (${session.difficulty}) — ${won ? 'победа' : 'поражение'}`,
            balanceAfter: newBalance,
          },
        });
      }

      await tx.miniGameStats.update({
        where: { userId_gameType: { userId: session.userId, gameType: GAME_TYPE } },
        data: {
          played: stats.played + 1,
          wins: stats.wins + (won ? 1 : 0),
          losses: stats.losses + (won ? 0 : 1),
          currentWinStreak: newStreak,
          bestWinStreak: Math.max(stats.bestWinStreak, newStreak),
          totalShardsEarned: stats.totalShardsEarned + shardsAwarded,
          totalRatingChange: stats.totalRatingChange + ratingChange,
          bestTimeSec: won && (stats.bestTimeSec == null || durationSec < stats.bestTimeSec) ? durationSec : stats.bestTimeSec,
        },
      });

      const updatedSession = await tx.miniGameSession.update({
        where: { id: session.id },
        data: {
          status: outcome,
          endedAt: new Date(),
          durationSec: won ? durationSec : null,
          revealedJson: revealed as any,
          cellNumbersJson: cellNumbers as any,
          mineLayoutJson: outcome === 'LOST' ? (mines as any) : session.mineLayoutJson, // reveal mine positions only on a loss, for the explosion display
          shardsAwarded,
          ratingChange,
        },
      });

      return { session: updatedSession, revealed, hitMine: outcome === 'LOST', shardsAwarded, ratingChange, newBalance, newRating };
    });

    // Deliberately outside the transaction — a Hall of Fame detection
    // failure (or just being slow) should never roll back a reward the
    // player already legitimately earned. Best-effort, fire-and-check,
    // not part of the atomic guarantee the reward itself has.
    await this.checkHallOfFameRecords(session.userId, txResult);
    return txResult;
  }

  private async checkHallOfFameRecords(userId: string, txResult: any) {
    try {
      await this.hallOfFame.recordEvent({
        key: 'highest_rating_ever',
        userId,
        rawValue: txResult.newRating,
        value: `Рейтинг ${txResult.newRating}`,
      });
      await this.hallOfFame.recordEvent({
        key: 'most_plus_points_balance',
        userId,
        rawValue: txResult.newBalance,
        value: `${txResult.newBalance} Orion Plus`,
      });
      const stats = await this.getStats(userId);
      if (stats) {
        await this.hallOfFame.recordEvent({
          key: 'longest_minesweeper_win_streak',
          userId,
          rawValue: stats.bestWinStreak,
          value: `${stats.bestWinStreak} побед подряд`,
          description: 'Техис: Сапёр',
        });
      }
    } catch (e: any) {
      this.logger.warn(`Hall of Fame check failed after a Minesweeper game: ${e.message}`);
    }
  }

  async getStats(userId: string) {
    return this.prisma.miniGameStats.findUnique({ where: { userId_gameType: { userId, gameType: GAME_TYPE } } });
  }
}
