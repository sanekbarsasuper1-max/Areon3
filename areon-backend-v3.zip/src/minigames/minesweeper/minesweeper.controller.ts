import { Body, Controller, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../../auth/jwt-auth.guard';
import { MinesweeperService } from './minesweeper.service';

@Controller('minigames/minesweeper')
@UseGuards(JwtAuthGuard)
export class MinesweeperController {
  constructor(private readonly service: MinesweeperService) {}

  @Get('configs')
  listConfigs() {
    return this.service.listConfigs();
  }

  @Get('stats')
  getStats(@Req() req: any) {
    return this.service.getStats(req.user.sub);
  }

  @Post('sessions')
  startGame(@Req() req: any, @Body() body: { difficulty: string }) {
    return this.service.startGame(req.user.sub, body.difficulty);
  }

  @Post('sessions/:id/reveal')
  reveal(@Req() req: any, @Param('id') sessionId: string, @Body() body: { cellIndex: number }) {
    return this.service.reveal(req.user.sub, sessionId, body.cellIndex);
  }

  @Post('sessions/:id/flag')
  toggleFlag(@Req() req: any, @Param('id') sessionId: string, @Body() body: { cellIndex: number }) {
    return this.service.toggleFlag(req.user.sub, sessionId, body.cellIndex);
  }
}
