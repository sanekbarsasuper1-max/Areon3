/**
 * Pure game engine — no Prisma, no NestJS, no baked-in randomness
 * dependency (seedable). Same "pure functions are the trustworthy
 * layer" pattern as trial-evaluators.ts and coach-data-extractor.ts.
 */

export interface BoardConfig {
  width: number;
  height: number;
  mineCount: number;
}

/**
 * Classic "first click is always safe" convention — `safeIndex` (the
 * cell about to be revealed) and its immediate neighbors are
 * guaranteed mine-free, so a new game can never end on the very first
 * click. `rng` is injectable specifically so tests can make this
 * deterministic instead of actually random.
 */
export function generateMineLayout(config: BoardConfig, safeIndex: number, rng: () => number = Math.random): Set<number> {
  const total = config.width * config.height;
  if (config.mineCount >= total) {
    throw new Error(`mineCount (${config.mineCount}) must be less than total cells (${total})`);
  }
  const forbidden = new Set<number>([safeIndex, ...neighborsOf(safeIndex, config.width, config.height)]);
  let candidates: number[] = [];
  for (let i = 0; i < total; i++) {
    if (!forbidden.has(i)) candidates.push(i);
  }
  if (candidates.length < config.mineCount) {
    // Board too small relative to mine count for the full safe-zone
    // guarantee — fall back to only protecting safeIndex itself.
    candidates = [];
    for (let i = 0; i < total; i++) if (i !== safeIndex) candidates.push(i);
  }

  for (let i = candidates.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [candidates[i], candidates[j]] = [candidates[j], candidates[i]];
  }
  return new Set(candidates.slice(0, config.mineCount));
}

export function neighborsOf(index: number, width: number, height: number): number[] {
  const x = index % width;
  const y = Math.floor(index / width);
  const out: number[] = [];
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      if (dx === 0 && dy === 0) continue;
      const nx = x + dx;
      const ny = y + dy;
      if (nx >= 0 && nx < width && ny >= 0 && ny < height) out.push(ny * width + nx);
    }
  }
  return out;
}

export function adjacentMineCount(index: number, mines: Set<number>, width: number, height: number): number {
  return neighborsOf(index, width, height).filter((n) => mines.has(n)).length;
}

export interface RevealResult {
  revealed: number[];
  hitMine: boolean;
}

/**
 * Standard flood-fill: a zero-adjacent-mines cell auto-reveals its
 * whole connected zero-region plus the one ring of numbered cells
 * bordering it — but does NOT expand past a numbered cell.
 */
export function revealCell(
  index: number,
  mines: Set<number>,
  alreadyRevealed: Set<number>,
  width: number,
  height: number,
): RevealResult {
  if (mines.has(index)) {
    return { revealed: [index], hitMine: true };
  }
  if (alreadyRevealed.has(index)) {
    return { revealed: [], hitMine: false };
  }

  const revealed = new Set<number>();
  const queue = [index];
  while (queue.length > 0) {
    const current = queue.shift()!;
    if (revealed.has(current) || alreadyRevealed.has(current)) continue;
    revealed.add(current);

    const count = adjacentMineCount(current, mines, width, height);
    if (count === 0) {
      for (const n of neighborsOf(current, width, height)) {
        if (!mines.has(n) && !revealed.has(n) && !alreadyRevealed.has(n)) queue.push(n);
      }
    }
  }

  return { revealed: [...revealed], hitMine: false };
}

export function isWon(totalRevealedCount: number, config: BoardConfig): boolean {
  return totalRevealedCount === config.width * config.height - config.mineCount;
}
