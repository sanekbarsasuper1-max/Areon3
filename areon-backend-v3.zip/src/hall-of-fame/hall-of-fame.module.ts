import { Module } from '@nestjs/common';
import { HallOfFameController } from './hall-of-fame.controller';
import { HallOfFameService } from './hall-of-fame.service';
import { PrismaService } from '../prisma.service';

@Module({
  controllers: [HallOfFameController],
  providers: [HallOfFameService, PrismaService],
  exports: [HallOfFameService],
})
export class HallOfFameModule {}
