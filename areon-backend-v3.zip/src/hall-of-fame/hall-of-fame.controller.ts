import { Controller, Get, Param, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { HallOfFameService } from './hall-of-fame.service';

@Controller('hall-of-fame')
@UseGuards(JwtAuthGuard)
export class HallOfFameController {
  constructor(private readonly service: HallOfFameService) {}

  @Get()
  listAll() {
    return this.service.listAll();
  }

  @Get('record/:key')
  getHistory(@Param('key') key: string) {
    return this.service.getRecordTypeHistory(key);
  }

  @Get('me')
  getMine(@Req() req: any) {
    return this.service.getUserEntries(req.user.sub);
  }
}
