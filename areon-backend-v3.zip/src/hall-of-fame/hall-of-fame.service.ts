import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

export interface RecordTypeSeed {
  key: string;
  category: string;
  title: string;
  icon: string;
  mode: 'SUPERSEDING' | 'ONE_TIME' | 'PER_EVENT';
  higherIsBetter?: boolean;
  isAutomatic: boolean;
}

/**
 * SUPERSEDING/ONE_TIME/PER_EVENT are genuinely different, not one
 * generic "is this better" comparison — see each case's comment below.
 *
 * NOT included here, and stated plainly rather than faked: "biggest
 * comeback" needs parsed teamfight/gold-swing data (see AI Coach's own
 * README section on why that's parse-only, rare) — no detector exists
 * for it. Its row is seeded with isAutomatic=false specifically so the
 * admin panel can still surface it as an intentionally-manual
 * category, not a silently broken one.
 */
export const RECORD_TYPES: RecordTypeSeed[] = [
  { key: 'highest_rating_ever', category: 'RECORDS', title: 'Наивысший рейтинг Areon', icon: '🏆', mode: 'SUPERSEDING', higherIsBetter: true, isAutomatic: true },
  { key: 'longest_minesweeper_win_streak', category: 'STREAKS', title: 'Самая длинная серия побед — Техис: Сапёр', icon: '🔥', mode: 'SUPERSEDING', higherIsBetter: true, isAutomatic: true },
  { key: 'longest_real_match_win_streak', category: 'STREAKS', title: 'Самая длинная серия побед в реальных матчах', icon: '🔥', mode: 'SUPERSEDING', higherIsBetter: true, isAutomatic: true },
  { key: 'most_plus_points_balance', category: 'PLUS_POINTS', title: 'Наибольший баланс Orion Plus', icon: '💎', mode: 'SUPERSEDING', higherIsBetter: true, isAutomatic: true },
  { key: 'fastest_real_match', category: 'MATCHES', title: 'Самый быстрый матч', icon: '⚡', mode: 'SUPERSEDING', higherIsBetter: false, isAutomatic: true },
  { key: 'longest_real_match', category: 'MATCHES', title: 'Самый долгий матч', icon: '⚡', mode: 'SUPERSEDING', higherIsBetter: true, isAutomatic: true },
  { key: 'tournament_champion', category: 'TOURNAMENTS', title: 'Чемпион турнира Areon', icon: '⚔️', mode: 'PER_EVENT', isAutomatic: true },
  { key: 'first_legendary_trial', category: 'LEGENDS', title: 'Первое LEGENDARY испытание Areon', icon: '👑', mode: 'ONE_TIME', isAutomatic: true },
  { key: 'biggest_comeback', category: 'MATCHES', title: 'Самый крупный камбэк', icon: '⚡', mode: 'PER_EVENT', isAutomatic: false },
];

export interface RecordEventInput {
  key: string;
  userId?: string;
  teamId?: string;
  rawValue?: number;
  value: string;
  description?: string;
  relatedMatchId?: string;
  relatedTournamentId?: string;
}

@Injectable()
export class HallOfFameService {
  private readonly logger = new Logger(HallOfFameService.name);

  constructor(private readonly prisma: PrismaService) {}

  async seedRecordTypes() {
    let created = 0;
    for (const seed of RECORD_TYPES) {
      const existing = await this.prisma.hallOfFameRecordType.findUnique({ where: { key: seed.key } });
      if (existing) continue;
      await this.prisma.hallOfFameRecordType.create({ data: seed });
      created += 1;
    }
    return { created };
  }

  /**
   * The single entry point every hook (Minesweeper, Trials,
   * Tournaments, match sync) calls. Fails SOFT on an unknown key or an
   * uncomparable SUPERSEDING attempt — a missing/broken Hall of Fame
   * record type should never break the real work calling it.
   */
  async recordEvent(input: RecordEventInput) {
    const recordType = await this.prisma.hallOfFameRecordType.findUnique({ where: { key: input.key } });
    if (!recordType) {
      this.logger.warn(`recordEvent called with unknown key "${input.key}" — ignored`);
      return null;
    }

    // PER_EVENT: every occurrence gets its own permanent entry, never
    // competing with the others (each tournament's champion is its own
    // entry, not "beating" a previous tournament's winner).
    if (recordType.mode === 'PER_EVENT') {
      return this.createEntry(recordType.id, input, true);
    }

    // ONE_TIME: claimed exactly once, forever. Being first is the
    // whole point — later achievers of the same milestone get nothing.
    if (recordType.mode === 'ONE_TIME') {
      const alreadyClaimed = await this.prisma.hallOfFameEntry.findFirst({ where: { recordTypeId: recordType.id } });
      if (alreadyClaimed) return null;
      return this.createEntry(recordType.id, input, true);
    }

    // SUPERSEDING: one current holder. The old entry stays, flipped to
    // isCurrent=false — requirement 4's "история должна сохранять обоих."
    const current = await this.prisma.hallOfFameEntry.findFirst({ where: { recordTypeId: recordType.id, isCurrent: true } });
    if (current) {
      if (current.rawValue == null || input.rawValue == null) {
        this.logger.warn(`Cannot compare for SUPERSEDING record "${input.key}" — missing rawValue on one side. Refusing to overwrite rather than guessing.`);
        return null;
      }
      const isBetter = recordType.higherIsBetter ? input.rawValue > current.rawValue : input.rawValue < current.rawValue;
      if (!isBetter) return null; // not a new record — the common/expected outcome on most calls
      await this.prisma.hallOfFameEntry.update({ where: { id: current.id }, data: { isCurrent: false } });
    }
    return this.createEntry(recordType.id, input, true);
  }

  private async createEntry(recordTypeId: string, input: RecordEventInput, isCurrent: boolean) {
    return this.prisma.hallOfFameEntry.create({
      data: {
        recordTypeId,
        userId: input.userId,
        teamId: input.teamId,
        value: input.value,
        rawValue: input.rawValue,
        description: input.description,
        relatedMatchId: input.relatedMatchId,
        relatedTournamentId: input.relatedTournamentId,
        isCurrent,
        createdByAdmin: false,
      },
    });
  }

  async listAll() {
    return this.prisma.hallOfFameRecordType.findMany({
      include: {
        entries: {
          where: { OR: [{ isCurrent: true }, { isPinned: true }] },
          include: { user: true, team: true },
          orderBy: { achievedAt: 'desc' },
        },
      },
    });
  }

  async getRecordTypeHistory(key: string) {
    const recordType = await this.prisma.hallOfFameRecordType.findUnique({ where: { key } });
    if (!recordType) return null;
    const entries = await this.prisma.hallOfFameEntry.findMany({
      where: { recordTypeId: recordType.id },
      include: { user: true, team: true },
      orderBy: { achievedAt: 'asc' },
    });
    return { recordType, entries };
  }

  async getUserEntries(userId: string) {
    return this.prisma.hallOfFameEntry.findMany({
      where: { userId, OR: [{ isCurrent: true }, { isPinned: true }] },
      include: { recordType: true },
      orderBy: { achievedAt: 'desc' },
    });
  }
}
