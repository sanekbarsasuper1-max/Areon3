/**
 * Same discipline as coach-prompt-builder.ts: the AI is only ever given
 * real, pre-verified facts, and its response is validated against the
 * real item catalog before ever being trusted.
 */

export interface HeroFacts {
  id: number;
  localizedName: string;
  primaryAttr: string;
  roles: string[];
  popularItems: { itemName: string; winrate: number }[] | null;
}

export interface ItemCatalogEntry {
  id: number;
  name: string;
  dname: string;
}

export interface GeneratedConcept {
  conceptName: string;
  itemNames: string[];
  reasoning: string;
}

const SYSTEM_PROMPT = `Ты — эксперт по Dota 2, придумывающий сборки предметов для функции Areon "Wheel of Fate".

СТРОГИЕ ПРАВИЛА:
1. Каждый предмет в сборке должен быть выбран ТОЛЬКО из предоставленного списка реальных предметов — по его внутреннему имени (поле "name"), точно как в списке. Никогда не придумывай предметы, которых нет в списке.
2. Каждая сборка — ровно 6 предметов.
3. Дай 3 РАЗНЫХ, но одинаково логичных концепции для этого героя (например: магическая/поддержка/агрессивная — но подбирай концепции, реально подходящие именно этому герою, не шаблонно).
4. Объяснение "почему эта сборка" должно ссылаться на конкретные предметы и объяснять их синергию именно с этим героем — не общие фразы.
5. Ответ — строго JSON, без markdown-разметки, без пояснений вне JSON.`;

export function buildWheelPrompt(hero: HeroFacts, catalog: ItemCatalogEntry[]): { system: string; user: string } {
  const catalogForPrompt = catalog.map((i) => ({ name: i.name, displayName: i.dname }));
  const payload = {
    hero: {
      name: hero.localizedName,
      primaryAttribute: hero.primaryAttr,
      roles: hero.roles,
      realRecentPopularItems: hero.popularItems ?? 'Data unavailable — не собрано для этого героя',
    },
    availableItems: catalogForPrompt,
    responseFormat: {
      concepts: [{ conceptName: 'string', itemNames: ['ровно 6 значений поля "name" из availableItems'], reasoning: 'string' }],
    },
  };
  return {
    system: SYSTEM_PROMPT,
    user: `Придумай 3 концепции сборки для этого героя.\n\n${JSON.stringify(payload, null, 2)}`,
  };
}

export interface ValidatedConcept {
  conceptName: string;
  itemIds: number[];
  reasoning: string;
}

/**
 * A concept is only accepted if it has exactly 6 items AND every one
 * resolves to a real item in the catalog. A concept referencing even
 * one invented item name is dropped entirely, not "fixed."
 */
export function validateConcepts(raw: GeneratedConcept[], catalog: ItemCatalogEntry[]): ValidatedConcept[] {
  const byName = new Map(catalog.map((i) => [i.name, i.id]));
  const validated: ValidatedConcept[] = [];

  for (const concept of raw) {
    if (!concept.conceptName || !concept.reasoning) continue;
    if (!Array.isArray(concept.itemNames) || concept.itemNames.length !== 6) continue;

    const itemIds: number[] = [];
    let allValid = true;
    for (const name of concept.itemNames) {
      const id = byName.get(name);
      if (id == null) {
        allValid = false;
        break;
      }
      itemIds.push(id);
    }
    if (!allValid) continue;

    validated.push({ conceptName: concept.conceptName, itemIds, reasoning: concept.reasoning });
  }

  return validated;
}
