import { Module } from '@nestjs/common';
import { WheelOfFateController } from './wheel-of-fate.controller';
import { WheelOfFateService } from './wheel-of-fate.service';
import { PrismaService } from '../prisma.service';

@Module({
  controllers: [WheelOfFateController],
  providers: [WheelOfFateService, PrismaService],
})
export class WheelOfFateModule {}
