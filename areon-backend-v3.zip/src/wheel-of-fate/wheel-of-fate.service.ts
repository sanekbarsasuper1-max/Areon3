import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { buildWheelPrompt, validateConcepts, HeroFacts, ItemCatalogEntry, GeneratedConcept } from './wheel-prompt-builder';

const CONCEPTS_PER_HERO = 3;

@Injectable()
export class WheelOfFateService {
  private readonly logger = new Logger(WheelOfFateService.name);

  constructor(private readonly prisma: PrismaService) {}

  async spin() {
    const heroCount = await this.prisma.hero.count();
    if (heroCount === 0) throw new BadRequestException('No heroes synced yet — run hero sync first');

    const heroes = await this.prisma.hero.findMany({ select: { id: true } });
    const hero = await this.prisma.hero.findUniqueOrThrow({
      where: { id: heroes[Math.floor(Math.random() * heroes.length)].id },
    });

    const concepts = await this.ensureConcepts(hero.id);
    const concept = concepts[Math.floor(Math.random() * concepts.length)];
    const items = await this.prisma.item.findMany({ where: { id: { in: concept.itemIds } } });
    const orderedItems = concept.itemIds.map((id) => items.find((i) => i.id === id)!);

    return { hero, concept: { conceptName: concept.conceptName, reasoning: concept.reasoning }, items: orderedItems };
  }

  private async ensureConcepts(heroId: number) {
    const existing = await this.prisma.heroBuildConcept.findMany({ where: { heroId } });
    if (existing.length > 0) return existing;
    return this.generateConcepts(heroId);
  }

  /**
   * The only place this feature calls an LLM — grounded in real
   * Hero/Item facts, response validated against the real Item catalog
   * before a single row is persisted. Zero usable concepts after
   * validation throws rather than silently persisting nothing — same
   * "fail loud" principle as PatchSyncService refusing to sync from an
   * empty OpenDota response.
   */
  private async generateConcepts(heroId: number) {
    const hero = await this.prisma.hero.findUniqueOrThrow({ where: { id: heroId } });
    const catalog: ItemCatalogEntry[] = await this.prisma.item.findMany({ select: { id: true, name: true, dname: true } });
    if (catalog.length === 0) throw new BadRequestException('No items synced yet — run item sync first');

    const heroFacts: HeroFacts = {
      id: hero.id,
      localizedName: hero.localizedName,
      primaryAttr: hero.primaryAttr,
      roles: hero.roles,
      popularItems: (hero.itemBuildsJson as any)?.items?.map((i: any) => ({ itemName: String(i.itemId), winrate: i.winrate })) ?? null,
    };

    const { system, user } = buildWheelPrompt(heroFacts, catalog);
    const raw = await this.callClaude(system, user);

    const validated = validateConcepts(raw, catalog);
    if (validated.length === 0) {
      throw new Error(`AI generated zero valid build concepts for hero ${hero.localizedName} — every candidate referenced an invalid item or was malformed`);
    }

    const created = [];
    for (const c of validated.slice(0, CONCEPTS_PER_HERO)) {
      created.push(
        await this.prisma.heroBuildConcept.create({
          data: { heroId, conceptName: c.conceptName, itemIds: c.itemIds, reasoning: c.reasoning },
        }),
      );
    }
    this.logger.log(`Generated ${created.length}/${validated.length} valid build concepts for ${hero.localizedName}`);
    return created;
  }

  /**
   * NOT executable in this sandbox — no network access to actually
   * call the Anthropic API here. Reviewed, not run, same honesty flag
   * as AI Coach's identical call pattern (deliberately reuses that
   * same structure, not a second copy of API-calling logic).
   */
  private async callClaude(system: string, user: string): Promise<GeneratedConcept[]> {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      throw new BadRequestException('ANTHROPIC_API_KEY is not set — Wheel of Fate needs it to generate builds. See FIRST_LAUNCH.md.');
    }
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL ?? 'claude-sonnet-4-6',
        max_tokens: 2000,
        system,
        messages: [{ role: 'user', content: user }],
      }),
    });
    if (!res.ok) throw new Error(`Anthropic API call failed: ${res.status} ${await res.text()}`);
    const data = await res.json();
    const text = data.content?.map((b: any) => b.text ?? '').join('') ?? '{}';
    const parsed = JSON.parse(text.trim());
    return parsed.concepts ?? [];
  }
}
