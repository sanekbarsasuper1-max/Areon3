import { Controller, Post, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { WheelOfFateService } from './wheel-of-fate.service';

@Controller('wheel-of-fate')
@UseGuards(JwtAuthGuard)
export class WheelOfFateController {
  constructor(private readonly service: WheelOfFateService) {}

  // Most spins are cheap (cached HeroBuildConcept, no LLM call) once a
  // hero's concepts already exist — but early on, or for a
  // rarely-spun hero, this triggers a real Anthropic call. Throttled
  // less strictly than Coach (which calls the LLM on essentially every
  // request) but still bounded — audit finding CRITICAL #2.
  @Throttle({ default: { limit: 10, ttl: 300_000 } })
  @Post('spin')
  spin() {
    return this.service.spin();
  }
}
