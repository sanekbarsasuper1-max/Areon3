import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ConfigService } from '@nestjs/config';
// Steam uses OpenID 2.0, not OAuth — passport-steam wraps that for us.
import { Strategy } from 'passport-steam';

export interface SteamProfile {
  steamId64: string;
  personaName: string;
  avatarFull: string;
}

@Injectable()
export class SteamStrategy extends PassportStrategy(Strategy, 'steam') {
  constructor(private readonly config: ConfigService) {
    super({
      returnURL: `${config.get('APP_URL')}/auth/steam/return`,
      realm: config.get('APP_URL'),
      apiKey: config.get('STEAM_API_KEY'),
    });
  }

  async validate(
    _identifier: string,
    profile: any,
  ): Promise<SteamProfile> {
    // profile.id is the 64-bit SteamID that everything else (account_id
    // conversion, Prisma lookup) is keyed off of.
    return {
      steamId64: profile.id,
      personaName: profile.displayName,
      avatarFull: profile._json.avatarfull,
    };
  }
}
