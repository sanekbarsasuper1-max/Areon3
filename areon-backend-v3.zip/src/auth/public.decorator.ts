import { SetMetadata } from '@nestjs/common';

// Only /auth/steam and /auth/steam/return should ever carry this — those
// are the two routes a logged-out browser must be able to hit. Everything
// else in the app defaults to requiring a session, enforced globally by
// JwtAuthGuard in app.module.ts rather than a @UseGuards on each
// controller, which is what let /heroes almost ship unguarded.
export const IS_PUBLIC_KEY = 'isPublic';
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);
