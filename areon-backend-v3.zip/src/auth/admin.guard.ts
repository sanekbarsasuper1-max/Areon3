import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

/**
 * Checks User.isAdmin fresh from the database rather than trusting a
 * claim baked into the JWT — the JWT is valid for 30 days, and admin
 * status can change (or be revoked) at any login in between by editing
 * ADMIN_STEAM_ID64. A stale "isAdmin: true" sitting in an old token
 * would defeat the whole point of that env var being the single source
 * of truth.
 */
@Injectable()
export class AdminGuard implements CanActivate {
  constructor(private readonly prisma: PrismaService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const req = context.switchToHttp().getRequest();
    const userId = req.user?.sub;
    if (!userId) throw new ForbiddenException('Not authenticated');

    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user?.isAdmin) throw new ForbiddenException('Admin access required');

    return true;
  }
}
