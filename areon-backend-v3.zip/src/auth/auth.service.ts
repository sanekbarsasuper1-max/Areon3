import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma.service';
import { PlayersService } from '../players/players.service';
import { steamId64ToAccountId32 } from '../common/steam-id.util';
import { SteamProfile } from './steam.strategy';

@Injectable()
export class AuthService {
  constructor(
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
    private readonly prisma: PrismaService,
    private readonly playersService: PlayersService,
  ) {}

  async loginOrCreate(steamProfile: SteamProfile) {
    const accountId32 = steamId64ToAccountId32(steamProfile.steamId64);

    let user = await this.prisma.user.findUnique({
      where: { steamId64: steamProfile.steamId64 },
    });

    if (!user) {
      user = await this.prisma.user.create({
        data: {
          steamId64: steamProfile.steamId64,
          accountId32,
          personaName: steamProfile.personaName,
          avatarFull: steamProfile.avatarFull,
          statsExposed: false,
        },
      });
    }

    // Run the check inline at login too, so the very first redirect
    // already lands on the right screen (profile vs. onboarding) instead
    // of flashing an empty profile for a moment.
    const statsExposed = await this.playersService.checkStatsExposed(accountId32);

    // isAdmin is recomputed from the env var every login, not just set
    // once — this is what makes ADMIN_STEAM_ID64 the single source of
    // truth. Changing the env var and having that person log back in
    // both promotes the new admin AND demotes whoever held it before,
    // rather than accumulating admins over time through some earlier
    // env value.
    const adminSteamId64 = this.config.get<string>('ADMIN_STEAM_ID64');
    const isAdmin = !!adminSteamId64 && steamProfile.steamId64 === adminSteamId64;

    if (statsExposed !== user.statsExposed || isAdmin !== user.isAdmin) {
      user = await this.prisma.user.update({
        where: { id: user.id },
        data: { statsExposed, statsLastCheckedAt: new Date(), isAdmin },
      });
    }

    const accessToken = this.jwt.sign({ sub: user.id, accountId32: user.accountId32, tokenVersion: user.tokenVersion });
    return { accessToken, user };
  }
}
