import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';
import { Request } from 'express';
import { PrismaService } from '../prisma.service';
import { SecurityLogService } from '../security/security-log.service';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(
    config: ConfigService,
    private readonly prisma: PrismaService,
    private readonly securityLog: SecurityLogService,
  ) {
    super({
      // Token lives in an httpOnly cookie set at /auth/steam/return,
      // not in an Authorization header.
      jwtFromRequest: ExtractJwt.fromExtractors([
        (req: Request) => req?.cookies?.areon_token ?? null,
      ]),
      ignoreExpiration: false,
      secretOrKey: config.get('JWT_SECRET'),
    });
  }

  /**
   * Runs on every authenticated request. Checking isBanned here — not
   * just at login — is what makes a ban take effect immediately: the
   * JWT is valid for 30 days, and a banned person shouldn't get to
   * keep using an already-issued token until it happens to expire.
   *
   * tokenVersion works the same way for logout: a token signed with an
   * older tokenVersion than the user's current one is rejected here,
   * regardless of whether it's expired yet — that's the actual
   * invalidation. Clearing the cookie (see AuthController.logout)
   * handles the normal case; this is what stops a copy of the old
   * token from still working after logout.
   *
   * Both rejection paths are logged (security audit MEDIUM #7) — a
   * banned account still trying to use an old token, or a
   * logged-out session still being replayed, are both exactly the
   * kind of event a Security Log exists to surface. Only a type/userId
   * is recorded, never the token itself.
   */
  async validate(payload: { sub: string; accountId32: number; tokenVersion?: number }) {
    const user = await this.prisma.user.findUnique({ where: { id: payload.sub } });
    if (!user || user.isBanned) {
      if (user?.isBanned) {
        await this.securityLog.log('BANNED_ACCESS_ATTEMPT', { userId: user.id });
      }
      throw new UnauthorizedException(user?.isBanned ? 'Account is banned' : 'User not found');
    }
    if ((payload.tokenVersion ?? 0) !== user.tokenVersion) {
      await this.securityLog.log('SESSION_INVALIDATED_ACCESS', { userId: user.id });
      throw new UnauthorizedException('Session has been logged out');
    }
    return payload;
  }
}
