import { Module } from '@nestjs/common';
import { DraftTournamentsService } from './draft-tournaments.service';
import { DraftTournamentsController } from './draft-tournaments.controller';
import { PrismaService } from '../prisma.service';

@Module({
  providers: [DraftTournamentsService, PrismaService],
  controllers: [DraftTournamentsController],
  exports: [DraftTournamentsService],
})
export class DraftTournamentsModule {}
