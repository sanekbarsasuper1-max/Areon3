import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

export interface PrivacySettings {
  profileVisible?: boolean;
  statsVisible?: boolean;
  matchHistoryVisible?: boolean;
  achievementsVisible?: boolean;
  ratingVisible?: boolean;
  friendsListVisible?: boolean;
}

// requirement 5: unset means visible — a user who never opens privacy
// settings sees no behavior change from before this feature existed.
function isVisible(settings: PrivacySettings | null, key: keyof PrivacySettings): boolean {
  return settings?.[key] !== false;
}

@Injectable()
export class PublicProfileService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * requirement 4: everything Areon can SAFELY and LEGALLY show, and
   * requirement 4's own closing line — never a fabricated or guessed
   * value for something unavailable. Every section below either comes
   * straight from data this project already collects (no new Steam/
   * OpenDota calls invented for this) or is explicitly marked
   * unavailable, never silently zero.
   */
  async getProfile(viewerId: string | null, targetId: string) {
    const user = await this.prisma.user.findUnique({ where: { id: targetId } });
    if (!user) throw new NotFoundException('Player not found');

    const settings = (user.privacySettings as PrivacySettings | null) ?? null;
    const isSelf = viewerId === targetId;
    const isFriend = viewerId ? await this.areFriends(viewerId, targetId) : false;
    // Blocked in either direction hides everything except the bare
    // fact of existing — same principle as friends/social platforms
    // generally use, not something invented for this feature alone.
    const blocked = viewerId ? await this.isBlocked(viewerId, targetId) : false;

    const canSeeProfile = isSelf || (!blocked && isVisible(settings, 'profileVisible'));
    if (!canSeeProfile) {
      return { id: user.id, personaName: user.personaName, avatarFull: user.avatarFull, restricted: true as const };
    }

    const canSeeStats = isSelf || (isVisible(settings, 'statsVisible') && user.statsExposed);
    const canSeeMatches = canSeeStats && (isSelf || isVisible(settings, 'matchHistoryVisible'));
    const canSeeAchievements = isSelf || isVisible(settings, 'achievementsVisible');
    const canSeeRating = isSelf || isVisible(settings, 'ratingVisible');
    const canSeeFriends = isSelf || isVisible(settings, 'friendsListVisible');

    const [matches, hallOfFame, equipped, draftHistory] = await Promise.all([
      canSeeMatches
        ? this.prisma.match.findMany({ where: { userId: targetId }, orderBy: { startTime: 'desc' }, take: 20 })
        : Promise.resolve(null),
      canSeeAchievements
        ? this.prisma.hallOfFameEntry.findMany({ where: { userId: targetId, isCurrent: true }, include: { recordType: true } })
        : Promise.resolve(null),
      this.prisma.userInventoryItem.findMany({ where: { userId: targetId, equipped: true }, include: { item: true } }),
      canSeeStats
        ? this.prisma.draftRatingHistoryEntry.findMany({ where: { userId: targetId }, orderBy: { newRating: 'desc' }, take: 1 })
        : Promise.resolve(null),
    ]);

    // Most-played heroes — derived from matches actually stored (never
    // a separate guessed stat), null (not an empty-looking 0-list)
    // when match history itself isn't visible.
    let topHeroes: { heroId: number; games: number; wins: number }[] | null = null;
    if (matches) {
      const byHero = new Map<number, { games: number; wins: number }>();
      for (const m of matches) {
        const isRadiant = m.playerSlot < 128;
        const won = isRadiant ? m.radiantWin : !m.radiantWin;
        const entry = byHero.get(m.heroId) ?? { games: 0, wins: 0 };
        entry.games += 1;
        if (won) entry.wins += 1;
        byHero.set(m.heroId, entry);
      }
      topHeroes = [...byHero.entries()]
        .map(([heroId, v]) => ({ heroId, ...v }))
        .sort((a, b) => b.games - a.games)
        .slice(0, 5);
    }

    const winLoss = matches
      ? matches.reduce(
          (acc, m) => {
            const isRadiant = m.playerSlot < 128;
            const won = isRadiant ? m.radiantWin : !m.radiantWin;
            return won ? { ...acc, wins: acc.wins + 1 } : { ...acc, losses: acc.losses + 1 };
          },
          { wins: 0, losses: 0 },
        )
      : null;

    return {
      restricted: false as const,
      id: user.id,
      personaName: user.personaName,
      avatarFull: user.avatarFull,
      accountId32: user.accountId32,
      steamProfileUrl: `https://steamcommunity.com/profiles/${user.steamId64}`,
      online: !!user.lastSeenAt && Date.now() - user.lastSeenAt.getTime() < 60_000,
      // null throughout = "not available/not visible", never a fake 0 — requirement 4's own closing line.
      siteRating: canSeeRating ? user.siteRating : null,
      draftRating: canSeeRating ? user.draftRating : null,
      orionRating: canSeeRating ? user.rating : null,
      matches: matches?.map((m) => ({
        matchId: m.matchId.toString(), heroId: m.heroId, startTime: m.startTime,
        won: (m.playerSlot < 128) === m.radiantWin, durationSec: m.durationSec, kills: m.kills, deaths: m.deaths, assists: m.assists,
      })) ?? null,
      winLoss,
      winRate: winLoss && winLoss.wins + winLoss.losses > 0 ? Math.round((winLoss.wins / (winLoss.wins + winLoss.losses)) * 100) : null,
      topHeroes,
      hallOfFame: hallOfFame?.map((h) => ({ title: h.recordType.title, icon: h.recordType.icon, value: h.value, achievedAt: h.achievedAt })) ?? null,
      equippedItems: equipped.map((e) => ({ name: e.item.name, iconEmoji: e.item.iconEmoji, iconUrl: e.item.iconUrl, rarity: e.item.rarity })),
      draftHighScore: draftHistory?.[0]?.newRating ?? null,
      friendsVisible: canSeeFriends,
      isFriend,
      isSelf,
    };
  }

  async areFriends(userId: string, otherId: string) {
    const rel = await this.prisma.friendRequest.findFirst({
      where: { status: 'ACCEPTED', OR: [{ fromUserId: userId, toUserId: otherId }, { fromUserId: otherId, toUserId: userId }] },
    });
    return !!rel;
  }

  async isBlocked(userId: string, otherId: string) {
    const rel = await this.prisma.block.findFirst({
      where: { OR: [{ blockerId: userId, blockedId: otherId }, { blockerId: otherId, blockedId: userId }] },
    });
    return !!rel;
  }

  async getPrivacySettings(userId: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    return (user?.privacySettings as PrivacySettings | null) ?? {};
  }

  async updatePrivacySettings(userId: string, partial: PrivacySettings) {
    const current = await this.getPrivacySettings(userId);
    const merged = { ...current, ...partial };
    await this.prisma.user.update({ where: { id: userId }, data: { privacySettings: merged as any } });
    return merged;
  }
}
