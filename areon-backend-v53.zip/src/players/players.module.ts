import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { PlayersService } from './players.service';
import { PlayersController } from './players.controller';
import { PublicProfileService } from './public-profile.service';
import { PublicProfileController } from './public-profile.controller';
import { PrismaService } from '../prisma.service';
import { MonitoringModule } from '../monitoring/monitoring.module';

@Module({
  imports: [HttpModule, MonitoringModule],
  providers: [PlayersService, PublicProfileService, PrismaService],
  controllers: [PlayersController, PublicProfileController],
  exports: [PlayersService],
})
export class PlayersModule {}
