import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common';
import { PublicProfileService } from './public-profile.service';

@Controller()
export class PublicProfileController {
  constructor(private readonly profiles: PublicProfileService) {}

  @Get('players/:id/profile')
  getProfile(@Req() req: any, @Param('id') id: string) {
    return this.profiles.getProfile(req.user?.sub ?? null, id);
  }

  @Get('me/privacy')
  getMyPrivacy(@Req() req: any) {
    return this.profiles.getPrivacySettings(req.user.sub);
  }

  @Post('me/privacy')
  updateMyPrivacy(@Req() req: any, @Body() body: Record<string, boolean>) {
    return this.profiles.updatePrivacySettings(req.user.sub, body);
  }
}
