import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { NotificationsService } from '../notifications/notifications.service';

@Injectable()
export class FriendsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly notifications: NotificationsService,
  ) {}

  async sendRequest(fromUserId: string, toUserId: string) {
    if (fromUserId === toUserId) throw new BadRequestException("You can't friend yourself");

    const blocked = await this.prisma.block.findFirst({
      where: { OR: [{ blockerId: fromUserId, blockedId: toUserId }, { blockerId: toUserId, blockedId: fromUserId }] },
    });
    if (blocked) throw new ForbiddenException('This user is unavailable');

    // Either direction already has a row — covers "already sent",
    // "already friends", and "they already sent you one" (which
    // should be accepted, not duplicated) in one check.
    const existing = await this.prisma.friendRequest.findFirst({
      where: {
        OR: [{ fromUserId, toUserId }, { fromUserId: toUserId, toUserId: fromUserId }],
      },
    });
    if (existing) {
      if (existing.status === 'ACCEPTED') throw new BadRequestException('Already friends');
      if (existing.fromUserId === toUserId && existing.status === 'PENDING') {
        // They'd already sent one — this "send" is really an accept.
        return this.respond(fromUserId, existing.id, true);
      }
      throw new BadRequestException('Friend request already pending');
    }

    const request = await this.prisma.friendRequest.create({ data: { fromUserId, toUserId } });
    const from = await this.prisma.user.findUnique({ where: { id: fromUserId } });
    this.notifications.create(toUserId, 'friend_request', { requestId: request.id, fromUserId, fromName: from?.personaName }).catch(() => {});
    return request;
  }

  async respond(userId: string, requestId: string, accept: boolean) {
    const request = await this.prisma.friendRequest.findUnique({ where: { id: requestId } });
    if (!request || request.toUserId !== userId) throw new NotFoundException('Request not found');
    if (request.status !== 'PENDING') throw new BadRequestException('Request already resolved');

    const updated = await this.prisma.friendRequest.update({
      where: { id: requestId },
      data: { status: accept ? 'ACCEPTED' : 'DECLINED', respondedAt: new Date() },
    });
    if (accept) {
      const me = await this.prisma.user.findUnique({ where: { id: userId } });
      this.notifications.create(request.fromUserId, 'friend_accepted', { byUserId: userId, byName: me?.personaName }).catch(() => {});
    }
    return updated;
  }

  async remove(userId: string, friendId: string) {
    const rel = await this.prisma.friendRequest.findFirst({
      where: {
        status: 'ACCEPTED',
        OR: [{ fromUserId: userId, toUserId: friendId }, { fromUserId: friendId, toUserId: userId }],
      },
    });
    if (!rel) return { removed: false };
    await this.prisma.friendRequest.delete({ where: { id: rel.id } });
    return { removed: true };
  }

  async block(userId: string, targetId: string) {
    if (userId === targetId) throw new BadRequestException("You can't block yourself");
    // Blocking also ends any existing friendship/request between them —
    // a block is a stronger signal than "still friends".
    await this.prisma.friendRequest.deleteMany({
      where: { OR: [{ fromUserId: userId, toUserId: targetId }, { fromUserId: targetId, toUserId: userId }] },
    });
    return this.prisma.block.upsert({
      where: { blockerId_blockedId: { blockerId: userId, blockedId: targetId } },
      create: { blockerId: userId, blockedId: targetId },
      update: {},
    });
  }

  async unblock(userId: string, targetId: string) {
    await this.prisma.block.deleteMany({ where: { blockerId: userId, blockedId: targetId } });
    return { unblocked: true };
  }

  async listFriends(userId: string) {
    const accepted = await this.prisma.friendRequest.findMany({
      where: { status: 'ACCEPTED', OR: [{ fromUserId: userId }, { toUserId: userId }] },
      include: { fromUser: true, toUser: true },
    });
    return accepted.map((r) => {
      const friend = r.fromUserId === userId ? r.toUser : r.fromUser;
      const isOnline = !!friend.lastSeenAt && Date.now() - friend.lastSeenAt.getTime() < 60_000;
      return {
        id: friend.id,
        personaName: friend.personaName,
        avatarFull: friend.avatarFull,
        siteRating: friend.siteRating,
        online: isOnline,
      };
    });
  }

  async listIncomingRequests(userId: string) {
    const requests = await this.prisma.friendRequest.findMany({
      where: { toUserId: userId, status: 'PENDING' },
      include: { fromUser: true },
      orderBy: { createdAt: 'desc' },
    });
    return requests.map((r) => ({
      id: r.id,
      fromUserId: r.fromUserId,
      personaName: r.fromUser.personaName,
      avatarFull: r.fromUser.avatarFull,
      createdAt: r.createdAt,
    }));
  }

  async listOutgoingRequests(userId: string) {
    return this.prisma.friendRequest.findMany({ where: { fromUserId: userId, status: 'PENDING' } });
  }

  async search(userId: string, query: string) {
    if (!query || query.trim().length < 2) return [];
    const blockedByMe = (await this.prisma.block.findMany({ where: { blockerId: userId }, select: { blockedId: true } })).map((b) => b.blockedId);
    const blockedMe = (await this.prisma.block.findMany({ where: { blockedId: userId }, select: { blockerId: true } })).map((b) => b.blockerId);
    const excluded = [...new Set([userId, ...blockedByMe, ...blockedMe])];

    const users = await this.prisma.user.findMany({
      where: {
        id: { notIn: excluded },
        OR: [
          { personaName: { contains: query, mode: 'insensitive' } },
          { accountId32: Number.isFinite(Number(query)) ? Number(query) : -1 },
        ],
      },
      take: 20,
      select: { id: true, personaName: true, avatarFull: true, siteRating: true },
    });
    return users;
  }
}
