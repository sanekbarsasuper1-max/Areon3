import { Body, Controller, Delete, Get, Param, Post, Query, Req } from '@nestjs/common';
import { FriendsService } from './friends.service';

@Controller('friends')
export class FriendsController {
  constructor(private readonly friends: FriendsService) {}

  @Get()
  list(@Req() req: any) {
    return this.friends.listFriends(req.user.sub);
  }

  @Get('requests')
  requests(@Req() req: any) {
    return this.friends.listIncomingRequests(req.user.sub);
  }

  @Get('requests/outgoing')
  outgoingRequests(@Req() req: any) {
    return this.friends.listOutgoingRequests(req.user.sub);
  }

  @Get('search')
  search(@Req() req: any, @Query('q') q: string) {
    return this.friends.search(req.user.sub, q);
  }

  @Post('request/:userId')
  sendRequest(@Req() req: any, @Param('userId') userId: string) {
    return this.friends.sendRequest(req.user.sub, userId);
  }

  @Post('requests/:id/accept')
  accept(@Req() req: any, @Param('id') id: string) {
    return this.friends.respond(req.user.sub, id, true);
  }

  @Post('requests/:id/decline')
  decline(@Req() req: any, @Param('id') id: string) {
    return this.friends.respond(req.user.sub, id, false);
  }

  @Delete(':userId')
  remove(@Req() req: any, @Param('userId') userId: string) {
    return this.friends.remove(req.user.sub, userId);
  }

  @Post('block/:userId')
  block(@Req() req: any, @Param('userId') userId: string) {
    return this.friends.block(req.user.sub, userId);
  }

  @Post('unblock/:userId')
  unblock(@Req() req: any, @Param('userId') userId: string) {
    return this.friends.unblock(req.user.sub, userId);
  }
}
