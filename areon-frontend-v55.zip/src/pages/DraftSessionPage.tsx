import { useEffect, useMemo, useRef, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { io, Socket } from 'socket.io-client';
import { api, DraftSession, Hero, DraftEvent, DraftRating, CompositionScore } from '../api';
import { useAudio } from '../audio/AudioContext';

const ACTION_LABEL: Record<'ban' | 'pick', string> = { ban: 'BAN', pick: 'PICK' };
const SIDE_LABEL: Record<'FIRST_PICK' | 'SECOND_PICK', string> = {
  FIRST_PICK: 'FIRST PICK',
  SECOND_PICK: 'SECOND PICK',
};

export function DraftSessionPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [session, setSession] = useState<DraftSession | null>(null);
  const [meId, setMeId] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [heroes, setHeroes] = useState<Hero[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [previewHeroId, setPreviewHeroId] = useState<number | null>(null);
  const [remainingSec, setRemainingSec] = useState<number | null>(null);
  const [joining, setJoining] = useState(false);
  const [rating, setRating] = useState<DraftRating | null>(null);
  const [myPositions, setMyPositions] = useState<Record<number, number>>({});
  const [ratingChange, setRatingChange] = useState<{ won: boolean; oldRating: number; change: number; newRating: number } | null>(null);
  const timeoutInFlight = useRef(false);
  const { playSFX } = useAudio();
  const openedSfxPlayed = useRef(false);
  const prevActionsLength = useRef<number | null>(null);
  const prevPhaseAction = useRef<'ban' | 'pick' | null>(null);
  const prevStatus = useRef<string | null>(null);
  const timerTensionPlayed = useRef(false);
  const lastCriticalSecond = useRef<number | null>(null);

  async function load() {
    if (!id) return;
    const [s, h, me] = await Promise.all([api.draftSession(id), api.heroes(), api.me()]);
    setSession(s);
    setHeroes(h);
    setMeId(me.id);
    setIsAdmin(me.isAdmin);
    timeoutInFlight.current = false;
    if (s.status === 'completed') {
      // Whatever the live in-progress comparison last held is now
      // stale intent, not a result — the real post-draft analysis
      // only exists once positions are confirmed (see submitPositions).
      setRating(null);
    }
    if (!openedSfxPlayed.current) {
      openedSfxPlayed.current = true;
      playSFX('nav_draft_open');
    }
    // Live comparison while actively drafting only — once the draft is
    // done, the final analysis is deliberately withheld until the
    // player confirms their position assignment (submitPositions
    // fetches it explicitly then); showing it immediately on
    // completion would be exactly the "preliminary score before
    // positions are locked in" the brief asked to stop doing.
    if (s.status !== 'completed' && s.actions.length > 0) {
      api.draftRating(id).then(setRating).catch(() => {});
    }
  }

  // Admin-only: there is no player-facing undo, per the product
  // decision — this exists so an admin watching a game live can correct
  // it, not for players to take back their own picks/bans.
  async function adminUndo() {
    if (!id) return;
    if (!confirm('Отменить последнее действие в этом драфте?')) return;
    await api.adminUndoDraft(id);
    playSFX('ui_confirm');
    load();
  }

  useEffect(() => {
    // Synchronous reset the instant `id` changes — before load()'s
    // async fetch resolves — so navigating from one finished draft
    // straight into a new session (client-side routing, no full page
    // reload) can never show the PREVIOUS session's already-computed
    // result screen for even one frame on the new session.
    setRating(null);
    setRatingChange(null);
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  // Friend/matchmaking sessions have two independent browsers acting on
  // the same session — this used to be a 2s poll; now it's a real
  // WebSocket subscription, one room per session, joined only after the
  // server verifies (via the same areon_token cookie the REST API
  // trusts) that this user is actually one of the two participants.
  // Not needed for solo ('self') play, where the only actor is the
  // person already looking at the screen.
  useEffect(() => {
    if (!id || !session || session.mode !== 'free' || session.opponentType === 'self') return;
    if (session.status === 'completed' || session.status === 'cancelled') return;

    const socket: Socket = io(import.meta.env.VITE_API_URL ?? 'http://localhost:3000', {
      withCredentials: true,
    });
    socket.emit('join', id);
    socket.on('draft:update', (updated: DraftSession) => {
      setSession(updated);
      if (updated.status === 'completed') {
        setRating(null);
      } else if (updated.actions.length > 0 && id) {
        api.draftRating(id).then(setRating).catch(() => {});
      }
    });

    return () => {
      socket.disconnect();
    };
  }, [id, session?.mode, session?.opponentType, session?.status]);

  // --- Timer: ticks locally, but the actual timeout is only ever
  // applied by the backend re-checking elapsed time (main + reserve)
  // against currentStepStartedAt — this loop just decides when to ask
  // it to. Once the main per-action allowance is spent, the countdown
  // falls through into that side's reserve pool instead of stopping —
  // that's the confirmed mechanic, not just a cosmetic detail.
  const [reserveInfo, setReserveInfo] = useState<{ inReserve: boolean; remaining: number } | null>(null);
  useEffect(() => {
    if (!session || session.status !== 'in_progress' || session.mode !== 'free') {
      setRemainingSec(null);
      setReserveInfo(null);
      return;
    }
    const nextStep = session.sequence[session.actions.length];
    if (!nextStep) return;

    const startedAt = new Date(session.currentStepStartedAt).getTime();
    const sideReserve = nextStep.side === 'FIRST_PICK' ? session.reserveFirstSec : session.reserveSecondSec;

    const checkTimerSfx = (activeRemaining: number) => {
      // Fires once when crossing under 10s (per-step, not per-tick —
      // timerTensionPlayed resets whenever the step itself changes,
      // below). Under 5s, fires once per whole second as it counts
      // down (1 beep per second, not a continuous alarm).
      if (activeRemaining <= 10 && !timerTensionPlayed.current) {
        timerTensionPlayed.current = true;
        playSFX('timer_tension');
      }
      const wholeSecond = Math.ceil(activeRemaining);
      if (activeRemaining <= 5 && activeRemaining > 0 && lastCriticalSecond.current !== wholeSecond) {
        lastCriticalSecond.current = wholeSecond;
        playSFX('timer_critical');
      }
    };

    const tick = () => {
      const elapsed = (Date.now() - startedAt) / 1000;
      const mainRemaining = Math.max(0, nextStep.timeLimitSec - elapsed);
      setRemainingSec(mainRemaining);

      if (elapsed <= nextStep.timeLimitSec) {
        setReserveInfo(null);
        checkTimerSfx(mainRemaining);
        return;
      }

      const overflow = elapsed - nextStep.timeLimitSec;
      const reserveRemaining = Math.max(0, sideReserve - overflow);
      setReserveInfo({ inReserve: true, remaining: reserveRemaining });
      checkTimerSfx(reserveRemaining);

      if (reserveRemaining <= 0 && !timeoutInFlight.current && id) {
        timeoutInFlight.current = true;
        timerTensionPlayed.current = false;
        lastCriticalSecond.current = null;
        playSFX('timer_expired');
        api.draftTimeout(id).then(load).catch(() => { timeoutInFlight.current = false; });
      }
    };
    tick();
    const interval = setInterval(tick, 250);
    return () => clearInterval(interval);
  }, [session, id]);

  // Reset the per-step tension/critical trackers whenever the step
  // itself changes (new action recorded) — otherwise timerTensionPlayed
  // would stay "already played" forever after the very first step.
  useEffect(() => {
    timerTensionPlayed.current = false;
    lastCriticalSecond.current = null;
  }, [session?.actions.length]);

  // One effect, watching session.actions, covers BOTH this user's own
  // moves (act()) and moves that arrive via the WebSocket (opponent or
  // bot) — a single source of truth for "a new action just happened",
  // rather than duplicating SFX-triggering logic in three call sites.
  useEffect(() => {
    if (!session) return;
    const newLength = session.actions.length;
    if (prevActionsLength.current === null) {
      // First load of this session — don't replay sounds for history
      // that already happened before this page was opened.
      prevActionsLength.current = newLength;
      prevPhaseAction.current = session.sequence[newLength]?.action ?? null;
      return;
    }
    if (newLength === prevActionsLength.current) return;

    for (let i = prevActionsLength.current; i < newLength; i++) {
      const action = session.actions[i];
      const actingUserId =
        action.side === 'FIRST_PICK'
          ? session.createdByUserId
          : session.opponentType === 'friend' || session.opponentType === 'matchmaking' || session.opponentType === 'tournament'
          ? session.participantSecondUserId
          : session.opponentType === 'ai'
          ? null // the bot — never "me"
          : session.createdByUserId; // 'self' mode: the one person

      if (action.action === 'ban') {
        // Deliberately silent — the product brief asked for the ban
        // sound to be removed entirely, while every other draft sound
        // (turn start, pick, timer states, draft complete) stays.
      } else if (actingUserId === meId) {
        playSFX('draft_pick_self');
      } else {
        playSFX('draft_pick_enemy');
      }
      playSFX('draft_step_transition');
    }

    const nextAction = session.sequence[newLength]?.action ?? null;
    if (nextAction && nextAction !== prevPhaseAction.current) {
      playSFX(nextAction === 'ban' ? 'draft_phase_ban_start' : 'draft_phase_pick_start');
    }
    prevPhaseAction.current = nextAction;
    prevActionsLength.current = newLength;
  }, [session, meId, playSFX]);

  useEffect(() => {
    if (!session) return;
    if (prevStatus.current === null) {
      prevStatus.current = session.status;
      return;
    }
    if (session.status === 'completed' && prevStatus.current !== 'completed') {
      playSFX('draft_complete');
    }
    prevStatus.current = session.status;
  }, [session?.status, playSFX]);

  useEffect(() => {
    if (!id || session?.status !== 'completed') return;
    api.draftMyRatingChange(id).then(setRatingChange).catch(() => {});
  }, [id, session?.status]);

  const heroesById = useMemo(() => Object.fromEntries(heroes.map((h) => [h.id, h])), [heroes]);

  const availableRoles = useMemo(() => {
    const set = new Set<string>();
    heroes.forEach((h) => (h.roles ?? []).forEach((r) => set.add(r)));
    return Array.from(set).sort();
  }, [heroes]);

  async function act(heroId: number) {
    if (!id) return;
    setError(null);
    try {
      const updated = await api.draftAction(id, heroId);
      setSession(updated);
      // Same reset the socket handler already does for two-player
      // drafts (see the join-effect above) — missing here meant the
      // LAST pick/ban, the one that actually completes the draft,
      // left whatever live in-progress score was last fetched still
      // showing, visible before positions were ever confirmed. This
      // path is what self/ai practice sessions actually go through
      // (they skip the socket connection entirely), so this was the
      // one that mattered most.
      if (updated.status === 'completed') {
        setRating(null);
      }
    } catch {
      setError('Не удалось выполнить действие — герой уже занят, недоступен в CM, или сейчас не ваш ход.');
      playSFX('ui_error');
    }
  }

  async function restart() {
    const fresh = await api.createFreeDraft();
    navigate(`/draft-trainer/${fresh.id}`);
  }

  async function rematch() {
    if (!session) return;
    // Same Radiant/Dire assignment as the draft just finished — a true
    // "play it again" rather than a fresh random coin flip.
    const fresh = await api.createFreeDraft({ radiantSide: session.radiantSide });
    navigate(`/draft-trainer/${fresh.id}`);
  }

  async function joinLobby() {
    if (!id) return;
    setJoining(true);
    try {
      const updated = await api.joinDraft(id);
      setSession(updated);
    } catch {
      setError('Не удалось присоединиться — возможно, место уже занято.');
    } finally {
      setJoining(false);
    }
  }

  async function cancelWaiting() {
    if (!id) return;
    await api.cancelWaiting(id);
    navigate('/draft-trainer');
  }

  if (!session) return <p style={{ padding: 24 }}>Загрузка…</p>;

  const isFree = session.mode === 'free';
  const isDone = session.status === 'completed';
  const isWaiting = session.status === 'waiting_for_opponent';
  const isCancelled = session.status === 'cancelled';
  const isTwoPlayerMode = session.opponentType === 'friend' || session.opponentType === 'matchmaking' || session.opponentType === 'tournament';
  const usedHeroIds = new Set(session.actions.filter((a) => a.heroId != null).map((a) => a.heroId));
  const currentStepIndex = session.actions.length; // 0-indexed position of the upcoming step
  const nextStep = session.sequence[currentStepIndex];

  // Mirrors the backend's participantForSide: who (if any real human)
  // owns the acting side right now.
  const turnUserId =
    session.opponentType === 'ai'
      ? nextStep?.side === session.aiSide
        ? null
        : session.createdByUserId
      : isTwoPlayerMode
      ? nextStep?.side === 'FIRST_PICK'
        ? session.createdByUserId
        : session.participantSecondUserId
      : session.createdByUserId;
  const isMyTurn = meId != null && turnUserId === meId;
  const iAmParticipant = meId === session.createdByUserId || meId === session.participantSecondUserId;
  const isVsBot = session.opponentType === 'ai';

  const direSide = session.radiantSide === 'FIRST_PICK' ? 'SECOND_PICK' : 'FIRST_PICK';
  const teamLabel = (side: 'FIRST_PICK' | 'SECOND_PICK') => (side === session.radiantSide ? 'RADIANT' : 'DIRE');
  const teamColor = (side: 'FIRST_PICK' | 'SECOND_PICK') =>
    side === session.radiantSide ? 'var(--accent)' : 'var(--danger)';

  const radiantPicks = session.actions.filter((a) => a.action === 'pick' && a.side === session.radiantSide);
  const direPicks = session.actions.filter((a) => a.action === 'pick' && a.side === direSide);
  const allBans = session.actions.filter((a) => a.action === 'ban');

  const mySide: 'FIRST_PICK' | 'SECOND_PICK' | null =
    // Solo practice (self/ai) has no real second participant — Radiant
    // is the natural "my team" default there (it's shown first
    // everywhere else in this UI), rather than whichever side
    // happened to draft first, which is meaningless to a solo player
    // and could show them the wrong team's heroes on the position map.
    session.opponentType === 'self' || session.opponentType === 'ai' ? session.radiantSide
    : meId === session.createdByUserId ? 'FIRST_PICK' : meId === session.participantSecondUserId ? 'SECOND_PICK' : null;
  const myPicks = mySide === session.radiantSide ? radiantPicks : mySide === direSide ? direPicks : [];
  const myPositionsSaved = mySide === session.radiantSide ? session.radiantPositions : mySide === direSide ? session.direPositions : null;

  async function submitPositions() {
    if (!id) return;
    try {
      const updated = await api.draftSetPositions(id, myPositions);
      setSession(updated);
      // This is the actual "Завершить драфт" moment — the full
      // analysis (score, synergy, lane matchups, everything) is
      // computed and shown for the first time only now, not the
      // instant the draft itself finished.
      api.draftRating(id).then(setRating).catch(() => {});
    } catch {
      setError('Не удалось сохранить позиции — убедитесь, что каждому герою назначена своя позиция.');
    }
  }
  const radiantBans = allBans.filter((a) => a.side === session.radiantSide);
  const direBans = allBans.filter((a) => a.side === direSide);

  const filteredHeroes = heroes.filter((h) => {
    if (search && !h.localizedName.toLowerCase().includes(search.toLowerCase())) return false;
    if (roleFilter !== 'all' && !(h.roles ?? []).includes(roleFilter)) return false;
    return true;
  });

  // OpenDota's primary_attr values: 'str' | 'agi' | 'int' | 'all'
  // ('all' = Universal, not "no filter" — a real attribute value, not
  // a sentinel). Grouped into columns the same way the actual Dota 2
  // hero grid separates them.
  const ATTR_GROUPS: { key: string; label: string; color: string }[] = [
    { key: 'str', label: 'СИЛА', color: '#c0524f' },
    { key: 'agi', label: 'ЛОВКОСТЬ', color: '#4e9c5e' },
    { key: 'int', label: 'ИНТЕЛЛЕКТ', color: '#4a7fc4' },
    { key: 'all', label: 'УНИВЕРСАЛЬНЫЕ', color: '#b98fd1' },
  ];

  return (
    <div style={{ maxWidth: 1400, margin: '0 auto', padding: '40px 48px 100px' }}>
      <Link to="/draft-trainer" className="button-ghost" style={{ textDecoration: 'none' }}>← Draft Trainer</Link>

      <p style={{ fontSize: 19, fontWeight: 500, margin: '16px 0 4px' }}>
        {isFree ? "Свободный драфт · Captain's Mode" : 'Просмотр про-драфта'}
      </p>
      {isWaiting && (
        <div className="card" style={{ marginBottom: 16 }}>
          {meId === session.createdByUserId ? (
            <>
              <p style={{ fontSize: 15, fontWeight: 500, margin: '0 0 6px' }}>
                {session.opponentType === 'matchmaking' ? 'Ищем соперника…' : 'Ждём, пока соперник примет приглашение'}
              </p>
              <button className="button-ghost" onClick={cancelWaiting}>Отменить</button>
            </>
          ) : (
            <>
              <p style={{ fontSize: 15, fontWeight: 500, margin: '0 0 6px' }}>Вас пригласили в драфт</p>
              <button className="button-primary" onClick={joinLobby} disabled={joining}>
                {joining ? 'Присоединяемся…' : 'Присоединиться'}
              </button>
            </>
          )}
        </div>
      )}

      {isCancelled && (
        <div className="card" style={{ marginBottom: 16 }}>
          <p style={{ fontSize: 15, color: 'var(--text-secondary)', margin: 0 }}>Этот драфт был отменён.</p>
        </div>
      )}

      {isFree && !isWaiting && (
        <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '0 0 16px' }}>
          Правила: {session.rulesVersion} — фазы банов/пиков подтверждены, точный порядок ходов внутри фазы — реконструкция
        </p>
      )}

        {isDone && (
          <div className="card" style={{ marginBottom: 16, textAlign: 'center' }}>
            <p style={{ fontSize: 16, fontWeight: 500, color: 'var(--accent)', margin: 0, letterSpacing: 1 }}>DRAFT COMPLETE</p>
          </div>
        )}

        {isDone && mySide && myPicks.length === 5 && !myPositionsSaved && (
          <PositionMap myPicks={myPicks} heroesById={heroesById} myPositions={myPositions} setMyPositions={setMyPositions} onConfirm={submitPositions} />
        )}

        {isDone && rating && myPositionsSaved && (
          <div style={{ marginBottom: 20 }}>
            <div
              className="card"
              style={{
                marginBottom: 16, textAlign: 'center', padding: '20px 16px',
                border: `1px solid ${rating.estimatedOutcome.strongerSide === 'radiant' ? 'var(--accent)' : 'var(--danger)'}`,
              }}
            >
              <p style={{ fontSize: 11, color: 'var(--text-muted)', letterSpacing: 1.5, margin: '0 0 10px' }}>
                ОЦЕНКА ПО КАЧЕСТВУ СОСТАВА · НЕ РЕЗУЛЬТАТ РЕАЛЬНОЙ ИГРЫ
              </p>
              <p style={{ fontSize: 15, margin: '0 0 4px' }}>
                <span style={{ color: 'var(--accent)' }}>RADIANT — {rating.radiant.total}</span>
                {'  ·  '}
                <span style={{ color: 'var(--danger)' }}>DIRE — {rating.dire.total}</span>
              </p>
              <p style={{
                fontSize: 24, fontWeight: 700, margin: '8px 0 0',
                color: rating.estimatedOutcome.strongerSide === 'radiant' ? 'var(--accent)' : 'var(--danger)',
              }}>
                🏆 {rating.estimatedOutcome.strongerSide === 'radiant' ? 'RADIANT' : 'DIRE'}
              </p>
              <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '6px 0 0' }}>
                Разница: +{Math.abs(rating.estimatedOutcome.scoreDiff)} очков — по ролям, разнообразию и контрпикам,
                не прогноз того, кто реально выиграл бы матч.
              </p>
              {ratingChange && (
                <p style={{
                  fontSize: 14, margin: '10px 0 0', paddingTop: 10, borderTop: '1px solid var(--border)',
                  color: ratingChange.won ? 'var(--accent)' : 'var(--danger)',
                }}>
                  Drafter Rating: {ratingChange.oldRating} → {ratingChange.newRating} ({ratingChange.change > 0 ? '+' : ''}{ratingChange.change})
                </p>
              )}
            </div>

            <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 8px' }}>
              Оценка состава — эвристика по ролям/атрибутам/контрпикам, не прогноз победы
            </p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
              <RatingCard label="RADIANT" color="var(--accent)" score={rating.radiant} heroesById={heroesById} />
              <RatingCard label="DIRE" color="var(--danger)" score={rating.dire} heroesById={heroesById} />
            </div>

            <ComparisonTable radiant={rating.comparison.radiant} dire={rating.comparison.dire} />

            <div className="card" style={{ marginBottom: 12 }}>
              <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 10px' }}>
                Вероятные позиции — эвристика по тегам ролей, не точный факт
              </p>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                <div>
                  {rating.positions.radiant.map((p) => (
                    <p key={p.position} style={{ fontSize: 13, margin: '0 0 6px' }}>
                      <span style={{ color: 'var(--accent)' }}>P{p.position} {p.label}</span> — {heroesById[p.heroId]?.localizedName ?? p.heroId}
                    </p>
                  ))}
                </div>
                <div>
                  {rating.positions.dire.map((p) => (
                    <p key={p.position} style={{ fontSize: 13, margin: '0 0 6px' }}>
                      <span style={{ color: 'var(--danger)' }}>P{p.position} {p.label}</span> — {heroesById[p.heroId]?.localizedName ?? p.heroId}
                    </p>
                  ))}
                </div>
              </div>
            </div>

            {rating.laneMatchups.length > 0 && (
              <div className="card" style={{ marginBottom: 12 }}>
                <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 10px' }}>
                  Противостояние по позициям — по реальным данным контрпиков, где они синхронизированы
                </p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {rating.laneMatchups.map((m) => (
                    <div key={m.position} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
                      <span style={{ width: 130, color: 'var(--text-muted)', fontSize: 11 }}>P{m.position} {m.label}</span>
                      <span style={{ color: m.favors === 'radiant' ? 'var(--accent)' : undefined }}>{heroesById[m.radiantHeroId]?.localizedName ?? m.radiantHeroId}</span>
                      <span style={{ color: 'var(--text-muted)' }}>vs</span>
                      <span style={{ color: m.favors === 'dire' ? 'var(--danger)' : undefined }}>{heroesById[m.direHeroId]?.localizedName ?? m.direHeroId}</span>
                      <span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--text-muted)' }}>
                        {!m.hasData ? 'нет данных' : m.favors === 'even' ? 'паритет' : m.favors === 'radiant' ? '→ Radiant' : '→ Dire'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 12 }}>
              <SynergyPentagon title="RADIANT SYNERGY" picks={radiantPicks} heroesById={heroesById} pairs={rating.synergyFull.radiant} color="var(--accent)" />
              <SynergyPentagon title="DIRE SYNERGY" picks={direPicks} heroesById={heroesById} pairs={rating.synergyFull.dire} color="var(--danger)" />
            </div>

            {(rating.synergy.radiant.length > 0 || rating.synergy.dire.length > 0) && (
              <div className="card" style={{ marginBottom: 12 }}>
                <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 10px' }}>
                  Синергия внутри состава — по реальным тегам ролей героев
                </p>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                  <div>
                    {rating.synergy.radiant.map((s, i) => (
                      <p key={i} title={s.reason} style={{ fontSize: 13, margin: '0 0 8px' }}>
                        <span>{heroesById[s.heroAId]?.localizedName ?? s.heroAId}</span>
                        {' '}
                        <span style={{ color: s.tone === 'positive' ? 'var(--accent)' : 'var(--danger)' }}>
                          {s.tone === 'positive' ? '🟢→' : '🔴─'}
                        </span>
                        {' '}
                        <span>{heroesById[s.heroBId]?.localizedName ?? s.heroBId}</span>
                        <br />
                        <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{s.reason}</span>
                      </p>
                    ))}
                    {rating.synergy.radiant.length === 0 && <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>Явных связей не найдено</p>}
                  </div>
                  <div>
                    {rating.synergy.dire.map((s, i) => (
                      <p key={i} title={s.reason} style={{ fontSize: 13, margin: '0 0 8px' }}>
                        <span>{heroesById[s.heroAId]?.localizedName ?? s.heroAId}</span>
                        {' '}
                        <span style={{ color: s.tone === 'positive' ? 'var(--accent)' : 'var(--danger)' }}>
                          {s.tone === 'positive' ? '🟢→' : '🔴─'}
                        </span>
                        {' '}
                        <span>{heroesById[s.heroBId]?.localizedName ?? s.heroBId}</span>
                        <br />
                        <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{s.reason}</span>
                      </p>
                    ))}
                    {rating.synergy.dire.length === 0 && <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>Явных связей не найдено</p>}
                  </div>
                </div>
              </div>
            )}

            {rating.counterPairs.length > 0 && (
              <div style={{ marginBottom: 12 }}>
                <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 6px' }}>Кто кого контрит в этом составе</p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                  {rating.counterPairs.map((p, i) => (
                    <div key={i} className="card" style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 10px' }}>
                      <span style={{ fontSize: 14, color: p.favors === 'radiant' ? 'var(--accent)' : 'var(--text-secondary)' }}>
                        {heroesById[p.radiantHeroId]?.localizedName ?? `#${p.radiantHeroId}`}
                      </span>
                      <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                        {p.favors === 'radiant' ? '→ контрит →' : '← контрит ←'}
                      </span>
                      <span style={{ fontSize: 14, color: p.favors === 'dire' ? 'var(--danger)' : 'var(--text-secondary)' }}>
                        {heroesById[p.direHeroId]?.localizedName ?? `#${p.direHeroId}`}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: 0 }}>
              {!rating.notes.synergiesAvailable && 'Синергии союзников не показаны — у OpenDota нет данных по совместному винрейту героев. '}
              {!rating.notes.itemRecommendationsAvailable && 'Рекомендации по предметам пока не реализованы — нужен отдельный фоновый сбор данных по сборкам.'}
            </p>
          </div>
        )}

      {/* ACTIVE DRAFTING WORKSPACE — fixed to the viewport, no page
          scroll during a live draft (per the Captain's Mode brief):
          top bar (turn + timer), a three-column middle row (Radiant
          slots | hero grid | Dire slots) each scrolling internally if
          it needs to, and a compact history strip at the bottom. The
          post-draft results screen above this is a normal scrolling
          report instead — that's the one part of a real Captain's
          Mode broadcast that isn't meant to fit on one screen either. */}
      {isFree && !isDone && !isWaiting && iAmParticipant && nextStep && (
        <div style={{ height: 'calc(100vh - 220px)', minHeight: 480, display: 'flex', flexDirection: 'column' }}>
          {/* TOP: turn + timer, both sides' reserve in one compact bar */}
          <div
            className="card"
            style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
              padding: '10px 18px', marginBottom: 8, flexShrink: 0,
              borderBottom: `2px solid ${teamColor(nextStep.side)}`,
            }}
          >
            <div style={{ minWidth: 110 }}>
              <p style={{ fontSize: 11, color: 'var(--accent)', margin: 0, letterSpacing: 1 }}>RADIANT</p>
              <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: 0 }}>
                резерв {isFree ? (session.radiantSide === 'FIRST_PICK' ? session.reserveFirstSec : session.reserveSecondSec) : 0}s
              </p>
            </div>

            <div style={{ textAlign: 'center', flex: 1 }}>
              <p style={{ fontSize: 13, fontWeight: 600, margin: 0, color: teamColor(nextStep.side), letterSpacing: 1 }}>
                {teamLabel(nextStep.side)}'S TURN TO {ACTION_LABEL[nextStep.action]}
                {isTwoPlayerMode && (isMyTurn ? ' · ВАШ ХОД' : ' · ХОД СОПЕРНИКА')}
                {isVsBot && (isMyTurn ? ' · ВАШ ХОД' : ' · ХОД БОТА')}
              </p>
              {remainingSec != null && (
                <p style={{
                  fontSize: 26, fontWeight: 700, margin: '2px 0 0', lineHeight: 1,
                  color: reserveInfo ? 'var(--danger)' : (remainingSec <= 5 ? 'var(--danger)' : 'var(--text)'),
                }}>
                  {reserveInfo ? Math.ceil(reserveInfo.remaining) : Math.ceil(remainingSec)}
                  <span style={{ fontSize: 11, color: 'var(--text-muted)', marginLeft: 6, letterSpacing: 1 }}>
                    {reserveInfo ? 'RESERVE' : 'MAIN TIME'}
                  </span>
                </p>
              )}
            </div>

            <div style={{ minWidth: 110, textAlign: 'right' }}>
              <p style={{ fontSize: 11, color: 'var(--danger)', margin: 0, letterSpacing: 1 }}>DIRE</p>
              <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: 0 }}>
                резерв {isFree ? (direSide === 'FIRST_PICK' ? session.reserveFirstSec : session.reserveSecondSec) : 0}s
              </p>
            </div>
          </div>

          {error && <p style={{ fontSize: 13, color: 'var(--danger)', margin: '0 0 6px', flexShrink: 0 }}>{error}</p>}

          {/* MIDDLE: hero grid (~70%) | Captain's Mode panel with both teams stacked (~30%) */}
          <div style={{ display: 'flex', gap: 10, flex: 1, minHeight: 0 }}>
            <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
              <div style={{ display: 'flex', gap: 6, marginBottom: 6, flexShrink: 0, flexWrap: 'wrap' }}>
                <input
                  placeholder="Поиск героя"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  style={{ flex: 1, minWidth: 120, background: 'var(--card)', border: '0.5px solid var(--border)', borderRadius: 6, padding: '6px 10px', fontSize: 13, color: 'var(--text)' }}
                />
                <button
                  onClick={() => setRoleFilter('all')}
                  className="button-ghost"
                  style={{ fontSize: 11, padding: '5px 10px', background: roleFilter === 'all' ? 'var(--accent-bg)' : undefined, color: roleFilter === 'all' ? 'var(--accent)' : undefined }}
                >
                  ALL
                </button>
                {availableRoles.map((r) => (
                  <button
                    key={r}
                    onClick={() => setRoleFilter(r)}
                    className="button-ghost"
                    style={{ fontSize: 11, padding: '5px 10px', background: roleFilter === r ? 'var(--accent-bg)' : undefined, color: roleFilter === r ? 'var(--accent)' : undefined }}
                  >
                    {r}
                  </button>
                ))}
              </div>

              {previewHeroId != null && heroesById[previewHeroId] && (
                <div className="card" style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6, padding: '6px 10px', flexShrink: 0 }}>
                  <img src={heroesById[previewHeroId].iconUrl} alt="" style={{ width: 48, aspectRatio: '16/9', objectFit: 'cover', borderRadius: 5, flexShrink: 0 }} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: 13, fontWeight: 500, margin: 0 }}>{heroesById[previewHeroId].localizedName}</p>
                    <p style={{ fontSize: 11, color: 'var(--text-secondary)', margin: 0 }}>
                      {heroesById[previewHeroId].primaryAttr}{heroesById[previewHeroId].roles?.length ? ` · ${heroesById[previewHeroId].roles!.join(', ')}` : ''}
                    </p>
                  </div>
                  <Link to={`/heroes/${previewHeroId}`} className="button-ghost" style={{ textDecoration: 'none', fontSize: 11, flexShrink: 0 }}>
                    Контрпики
                  </Link>
                </div>
              )}

              <div style={{ flex: 1, minHeight: 0, overflowY: 'auto' }}>
                {ATTR_GROUPS.map((group) => {
                  const groupHeroes = filteredHeroes.filter((h) => h.primaryAttr === group.key);
                  if (groupHeroes.length === 0) return null;
                  return (
                    <div key={group.key} style={{ marginBottom: 8 }}>
                      <p style={{ fontSize: 11, fontWeight: 500, letterSpacing: 1, color: group.color, margin: '0 0 4px' }}>{group.label}</p>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(58px, 1fr))', gap: 4 }}>
                        {groupHeroes.map((h) => {
                          const used = usedHeroIds.has(h.id);
                          const disabledCm = h.captainsModeAvailable === false;
                          const disabled = used || disabledCm || !isMyTurn;
                          return (
                            <button
                              key={h.id}
                              disabled={disabled}
                              onClick={() => act(h.id)}
                              onMouseEnter={() => setPreviewHeroId(h.id)}
                              onFocus={() => setPreviewHeroId(h.id)}
                              title={disabledCm ? `${h.localizedName} — недоступен в CM` : h.localizedName}
                              style={{
                                position: 'relative', aspectRatio: '1', padding: 0, overflow: 'hidden',
                                background: '#000', border: `1px solid ${group.color}55`, borderRadius: 5,
                                opacity: disabled ? 0.35 : 1, cursor: disabled ? 'not-allowed' : 'pointer',
                                filter: used ? 'grayscale(1)' : 'none',
                              }}
                            >
                              <img src={h.iconUrl} alt={h.localizedName} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Captain's Mode panel — both teams stacked, ~30% width,
                fitting without its own scroll (per the latest brief:
                teams are NOT separate columns flanking the hero grid,
                they're one compact panel to its right). */}
            <div style={{ width: 300, flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 10, minHeight: 0, overflowY: 'auto' }}>
              <DraftSequencePanel session={session} radiantSide={session.radiantSide} direSide={direSide} heroesById={heroesById} currentStepIndex={currentStepIndex} isDone={isDone} />
              {rating && (
                <div style={{ flexShrink: 0 }}>
                  <ComparisonTable radiant={rating.comparison.radiant} dire={rating.comparison.dire} compact />
                </div>
              )}
            </div>
          </div>

          {/* BOTTOM: compact scrolling history strip */}
          <div style={{ flexShrink: 0, marginTop: 6 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 3 }}>
              <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: 0, letterSpacing: 1 }}>ИСТОРИЯ ДРАФТА</p>
              {isAdmin && session.actions.length > 0 && (
                <button className="button-ghost" style={{ color: 'var(--danger)', fontSize: 10, padding: '2px 8px' }} onClick={adminUndo}>
                  Отменить ход (админ)
                </button>
              )}
            </div>
            <div style={{ display: 'flex', gap: 4, overflowX: 'auto', paddingBottom: 2 }}>
              {session.sequence.map((step, i) => {
                const done = session.actions[i] as DraftEvent | undefined;
                const isCurrent = i === currentStepIndex && !isDone;
                const hero = done?.heroId != null ? heroesById[done.heroId] : null;
                return (
                  <div
                    key={step.step}
                    title={`${teamLabel(step.side)} ${ACTION_LABEL[step.action]}${hero ? ': ' + hero.localizedName : ''}`}
                    style={{
                      flexShrink: 0, width: 34, aspectRatio: '1', borderRadius: 4, overflow: 'hidden', position: 'relative',
                      background: isCurrent ? 'var(--primary-bg)' : '#0d0f10',
                      border: `1px solid ${isCurrent ? 'var(--primary)' : teamColor(step.side) + '40'}`,
                      filter: step.action === 'ban' && hero ? 'grayscale(1)' : 'none',
                    }}
                  >
                    {hero ? (
                      <img src={hero.iconUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    ) : (
                      <span style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, color: 'var(--text-muted)' }}>
                        {isCurrent ? '…' : step.step}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {isDone && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 8, flexWrap: 'wrap' }}>
          <button className="button-primary" onClick={rematch}>Реванш (те же стороны)</button>
          <button className="button-ghost" onClick={restart}>Новый драфт (случайные стороны)</button>
          <button
            className="button-ghost"
            onClick={() => {
              navigator.clipboard.writeText(window.location.href);
              alert('Ссылка на этот драфт скопирована');
            }}
          >
            Поделиться
          </button>
          <Link to="/draft-trainer" className="button-ghost" style={{ textDecoration: 'none' }}>К списку сессий</Link>
        </div>
      )}
      {isDone && (
        <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '0 0 20px' }}>
          Ссылка открывает эту партию любому, у кого есть аккаунт Areon — платформа полностью закрыта,
          так что публичного просмотра без входа через Steam нет.
        </p>
      )}

      {isFree && !isDone && !isWaiting && !isTwoPlayerMode && (
        <div style={{ marginBottom: 16 }}>
          <button
            className="button-ghost"
            onClick={() => { if (confirm('Начать этот драфт заново? Текущий прогресс будет потерян.')) restart(); }}
          >
            Restart
          </button>
        </div>
      )}

    </div>
  );
}

const COMPARISON_LABELS: Record<string, string> = {
  initiation: 'Инициация',
  control: 'Контроль',
  damage: 'Урон (нюки)',
  survivability: 'Живучесть',
  push: 'Пуш',
  mobility: 'Мобильность/побег',
};

function ComparisonTable({
  radiant, dire, compact,
}: {
  radiant: Record<string, number>;
  dire: Record<string, number>;
  compact?: boolean;
}) {
  return (
    <div className="card" style={{ marginBottom: compact ? 0 : 12, padding: compact ? '8px 12px' : undefined }}>
      {!compact && (
        <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 10px' }}>
          Сравнение составов — по реальным тегам ролей героев, не прогноз
        </p>
      )}
      <div style={{ display: 'flex', flexDirection: compact ? 'row' : 'column', gap: compact ? 14 : 6, flexWrap: compact ? 'wrap' : undefined }}>
        {Object.keys(COMPARISON_LABELS).map((key) => {
          const r = radiant[key] ?? 0;
          const d = dire[key] ?? 0;
          const total = Math.max(r + d, 1);
          if (compact) {
            return (
              <div key={key} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11 }}>
                <span style={{ color: 'var(--accent)' }}>{r}</span>
                <div style={{ width: 40, display: 'flex', height: 5, borderRadius: 3, overflow: 'hidden', background: 'var(--card-2)' }}>
                  <div style={{ width: `${(r / total) * 100}%`, background: 'var(--accent)' }} />
                  <div style={{ width: `${(d / total) * 100}%`, background: 'var(--danger)' }} />
                </div>
                <span style={{ color: 'var(--danger)' }}>{d}</span>
                <span style={{ color: 'var(--text-muted)' }}>{COMPARISON_LABELS[key]}</span>
              </div>
            );
          }
          return (
            <div key={key} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
              <span style={{ width: 20, textAlign: 'right', color: 'var(--accent)' }}>{r}</span>
              <div style={{ flex: 1, display: 'flex', height: 8, borderRadius: 4, overflow: 'hidden', background: 'var(--card-2)' }}>
                <div style={{ width: `${(r / total) * 100}%`, background: 'var(--accent)' }} />
                <div style={{ width: `${(d / total) * 100}%`, background: 'var(--danger)' }} />
              </div>
              <span style={{ width: 20, color: 'var(--danger)' }}>{d}</span>
              <span style={{ width: 140, color: 'var(--text-secondary)' }}>{COMPARISON_LABELS[key]}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

const MAP_ZONES: { key: string; position: number; label: string; top: string; left: string }[] = [
  { key: 'offlane', position: 3, label: 'OFFLANE', top: '14%', left: '14%' },
  { key: 'support', position: 5, label: 'SUPPORT (HARD SUPPORT)', top: '27%', left: '27%' },
  { key: 'mid', position: 2, label: 'MID LANE', top: '50%', left: '50%' },
  { key: 'jungle', position: 4, label: 'JUNGLE / ROAM (SOFT SUPPORT)', top: '73%', left: '73%' },
  { key: 'safelane', position: 1, label: 'SAFE LANE (CARRY)', top: '86%', left: '86%' },
];

/**
 * An original, abstract terrain backdrop — river, lane paths, base
 * corners, a few jungle patches — evoking the general shape of a MOBA
 * map (diagonal river, two bases in opposite corners, three lanes
 * between) without tracing or reproducing Dota 2's actual map
 * artwork, which is Valve's asset. Pure geometry, this project's own
 * color palette.
 */
function MapBackdrop() {
  return (
    <svg viewBox="0 0 480 480" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
      <defs>
        <radialGradient id="terrainGrad" cx="50%" cy="50%" r="75%">
          <stop offset="0%" stopColor="#1c3a30" />
          <stop offset="100%" stopColor="#0d1f19" />
        </radialGradient>
        <linearGradient id="riverGrad" x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#2a5f7a" stopOpacity="0.55" />
          <stop offset="50%" stopColor="#3f7fa0" stopOpacity="0.7" />
          <stop offset="100%" stopColor="#2a5f7a" stopOpacity="0.55" />
        </linearGradient>
      </defs>

      <rect width="480" height="480" fill="url(#terrainGrad)" />

      {/* base corners — top-left (offlane/hard support side) and bottom-right (carry/soft support side) */}
      <circle cx="60" cy="60" r="90" fill="#2fa98f" opacity="0.10" />
      <circle cx="420" cy="420" r="90" fill="#e0735f" opacity="0.10" />

      {/* jungle patches — soft irregular blobs, purely decorative */}
      <ellipse cx="340" cy="150" rx="46" ry="34" fill="#255a48" opacity="0.5" />
      <ellipse cx="120" cy="180" rx="40" ry="30" fill="#255a48" opacity="0.4" />
      <ellipse cx="360" cy="340" rx="42" ry="32" fill="#255a48" opacity="0.4" />
      <ellipse cx="150" cy="330" rx="44" ry="34" fill="#255a48" opacity="0.5" />

      {/* diagonal river, now running the opposite way to match the corners above */}
      <path d="M -20 -20 L 260 260 L 260 300 L 20 500 L -20 500 L -20 460 L 220 220 L 220 200 L 40 -20 Z" fill="url(#riverGrad)" />

      {/* two lane paths flanking the diagonal */}
      {[
        { d: 'M 20 60 L 20 420 L 90 460', key: 'left-lane' },
        { d: 'M 60 20 L 420 20 L 460 90', key: 'top-lane' },
      ].map((lane) => (
        <path key={lane.key} d={lane.d} stroke="#4a6b5c" strokeWidth={3} strokeDasharray="2 6" fill="none" opacity="0.5" strokeLinecap="round" />
      ))}
    </svg>
  );
}

/**
 * A stylized, ABSTRACT map — deliberately not a reproduction of Dota
 * 2's actual map geometry/art (that's Valve's asset), just the same
 * "drag your 5 heroes onto lane zones" interaction the brief asked
 * for. Native HTML5 drag-and-drop, no extra library.
 */
function PositionMap({
  myPicks, heroesById, myPositions, setMyPositions, onConfirm,
}: {
  myPicks: DraftEvent[];
  heroesById: Record<number, Hero>;
  myPositions: Record<number, number>;
  setMyPositions: React.Dispatch<React.SetStateAction<Record<number, number>>>;
  onConfirm: () => void;
}) {
  const heroIds = myPicks.map((p) => p.heroId!);
  const placedHeroIds = new Set(Object.keys(myPositions).map(Number));
  const bench = heroIds.filter((id) => !placedHeroIds.has(id));
  const zoneForPosition = (position: number) => Object.entries(myPositions).find(([, pos]) => pos === position)?.[0];

  function dropOnZone(zonePosition: number, e: React.DragEvent) {
    e.preventDefault();
    const heroId = Number(e.dataTransfer.getData('text/heroId'));
    if (!heroId) return;
    setMyPositions((prev) => {
      const next = { ...prev };
      // Clear this hero from any zone it previously held, and clear
      // this zone of whatever hero was there — a drop always means
      // "exactly this hero, exactly this zone" now.
      for (const [hid, pos] of Object.entries(next)) {
        if (pos === zonePosition || Number(hid) === heroId) delete next[Number(hid)];
      }
      next[heroId] = zonePosition;
      return next;
    });
  }

  return (
    <div className="card" style={{ marginBottom: 20, padding: 20 }}>
      <p style={{ fontSize: 16, fontWeight: 600, margin: '0 0 4px' }}>POSITION ASSIGNMENT</p>
      <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 14px' }}>
        Перетащите своих героев на позиции карты — все пять обязательны
      </p>

      {bench.length > 0 && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
          {bench.map((heroId) => (
            <img
              key={heroId}
              src={heroesById[heroId]?.iconUrl}
              alt={heroesById[heroId]?.localizedName}
              title={heroesById[heroId]?.localizedName}
              draggable
              onDragStart={(e) => e.dataTransfer.setData('text/heroId', String(heroId))}
              style={{ width: 56, aspectRatio: '16/9', objectFit: 'cover', borderRadius: 6, border: '1px solid var(--border)', cursor: 'grab' }}
            />
          ))}
        </div>
      )}

      <div
        style={{
          position: 'relative', width: '100%', maxWidth: 480, aspectRatio: '1', margin: '0 auto 16px',
          borderRadius: 12, border: '1px solid var(--border)', overflow: 'hidden',
        }}
      >
        <MapBackdrop />
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
          {/* Connects each pair sharing a lane (offlane+hard support, carry+soft support) so the pairing reads at a glance, not just from proximity alone. */}
          <line x1={14} y1={14} x2={27} y2={27} stroke="#7C6FF0" strokeWidth={0.6} strokeDasharray="1.5 1.5" opacity={0.5} />
          <line x1={73} y1={73} x2={86} y2={86} stroke="#7C6FF0" strokeWidth={0.6} strokeDasharray="1.5 1.5" opacity={0.5} />
        </svg>
        {MAP_ZONES.map((zone) => {
          const heroId = zoneForPosition(zone.position);
          return (
            <div
              key={zone.key}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => dropOnZone(zone.position, e)}
              title={zone.label}
              style={{
                position: 'absolute', top: zone.top, left: zone.left, transform: 'translate(-50%, -50%)',
                width: 66, height: 44, borderRadius: 8,
                background: heroId ? 'rgba(10,10,16,0.55)' : 'rgba(124,111,240,0.16)',
                border: `1.5px solid ${heroId ? 'var(--primary)' : 'rgba(124,111,240,0.55)'}`,
                boxShadow: heroId ? '0 0 10px rgba(124,111,240,0.35)' : 'none',
                display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden',
              }}
            >
              {heroId ? (
                <img
                  src={heroesById[Number(heroId)]?.iconUrl}
                  alt=""
                  draggable
                  onDragStart={(e) => e.dataTransfer.setData('text/heroId', heroId)}
                  style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 6, cursor: 'grab' }}
                />
              ) : (
                <span style={{ fontSize: 9, fontWeight: 600, color: '#C9C4F5', textAlign: 'center', lineHeight: 1.25, padding: 2 }}>{zone.label}</span>
              )}
            </div>
          );
        })}
      </div>

      <button className="button-primary" disabled={Object.keys(myPositions).length !== 5} onClick={onConfirm}>
        ЗАВЕРШИТЬ ДРАФТ
      </button>
    </div>
  );
}

function SynergyPentagon({
  title, picks, heroesById, pairs, color,
}: {
  title: string;
  picks: DraftEvent[];
  heroesById: Record<number, Hero>;
  pairs: { heroAId: number; heroBId: number; tone: 'positive' | 'negative' | 'neutral' }[];
  color: string;
}) {
  const heroIds = picks.map((p) => p.heroId!).filter((id) => id != null);
  if (heroIds.length < 5) return <div className="card" style={{ padding: 16 }}><p style={{ fontSize: 12, color: 'var(--text-muted)' }}>{title}: недостаточно героев</p></div>;

  const size = 220;
  const cx = size / 2, cy = size / 2, r = size / 2 - 30;
  const points = heroIds.map((_, i) => {
    const angle = (Math.PI * 2 * i) / 5 - Math.PI / 2;
    return { x: cx + r * Math.cos(angle), y: cy + r * Math.sin(angle) };
  });

  return (
    <div className="card" style={{ padding: 16, textAlign: 'center' }}>
      <p style={{ fontSize: 12, color, letterSpacing: 1, margin: '0 0 8px' }}>{title}</p>
      <svg width={size} height={size} style={{ overflow: 'visible' }}>
        {pairs.map((pair, i) => {
          const ai = heroIds.indexOf(pair.heroAId);
          const bi = heroIds.indexOf(pair.heroBId);
          if (ai === -1 || bi === -1) return null;
          const lineColor = pair.tone === 'positive' ? 'var(--accent)' : pair.tone === 'negative' ? 'var(--danger)' : 'rgba(255,255,255,0.12)';
          return (
            <line
              key={i}
              x1={points[ai].x} y1={points[ai].y} x2={points[bi].x} y2={points[bi].y}
              stroke={lineColor} strokeWidth={pair.tone === 'neutral' ? 1 : 2}
            />
          );
        })}
        {points.map((p, i) => (
          <image key={i} href={heroesById[heroIds[i]]?.iconUrl} x={p.x - 18} y={p.y - 11} width={36} height={22} clipPath="inset(0 round 4px)" />
        ))}
      </svg>
    </div>
  );
}

function DraftSequencePanel({
  session, radiantSide, direSide, heroesById, currentStepIndex, isDone,
}: {
  session: DraftSession;
  radiantSide: 'FIRST_PICK' | 'SECOND_PICK';
  direSide: 'FIRST_PICK' | 'SECOND_PICK';
  heroesById: Record<number, Hero>;
  currentStepIndex: number;
  isDone: boolean;
}) {
  const radiantSteps = session.sequence.filter((s) => s.side === radiantSide);
  const direSteps = session.sequence.filter((s) => s.side === direSide);
  const radiantActions = session.actions.filter((a) => a.side === radiantSide);
  const direActions = session.actions.filter((a) => a.side === direSide);
  const rowCount = Math.max(radiantSteps.length, direSteps.length);
  const nextStep = session.sequence[currentStepIndex];
  // The real global order number for a step — session.sequence.step is
  // 0-indexed and may not itself be a dense 1..N sequence depending on
  // the ruleset, so this looks up each step's actual position rather
  // than assuming radiantSteps[i]/direSteps[i]'s local index doubles
  // as the true pick/ban order number.
  const globalOrder = (step: (typeof radiantSteps)[number]) => session.sequence.indexOf(step) + 1;

  function makeCell(steps: typeof radiantSteps, actions: typeof radiantActions, side: 'FIRST_PICK' | 'SECOND_PICK') {
    return (i: number) => {
      const step = steps[i];
      if (!step) return <div key={i} style={{ width: 44, aspectRatio: '16/10' }} />;
      const done = actions[i];
      const isCurrent = !isDone && !done && i === actions.length && nextStep?.side === side;
      const hero = done?.heroId != null ? heroesById[done.heroId] : null;
      const isBan = step.action === 'ban';
      // Picks are the primary content of the lineup, so they read as
      // slightly larger and softer-cornered; bans stay compact and
      // sharper-edged — the size difference itself is the first signal
      // of which is which, before the red X even registers.
      const w = isBan ? 34 : 46;
      return (
        <div
          key={i}
          title={hero ? hero.localizedName : undefined}
          style={{
            width: w, aspectRatio: '16/10', borderRadius: isBan ? 4 : 8, overflow: 'hidden', position: 'relative', flexShrink: 0,
            background: '#0d0f10',
            border: isCurrent ? '1.5px solid var(--primary)' : '0.5px solid var(--border)',
            boxShadow: isCurrent ? '0 0 6px var(--primary)' : undefined,
            filter: isBan && hero ? 'grayscale(0.6)' : 'none',
            opacity: isBan && hero ? 0.85 : 1,
          }}
        >
          {hero ? (
            <>
              <img src={hero.iconUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              {isBan && (
                <svg style={{ position: 'absolute', inset: 0 }} viewBox="0 0 34 21" preserveAspectRatio="none">
                  <line x1="4" y1="3" x2="30" y2="18" stroke="var(--danger)" strokeWidth="3.5" strokeLinecap="round" />
                  <line x1="30" y1="3" x2="4" y2="18" stroke="var(--danger)" strokeWidth="3.5" strokeLinecap="round" />
                </svg>
              )}
              <span style={{
                position: 'absolute', left: 0, right: 0, bottom: 0, textAlign: 'center',
                fontSize: 9, fontWeight: 700, color: '#fff', textShadow: '0 1px 2px rgba(0,0,0,0.9)',
                background: 'linear-gradient(transparent, rgba(0,0,0,0.55))', lineHeight: '14px',
              }}>
                {globalOrder(step)}
              </span>
            </>
          ) : (
            <span style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, color: isCurrent ? 'var(--primary)' : 'var(--text-muted)' }}>
              {isCurrent ? '…' : ''}
            </span>
          )}
        </div>
      );
    };
  }

  const radiantCell = makeCell(radiantSteps, radiantActions, radiantSide);
  const direCell = makeCell(direSteps, direActions, direSide);

  return (
    <div className="card" style={{ padding: '10px 10px 8px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
        <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--accent)', letterSpacing: 1 }}>RADIANT</span>
        <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--danger)', letterSpacing: 1 }}>DIRE</span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
        {Array.from({ length: rowCount }, (_, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            {radiantCell(i)}
            <span style={{ width: 16, textAlign: 'center', fontSize: 9, color: 'var(--text-muted)', flexShrink: 0 }}>
              {i + 1}
            </span>
            {direCell(i)}
          </div>
        ))}
      </div>
    </div>
  );
}

function CaptainsModeTeam({
  side, picks, bans, heroesById,
}: {
  side: 'radiant' | 'dire';
  picks: DraftEvent[];
  bans: DraftEvent[];
  heroesById: Record<number, Hero>;
}) {
  const color = side === 'radiant' ? 'var(--accent)' : 'var(--danger)';
  const pickSlots = Array.from({ length: 5 }, (_, i) => picks[i]);
  const banSlots = Array.from({ length: Math.max(4, bans.length) }, (_, i) => bans[i]);
  return (
    <div className="card" style={{ padding: '10px 10px 8px', borderLeft: `3px solid ${color}` }}>
      <p style={{ fontSize: 12, fontWeight: 700, color, margin: '0 0 8px', letterSpacing: 1.5 }}>{side.toUpperCase()}</p>

      <p style={{ fontSize: 9, color: 'var(--text-muted)', margin: '0 0 4px', letterSpacing: 1 }}>PICKS</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 4, marginBottom: 8 }}>
        {pickSlots.map((p, i) => (
          <div
            key={i}
            style={{
              position: 'relative', aspectRatio: '1', borderRadius: 6, overflow: 'hidden',
              background: '#0d0f10', border: `1px solid ${p?.heroId != null ? color + '80' : 'var(--border)'}`,
            }}
          >
            {p?.heroId != null ? (
              <>
                <img src={heroesById[p.heroId]?.iconUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
                <span style={{ position: 'absolute', top: 2, left: 2, fontSize: 9, fontWeight: 700, color: '#fff', background: 'rgba(0,0,0,0.6)', borderRadius: 3, padding: '0 3px' }}>
                  {i + 1}
                </span>
                <span style={{ position: 'absolute', left: 0, right: 0, bottom: 0, padding: '1px 3px', fontSize: 9, color: '#fff', background: 'linear-gradient(transparent, rgba(0,0,0,0.92))', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {heroesById[p.heroId]?.localizedName}
                </span>
              </>
            ) : (
              <span style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, color: 'var(--text-muted)' }}>
                {i + 1}
              </span>
            )}
          </div>
        ))}
      </div>

      <p style={{ fontSize: 9, color: 'var(--text-muted)', margin: '0 0 4px', letterSpacing: 1 }}>BANS</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 3 }}>
        {banSlots.map((b, i) => {
          const hero = b?.heroId != null ? heroesById[b.heroId] : null;
          return (
            <div
              key={i}
              style={{
                position: 'relative', aspectRatio: '1', borderRadius: 4, overflow: 'hidden',
                background: '#0d0f10', border: '0.5px solid var(--border)',
                filter: hero ? 'grayscale(1)' : 'none', opacity: hero ? 0.8 : 0.4,
              }}
            >
              {hero ? (
                <>
                  <img src={hero.iconUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  <svg style={{ position: 'absolute', inset: 0 }} viewBox="0 0 40 40" preserveAspectRatio="none">
                    <line x1="4" y1="4" x2="36" y2="36" stroke="#C97B63" strokeWidth="3" />
                    <line x1="36" y1="4" x2="4" y2="36" stroke="#C97B63" strokeWidth="3" />
                  </svg>
                </>
              ) : (
                <span style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, color: 'var(--text-muted)' }}>
                  {i + 1}
                </span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function RatingCard({ label, color, score, heroesById }: { label: string; color: string; score: CompositionScore; heroesById: Record<number, Hero> }) {
  return (
    <div className="card">
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 8 }}>
        <p style={{ fontSize: 13, fontWeight: 500, color, margin: 0, letterSpacing: 1 }}>{label}</p>
        <p style={{ fontSize: 21, fontWeight: 600, margin: 0 }}>{score.total}<span style={{ fontSize: 13, color: 'var(--text-muted)' }}>/100</span></p>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4, fontSize: 13, marginBottom: 8 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ color: 'var(--text-secondary)' }}>Роли</span>
          <span>{score.roleCoverage}/25</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ color: 'var(--text-secondary)' }}>Атрибуты</span>
          <span>{score.attributeDiversity}/15</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ color: 'var(--text-secondary)' }}>Контрпики</span>
          <span>{score.counterAwareRatio == null ? 'н/д' : `${score.counterAwareness}/25`}</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ color: 'var(--text-secondary)' }}>Синергия</span>
          <span>{score.synergyScore}/20</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ color: 'var(--text-secondary)' }}>Линии</span>
          <span>{score.laneMatchupRatio == null ? 'н/д' : `${score.laneMatchupScore}/15`}</span>
        </div>
      </div>

      {score.reasons.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4, marginBottom: score.mostDangerousUnbanned ? 8 : 0 }}>
          {score.reasons.map((r, i) => (
            <p key={i} style={{ fontSize: 12, color: 'var(--text-secondary)', margin: 0 }}>• {r}</p>
          ))}
        </div>
      )}

      {score.mostDangerousUnbanned && (
        <p style={{ fontSize: 12, color: 'var(--danger)', margin: 0 }}>
          Стоило забанить: {heroesById[score.mostDangerousUnbanned.heroId]?.localizedName ?? `герой #${score.mostDangerousUnbanned.heroId}`}
        </p>
      )}
    </div>
  );
}

function TeamColumn({
  label, color, picks, bans, heroesById, reserveSec,
}: {
  label: string;
  color: string;
  picks: DraftEvent[];
  bans: DraftEvent[];
  heroesById: Record<number, Hero>;
  reserveSec?: number;
}) {
  const pickSlots = Array.from({ length: 5 }, (_, i) => picks[i]);
  const banSlots = Array.from({ length: 5 }, (_, i) => bans[i]);
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 6 }}>
        <p style={{ fontSize: 13, fontWeight: 500, color, margin: 0, letterSpacing: 1 }}>{label}</p>
        {reserveSec != null && (
          <span style={{ fontSize: 12, color: reserveSec <= 20 ? 'var(--danger)' : 'var(--text-muted)' }}>
            резерв {reserveSec}s
          </span>
        )}
      </div>

      {/* Picks — the large, primary cells: this is the team's actual lineup. */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 5, marginBottom: 10 }}>
        {pickSlots.map((p, i) => (
          <div
            key={i}
            style={{
              position: 'relative', aspectRatio: '16/6', borderRadius: 6, overflow: 'hidden',
              background: '#0d0f10', border: `0.5px solid ${p?.heroId != null ? color + '55' : 'var(--border)'}`,
            }}
          >
            {p?.heroId != null ? (
              <>
                <img src={heroesById[p.heroId]?.iconUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
                <span
                  style={{
                    position: 'absolute', left: 0, right: 0, bottom: 0, padding: '3px 8px',
                    fontSize: 13, color: '#fff', background: 'linear-gradient(transparent, rgba(0,0,0,0.88))',
                  }}
                >
                  {heroesById[p.heroId]?.localizedName ?? p.heroId}
                </span>
              </>
            ) : (
              <span style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, color: 'var(--text-muted)' }}>
                {i + 1}
              </span>
            )}
          </div>
        ))}
      </div>

      {/* Bans — intentionally smaller cells than picks, so size alone
          signals "this is a ban, not a pick" at a glance, per the
          Captain's Mode layout this is modeled on. Still part of this
          team's own panel, not a separate combined list. */}
      <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '0 0 4px', letterSpacing: 1 }}>BAN</p>
      <div style={{ display: 'flex', gap: 4 }}>
        {banSlots.map((b, i) => {
          const hero = b?.heroId != null ? heroesById[b.heroId] : null;
          return (
            <div
              key={i}
              style={{
                position: 'relative', flex: 1, aspectRatio: '16/10', borderRadius: 4, overflow: 'hidden',
                background: '#0d0f10', border: '0.5px solid var(--border)',
                filter: hero ? 'grayscale(1)' : 'none', opacity: hero ? 0.75 : 0.5,
              }}
            >
              {hero ? (
                <img src={hero.iconUrl} alt={hero.localizedName} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : (
                <span style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, color: 'var(--text-muted)' }}>
                  {b === undefined ? i + 1 : 'timeout'}
                </span>
              )}
              {hero && (
                <svg style={{ position: 'absolute', inset: 0 }} viewBox="0 0 68 42" preserveAspectRatio="none">
                  <line x1="4" y1="4" x2="64" y2="38" stroke="#C97B63" strokeWidth="3" />
                  <line x1="64" y1="4" x2="4" y2="38" stroke="#C97B63" strokeWidth="3" />
                </svg>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
