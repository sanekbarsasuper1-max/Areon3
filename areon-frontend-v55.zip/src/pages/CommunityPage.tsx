import { useEffect, useState } from 'react';

// Set these once the real Areon Discord server / WhatsApp channel exist.
// Discord's widget needs "Server Widget" enabled in Server Settings →
// Widget for the online-count fetch below to return real data — until
// then it fails silently and the card just omits the online count.
const DISCORD_INVITE_URL = 'https://discord.gg/YOUR_INVITE_CODE';
const DISCORD_SERVER_ID = 'YOUR_SERVER_ID';
const WHATSAPP_URL = 'https://wa.me/YOUR_PHONE_NUMBER';

interface DiscordWidget {
  presence_count: number;
}

export function CommunityPage() {
  const [discordOnline, setDiscordOnline] = useState<number | null>(null);

  useEffect(() => {
    // Discord's widget.json endpoint is public and needs no auth or
    // bot token — just the server having its widget enabled. Fails
    // silently (network error or widget disabled) rather than
    // breaking the page; the card works fine without the count.
    fetch(`https://discord.com/api/guilds/${DISCORD_SERVER_ID}/widget.json`)
      .then((r) => (r.ok ? r.json() : null))
      .then((data: DiscordWidget | null) => {
        if (data) setDiscordOnline(data.presence_count);
      })
      .catch(() => {});
  }, []);

  return (
    <div style={{ maxWidth: 1000, margin: '0 auto', padding: '40px 24px 100px' }}>
      <p style={{ fontSize: 21, fontWeight: 500, margin: '0 0 4px' }}>👥 СООБЩЕСТВО</p>
      <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 24px' }}>
        Общение, поиск команды и голосовые комнаты Areon
      </p>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 16 }}>
        <CommunityCard
          icon="🎙️"
          title="Areon Voice"
          description="Голосовые комнаты прямо на сайте, привязанные к вашему аккаунту Areon."
          badge="СКОРО"
          accent="#7C6FF0"
        />

        <a href={DISCORD_INVITE_URL} target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
          <CommunityCard
            icon="💬"
            title="Discord"
            description="Новости, поиск игроков, турниры и общение с комьюнити Areon."
            accent="#5865F2"
            footer={discordOnline != null ? `🟢 ${discordOnline} онлайн` : undefined}
          />
        </a>

        <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
          <CommunityCard
            icon="📱"
            title="WhatsApp"
            description="Официальный канал Areon — поддержка и связь с сообществом."
            accent="#25D366"
          />
        </a>

        <CommunityCard
          icon="🔍"
          title="Поиск игроков"
          description="Находите тиммейтов по рангу, ролям и целям."
          badge="СКОРО"
          accent="#2FA98F"
        />

        <CommunityCard
          icon="🎮"
          title="Пати"
          description="Собирайте группу и заходите в игру вместе."
          badge="СКОРО"
          accent="#E0A63E"
        />
      </div>
    </div>
  );
}

function CommunityCard({
  icon, title, description, accent, badge, footer,
}: {
  icon: string;
  title: string;
  description: string;
  accent: string;
  badge?: string;
  footer?: string;
}) {
  return (
    <div className="card" style={{ padding: 20, border: `1px solid ${accent}33`, height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
        <span style={{ fontSize: 32 }}>{icon}</span>
        {badge && (
          <span style={{ fontSize: 10, letterSpacing: 1, color: 'var(--text-muted)', border: '1px solid var(--border)', borderRadius: 4, padding: '2px 6px' }}>
            {badge}
          </span>
        )}
      </div>
      <p style={{ fontSize: 17, fontWeight: 600, margin: '0 0 6px', color: 'var(--text)' }}>{title}</p>
      <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: 0, flex: 1 }}>{description}</p>
      {footer && <p style={{ fontSize: 12, color: accent, margin: '10px 0 0' }}>{footer}</p>}
    </div>
  );
}
