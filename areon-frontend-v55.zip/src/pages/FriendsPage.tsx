import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';

export function FriendsPage() {
  const [tab, setTab] = useState<'friends' | 'requests' | 'search'>('friends');
  const [friends, setFriends] = useState<any[]>([]);
  const [requests, setRequests] = useState<any[]>([]);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [searching, setSearching] = useState(false);

  async function loadFriends() {
    setFriends(await api.friendsList());
  }
  async function loadRequests() {
    setRequests(await api.friendRequests());
  }

  useEffect(() => { loadFriends(); loadRequests(); }, []);

  async function search() {
    if (query.trim().length < 2) return;
    setSearching(true);
    try {
      setResults(await api.friendsSearch(query));
    } finally {
      setSearching(false);
    }
  }

  async function sendRequest(userId: string) {
    try {
      await api.friendSendRequest(userId);
      setResults((prev) => prev.map((r) => (r.id === userId ? { ...r, requested: true } : r)));
    } catch (e: any) {
      alert(e?.message ?? 'Не удалось отправить заявку');
    }
  }

  async function accept(id: string) {
    await api.friendAccept(id);
    loadRequests();
    loadFriends();
  }
  async function decline(id: string) {
    await api.friendDecline(id);
    loadRequests();
  }
  async function remove(userId: string) {
    if (!confirm('Удалить из друзей?')) return;
    await api.friendRemove(userId);
    loadFriends();
  }
  async function block(userId: string) {
    if (!confirm('Заблокировать этого пользователя?')) return;
    await api.friendBlock(userId);
    loadFriends();
    loadRequests();
  }

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '40px 24px 100px' }}>
      <p style={{ fontSize: 21, fontWeight: 500, margin: '0 0 16px' }}>👥 ДРУЗЬЯ</p>

      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        <button className={tab === 'friends' ? 'button-primary' : 'button-ghost'} onClick={() => setTab('friends')}>
          Друзья ({friends.length})
        </button>
        <button className={tab === 'requests' ? 'button-primary' : 'button-ghost'} onClick={() => setTab('requests')}>
          Заявки {requests.length > 0 ? `(${requests.length})` : ''}
        </button>
        <button className={tab === 'search' ? 'button-primary' : 'button-ghost'} onClick={() => setTab('search')}>
          Поиск игроков
        </button>
      </div>

      {tab === 'friends' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {friends.length === 0 && <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>Пока никого нет — найдите игроков во вкладке «Поиск».</p>}
          {friends.map((f) => (
            <div key={f.id} className="card" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12 }}>
              <div style={{ position: 'relative' }}>
                <img src={f.avatarFull} alt="" style={{ width: 48, height: 48, borderRadius: 8 }} />
                <span style={{ position: 'absolute', bottom: -2, right: -2, width: 12, height: 12, borderRadius: '50%', background: f.online ? 'var(--accent)' : 'var(--text-muted)', border: '2px solid var(--bg)' }} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <Link to={`/players/${f.id}`} style={{ fontSize: 15, fontWeight: 600, color: 'var(--text)', textDecoration: 'none' }}>{f.personaName}</Link>
                <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '2px 0 0' }}>
                  {f.online ? 'Онлайн' : 'Оффлайн'} · Site Rating: {f.siteRating}
                </p>
              </div>
              <Link to={`/players/${f.id}`} className="button-ghost" style={{ fontSize: 13, padding: '6px 10px' }}>Профиль</Link>
              <button className="button-ghost" style={{ fontSize: 13, padding: '6px 10px' }} onClick={() => remove(f.id)}>Удалить</button>
              <button className="button-ghost" style={{ fontSize: 13, padding: '6px 10px', color: 'var(--danger)' }} onClick={() => block(f.id)}>Заблокировать</button>
            </div>
          ))}
        </div>
      )}

      {tab === 'requests' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {requests.length === 0 && <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>Нет новых заявок.</p>}
          {requests.map((r) => (
            <div key={r.id} className="card" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12 }}>
              <img src={r.avatarFull} alt="" style={{ width: 48, height: 48, borderRadius: 8 }} />
              <p style={{ flex: 1, fontSize: 15, fontWeight: 600, margin: 0 }}>{r.personaName}</p>
              <button className="button-primary" style={{ fontSize: 13, padding: '6px 10px' }} onClick={() => accept(r.id)}>Принять</button>
              <button className="button-ghost" style={{ fontSize: 13, padding: '6px 10px' }} onClick={() => decline(r.id)}>Отклонить</button>
              <button className="button-ghost" style={{ fontSize: 13, padding: '6px 10px', color: 'var(--danger)' }} onClick={() => block(r.fromUserId)}>Заблокировать</button>
            </div>
          ))}
        </div>
      )}

      {tab === 'search' && (
        <div>
          <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && search()}
              placeholder="Никнейм или Areon ID"
              style={{ flex: 1, background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 8, padding: '10px 12px', color: 'var(--text)' }}
            />
            <button className="button-primary" onClick={search} disabled={searching}>{searching ? '…' : 'Найти'}</button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {results.map((u) => (
              <div key={u.id} className="card" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12 }}>
                <img src={u.avatarFull} alt="" style={{ width: 48, height: 48, borderRadius: 8 }} />
                <div style={{ flex: 1 }}>
                  <Link to={`/players/${u.id}`} style={{ fontSize: 15, fontWeight: 600, color: 'var(--text)', textDecoration: 'none' }}>{u.personaName}</Link>
                  <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '2px 0 0' }}>Site Rating: {u.siteRating}</p>
                </div>
                <Link to={`/players/${u.id}`} className="button-ghost" style={{ fontSize: 13, padding: '6px 10px' }}>Открыть профиль</Link>
                <button
                  className="button-primary"
                  style={{ fontSize: 13, padding: '6px 10px' }}
                  disabled={u.requested}
                  onClick={() => sendRequest(u.id)}
                >
                  {u.requested ? 'Заявка отправлена' : '+ Добавить в друзья'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
