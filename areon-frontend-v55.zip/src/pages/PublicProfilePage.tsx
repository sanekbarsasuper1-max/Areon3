import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { api, PublicProfile, Hero } from '../api';

export function PublicProfilePage() {
  const { id } = useParams<{ id: string }>();
  const [profile, setProfile] = useState<PublicProfile | null>(null);
  const [heroes, setHeroes] = useState<Hero[]>([]);
  const [requestSent, setRequestSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    Promise.all([api.publicProfile(id), api.heroes()])
      .then(([p, h]) => { setProfile(p); setHeroes(h); })
      .catch(() => setError('Не удалось загрузить профиль.'));
  }, [id]);

  async function addFriend() {
    if (!id) return;
    try {
      await api.friendSendRequest(id);
      setRequestSent(true);
    } catch (e: any) {
      setError(e?.message ?? 'Не удалось отправить заявку');
    }
  }

  const heroesById = Object.fromEntries(heroes.map((h) => [h.id, h]));

  if (error) return <div style={{ maxWidth: 800, margin: '40px auto', padding: '0 24px' }}><p style={{ color: 'var(--danger)' }}>{error}</p></div>;
  if (!profile) return <div style={{ maxWidth: 800, margin: '40px auto', padding: '0 24px' }}><p style={{ color: 'var(--text-muted)' }}>Загрузка…</p></div>;

  if (profile.restricted) {
    return (
      <div style={{ maxWidth: 500, margin: '80px auto', padding: '0 24px', textAlign: 'center' }}>
        <img src={profile.avatarFull} alt="" style={{ width: 96, height: 96, borderRadius: 16, marginBottom: 16 }} />
        <p style={{ fontSize: 20, fontWeight: 600, margin: '0 0 8px' }}>{profile.personaName}</p>
        <p style={{ color: 'var(--text-muted)' }}>Этот профиль закрыт настройками приватности.</p>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '40px 24px 100px' }}>
      <div style={{ display: 'flex', gap: 20, alignItems: 'center', marginBottom: 24, flexWrap: 'wrap' }}>
        <div style={{ position: 'relative' }}>
          <img src={profile.avatarFull} alt="" style={{ width: 96, height: 96, borderRadius: 16 }} />
          <span style={{ position: 'absolute', bottom: 0, right: 0, width: 16, height: 16, borderRadius: '50%', background: profile.online ? 'var(--accent)' : 'var(--text-muted)', border: '3px solid var(--bg)' }} />
        </div>
        <div style={{ flex: 1, minWidth: 200 }}>
          <p style={{ fontSize: 26, fontWeight: 700, margin: '0 0 4px' }}>{profile.personaName}</p>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: 0 }}>
            {profile.online ? 'Онлайн' : 'Оффлайн'}
            {profile.steamProfileUrl && (
              <> · <a href={profile.steamProfileUrl} target="_blank" rel="noreferrer" style={{ color: 'var(--primary)' }}>Steam-профиль</a></>
            )}
          </p>
          {profile.siteRating != null && (
            <p style={{ fontSize: 14, color: 'var(--primary)', margin: '6px 0 0' }}>
              Site Rating: <strong>{profile.siteRating}</strong>
              {profile.draftRating != null && <>{'  ·  '}Drafter Rating: <strong>{profile.draftRating}</strong></>}
            </p>
          )}
        </div>
        {!profile.isSelf && (
          profile.isFriend ? (
            <span className="button-ghost" style={{ fontSize: 13, padding: '8px 14px' }}>✓ В друзьях</span>
          ) : (
            <button className="button-primary" onClick={addFriend} disabled={requestSent}>
              {requestSent ? 'Заявка отправлена' : '+ Добавить в друзья'}
            </button>
          )
        )}
      </div>

      {profile.equippedItems && profile.equippedItems.length > 0 && (
        <div style={{ display: 'flex', gap: 12, marginBottom: 24 }}>
          {profile.equippedItems.map((e, i) => (
            <div key={i} title={e.name} style={{ textAlign: 'center', width: 64 }}>
              {e.iconUrl ? <img src={e.iconUrl} alt="" style={{ width: 56, height: 56, objectFit: 'contain' }} /> : <div style={{ fontSize: 36 }}>{e.iconEmoji}</div>}
            </div>
          ))}
        </div>
      )}

      {profile.winLoss ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', gap: 12, marginBottom: 24 }}>
          <StatBox label="Матчей" value={String(profile.winLoss.wins + profile.winLoss.losses)} />
          <StatBox label="Win Rate" value={profile.winRate != null ? `${profile.winRate}%` : 'н/д'} />
          <StatBox label="Победы" value={String(profile.winLoss.wins)} />
          <StatBox label="Поражения" value={String(profile.winLoss.losses)} />
        </div>
      ) : (
        <p style={{ color: 'var(--text-muted)', fontSize: 14, marginBottom: 24 }}>Статистика матчей недоступна — скрыта настройками приватности или Steam-данные закрыты.</p>
      )}

      {profile.topHeroes && profile.topHeroes.length > 0 && (
        <div style={{ marginBottom: 24 }}>
          <p style={{ fontSize: 15, fontWeight: 600, margin: '0 0 10px' }}>Любимые герои</p>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            {profile.topHeroes.map((th) => (
              <div key={th.heroId} title={heroesById[th.heroId]?.localizedName} style={{ textAlign: 'center' }}>
                <img src={heroesById[th.heroId]?.iconUrl} alt="" style={{ width: 64, aspectRatio: '16/9', objectFit: 'cover', borderRadius: 6 }} />
                <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '4px 0 0' }}>{th.games} игр · {th.wins}W</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {profile.hallOfFame && profile.hallOfFame.length > 0 && (
        <div style={{ marginBottom: 24 }}>
          <p style={{ fontSize: 15, fontWeight: 600, margin: '0 0 10px' }}>Достижения</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {profile.hallOfFame.map((h, i) => (
              <div key={i} className="card" style={{ padding: '8px 12px', fontSize: 13, display: 'flex', gap: 8 }}>
                <span>{h.icon ?? '🏅'}</span>
                <span style={{ flex: 1 }}>{h.title}</span>
                <span style={{ color: 'var(--text-muted)' }}>{h.value}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {profile.matches && profile.matches.length > 0 && (
        <div>
          <p style={{ fontSize: 15, fontWeight: 600, margin: '0 0 10px' }}>Последние матчи</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {profile.matches.slice(0, 10).map((m) => (
              <div key={m.matchId} className="card" style={{ padding: '8px 12px', fontSize: 13, display: 'flex', alignItems: 'center', gap: 10 }}>
                <img src={heroesById[m.heroId]?.iconUrl} alt="" style={{ width: 40, aspectRatio: '16/9', objectFit: 'cover', borderRadius: 4 }} />
                <span style={{ color: m.won ? 'var(--accent)' : 'var(--danger)', fontWeight: 600 }}>{m.won ? 'Победа' : 'Поражение'}</span>
                <span style={{ color: 'var(--text-muted)' }}>{m.kills}/{m.deaths}/{m.assists}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StatBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="card" style={{ padding: 14, textAlign: 'center' }}>
      <p style={{ fontSize: 20, fontWeight: 700, margin: 0 }}>{value}</p>
      <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: '2px 0 0' }}>{label}</p>
    </div>
  );
}
