import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Me, api } from '../api';

const NAV_ITEMS: { to: string; label: string }[] = [
  { to: '/profile', label: 'Профиль' },
  { to: '/matches', label: 'Матчи' },
  { to: '/teams', label: 'Команда' },
  { to: '/tournaments', label: 'Турниры' },
  { to: '/draft-trainer', label: 'Draft Trainer' },
  { to: '/draft-tournaments', label: 'Драфт-турниры' },
  { to: '/players/search', label: 'Найти игроков' },
  { to: '/trials', label: 'Orion Trials' },
  { to: '/shop', label: 'Магазин' },
  { to: '/minigames/minesweeper', label: 'Техис: Сапёр' },
  { to: '/community', label: 'Сообщество' },
  { to: '/friends', label: 'Друзья' },
  // Temporarily off the nav — Gemini's free-tier daily quota made the
  // live feature unreliable; the route itself still works, just not
  // linked from here until that's sorted out.
  // { to: '/wheel-of-fate', label: 'Wheel of Fate' },
  { to: '/hall-of-fame', label: 'Зал славы' },
  { to: '/updates', label: 'Что нового' },
  { to: '/support', label: 'Поддержка' },
  { to: '/suggestions', label: 'Предложить' },
  { to: '/settings', label: 'Настройки' },
];

export function AppHeader({ me }: { me: Me }) {
  const location = useLocation();
  const [version, setVersion] = useState<string | null>(null);
  const [hasUnseenUpdate, setHasUnseenUpdate] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);

  useEffect(() => {
    api.currentVersion().then((v) => {
      setVersion(v?.version ?? null);
      if (v?.version) {
        const lastSeen = localStorage.getItem('areon_last_seen_version');
        setHasUnseenUpdate(lastSeen !== v.version);
      }
    });
  }, []);

  useEffect(() => {
    // requirement 8 — polling rather than a dedicated socket channel
    // just for this: notifications aren't latency-sensitive the way
    // Draft Trainer's live state is, so a 30s interval is simple and
    // cheap rather than another persistent connection.
    function poll() {
      api.notificationsUnreadCount().then(setUnreadCount).catch(() => {});
    }
    poll();
    const interval = setInterval(poll, 30_000);
    return () => clearInterval(interval);
  }, []);

  function toggleNotifications() {
    const next = !notifOpen;
    setNotifOpen(next);
    if (next) {
      api.notifications().then(setNotifications).catch(() => {});
    }
  }

  async function markAllRead() {
    await api.notificationsMarkAllRead();
    setUnreadCount(0);
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }

  function notificationText(n: any) {
    switch (n.type) {
      case 'friend_request': return `${n.payload?.fromName ?? 'Игрок'} отправил заявку в друзья`;
      case 'friend_accepted': return `${n.payload?.byName ?? 'Игрок'} принял вашу заявку в друзья`;
      case 'party_invite': return 'Приглашение в пати';
      case 'voice_invite': return 'Приглашение в голосовую комнату';
      case 'tournament_invite': return 'Приглашение на турнир';
      default: return 'Новое уведомление';
    }
  }

  return (
    <aside className="app-sidebar">
      <Link
        to="/profile"
        style={{
          display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none',
          padding: '22px 22px 18px', flexShrink: 0,
        }}
      >
        <svg width="26" height="26" viewBox="0 0 28 28" style={{ flexShrink: 0 }}>
          <polygon points="14,2 25,8 25,20 14,26 3,20 3,8" fill="none" stroke="#2FA98F" strokeWidth="1.6" />
          <path d="M14 8 L19 19 M14 8 L9 19 M10.5 15 H17.5" fill="none" stroke="#2FA98F" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
        <div>
          <div style={{ fontSize: 19, fontWeight: 700, letterSpacing: 1.5, color: 'var(--text)', lineHeight: 1.1 }}>AREON</div>
          {version && (
            <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>v{version}</div>
          )}
        </div>
      </Link>

      <div style={{ position: 'relative', padding: '0 22px 14px' }}>
        <button
          onClick={toggleNotifications}
          className="button-ghost"
          style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: 13, padding: '8px 12px' }}
        >
          <span>🔔 Уведомления</span>
          {unreadCount > 0 && (
            <span style={{ background: 'var(--danger)', color: 'white', borderRadius: 10, fontSize: 11, padding: '1px 7px', fontWeight: 700 }}>{unreadCount}</span>
          )}
        </button>
        {notifOpen && (
          <div
            style={{
              position: 'absolute', top: '100%', left: 14, right: 14, zIndex: 50, marginTop: 4,
              background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 10, padding: 8,
              maxHeight: 320, overflowY: 'auto', boxShadow: '0 12px 32px rgba(0,0,0,0.5)',
            }}
          >
            {notifications.length === 0 ? (
              <p style={{ fontSize: 12, color: 'var(--text-muted)', padding: 8, margin: 0 }}>Уведомлений пока нет.</p>
            ) : (
              <>
                <button onClick={markAllRead} style={{ fontSize: 11, color: 'var(--primary)', background: 'none', border: 'none', cursor: 'pointer', marginBottom: 6 }}>
                  Отметить все прочитанными
                </button>
                {notifications.map((n) => (
                  <div key={n.id} style={{ fontSize: 12, padding: '8px', borderRadius: 6, background: n.read ? 'transparent' : 'rgba(124,111,240,0.1)', marginBottom: 2 }}>
                    {notificationText(n)}
                  </div>
                ))}
              </>
            )}
          </div>
        )}
      </div>

      <nav className="sidebar-nav" style={{ display: 'flex', flexDirection: 'column', gap: 2, padding: '4px 14px', flex: 1, overflowY: 'auto' }}>
        {NAV_ITEMS.map((item) => {
          const active = location.pathname === item.to || location.pathname.startsWith(item.to + '/');
          return (
            <Link
              key={item.to}
              to={item.to}
              style={{
                textDecoration: 'none', fontSize: 15, fontWeight: active ? 600 : 500,
                padding: '11px 14px', borderRadius: 8, whiteSpace: 'nowrap',
                color: active ? 'var(--primary)' : 'var(--text-secondary)',
                background: active ? 'var(--primary-bg)' : 'transparent',
                display: 'flex', alignItems: 'center', gap: 8,
              }}
            >
              {item.label}
              {item.to === '/updates' && hasUnseenUpdate && (
                <span style={{
                  fontSize: 10, fontWeight: 700, letterSpacing: 0.5, color: '#fff',
                  background: 'var(--primary)', borderRadius: 4, padding: '1px 6px',
                }}>
                  NEW
                </span>
              )}
            </Link>
          );
        })}
        {me.isAdmin && (
          <Link
            to="/admin"
            style={{
              textDecoration: 'none', fontSize: 15, fontWeight: 500,
              padding: '11px 14px', borderRadius: 8, whiteSpace: 'nowrap', marginTop: 6,
              color: location.pathname.startsWith('/admin') ? 'var(--accent)' : 'var(--danger)',
              background: location.pathname.startsWith('/admin') ? 'var(--accent-bg)' : 'transparent',
            }}
          >
            Админ-панель
          </Link>
        )}
      </nav>

      <Link
        to="/profile"
        className="sidebar-bottom"
        style={{
          display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none',
          padding: '16px 22px', borderTop: '1px solid var(--border)', flexShrink: 0,
        }}
      >
        <img src={me.avatarFull} alt="" width={36} height={36} style={{ borderRadius: 8, display: 'block', flexShrink: 0 }} />
        <span style={{ fontSize: 14, color: 'var(--text-secondary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {me.personaName}
        </span>
      </Link>
    </aside>
  );
}
