import { Injectable, Logger } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';
import { firstValueFrom } from 'rxjs';

// Shape of one item from GET /players/{account_id}/matches.
// This is OpenDota's summary endpoint — cheap, no replay parse required,
// available even for accounts OpenDota hasn't deeply processed yet.
export interface OpenDotaMatchSummary {
  match_id: number;
  hero_id: number;
  kills: number;
  deaths: number;
  assists: number;
  gold_per_min: number;
  xp_per_min: number;
  duration: number;
  start_time: number;
  radiant_win: boolean;
  player_slot: number;
  lobby_type: number;
  game_mode: number;
  // 1=Safe, 2=Mid, 3=Off, 4=Jungle. Optional in OpenDota's own response
  // (older/unparsed matches may not have it).
  lane_role?: number;
  // Confirmed present in this same lightweight endpoint (cross-checked
  // against multiple independent client library field mappings, all
  // showing these as real — if sometimes zero/absent for old matches —
  // fields here, not exclusively on the heavier /matches/{id} detail
  // response). Needed for Orion Trials' FARM/SUPPORT categories.
  hero_damage?: number;
  hero_healing?: number;
  last_hits?: number;
  denies?: number;
}

export interface OpenDotaHero {
  id: number;
  name: string;
  localized_name: string;
  primary_attr: string;
  attack_type: string;
  roles: string[];
  img: string;
  icon: string;
}

// Only the fields we actually use from a much larger response.
export interface OpenDotaMatchPlayer {
  account_id: number | null;
  hero_id: number;
  kills: number;
  deaths: number;
  assists: number;
  gold_per_min: number;
  xp_per_min: number;
  hero_damage: number;
  tower_damage: number;
  hero_healing: number;
  last_hits: number;
  denies: number;
  player_slot: number;
  item_0: number;
  item_1: number;
  item_2: number;
  item_3: number;
  item_4: number;
  item_5: number;
  // Cumulative gold per minute of game time — an approximation of net
  // worth over time, not exact (it doesn't fully reconcile with items
  // sold/gold spent the way true net worth does). Good enough for a
  // trend line, not for precise moment-by-moment net worth.
  gold_t: number[];
  xp_t: number[];
  // PARSE-ONLY — present only once a match has been through OpenDota's
  // replay parse. See the AI Coach section of the backend README for
  // where these are actually used, and the real, documented gaps in
  // this data (an odota/parser GitHub issue confirms aegis-reincarnation
  // deaths sometimes leak into kills_log; a separate independent
  // research project documented unexplained gaps in
  // ability_upgrades_arr even on parsed matches). Never assume these
  // are 100% complete just because a match shows isParsed=true.
  purchase_log?: { time: number; key: string }[]; // key = item internal name, matches Item.name in our own table
  ability_upgrades_arr?: number[]; // ability ids in upgrade order
  kills_log?: { time: number; key: string }[];
  obs_log?: { time: number }[];
  sen_log?: { time: number }[];
  buyback_log?: { time: number }[];
}

export interface OpenDotaPickBan {
  is_pick: boolean;
  hero_id: number;
  team: number; // 0 = Radiant, 1 = Dire
  order: number;
}

export interface OpenDotaTeamfightPlayer {
  ability_uses: Record<string, number>;
  item_uses: Record<string, number>;
  killed: Record<string, number>; // opposing player_slot (as string) -> kill count in this fight
  deaths: number;
  buybacks: number;
  damage: number;
  healing: number;
  gold_delta: number;
  xp_delta: number;
}

export interface OpenDotaTeamfight {
  start: number;
  end: number;
  last_death: number;
  deaths: number;
  players: OpenDotaTeamfightPlayer[]; // indexed the same order as match.players
}

export interface OpenDotaObjective {
  time: number;
  type: string; // e.g. "building_kill", "CHAT_MESSAGE_ROSHAN_KILL"
  key?: string; // building identifier for tower/barracks kills
  player_slot?: number;
}

export interface OpenDotaMatchDetail {
  match_id: number;
  duration: number;
  radiant_win: boolean;
  players: OpenDotaMatchPlayer[];
  // Only present for Captain's Mode games. Absent for All Pick / Turbo /
  // etc — callers must handle that, not assume every match has a draft.
  picks_bans?: OpenDotaPickBan[];
  // Everything below this line is PARSE-ONLY — present only once a
  // match has been through OpenDota's replay parse (requested
  // on-demand for AI Coach, not assumed present on a routine fetch).
  // Confirmed via cross-referenced independent client libraries
  // (Go structs, R package) rather than a single source, given how
  // consequential getting this wrong would be for a feature that
  // exists specifically to avoid inventing data.
  patch?: number; // patch id — cross-reference against /constants/patch to get "7.41e" style string
  version?: number; // parse format version — non-null is itself evidence a match WAS parsed
}

// Minimal shape — /heroes/{hero_id}/matches returns much more, but a
// match_id is all syncItemBuilds needs before pulling full detail per
// match via getMatch().
export interface OpenDotaHeroRecentMatch {
  match_id: number;
}

// GET /constants/items — keyed by internal item name (e.g. "blink"),
// not by numeric id. This shape has been stable in OpenDota's public
// constants for years; worth a spot-check against a live response
// before depending on it in production, same caution as anywhere else
// in this codebase where a field shape wasn't freshly re-verified.
export interface OpenDotaItemConstant {
  id: number;
  dname: string;
  img: string;
}

export interface OpenDotaProMatch {
  match_id: number;
  radiant_name: string | null;
  dire_name: string | null;
  radiant_win: boolean;
  start_time: number;
}

// Shape of GET /benchmarks?hero_id=X — percentile distributions for a
// hero across recent matches, used to say "above/below average" rather
// than inventing a threshold ourselves.
export interface OpenDotaBenchmarks {
  hero_id: number;
  result: Record<string, { percentile: number; value: number }[]>;
}

export interface OpenDotaPlayerRank {
  // Two-digit encoding: tens = medal (1 Herald … 8 Immortal), units = star.
  // Reliable — doesn't need Expose Public Match Data.
  rank_tier: number | null;
  // Heuristic estimate from public match history, not a real MMR value.
  mmr_estimate: { estimate: number | null };
  leaderboard_rank?: number;
}

export interface OpenDotaHeroStats extends OpenDotaHero {
  base_str: number;
  base_agi: number;
  base_int: number;
  str_gain: number;
  agi_gain: number;
  int_gain: number;
  move_speed: number;
}

export interface OpenDotaMatchup {
  hero_id: number;
  games_played: number;
  wins: number;
}

@Injectable()
export class OpenDotaService {
  private readonly logger = new Logger(OpenDotaService.name);
  private readonly baseUrl = 'https://api.opendota.com/api';

  constructor(
    private readonly http: HttpService,
    private readonly config: ConfigService,
  ) {}

  /**
   * Fetches recent match summaries for a player.
   *
   * `limit` maps to OpenDota's own `limit` query param. There's no offset
   * pagination on this endpoint — for a full backfill beyond the most
   * recent N matches, OpenDota's docs point to date-based windowing
   * instead, which we're not implementing yet (out of scope for this
   * first sync slice).
   */
  async getPlayerMatches(
    accountId32: number,
    limit = 20,
  ): Promise<OpenDotaMatchSummary[]> {
    const apiKey = this.config.get<string>('OPENDOTA_API_KEY');

    // OpenDota's /players/{id}/matches endpoint only returns a small
    // default field set (match_id, hero_id, kills/deaths/assists,
    // duration, etc.) — gold_per_min, xp_per_min, hero_damage,
    // hero_healing, last_hits and denies are NOT included unless
    // explicitly requested via repeated `project` query params. This
    // was the actual cause of GPM/XPM always showing 0 — the request
    // never asked for them, so they were always undefined, not
    // actually missing from OpenDota's data.
    const projectFields = ['gold_per_min', 'xp_per_min', 'hero_damage', 'hero_healing', 'last_hits', 'denies'];
    const projectQuery = projectFields.map((f) => `project=${f}`).join('&');
    const url = `${this.baseUrl}/players/${accountId32}/matches?limit=${limit}&${projectQuery}${apiKey ? `&api_key=${apiKey}` : ''}`;

    try {
      const { data } = await firstValueFrom(
        this.http.get<OpenDotaMatchSummary[]>(url, { timeout: 10000 }),
      );
      return data;
    } catch (err) {
      this.logger.error(
        `OpenDota fetch failed for account_id=${accountId32}: ${err instanceof Error ? err.message : String(err)}`,
      );
      throw err;
    }
  }

  /**
   * Static hero reference data — no account_id involved, same list for
   * everyone, safe to cache aggressively (only changes on patch days).
   * `img`/`icon` come back as relative paths; the caller prefixes them
   * with Valve's Steam CDN host.
   */
  async getHeroes(): Promise<OpenDotaHero[]> {
    const { data } = await firstValueFrom(
      this.http.get<OpenDotaHero[]>(`${this.baseUrl}/heroes`, { timeout: 10000 }),
    );
    return data;
  }

  /**
   * Recent public matches for one hero — a small, cheap summary list,
   * used only to get match_ids to then fetch full detail for (see
   * HeroesService.syncItemBuilds). Not the same as a player's own match
   * history.
   */
  async getHeroRecentMatches(heroId: number, limit = 20): Promise<OpenDotaHeroRecentMatch[]> {
    const { data } = await firstValueFrom(
      this.http.get<OpenDotaHeroRecentMatch[]>(`${this.baseUrl}/heroes/${heroId}/matches`, {
        timeout: 10000,
      }),
    );
    return data.slice(0, limit);
  }

  /**
   * Item id -> display name/icon. Static, safe to cache aggressively —
   * only changes on patch days, same as hero data.
   */
  async getItemConstants(): Promise<Record<string, OpenDotaItemConstant>> {
    const { data } = await firstValueFrom(
      this.http.get<Record<string, OpenDotaItemConstant>>(`${this.baseUrl}/constants/items`, {
        timeout: 10000,
      }),
    );
    return data;
  }

  /**
   * Full match detail, including per-player time-series arrays. This is
   * the heavier fetch that Match Analyzer needs on top of the cheap
   * match-list summary — one call per match_id, not something to do for
   * every match in a list view.
   */
  async getMatch(matchId: number): Promise<OpenDotaMatchDetail> {
    const { data } = await firstValueFrom(
      this.http.get<OpenDotaMatchDetail>(`${this.baseUrl}/matches/${matchId}`, {
        timeout: 15000,
      }),
    );
    return data;
  }

  /**
   * Requests OpenDota parse a match's replay — the on-demand trigger
   * behind AI Coach, per-match and user-initiated, NOT a bulk background
   * job the way rank-snapshot/trial-matching sync everything. Typically
   * completes in 1-5 minutes; can genuinely fail for very old matches
   * or ones from private lobbies where the replay no longer exists on
   * Valve's servers — callers must handle that as a real outcome, not
   * an error to retry indefinitely.
   */
  async requestParse(matchId: number): Promise<{ job?: { jobId: number } }> {
    const { data } = await firstValueFrom(
      this.http.post(`${this.baseUrl}/request/${matchId}`, null, { timeout: 10000 }),
    );
    return data;
  }

  /**
   * `/constants/patch` — the source behind PatchSyncService's
   * detection. Returns entries in the SAME human-readable naming Areon
   * already depends on elsewhere (Match.patch, DraftSession's
   * rulesVersion comment referencing "7.40") — deliberately not using
   * Steam's internal build-number versioning, which is a different,
   * less directly useful numbering scheme for what Areon actually
   * needs to detect ("did gameplay-relevant patch data change").
   */
  async getPatchList(): Promise<{ name: string; date: string }[]> {
    const { data } = await firstValueFrom(
      this.http.get<{ name: string; date: string }[]>(`${this.baseUrl}/constants/patch`, { timeout: 10000 }),
    );
    return data;
  }

  async getBenchmarks(heroId: number): Promise<OpenDotaBenchmarks> {
    const { data } = await firstValueFrom(
      this.http.get<OpenDotaBenchmarks>(`${this.baseUrl}/benchmarks`, {
        params: { hero_id: heroId },
        timeout: 10000,
      }),
    );
    return data;
  }

  /**
   * rank_tier is available without Expose Public Match Data — that's why
   * we snapshot it daily regardless of a user's exposure state. See the
   * MMR-hierarchy discussion: medal is reliable, mmr_estimate is a
   * heuristic, and exact numeric MMR usually isn't available at all.
   */
  async getPlayerRank(accountId32: number): Promise<OpenDotaPlayerRank> {
    const { data } = await firstValueFrom(
      this.http.get<OpenDotaPlayerRank>(`${this.baseUrl}/players/${accountId32}`, {
        timeout: 10000,
      }),
    );
    return data;
  }

  /**
   * Recent professional matches — used by Draft Trainer's "Pro Draft"
   * mode to let someone browse real drafts to replay/study. Only matches
   * with a `picks_bans` array (Captain's Mode) are actually usable for
   * that; not every pro match will have one.
   */
  async getProMatches(): Promise<OpenDotaProMatch[]> {
    const { data } = await firstValueFrom(
      this.http.get<OpenDotaProMatch[]>(`${this.baseUrl}/proMatches`, { timeout: 10000 }),
    );
    return data;
  }

  /**
   * Base attributes (str/agi/int, gains, move speed) alongside the same
   * fields /heroes returns. Kept as a separate call because it's a
   * separate OpenDota endpoint with a heavier payload (win rates by
   * rank bracket that we don't use), not because it's used differently.
   */
  async getHeroStats(): Promise<OpenDotaHeroStats[]> {
    const { data } = await firstValueFrom(
      this.http.get<OpenDotaHeroStats[]>(`${this.baseUrl}/heroStats`, { timeout: 10000 }),
    );
    return data;
  }

  /**
   * Per-opponent win rate for one hero — this hero's win rate against
   * each other hero, computed from real match data. This is what powers
   * "хорош против / слаб против": high win rate = this hero counters
   * that one, low win rate = this hero gets countered by it.
   *
   * NOTE: this is confirmed to exist in OpenDota's API. A matching
   * "synergy with ally" endpoint (win rate *with* another hero on the
   * same team) is NOT confirmed here — don't assume one and fabricate
   * "хорошо сочетается с" data from this same call. See heroes.service.ts.
   */
  async getHeroMatchups(heroId: number): Promise<OpenDotaMatchup[]> {
    const { data } = await firstValueFrom(
      this.http.get<OpenDotaMatchup[]>(`${this.baseUrl}/heroes/${heroId}/matchups`, {
        timeout: 10000,
      }),
    );
    return data;
  }
}
