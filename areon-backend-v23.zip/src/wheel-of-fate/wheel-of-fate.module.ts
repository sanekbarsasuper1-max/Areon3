import { Module } from '@nestjs/common';
import { WheelOfFateController } from './wheel-of-fate.controller';
import { WheelOfFateService } from './wheel-of-fate.service';
import { PrismaService } from '../prisma.service';
import { OpenDotaModule } from '../opendota/opendota.module';
import { MonitoringModule } from '../monitoring/monitoring.module';

@Module({
  imports: [OpenDotaModule, MonitoringModule],
  controllers: [WheelOfFateController],
  providers: [WheelOfFateService, PrismaService],
})
export class WheelOfFateModule {}
