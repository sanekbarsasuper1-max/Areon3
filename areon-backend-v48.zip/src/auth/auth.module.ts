import { Module, MiddlewareConsumer, NestModule, RequestMethod } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { PassportModule } from '@nestjs/passport';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { SteamStrategy } from './steam.strategy';
import { JwtStrategy } from './jwt.strategy';
import { PrismaService } from '../prisma.service';
import { PlayersModule } from '../players/players.module';
import { SecurityModule } from '../security/security.module';
import { MonitoringModule } from '../monitoring/monitoring.module';
import { CaptureReturnToMiddleware } from './capture-return-to.middleware';

@Module({
  imports: [
    PassportModule,
    PlayersModule,
    SecurityModule,
    MonitoringModule,
    JwtModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        secret: config.get('JWT_SECRET'),
        signOptions: { expiresIn: '30d' },
      }),
    }),
  ],
  controllers: [AuthController],
  providers: [AuthService, SteamStrategy, JwtStrategy, PrismaService],
})
export class AuthModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(CaptureReturnToMiddleware).forRoutes({ path: 'auth/steam', method: RequestMethod.GET });
  }
}
