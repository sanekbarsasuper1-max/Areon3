import { Injectable, NestMiddleware } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Request, Response, NextFunction } from 'express';

/**
 * Runs BEFORE AuthGuard('steam') on /auth/steam (middleware executes
 * ahead of guards in Nest's request pipeline), so it can stash where
 * the person actually was before Passport takes over and redirects to
 * Steam. This is what was missing entirely before — steamReturn()
 * always landed everyone on a hardcoded /profile regardless of where
 * they started, which is what looked like a mobile/desktop mixup when
 * someone happened to notice it after toggling "Desktop site" (the
 * bug is the same regardless of User-Agent or viewport; that's just
 * when it became visible to them).
 *
 * A cookie survives the round trip to Steam and back — Steam's OpenID
 * return_to mechanics are passport-steam's internal concern, not
 * something worth depending on for this. Short-lived and scoped to
 * exactly the /auth/steam/return path it's read from.
 */
@Injectable()
export class CaptureReturnToMiddleware implements NestMiddleware {
  constructor(private readonly config: ConfigService) {}

  use(req: Request, res: Response, next: NextFunction) {
    const returnTo = req.query.returnTo;
    if (typeof returnTo === 'string' && isSafeRelativePath(returnTo)) {
      const appUrl = this.config.get('APP_URL');
      res.cookie('areon_return_to', returnTo, {
        httpOnly: true,
        sameSite: 'lax', // both legs of this round trip hit the backend's own domain directly — a real cross-site case, unlike the frontend's areon_token, would need 'none'
        secure: appUrl?.startsWith('https://') ?? false,
        maxAge: 5 * 60 * 1000, // the whole Steam round trip should take well under this
        path: '/auth/steam/return',
      });
    }
    next();
  }
}

/**
 * Only ever a same-site path+hash, never an absolute URL or
 * protocol-relative one — this value came from a query string on a
 * public, unauthenticated endpoint, so treating it as a safe redirect
 * target without this check would be an open-redirect vector.
 */
export function isSafeRelativePath(value: string): boolean {
  return value.startsWith('/') && !value.startsWith('//') && !value.includes('\\');
}
