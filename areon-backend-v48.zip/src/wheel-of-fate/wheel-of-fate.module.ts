import { Module } from '@nestjs/common';
import { WheelOfFateController } from './wheel-of-fate.controller';
import { WheelOfFateService } from './wheel-of-fate.service';
import { PrismaService } from '../prisma.service';
import { OpenDotaModule } from '../opendota/opendota.module';
import { MonitoringModule } from '../monitoring/monitoring.module';
import { RewardsModule } from '../rewards/rewards.module';

@Module({
  imports: [OpenDotaModule, MonitoringModule, RewardsModule],
  controllers: [WheelOfFateController],
  providers: [WheelOfFateService, PrismaService],
  exports: [WheelOfFateService],
})
export class WheelOfFateModule {}
