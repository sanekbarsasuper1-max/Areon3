import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { YouTubeProviderService } from './youtube-provider.service';

const SEARCH_CACHE_TTL_MS = 15 * 60 * 1000; // 15 minutes — requirement 9

@Injectable()
export class MusicService {
  private searchCache = new Map<string, { data: unknown; expiresAt: number }>();

  constructor(
    private readonly prisma: PrismaService,
    private readonly youtube: YouTubeProviderService,
  ) {}

  /**
   * requirement 9's cache — in-memory (this service already runs as a
   * single instance on the free tier, so this covers the actual case
   * that matters: many people searching the same popular artist
   * without each one round-tripping to YouTube's search API, which
   * also directly stretches YouTube Data API's modest free daily
   * quota further) rather than adding a new Redis client dependency
   * just for this; Redis in this project is already reserved for
   * BullMQ's job queue, not a general cache.
   */
  async searchCached(query: string) {
    const q = query?.trim().toLowerCase();
    if (!q) return { tracks: [] };

    const cached = this.searchCache.get(q);
    if (cached && cached.expiresAt > Date.now()) return cached.data;

    const result = await this.youtube.search(q);
    this.searchCache.set(q, { data: result, expiresAt: Date.now() + SEARCH_CACHE_TTL_MS });
    return result;
  }

  async listFavorites(userId: string) {
    return this.prisma.favoriteTrack.findMany({ where: { userId }, orderBy: { createdAt: 'desc' } });
  }

  async addFavorite(userId: string, track: { providerTrackId: string; name: string; artist: string; imageUrl?: string }) {
    // Upsert-by-hand rather than a real upsert — same effect, and this
    // codebase already leans on findUnique-then-create in a few places
    // (e.g. rank snapshots) for the same "don't error on a harmless
    // double-click" reasoning.
    const existing = await this.prisma.favoriteTrack.findUnique({
      where: { userId_provider_providerTrackId: { userId, provider: 'youtube', providerTrackId: track.providerTrackId } },
    });
    if (existing) return existing;
    return this.prisma.favoriteTrack.create({
      data: { userId, provider: 'youtube', ...track },
    });
  }

  async removeFavorite(userId: string, providerTrackId: string) {
    const existing = await this.prisma.favoriteTrack.findUnique({
      where: { userId_provider_providerTrackId: { userId, provider: 'youtube', providerTrackId } },
    });
    if (!existing) return { deleted: false };
    await this.prisma.favoriteTrack.delete({ where: { id: existing.id } });
    return { deleted: true };
  }
}
