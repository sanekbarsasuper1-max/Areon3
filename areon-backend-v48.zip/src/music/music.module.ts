import { Module } from '@nestjs/common';
import { MusicController } from './music.controller';
import { MusicService } from './music.service';
import { YouTubeProviderService } from './youtube-provider.service';
import { PrismaService } from '../prisma.service';

@Module({
  controllers: [MusicController],
  providers: [MusicService, YouTubeProviderService, PrismaService],
})
export class MusicModule {}
