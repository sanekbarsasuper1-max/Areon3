import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

export interface YouTubeTrack {
  id: string; // YouTube video id — what the frontend's IFrame Player loads directly
  name: string;
  artist: string; // the channel name — YouTube's search results don't expose a separate "artist" field the way a music-specific catalog would
  imageUrl: string | null;
  durationSec: number;
}

/**
 * Third source tried for this feature, and the only one so far that
 * actually plays full tracks rather than a 30-second clip — Spotify
 * (Premium-only dev accounts), Apple/iTunes (erratic rate limiting),
 * and Deezer (legitimate but preview-only by design, same as every
 * other public catalog API — see deezer-provider.service.ts's own
 * comment) all came before this. The tradeoff or requiring the
 * YouTube-branded player is the cost of full-length playback done
 * legally: nothing extracts or rehosts audio, playback happens
 * entirely inside YouTube's own official embeddable IFrame Player,
 * which is explicitly designed and permitted for exactly this.
 *
 * Needs a YOUTUBE_API_KEY (YouTube Data API v3, enabled in Google
 * Cloud Console — free tier is 10,000 units/day; a search costs 100
 * units, so roughly 100 searches/day before hitting that ceiling,
 * shared across everyone using the site. Not configured yet — set
 * the env var to turn this on).
 */
@Injectable()
export class YouTubeProviderService {
  private readonly logger = new Logger(YouTubeProviderService.name);
  private readonly baseUrl = 'https://www.googleapis.com/youtube/v3';

  constructor(private readonly config: ConfigService) {}

  private get apiKey(): string | undefined {
    return this.config.get('YOUTUBE_API_KEY');
  }

  async search(query: string, limit = 20): Promise<{ tracks: YouTubeTrack[] }> {
    const key = this.apiKey;
    if (!key) {
      throw new HttpException('Music search is not configured yet (missing YOUTUBE_API_KEY).', HttpStatus.SERVICE_UNAVAILABLE);
    }

    const searchUrl = `${this.baseUrl}/search?part=snippet&type=video&videoCategoryId=10&maxResults=${limit}&q=${encodeURIComponent(query)}&key=${key}`;
    const searchRes = await fetch(searchUrl);
    if (searchRes.status === 403) {
      // YouTube returns 403 (not 429) for a blown daily quota —
      // surfaced distinctly so the frontend can say something honest
      // rather than "nothing found".
      throw new HttpException('Music search has hit its daily quota — try again tomorrow.', HttpStatus.TOO_MANY_REQUESTS);
    }
    if (!searchRes.ok) {
      this.logger.warn(`YouTube search failed: ${searchRes.status}`);
      throw new HttpException('Music search failed — try again shortly.', HttpStatus.BAD_GATEWAY);
    }
    const searchData = await searchRes.json();
    const items: any[] = searchData.items ?? [];
    if (items.length === 0) return { tracks: [] };

    // search.list doesn't return duration — a second call (cheap: 1
    // unit) against videos.list for contentDetails does.
    const ids = items.map((it) => it.id.videoId).filter(Boolean);
    const durationsById = await this.fetchDurations(ids, key);

    const tracks: YouTubeTrack[] = items
      .filter((it) => it.id?.videoId)
      .map((it) => ({
        id: it.id.videoId,
        name: it.snippet.title,
        artist: it.snippet.channelTitle,
        imageUrl: it.snippet.thumbnails?.medium?.url ?? it.snippet.thumbnails?.default?.url ?? null,
        durationSec: durationsById[it.id.videoId] ?? 0,
      }));

    return { tracks };
  }

  private async fetchDurations(videoIds: string[], key: string): Promise<Record<string, number>> {
    if (videoIds.length === 0) return {};
    try {
      const res = await fetch(`${this.baseUrl}/videos?part=contentDetails&id=${videoIds.join(',')}&key=${key}`);
      if (!res.ok) return {};
      const data = await res.json();
      const out: Record<string, number> = {};
      for (const item of data.items ?? []) {
        out[item.id] = parseIso8601Duration(item.contentDetails?.duration);
      }
      return out;
    } catch (e) {
      this.logger.warn(`Failed to fetch video durations: ${e instanceof Error ? e.message : String(e)}`);
      return {};
    }
  }
}

/** "PT3M32S" -> 212 (seconds). YouTube's contentDetails.duration format — ISO 8601, not a plain number. */
function parseIso8601Duration(iso?: string): number {
  if (!iso) return 0;
  const m = /^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/.exec(iso);
  if (!m) return 0;
  const [, h, mi, s] = m;
  return (Number(h) || 0) * 3600 + (Number(mi) || 0) * 60 + (Number(s) || 0);
}
