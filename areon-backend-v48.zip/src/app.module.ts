import { Module, OnModuleInit } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { ScheduleModule } from '@nestjs/schedule';
import { BullModule } from '@nestjs/bullmq';
import { ThrottlerModule } from '@nestjs/throttler';
import { LoggingThrottlerGuard } from './security/logging-throttler.guard';
import { SecurityModule } from './security/security.module';
import { AuthModule } from './auth/auth.module';
import { PlayersModule } from './players/players.module';
import { MatchesModule } from './matches/matches.module';
import { HeroesModule } from './heroes/heroes.module';
import { RankSnapshotsModule } from './rank-snapshots/rank-snapshots.module';
import { TeamsModule } from './teams/teams.module';
import { TournamentsModule } from './tournaments/tournaments.module';
import { DraftTrainerModule } from './draft-trainer/draft-trainer.module';
import { AdminModule } from './admin/admin.module';
import { TrialsModule } from './trials/trials.module';
import { TrialGeneratorService } from './trials/trial-generator.service';
import { MusicModule } from './music/music.module';
import { CoachModule } from './coach/coach.module';
import { PatchModule } from './patch/patch.module';
import { PatchSyncService } from './patch/patch-sync.service';
import { MiniGamesModule } from './minigames/minigames.module';
import { MinesweeperService } from './minigames/minesweeper/minesweeper.service';
import { WheelOfFateModule } from './wheel-of-fate/wheel-of-fate.module';
import { DraftTournamentsModule } from './draft-tournaments/draft-tournaments.module';
import { RewardsModule } from './rewards/rewards.module';
import { ShopModule } from './shop/shop.module';
import { ShopService } from './shop/shop.service';
import { HallOfFameModule } from './hall-of-fame/hall-of-fame.module';
import { HallOfFameService } from './hall-of-fame/hall-of-fame.service';
import { UpdatesModule } from './updates/updates.module';
import { VersionsService } from './updates/versions.service';
import { JwtAuthGuard } from './auth/jwt-auth.guard';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ScheduleModule.forRoot(),
    // Global default: 60 requests/minute per IP. Deliberately generous
    // for ordinary browsing — the AI-calling endpoints (Coach, Wheel of
    // Fate) get a much stricter override right on their own
    // controllers (@Throttle), since those are the ones that actually
    // cost real money per call and are the specific concern from the
    // security audit, not general API abuse.
    ThrottlerModule.forRoot([{ ttl: 60_000, limit: 60 }]),
    // One Redis connection, shared by every queue registered anywhere
    // in the app (currently just rank-snapshot) — REDIS_URL is required
    // once any queue-backed module is imported; there's no in-memory
    // fallback, on purpose, so a missing Redis fails loudly at startup
    // rather than silently degrading to "cron never actually runs."
    BullModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        connection: { url: config.get<string>('REDIS_URL') },
      }),
    }),
    AuthModule,
    PlayersModule,
    MatchesModule,
    HeroesModule,
    RankSnapshotsModule,
    TeamsModule,
    TournamentsModule,
    DraftTrainerModule,
    AdminModule,
    TrialsModule,
    MusicModule,
    CoachModule,
    PatchModule,
    MiniGamesModule,
    WheelOfFateModule,
    DraftTournamentsModule,
    RewardsModule,
    ShopModule,
    HallOfFameModule,
    UpdatesModule,
    SecurityModule,
  ],
  providers: [
    // Every route requires a session by default now. Only /auth/steam and
    // /auth/steam/return opt out, via @Public() — see public.decorator.ts.
    // This replaces the old pattern of remembering @UseGuards(JwtAuthGuard)
    // on every new controller, which is exactly how /heroes almost shipped
    // unguarded despite the explicit "closed, no exceptions" decision.
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    // Runs on every request too (both APP_GUARD providers do) —
    // order doesn't matter here since the two checks are independent
    // (rate limit is by IP, not by auth state) and neither short-
    // circuits the other's reasoning.
    { provide: APP_GUARD, useClass: LoggingThrottlerGuard },
  ],
})
export class AppModule implements OnModuleInit {
  constructor(
    private readonly trialGenerator: TrialGeneratorService,
    private readonly patchSync: PatchSyncService,
    private readonly minesweeperService: MinesweeperService,
    private readonly hallOfFameService: HallOfFameService,
    private readonly versionsService: VersionsService,
    private readonly shopService: ShopService,
  ) {}

  // Idempotent (see seedTemplates' own comment) — safe to run on every
  // boot, not just the first one.
  async onModuleInit() {
    await this.trialGenerator.seedTemplates();
    await this.patchSync.ensureInitialized();
    await this.minesweeperService.seedConfigs();
    await this.hallOfFameService.seedRecordTypes();
    await this.versionsService.seedInitialVersion();
    await this.versionsService.ensureVersion2();
    await this.versionsService.ensureVersion21();
    await this.versionsService.ensureVersion22();
    await this.versionsService.ensureVersion23();
    await this.versionsService.ensureVersion24();
    await this.versionsService.ensureVersion25();
    await this.versionsService.ensureVersion26();
    await this.versionsService.ensureVersion27();
    await this.versionsService.ensureVersion28();
    await this.shopService.ensureSeeded();
    await this.versionsService.ensureVersion29();
    await this.versionsService.ensureVersion30();
    await this.versionsService.ensureVersion31();
    await this.versionsService.ensureVersion32();
    await this.versionsService.ensureVersion33();
  }
}
