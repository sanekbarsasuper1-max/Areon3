import { Body, Controller, Delete, Get, Param, ParseIntPipe, Patch, Post, Query, Req, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { AdminGuard } from '../auth/admin.guard';
import { PrismaService } from '../prisma.service';
import { HeroesService } from '../heroes/heroes.service';
import { WheelOfFateService } from '../wheel-of-fate/wheel-of-fate.service';
import { TournamentsService } from '../tournaments/tournaments.service';
import { DraftTrainerService } from '../draft-trainer/draft-trainer.service';
import { ShardsService } from '../trials/shards.service';
import { PatchSyncService } from '../patch/patch-sync.service';
import { HallOfFameService } from '../hall-of-fame/hall-of-fame.service';
import { VersionsService } from '../updates/versions.service';
import { SuggestionsService } from '../updates/suggestions.service';
import { SupportService } from '../updates/support.service';
import { SecurityLogService } from '../security/security-log.service';
import { PlayerReportsService } from '../security/player-reports.service';
import { MonitoringService } from '../monitoring/monitoring.service';

// Stricter than the global 60/min default (audit MEDIUM #6/#28: "админ-панель
// должна быть защищена ещё сильнее, чем обычный сайт"). AdminGuard already
// checks a fixed ADMIN_STEAM_ID64 server-side, not a guessable credential —
// this isn't about slowing down brute force, it's about limiting how much
// automated damage a single compromised admin session could do in a burst
// (e.g. a script looping a bulk ban/config-change call), and about making
// reconnaissance against the admin surface slower even for someone who did
// get in. 30/min is tight enough to matter but loose enough that a human
// admin clicking around several tabs won't hit it in normal use.
@Throttle({ default: { limit: 30, ttl: 60_000 } })
@Controller('admin')
@UseGuards(AdminGuard)
export class AdminController {
  constructor(
    private readonly prisma: PrismaService,
    private readonly heroesService: HeroesService,
    private readonly tournamentsService: TournamentsService,
    private readonly draftTrainerService: DraftTrainerService,
    private readonly shardsService: ShardsService,
    private readonly patchSync: PatchSyncService,
    private readonly hallOfFame: HallOfFameService,
    private readonly versionsService: VersionsService,
    private readonly suggestionsService: SuggestionsService,
    private readonly supportService: SupportService,
    private readonly securityLog: SecurityLogService,
    private readonly playerReports: PlayerReportsService,
    private readonly monitoring: MonitoringService,
    private readonly wheelOfFateService: WheelOfFateService,
  ) {}

  // --- Monitoring (requirement: online now, visits, activity log) ---

  @Get('monitoring/overview')
  getMonitoringOverview() {
    return this.monitoring.getOverview();
  }

  @Get('monitoring/online')
  getOnlineNow() {
    return this.monitoring.getOnlineNow();
  }

  @Get('monitoring/visits')
  getVisits(@Query('from') from?: string, @Query('to') to?: string) {
    const range = {
      from: from ? new Date(from) : new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      to: to ? new Date(to) : new Date(),
    };
    return this.monitoring.getVisits(range);
  }

  @Get('monitoring/activity')
  getActivity(@Query('userId') userId?: string, @Query('type') type?: string) {
    return this.monitoring.getActivity({ userId, type });
  }

  @Get('monitoring/user/:id')
  getUserDetail(@Param('id') id: string) {
    return this.monitoring.getUserDetail(id);
  }

  @Get('stats')
  async stats() {
    const [users, teams, tournaments, matches, heroes, draftSessions] = await Promise.all([
      this.prisma.user.count(),
      this.prisma.team.count(),
      this.prisma.tournament.count(),
      this.prisma.match.count(),
      this.prisma.hero.count(),
      this.prisma.draftSession.count(),
    ]);
    return { users, teams, tournaments, matches, heroes, draftSessions };
  }

  @Get('users')
  async users() {
    return this.prisma.user.findMany({
      select: {
        id: true,
        personaName: true,
        avatarFull: true,
        accountId32: true,
        statsExposed: true,
        isAdmin: true,
        isBanned: true,
        banReason: true,
        createdAt: true,
        lastSeenAt: true,
        _count: { select: { matches: true, teamMemberships: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  @Get('teams')
  async teams() {
    return this.prisma.team.findMany({
      include: { members: { select: { role: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  @Get('tournaments')
  async tournaments() {
    return this.prisma.tournament.findMany({
      include: { registrations: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  // Moved here from HeroesController: syncing the full hero database
  // is a global, moderately expensive operation that shouldn't be
  // triggerable by any logged-in user, just because they happened to
  // find the route.
  @Get('heroes')
  async heroes() {
    return this.prisma.hero.findMany({ orderBy: { localizedName: 'asc' } });
  }

  @Post('heroes/sync')
  syncHeroes() {
    return this.heroesService.syncHeroes();
  }

  @Post('heroes/:id/sync-matchups')
  syncMatchups(@Param('id', ParseIntPipe) id: number) {
    return this.heroesService.syncMatchups(id);
  }

  @Post('heroes/sync-all-matchups')
  syncAllMatchups() {
    return this.heroesService.syncAllMatchups();
  }

  @Post('abilities/sync')
  syncAbilities() {
    return this.heroesService.syncAbilities();
  }

  @Post('wheel/pregenerate-concepts')
  pregenerateWheelConcepts() {
    return this.wheelOfFateService.pregenerateAllConcepts();
  }

  // Item recommendations — see the cost note on syncItemBuilds itself.
  // syncItems must be run at least once before this means anything
  // (it's what maps raw item ids to names/icons).
  @Post('items/sync')
  syncItems() {
    return this.heroesService.syncItems();
  }

  @Post('heroes/:id/sync-items')
  syncItemBuilds(@Param('id', ParseIntPipe) id: number) {
    return this.heroesService.syncItemBuilds(id);
  }

  /**
   * The mechanism behind Hero.captainsModeAvailable existed since the
   * hero database was first built, but nothing ever set it to false —
   * there was no curated exclusion list and no way to edit it. This is
   * that way: a support/admin action for "this hero was just released
   * and Valve hasn't enabled it in CM yet" or similar, without needing
   * direct database access.
   */
  @Patch('heroes/:id')
  async editHero(@Param('id', ParseIntPipe) id: number, @Body() body: { captainsModeAvailable: boolean }) {
    return this.prisma.hero.update({
      where: { id },
      data: { captainsModeAvailable: body.captainsModeAvailable },
    });
  }

  // --- Support actions ---

  /**
   * A banned account can't do anything from this point on — enforced
   * in JwtStrategy.validate(), not just checked here. Reason is stored,
   * not just a boolean, so a later "why was this account banned" is
   * answerable without relying on someone's memory.
   */
  @Post('users/:id/ban')
  async banUser(@Req() req: any, @Param('id') id: string, @Body() body: { reason?: string }) {
    const result = await this.prisma.user.update({
      where: { id },
      data: { isBanned: true, bannedAt: new Date(), banReason: body.reason ?? null },
    });
    await this.securityLog.log('ADMIN_ACTION', {
      userId: req.user.sub,
      metadata: { action: 'ban', targetUserId: id, reason: body.reason ?? null },
    });
    return result;
  }

  @Post('users/:id/unban')
  async unbanUser(@Req() req: any, @Param('id') id: string) {
    const result = await this.prisma.user.update({
      where: { id },
      data: { isBanned: false, bannedAt: null, banReason: null },
    });
    await this.securityLog.log('ADMIN_ACTION', { userId: req.user.sub, metadata: { action: 'unban', targetUserId: id } });
    return result;
  }

  /**
   * Deliberately narrow: only personaName and statsExposed are
   * editable here. accountId32/steamId64 are tied to real Steam
   * identity — editing them would desync the account from the person
   * it actually belongs to. isAdmin is excluded on purpose too: that
   * stays governed solely by ADMIN_STEAM_ID64, per the earlier decision
   * that there should be no in-app way to grant or revoke it.
   */
  @Patch('users/:id')
  async editUser(@Param('id') id: string, @Body() body: { personaName?: string; statsExposed?: boolean }) {
    return this.prisma.user.update({
      where: { id },
      data: {
        ...(body.personaName !== undefined ? { personaName: body.personaName } : {}),
        ...(body.statsExposed !== undefined ? { statsExposed: body.statsExposed } : {}),
      },
    });
  }

  // Support action: closes a stuck tournament regardless of state.
  @Post('tournaments/:id/force-close')
  forceCloseTournament(@Param('id') id: string) {
    return this.tournamentsService.adminForceClose(id);
  }

  // Support action: forces a match result without needing to be the
  // tournament's organizer — for when a bracket is stuck waiting on an
  // organizer who's unreachable.
  @Post('tournaments/:id/matches/:matchId/force-result')
  forceMatchResult(
    @Param('matchId') matchId: string,
    @Body() body: { winnerTeamId: string; scoreA: number; scoreB: number },
  ) {
    return this.tournamentsService.adminForceResult(matchId, body.winnerTeamId, body.scoreA, body.scoreB);
  }

  // --- Draft Trainer spectating ---

  // Every active/waiting free-mode draft, for the "watch any game" list
  // — not scoped to games the admin is playing in.
  @Get('draft-sessions')
  listActiveDrafts() {
    return this.draftTrainerService.adminListActiveSessions();
  }

  // --- Wheel of Fate ---
  // Uses PrismaService directly (already injected above) rather than
  // adding a new service dependency for two read-only admin queries —
  // WheelOfFateService itself has no admin-specific methods yet, same
  // as most other features' admin visibility in this controller.

  @Get('wheel/active')
  async listActiveWheelChallenges() {
    const challenges = await this.prisma.wheelChallenge.findMany({
      where: { status: { in: ['READY', 'ACCEPTED', 'SEARCHING_MATCH', 'CHECKING'] } },
      orderBy: { createdAt: 'desc' },
      include: { user: { select: { personaName: true, steamId64: true } } },
    });
    return challenges.map((c) => ({ ...c, matchId: c.matchId?.toString() ?? null }));
  }

  @Get('wheel/history')
  async listWheelHistory() {
    const challenges = await this.prisma.wheelChallenge.findMany({
      where: { status: { in: ['WON', 'LOST', 'REROLLED', 'EXPIRED'] } },
      orderBy: { resolvedAt: 'desc' },
      take: 100,
      include: { user: { select: { personaName: true, steamId64: true } } },
    });
    return challenges.map((c) => ({ ...c, matchId: c.matchId?.toString() ?? null }));
  }

  @Get('wheel/config')
  async getWheelConfig() {
    const existing = await this.prisma.wheelConfig.findUnique({ where: { id: 'singleton' } });
    return existing ?? this.prisma.wheelConfig.create({ data: { id: 'singleton' } });
  }

  @Patch('wheel/config')
  async updateWheelConfig(
    @Body() body: { winShards?: number; lossShards?: number; rerollCost?: number; winRating?: number; lossRating?: number },
  ) {
    await this.prisma.wheelConfig.upsert({ where: { id: 'singleton' }, create: { id: 'singleton' }, update: {} });
    return this.prisma.wheelConfig.update({ where: { id: 'singleton' }, data: body });
  }

  // Admin-only undo. There is no player-facing equivalent — see the
  // limitation noted on adminUndo() about reserve time not being
  // refunded.
  @Post('draft-sessions/:id/undo')
  undoDraftAction(@Param('id') id: string) {
    return this.draftTrainerService.adminUndo(id);
  }

  // --- Orion Trials — Trial Management (requirement 22) ---

  @Get('trials/templates')
  async listTrialTemplates() {
    const templates = await this.prisma.trialTemplate.findMany({ orderBy: { createdAt: 'asc' } });
    // Completion counts — "просматривать количество выполнений" from
    // the spec, computed rather than stored, since it's cheap at this
    // scale and never goes stale.
    const counts = await this.prisma.userTrial.groupBy({
      by: ['templateId'],
      where: { status: 'COMPLETED' },
      _count: { id: true },
    });
    const countByTemplate = new Map(counts.map((c) => [c.templateId, c._count.id]));
    return templates.map((t) => ({ ...t, completionCount: countByTemplate.get(t.id) ?? 0 }));
  }

  @Post('trials/templates')
  createTrialTemplate(
    @Body()
    body: {
      code: string;
      category: string;
      difficulty: string;
      title: string;
      description: string;
      conditionJson: Record<string, any>;
      targetValue: number;
      rewardShards: number;
    },
  ) {
    return this.prisma.trialTemplate.create({ data: body as any });
  }

  // Deliberately narrow, same reasoning as editUser above: title,
  // description, reward, difficulty, active toggle. `code` and
  // `conditionJson`'s *shape* aren't editable here — those are tied to
  // a specific evaluator function in trial-evaluators.ts, and editing
  // them freely could point a template at parameters its evaluator
  // doesn't know how to read. Tuning existing numeric parameters
  // (targetValue, reward) is safe; changing what KIND of condition a
  // template checks is a code change, not an admin-panel edit.
  @Patch('trials/templates/:id')
  updateTrialTemplate(
    @Param('id') id: string,
    @Body()
    body: {
      title?: string;
      description?: string;
      difficulty?: string;
      targetValue?: number;
      rewardShards?: number;
      active?: boolean;
    },
  ) {
    return this.prisma.trialTemplate.update({ where: { id }, data: body as any });
  }

  @Get('trials/cycles')
  async listActiveCycles() {
    return this.prisma.userTrialCycle.findMany({
      where: { status: 'ACTIVE' },
      include: { trials: { include: { template: true } } },
      orderBy: { startedAt: 'desc' },
      take: 100,
    });
  }

  // Manual correction path — see ShardsService.adminAdjust's own
  // comment on why this still goes through the ledger, never a bare
  // balance write.
  @Post('users/:id/shards/adjust')
  adjustShards(@Param('id') userId: string, @Body() body: { amount: number; reason: string }) {
    return this.shardsService.adminAdjust(userId, body.amount, body.reason);
  }

  // --- Patch sync ---

  @Post('patch/check-now')
  checkPatchNow() {
    return this.patchSync.checkForNewPatch();
  }

  // See PatchSyncService's own comment on what this can and can't
  // actually restore — stops advancing to a broken patch, does not
  // resurrect prior hero/item stat values.
  @Post('patch/rollback')
  rollbackPatch() {
    return this.patchSync.rollback();
  }

  // --- Hall of Fame ---

  @Get('hall-of-fame/types')
  listHofTypes() {
    return this.prisma.hallOfFameRecordType.findMany({ orderBy: { category: 'asc' } });
  }

  @Get('hall-of-fame/entries')
  listHofEntries() {
    return this.prisma.hallOfFameEntry.findMany({
      include: { recordType: true, user: true, team: true },
      orderBy: { achievedAt: 'desc' },
      take: 200,
    });
  }

  // Manual entries — requirement 9's fallback for whatever isn't
  // automatically detected yet (e.g. "biggest_comeback"). Goes through
  // the SAME recordTypeId reference as automatic entries so it shows
  // up in the same history/category views, but createdByAdmin=true
  // keeps it clearly distinguished and — per requirement 9 — never
  // touched by any detector's SUPERSEDING/ONE_TIME logic, which only
  // ever looks at entries created through recordEvent().
  @Post('hall-of-fame/entries')
  createHofEntry(
    @Body()
    body: {
      recordTypeId: string;
      userId?: string;
      teamId?: string;
      value: string;
      rawValue?: number;
      description?: string;
      achievedAt?: string;
      isPinned?: boolean;
    },
  ) {
    return this.prisma.hallOfFameEntry.create({
      data: {
        recordTypeId: body.recordTypeId,
        userId: body.userId,
        teamId: body.teamId,
        value: body.value,
        rawValue: body.rawValue,
        description: body.description,
        achievedAt: body.achievedAt ? new Date(body.achievedAt) : new Date(),
        isPinned: body.isPinned ?? false,
        isCurrent: true,
        createdByAdmin: true,
      },
    });
  }

  @Patch('hall-of-fame/entries/:id')
  updateHofEntry(
    @Param('id') id: string,
    @Body() body: { value?: string; description?: string; isPinned?: boolean; isCurrent?: boolean },
  ) {
    return this.prisma.hallOfFameEntry.update({ where: { id }, data: body });
  }

  @Delete('hall-of-fame/entries/:id')
  deleteHofEntry(@Param('id') id: string) {
    return this.prisma.hallOfFameEntry.delete({ where: { id } });
  }

  @Post('hall-of-fame/types')
  createHofType(
    @Body() body: { key: string; category: string; title: string; icon: string; mode: string; higherIsBetter?: boolean },
  ) {
    return this.prisma.hallOfFameRecordType.create({ data: { ...body, isAutomatic: false } }); // admin-created types are never auto-detected, by construction — nothing calls recordEvent with a key nobody wired up
  }

  @Patch('hall-of-fame/types/:id')
  updateHofType(@Param('id') id: string, @Body() body: { title?: string; icon?: string; category?: string }) {
    return this.prisma.hallOfFameRecordType.update({ where: { id }, data: body });
  }

  // --- Updates & Feedback ---

  @Post('versions')
  createVersion(
    @Body() body: { version: string; added?: string[]; fixed?: string[]; improved?: string[]; addressed?: string[]; knownIssues?: string[] },
  ) {
    return this.versionsService.createVersion(body);
  }

  @Patch('versions/:id')
  updateVersion(
    @Param('id') id: string,
    @Body() body: { added?: string[]; fixed?: string[]; improved?: string[]; addressed?: string[]; knownIssues?: string[] },
  ) {
    return this.versionsService.updateVersion(id, body);
  }

  @Post('versions/:id/set-current')
  setCurrentVersion(@Param('id') id: string) {
    return this.versionsService.setCurrent(id);
  }

  @Post('versions/:id/link-suggestion/:suggestionId')
  linkSuggestionToVersion(@Param('id') id: string, @Param('suggestionId') suggestionId: string) {
    return this.versionsService.linkSuggestion(id, suggestionId);
  }

  @Patch('suggestions/:id/status')
  updateSuggestionStatus(@Param('id') id: string, @Body() body: { status: string; adminNote?: string }) {
    return this.suggestionsService.updateStatus(id, body.status, body.adminNote);
  }

  @Get('support/tickets')
  listAllTickets() {
    return this.supportService.listAll();
  }

  @Post('support/tickets/:id/reply')
  replyToTicket(@Param('id') id: string, @Body() body: { message: string }) {
    return this.supportService.reply(id, body.message);
  }

  @Post('support/tickets/:id/close')
  closeTicket(@Param('id') id: string) {
    return this.supportService.close(id);
  }

  // --- Security Dashboard ---

  @Get('security/log')
  getSecurityLog() {
    return this.securityLog.listRecent();
  }

  @Get('security/reports')
  getReportQueue() {
    return this.playerReports.listQueue();
  }

  @Patch('security/reports/:id')
  updateReportStatus(@Param('id') id: string, @Body() body: { status: string; adminNote?: string }) {
    return this.playerReports.setStatus(id, body.status, body.adminNote);
  }
}
