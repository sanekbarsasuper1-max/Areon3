import { Module } from '@nestjs/common';
import { AdminController } from './admin.controller';
import { AdminGuard } from '../auth/admin.guard';
import { PrismaService } from '../prisma.service';
import { HeroesModule } from '../heroes/heroes.module';
import { TournamentsModule } from '../tournaments/tournaments.module';
import { DraftTrainerModule } from '../draft-trainer/draft-trainer.module';
import { TrialsModule } from '../trials/trials.module';
import { PatchModule } from '../patch/patch.module';
import { HallOfFameModule } from '../hall-of-fame/hall-of-fame.module';
import { UpdatesModule } from '../updates/updates.module';
import { SecurityModule } from '../security/security.module';
import { MonitoringModule } from '../monitoring/monitoring.module';
import { WheelOfFateModule } from '../wheel-of-fate/wheel-of-fate.module';

@Module({
  imports: [HeroesModule, TournamentsModule, DraftTrainerModule, TrialsModule, PatchModule, HallOfFameModule, UpdatesModule, SecurityModule, MonitoringModule, WheelOfFateModule],
  controllers: [AdminController],
  providers: [AdminGuard, PrismaService],
})
export class AdminModule {}
