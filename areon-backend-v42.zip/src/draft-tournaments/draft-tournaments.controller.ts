import { Body, Controller, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { AdminGuard } from '../auth/admin.guard';
import { DraftTournamentsService } from './draft-tournaments.service';

@Controller('draft-tournaments')
@UseGuards(JwtAuthGuard)
export class DraftTournamentsController {
  constructor(private readonly service: DraftTournamentsService) {}

  @Get()
  list() {
    return this.service.list();
  }

  @Post()
  @UseGuards(AdminGuard)
  create(@Req() req: any, @Body() body: { name: string; maxPlayers: number }) {
    return this.service.create(req.user.sub, body.name, body.maxPlayers);
  }

  @Get(':id')
  detail(@Param('id') id: string) {
    return this.service.getDetail(id);
  }

  @Post(':id/register')
  register(@Req() req: any, @Param('id') id: string) {
    return this.service.register(id, req.user.sub);
  }

  @Post(':id/start')
  @UseGuards(AdminGuard)
  start(@Req() req: any, @Param('id') id: string) {
    return this.service.start(id, req.user.sub);
  }

  @Get(':id/my-match')
  myMatch(@Req() req: any, @Param('id') id: string) {
    return this.service.getMyMatch(id, req.user.sub);
  }

  // --- Admin tools ---

  @Post(':id/cancel')
  @UseGuards(AdminGuard)
  cancel(@Param('id') id: string) {
    return this.service.adminCancel(id);
  }

  @Post(':id/delete')
  @UseGuards(AdminGuard)
  delete(@Param('id') id: string) {
    return this.service.adminDelete(id);
  }

  @Post(':id/remove-player')
  @UseGuards(AdminGuard)
  removePlayer(@Param('id') id: string, @Body() body: { userId: string }) {
    return this.service.adminRemovePlayer(id, body.userId);
  }

  @Post('match/:matchId/force-result')
  @UseGuards(AdminGuard)
  forceResult(@Param('matchId') matchId: string, @Body() body: { winnerId: string }) {
    return this.service.adminForceResult(matchId, body.winnerId);
  }

  @Post('match/:matchId/replace-player')
  @UseGuards(AdminGuard)
  replacePlayer(@Param('matchId') matchId: string, @Body() body: { slot: 'A' | 'B'; newUserId: string }) {
    return this.service.adminReplacePlayer(matchId, body.slot, body.newUserId);
  }
}
