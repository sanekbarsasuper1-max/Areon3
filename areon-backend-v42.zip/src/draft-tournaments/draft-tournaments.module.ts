import { Module } from '@nestjs/common';
import { DraftTournamentsService } from './draft-tournaments.service';
import { DraftTournamentsController } from './draft-tournaments.controller';
import { PrismaService } from '../prisma.service';
import { RewardsModule } from '../rewards/rewards.module';

@Module({
  imports: [RewardsModule],
  providers: [DraftTournamentsService, PrismaService],
  controllers: [DraftTournamentsController],
  exports: [DraftTournamentsService],
})
export class DraftTournamentsModule {}
