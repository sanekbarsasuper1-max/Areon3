import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { RewardEngineService } from '../rewards/reward-engine.service';

function nextPowerOfTwo(n: number): number {
  return Math.pow(2, Math.ceil(Math.log2(Math.max(n, 1))));
}

@Injectable()
export class DraftTournamentsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly rewardEngine: RewardEngineService,
  ) {}

  async create(createdByUserId: string, name: string, maxPlayers: number) {
    if (maxPlayers < 2) throw new BadRequestException('maxPlayers must be at least 2');
    return this.prisma.draftTournament.create({ data: { name, maxPlayers, createdByUserId } });
  }

  async list() {
    return this.prisma.draftTournament.findMany({ orderBy: { createdAt: 'desc' } });
  }

  async register(tournamentId: string, userId: string) {
    const tournament = await this.prisma.draftTournament.findUnique({ where: { id: tournamentId } });
    if (!tournament) throw new NotFoundException('Tournament not found');
    if (tournament.status !== 'registration') throw new BadRequestException('Registration is closed for this tournament');

    const count = await this.prisma.draftTournamentRegistration.count({ where: { tournamentId } });
    if (count >= tournament.maxPlayers) throw new BadRequestException('Tournament is full');

    return this.prisma.draftTournamentRegistration.upsert({
      where: { tournamentId_userId: { tournamentId, userId } },
      create: { tournamentId, userId },
      update: {},
    });
  }

  async getDetail(tournamentId: string) {
    const tournament = await this.prisma.draftTournament.findUnique({
      where: { id: tournamentId },
      include: {
        registrations: { include: { } },
        matches: { orderBy: [{ round: 'asc' }, { position: 'asc' }] },
      },
    });
    if (!tournament) throw new NotFoundException('Tournament not found');

    const userIds = [
      ...new Set(tournament.registrations.map((r) => r.userId).concat(
        tournament.matches.flatMap((m) => [m.playerAId, m.playerBId, m.winnerId].filter((x): x is string => !!x)),
      )),
    ];
    const users = await this.prisma.user.findMany({ where: { id: { in: userIds } }, select: { id: true, personaName: true, avatarFull: true } });
    return { ...tournament, players: users };
  }

  /** Admin only, gated at the controller. */
  async start(tournamentId: string, requestingUserId: string) {
    const tournament = await this.prisma.draftTournament.findUnique({ where: { id: tournamentId } });
    if (!tournament) throw new NotFoundException('Tournament not found');
    if (tournament.status !== 'registration') throw new BadRequestException(`Tournament is already ${tournament.status}`);

    const registrations = await this.prisma.draftTournamentRegistration.findMany({ where: { tournamentId } });
    if (registrations.length < 2) throw new BadRequestException('Need at least 2 registered players to start');

    const playerIds = registrations.map((r) => r.userId);
    await this.generateSingleElimination(tournamentId, playerIds);

    return this.prisma.draftTournament.update({ where: { id: tournamentId }, data: { status: 'live', startedAt: new Date() } });
  }

  /**
   * Byes go to the first `byeCount` registered players, one per match,
   * spread across separate round-1 matches — identical reasoning to
   * TournamentsService.generateSingleEliminationBracket (see that
   * function's own comment): clustering byes can produce an
   * unplayable double-bye match, one-per-match never can.
   */
  private async generateSingleElimination(tournamentId: string, playerIds: string[]) {
    const bracketSize = nextPowerOfTwo(playerIds.length);
    const totalRounds = Math.log2(bracketSize);
    const byeCount = bracketSize - playerIds.length;

    const round1Pairs: [string | null, string | null][] = [];
    for (let i = 0; i < byeCount; i++) round1Pairs.push([playerIds[i], null]);
    for (let i = byeCount; i < bracketSize / 2; i++) {
      const idx = byeCount + (i - byeCount) * 2;
      round1Pairs.push([playerIds[idx] ?? null, playerIds[idx + 1] ?? null]);
    }

    const created = await this.prisma.$transaction(async (tx) => {
      const matches = [];
      for (let round = 1; round <= totalRounds; round++) {
        const matchesInRound = bracketSize / Math.pow(2, round);
        for (let position = 0; position < matchesInRound; position++) {
          const [playerAId, playerBId] = round === 1 ? round1Pairs[position] : [null, null];
          const status = round === 1 && playerAId && playerBId ? 'ready' : 'pending';
          matches.push(
            await tx.draftTournamentMatch.create({
              data: { tournamentId, round, position, playerAId, playerBId, status },
            }),
          );
        }
      }
      return matches;
    });

    for (const match of created.filter((m) => m.round === 1)) {
      const hasBye = (match.playerAId && !match.playerBId) || (!match.playerAId && match.playerBId);
      if (hasBye) {
        const winnerId = (match.playerAId ?? match.playerBId) as string;
        await this.resolveMatch(match.id, winnerId, true);
      }
    }
  }

  /**
   * The one place a match result gets decided — called either for a
   * bye (above) or from DraftTrainerService the instant a linked
   * DraftSession completes (see the hook there). Never called directly
   * by a player or admin action; there is deliberately no "submit
   * result" endpoint.
   */
  async resolveMatch(matchId: string, winnerId: string, isBye: boolean) {
    const match = await this.prisma.draftTournamentMatch.findUnique({ where: { id: matchId } });
    if (!match) throw new NotFoundException('Tournament match not found');
    if (match.status === 'completed' || match.status === 'bye') return match;
    if (!isBye && winnerId !== match.playerAId && winnerId !== match.playerBId) {
      throw new BadRequestException('winnerId must be one of the two players in this match');
    }

    const updated = await this.prisma.draftTournamentMatch.update({
      where: { id: matchId },
      data: { winnerId, status: isBye ? 'bye' : 'completed', completedAt: new Date() },
    });

    const nextMatch = await this.prisma.draftTournamentMatch.findUnique({
      where: { tournamentId_round_position: { tournamentId: match.tournamentId, round: match.round + 1, position: Math.floor(match.position / 2) } },
    });

    if (nextMatch) {
      const slot = match.position % 2 === 0 ? 'playerAId' : 'playerBId';
      const nextData: any = { [slot]: winnerId };
      const otherSlotFilled = match.position % 2 === 0 ? nextMatch.playerBId : nextMatch.playerAId;
      if (otherSlotFilled) nextData.status = 'ready';
      await this.prisma.draftTournamentMatch.update({ where: { id: nextMatch.id }, data: nextData });
    } else {
      // No next match exists — this was the final.
      await this.prisma.draftTournament.update({ where: { id: match.tournamentId }, data: { status: 'completed', completedAt: new Date() } });
    }

    // No reward for a bye — nobody actually played anything, so
    // there's no real activity to credit (requirement 3's
    // participation/result distinction only applies to matches that
    // were actually played).
    if (!isBye) {
      const loserId = winnerId === match.playerAId ? match.playerBId : match.playerAId;
      this.rewardEngine.grant({
        userId: winnerId, activityType: 'tournament_match', activityId: match.id,
        siteRatingDelta: 15, shardsDelta: nextMatch ? 0 : 500,
        reason: nextMatch ? 'Победа в матче Драфт-турнира' : 'Победа в Драфт-турнире',
      }).catch(() => {});
      if (loserId) {
        this.rewardEngine.grant({
          userId: loserId, activityType: 'tournament_match', activityId: match.id,
          siteRatingDelta: 3, reason: 'Участие в матче Драфт-турнира',
        }).catch(() => {});
      }
    }

    return updated;
  }

  async getMyMatch(tournamentId: string, userId: string) {
    const match = await this.prisma.draftTournamentMatch.findFirst({
      where: {
        tournamentId,
        status: { in: ['ready', 'pending', 'in_progress'] },
        OR: [{ playerAId: userId }, { playerBId: userId }],
      },
      orderBy: { round: 'asc' },
    });
    return match;
  }

  /** Called by DraftTrainerController when a player starts a draft for a 'ready' tournament match they're part of. */
  async markInProgress(matchId: string, draftSessionId: string) {
    await this.prisma.draftTournamentMatch.update({ where: { id: matchId }, data: { status: 'in_progress', draftSessionId } });
  }

  async getMatch(matchId: string) {
    const match = await this.prisma.draftTournamentMatch.findUnique({ where: { id: matchId } });
    if (!match) throw new NotFoundException('Tournament match not found');
    return match;
  }

  // ============================== Admin tools ==============================
  // Every method below is gated by AdminGuard at the controller — never
  // reachable by a regular user's request, matching this codebase's
  // existing pattern (see AdminGuard's own comment on re-checking
  // User.isAdmin fresh from the database on every request).

  async adminCancel(tournamentId: string) {
    const t = await this.prisma.draftTournament.findUnique({ where: { id: tournamentId } });
    if (!t) throw new NotFoundException('Tournament not found');
    if (t.status === 'completed') throw new BadRequestException('Cannot cancel a completed tournament');
    return this.prisma.draftTournament.update({ where: { id: tournamentId }, data: { status: 'cancelled' } });
  }

  async adminDelete(tournamentId: string) {
    const t = await this.prisma.draftTournament.findUnique({ where: { id: tournamentId } });
    if (!t) throw new NotFoundException('Tournament not found');
    await this.prisma.$transaction([
      this.prisma.draftTournamentMatch.deleteMany({ where: { tournamentId } }),
      this.prisma.draftTournamentRegistration.deleteMany({ where: { tournamentId } }),
      this.prisma.draftTournament.delete({ where: { id: tournamentId } }),
    ]);
    return { deleted: true };
  }

  /** Only before the bracket exists — once matches are generated, use adminReplacePlayer instead. */
  async adminRemovePlayer(tournamentId: string, userId: string) {
    const t = await this.prisma.draftTournament.findUnique({ where: { id: tournamentId } });
    if (!t) throw new NotFoundException('Tournament not found');
    if (t.status !== 'registration') throw new BadRequestException('Can only remove a player before the tournament starts');
    await this.prisma.draftTournamentRegistration.deleteMany({ where: { tournamentId, userId } });
    return { removed: true };
  }

  /**
   * Overrides a match's winner regardless of its current status —
   * requirement 2's "fix a wrong result without breaking the bracket"
   * (re-runs the same advance-to-next-round logic resolveMatch already
   * uses, so the rest of the bracket updates consistently rather than
   * needing separate patch-up logic).
   */
  async adminForceResult(matchId: string, winnerId: string) {
    const match = await this.prisma.draftTournamentMatch.findUnique({ where: { id: matchId } });
    if (!match) throw new NotFoundException('Tournament match not found');
    if (winnerId !== match.playerAId && winnerId !== match.playerBId) {
      throw new BadRequestException('winnerId must be one of the two players in this match');
    }
    // Un-complete it first so resolveMatch's own "already completed" guard doesn't block a correction.
    await this.prisma.draftTournamentMatch.update({ where: { id: matchId }, data: { status: 'ready', winnerId: null } });
    return this.resolveMatch(matchId, winnerId, false);
  }

  /** Swap in a replacement player before a match has been played — requirement 1's "заменить участника". */
  async adminReplacePlayer(matchId: string, slot: 'A' | 'B', newUserId: string) {
    const match = await this.prisma.draftTournamentMatch.findUnique({ where: { id: matchId } });
    if (!match) throw new NotFoundException('Tournament match not found');
    if (match.status === 'completed' || match.status === 'in_progress') {
      throw new BadRequestException('Cannot replace a player in a match that has already started');
    }
    return this.prisma.draftTournamentMatch.update({
      where: { id: matchId },
      data: slot === 'A' ? { playerAId: newUserId } : { playerBId: newUserId },
    });
  }
}
