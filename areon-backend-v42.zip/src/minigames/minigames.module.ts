import { Module } from '@nestjs/common';
import { MinesweeperController } from './minesweeper/minesweeper.controller';
import { MinesweeperService } from './minesweeper/minesweeper.service';
import { PrismaService } from '../prisma.service';
import { HallOfFameModule } from '../hall-of-fame/hall-of-fame.module';
import { RewardsModule } from '../rewards/rewards.module';

@Module({
  imports: [HallOfFameModule, RewardsModule],
  controllers: [MinesweeperController],
  providers: [MinesweeperService, PrismaService],
  exports: [MinesweeperService],
})
export class MiniGamesModule {}
