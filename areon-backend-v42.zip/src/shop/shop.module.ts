import { Module } from '@nestjs/common';
import { ShopService } from './shop.service';
import { ShopController } from './shop.controller';
import { PrismaService } from '../prisma.service';

@Module({
  providers: [ShopService, PrismaService],
  controllers: [ShopController],
  exports: [ShopService],
})
export class ShopModule {}
