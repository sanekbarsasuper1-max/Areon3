import { Body, Controller, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { AdminGuard } from '../auth/admin.guard';
import { ShopService } from './shop.service';

@Controller('shop')
export class ShopController {
  constructor(private readonly shop: ShopService) {}

  @Get('items')
  async items() {
    // Public browsing — ownership is cross-referenced client-side
    // against the separate authenticated /shop/inventory call rather
    // than needing a new "optional auth" guard pattern just for this.
    return this.shop.listItems(null);
  }

  @Post('items/:id/purchase')
  @UseGuards(JwtAuthGuard)
  purchase(@Req() req: any, @Param('id') id: string) {
    return this.shop.purchase(req.user.sub, id);
  }

  @Get('inventory')
  @UseGuards(JwtAuthGuard)
  inventory(@Req() req: any) {
    return this.shop.getInventory(req.user.sub);
  }

  @Post('inventory/:id/equip')
  @UseGuards(JwtAuthGuard)
  equip(@Req() req: any, @Param('id') id: string) {
    return this.shop.equip(req.user.sub, id);
  }

  @Post('inventory/:id/unequip')
  @UseGuards(JwtAuthGuard)
  unequip(@Req() req: any, @Param('id') id: string) {
    return this.shop.unequip(req.user.sub, id);
  }

  @Get('equipped')
  @UseGuards(JwtAuthGuard)
  equipped(@Req() req: any) {
    return this.shop.getEquipped(req.user.sub);
  }

  // --- Admin ---

  @Post('admin/items')
  @UseGuards(AdminGuard)
  adminCreate(@Body() body: { name: string; description: string; category: string; rarity: string; priceShards: number; iconEmoji: string }) {
    return this.shop.adminCreate(body);
  }

  @Post('admin/items/:id/active')
  @UseGuards(AdminGuard)
  adminSetActive(@Param('id') id: string, @Body() body: { active: boolean }) {
    return this.shop.adminSetActive(id, body.active);
  }

  @Get('admin/stats')
  @UseGuards(AdminGuard)
  adminStats() {
    return this.shop.adminStats();
  }

  @Post('admin/grant')
  @UseGuards(AdminGuard)
  adminGrant(@Body() body: { userId: string; itemId: string }) {
    return this.shop.adminGrant(body.userId, body.itemId);
  }
}
