import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

/**
 * The starting catalog (requirement 1: minimum 5 items). Cosmetic and
 * status only — no stat, no advantage, no effect on Drafter/rating
 * (requirement 7). Priced above a generous single-day ceiling: this
 * project's own reward values put a very active day (a full 10-trial
 * cycle plus several drafts/tournament matches) at roughly 1,500-3,000
 * Arium Points — see TrialTemplate rewardShards, DraftTrainerService's
 * RewardEngine grants, and WheelConfig.winShards for where that
 * estimate comes from. The cheapest item here (15,000) is deliberately
 * several days out even for that pace, not achievable in one sitting.
 */
const SEED_ITEMS: { name: string; description: string; category: string; rarity: string; priceShards: number; iconEmoji: string; iconUrl?: string }[] = [
  {
    name: 'Areon Veteran',
    description: 'Статусный бейдж для игроков, которые уже давно с Areon.',
    category: 'badge', rarity: 'rare', priceShards: 15000, iconEmoji: '🛡️',
  },
  {
    name: 'Scourgeborn Emblem',
    description: 'Тёмная эмблема профиля в стиле Dire — редкое украшение карточки игрока.',
    category: 'badge', rarity: 'rare', priceShards: 18000, iconEmoji: '💀', iconUrl: '/badges/scourgeborn.png',
  },
  {
    name: 'Void Hunter',
    description: 'Рамка аватара с эффектом искажения пространства.',
    category: 'profile_frame', rarity: 'epic', priceShards: 25000, iconEmoji: '🌌',
  },
  {
    name: 'Areon Champion',
    description: 'Титул под именем игрока — для тех, кто прошёл долгий путь в Areon.',
    category: 'title', rarity: 'legendary', priceShards: 35000, iconEmoji: '🏆',
  },
  {
    name: 'Areon Aegis',
    description: 'Эксклюзивная награда высшего уровня — редкая рамка с постоянным свечением.',
    category: 'profile_frame', rarity: 'mythic', priceShards: 50000, iconEmoji: '⚡',
  },
];

@Injectable()
export class ShopService {
  private readonly logger = new Logger(ShopService.name);

  constructor(private readonly prisma: PrismaService) {}

  async ensureSeeded() {
    const count = await this.prisma.shopItem.count();
    if (count === 0) {
      await this.prisma.shopItem.createMany({ data: SEED_ITEMS });
      this.logger.log(`Seeded ${SEED_ITEMS.length} shop items`);
      return { created: SEED_ITEMS.length };
    }
    // Already seeded on a live database — createMany above only runs
    // once, so a real art asset produced AFTER the initial seed (like
    // Scourgeborn's) needs its own explicit update here to actually
    // reach an existing database, not just a fresh one.
    for (const seedItem of SEED_ITEMS) {
      if (!seedItem.iconUrl) continue;
      await this.prisma.shopItem.updateMany({
        where: { name: seedItem.name, iconUrl: null },
        data: { iconUrl: seedItem.iconUrl },
      });
    }
    return { created: 0 };
  }

  async listItems(userId: string | null) {
    const items = await this.prisma.shopItem.findMany({
      where: { active: true },
      orderBy: { priceShards: 'asc' },
    });
    if (!userId) return items.map((i) => ({ ...i, owned: false }));

    const owned = new Set(
      (await this.prisma.userInventoryItem.findMany({ where: { userId }, select: { itemId: true } })).map((r) => r.itemId),
    );
    return items.map((i) => ({ ...i, owned: owned.has(i.id) }));
  }

  /**
   * requirement 5's double-purchase protection: the unique
   * ([userId, itemId]) constraint on UserInventoryItem is the actual
   * guarantee, checked inside the same transaction as the balance
   * deduction — a retried or double-clicked request either finds the
   * row already there (checked explicitly below, cheap early exit) or
   * loses the unique-constraint race inside the transaction and rolls
   * back with nothing deducted.
   */
  async purchase(userId: string, itemId: string) {
    const item = await this.prisma.shopItem.findUnique({ where: { id: itemId } });
    if (!item || !item.active) throw new NotFoundException('Item not found');

    const alreadyOwned = await this.prisma.userInventoryItem.findUnique({
      where: { userId_itemId: { userId, itemId } },
    });
    if (alreadyOwned) throw new BadRequestException('You already own this item');

    return this.prisma.$transaction(async (tx) => {
      const user = await tx.user.findUniqueOrThrow({ where: { id: userId } });
      if (user.shardBalance < item.priceShards) {
        throw new BadRequestException('Insufficient Arium Points');
      }

      const newBalance = user.shardBalance - item.priceShards;
      await tx.user.update({ where: { id: userId }, data: { shardBalance: newBalance } });
      await tx.shardTransaction.create({
        data: { userId, amount: -item.priceShards, type: 'SHOP_PURCHASE', reason: item.name, balanceAfter: newBalance },
      });
      // The unique constraint on [userId, itemId] is what actually
      // stops a double purchase under concurrency — this create()
      // throws (P2002) if a second request already landed first,
      // rolling back the whole transaction including the deduction
      // above.
      const purchase = await tx.userInventoryItem.create({ data: { userId, itemId } });
      return { purchase, newBalance };
    });
  }

  async getInventory(userId: string) {
    return this.prisma.userInventoryItem.findMany({
      where: { userId },
      include: { item: true },
      orderBy: { purchasedAt: 'desc' },
    });
  }

  /**
   * Only one equipped item per category at a time (you can't wear two
   * profile frames at once) — enforced here by unequipping any other
   * item in the same category before equipping this one, inside the
   * same transaction so there's never a moment with two equipped
   * items in one category even under a race.
   */
  async equip(userId: string, inventoryItemId: string) {
    const row = await this.prisma.userInventoryItem.findUnique({
      where: { id: inventoryItemId },
      include: { item: true },
    });
    if (!row || row.userId !== userId) throw new NotFoundException('Inventory item not found');

    return this.prisma.$transaction(async (tx) => {
      await tx.userInventoryItem.updateMany({
        where: { userId, equipped: true, item: { category: row.item.category } },
        data: { equipped: false },
      });
      return tx.userInventoryItem.update({ where: { id: inventoryItemId }, data: { equipped: true } });
    });
  }

  async unequip(userId: string, inventoryItemId: string) {
    const row = await this.prisma.userInventoryItem.findUnique({ where: { id: inventoryItemId } });
    if (!row || row.userId !== userId) throw new NotFoundException('Inventory item not found');
    return this.prisma.userInventoryItem.update({ where: { id: inventoryItemId }, data: { equipped: false } });
  }

  /** For the profile page — what's currently equipped, one per category. */
  async getEquipped(userId: string) {
    return this.prisma.userInventoryItem.findMany({
      where: { userId, equipped: true },
      include: { item: true },
    });
  }

  // --- Admin (requirement 8 — architecture ready, not every control built yet) ---

  async adminCreate(data: { name: string; description: string; category: string; rarity: string; priceShards: number; iconEmoji: string }) {
    return this.prisma.shopItem.create({ data });
  }

  async adminSetActive(itemId: string, active: boolean) {
    return this.prisma.shopItem.update({ where: { id: itemId }, data: { active } });
  }

  /**
   * Free gift from an admin — no shardBalance touched at all (unlike
   * purchase(), which always deducts). Still goes through the same
   * unique ([userId, itemId]) constraint as a real purchase, so a
   * user who already owns the item just gets a clear "already owns
   * it" response instead of a duplicate inventory row.
   */
  async adminGrant(userId: string, itemId: string) {
    const item = await this.prisma.shopItem.findUnique({ where: { id: itemId } });
    if (!item) throw new NotFoundException('Item not found');

    const already = await this.prisma.userInventoryItem.findUnique({ where: { userId_itemId: { userId, itemId } } });
    if (already) throw new BadRequestException('This user already owns this item');

    return this.prisma.userInventoryItem.create({ data: { userId, itemId } });
  }

  async adminStats() {
    const items = await this.prisma.shopItem.findMany({
      include: { _count: { select: { purchases: true } } },
      orderBy: { priceShards: 'asc' },
    });
    return items.map((i) => ({ id: i.id, name: i.name, active: i.active, priceShards: i.priceShards, purchases: i._count.purchases }));
  }
}
