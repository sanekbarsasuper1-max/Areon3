import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { DraftTrainerService } from './draft-trainer.service';
import { DraftTrainerController } from './draft-trainer.controller';
import { DraftGateway } from './draft.gateway';
import { PrismaService } from '../prisma.service';
import { OpenDotaModule } from '../opendota/opendota.module';
import { MonitoringModule } from '../monitoring/monitoring.module';
import { DraftTournamentsModule } from '../draft-tournaments/draft-tournaments.module';
import { RewardsModule } from '../rewards/rewards.module';

@Module({
  imports: [
    OpenDotaModule,
    MonitoringModule,
    DraftTournamentsModule,
    RewardsModule,
    JwtModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({ secret: config.get('JWT_SECRET') }),
    }),
  ],
  providers: [DraftTrainerService, DraftGateway, PrismaService],
  controllers: [DraftTrainerController],
  exports: [DraftTrainerService],
})
export class DraftTrainerModule {}
