import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common';
import { DraftTrainerService, DraftSide } from './draft-trainer.service';

@Controller('draft-trainer')
export class DraftTrainerController {
  constructor(private readonly draftTrainerService: DraftTrainerService) {}

  @Post('free')
  createFree(@Req() req: any, @Body() body: { radiantSide?: DraftSide }) {
    return this.draftTrainerService.createFreeDraft(req.user.sub, body);
  }

  @Post('tournament-match/:matchId/start')
  startTournamentMatch(@Req() req: any, @Param('matchId') matchId: string) {
    return this.draftTrainerService.startTournamentMatch(matchId, req.user.sub);
  }

  @Post('ai')
  createAiDraft(@Req() req: any, @Body() body: { radiantSide?: DraftSide; botSide?: DraftSide }) {
    return this.draftTrainerService.createAiDraft(req.user.sub, body);
  }

  // On-site invite to a specific (online) user — no link to share.
  @Post('invite')
  inviteFriend(@Req() req: any, @Body() body: { invitedUserId: string; radiantSide?: DraftSide }) {
    return this.draftTrainerService.inviteFriend(req.user.sub, body.invitedUserId, body.radiantSide);
  }

  @Get('invites')
  listPendingInvites(@Req() req: any) {
    return this.draftTrainerService.listPendingInvites(req.user.sub);
  }

  // Claims the open seat in a friend invite or a matchmaking lobby.
  @Post('sessions/:id/join')
  joinFriendDraft(@Req() req: any, @Param('id') id: string) {
    return this.draftTrainerService.joinFriendDraft(id, req.user.sub);
  }

  // Joins the matchmaking queue — matches immediately if someone's
  // already waiting, otherwise starts waiting itself. Frontend polls
  // the returned session until its status flips to 'in_progress'.
  @Post('matchmaking/search')
  searchMatch(@Req() req: any) {
    return this.draftTrainerService.searchMatch(req.user.sub);
  }

  @Post('sessions/:id/cancel')
  cancelWaiting(@Req() req: any, @Param('id') id: string) {
    return this.draftTrainerService.cancelWaiting(id, req.user.sub);
  }

  @Get('sessions')
  listMine(@Req() req: any) {
    return this.draftTrainerService.listMine(req.user.sub);
  }

  @Get('sessions/:id')
  getSession(@Req() req: any, @Param('id') id: string) {
    return this.draftTrainerService.getSessionForViewer(id, req.user.sub);
  }

  // Composition heuristics for a finished draft — see the module
  // comment on computeDraftRating for exactly what this does and
  // doesn't measure (not a win-probability prediction).
  @Get('sessions/:id/rating')
  getRating(@Param('id') id: string) {
    return this.draftTrainerService.computeDraftRating(id);
  }

  @Get('sessions/:id/my-rating-change')
  getMyRatingChange(@Req() req: any, @Param('id') id: string) {
    return this.draftTrainerService.getMyRatingChangeForSession(id, req.user.sub);
  }

  @Post('sessions/:id/actions')
  performAction(@Req() req: any, @Param('id') id: string, @Body() body: { heroId: number }) {
    return this.draftTrainerService.performAction(id, req.user.sub, body.heroId);
  }

  @Post('sessions/:id/positions')
  setPositions(@Req() req: any, @Param('id') id: string, @Body() body: { positions: Record<number, number> }) {
    return this.draftTrainerService.setPositions(id, req.user.sub, body.positions);
  }

  // Called by the client when its local countdown reaches zero. The
  // service re-validates elapsed time server-side before applying
  // anything — see the comment on performTimeout.
  @Post('sessions/:id/timeout')
  performTimeout(@Req() req: any, @Param('id') id: string) {
    return this.draftTrainerService.performTimeout(id, req.user.sub);
  }

  @Get('pro-matches')
  listProMatches() {
    return this.draftTrainerService.listProMatches();
  }

  @Post('pro-matches/:matchId/replay')
  startProReplay(@Req() req: any, @Param('matchId') matchId: string) {
    return this.draftTrainerService.startProReplay(req.user.sub, Number(matchId));
  }
}
