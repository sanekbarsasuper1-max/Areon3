import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma.service';
import { PlayersService } from '../players/players.service';
import { steamId64ToAccountId32 } from '../common/steam-id.util';
import { SteamProfile } from './steam.strategy';
import { MonitoringService } from '../monitoring/monitoring.service';

@Injectable()
export class AuthService {
  constructor(
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
    private readonly prisma: PrismaService,
    private readonly playersService: PlayersService,
    private readonly monitoring: MonitoringService,
  ) {}

  async loginOrCreate(steamProfile: SteamProfile) {
    const accountId32 = steamId64ToAccountId32(steamProfile.steamId64);

    let user = await this.prisma.user.findUnique({
      where: { steamId64: steamProfile.steamId64 },
    });

    if (!user) {
      user = await this.prisma.user.create({
        data: {
          steamId64: steamProfile.steamId64,
          accountId32,
          personaName: steamProfile.personaName,
          avatarFull: steamProfile.avatarFull,
          statsExposed: false,
        },
      });
    }

    // Stale-while-revalidate, not a synchronous check on every login.
    // checkStatsExposed() is a real network call to Steam's API (up to
    // an 8s timeout) — awaiting it here used to mean every single login
    // waited on Steam before the redirect could even happen. A brand
    // new user (never checked) still needs a first real check so their
    // very first redirect lands on the right screen; everyone else
    // gets last login's stored value immediately, with a fresh check
    // kicked off in the background (not awaited) whenever that value
    // is more than 30 minutes old.
    const STATS_CHECK_TTL_MS = 30 * 60 * 1000;
    const isStale =
      user.statsLastCheckedAt == null ||
      Date.now() - user.statsLastCheckedAt.getTime() > STATS_CHECK_TTL_MS;

    let statsExposed = user.statsExposed;
    if (user.statsLastCheckedAt == null) {
      // First-ever login for this account — nothing stored yet to show,
      // so this one case still has to wait for a real answer.
      statsExposed = await this.playersService.checkStatsExposed(accountId32);
    } else if (isStale) {
      this.playersService
        .checkStatsExposed(accountId32)
        .then((fresh) =>
          this.prisma.user.update({
            where: { id: user!.id },
            data: { statsExposed: fresh, statsLastCheckedAt: new Date() },
          }),
        )
        .catch(() => {
          // Steam API error — keep the last known value, try again next
          // login rather than hammering Steam or blocking anyone on it.
        });
    }

    // isAdmin is recomputed from the env var every login, not just set
    // once — this is what makes ADMIN_STEAM_ID64 the single source of
    // truth. Changing the env var and having that person log back in
    // both promotes the new admin AND demotes whoever held it before,
    // rather than accumulating admins over time through some earlier
    // env value.
    const adminSteamId64 = this.config.get<string>('ADMIN_STEAM_ID64');
    const isAdmin = !!adminSteamId64 && steamProfile.steamId64 === adminSteamId64;

    if (statsExposed !== user.statsExposed || isAdmin !== user.isAdmin || user.statsLastCheckedAt == null) {
      user = await this.prisma.user.update({
        where: { id: user.id },
        data: { statsExposed, statsLastCheckedAt: new Date(), isAdmin },
      });
    }

    const accessToken = this.jwt.sign({ sub: user.id, accountId32: user.accountId32, tokenVersion: user.tokenVersion });
    this.monitoring.log(user.id, 'login').catch(() => {});
    return { accessToken, user };
  }
}
