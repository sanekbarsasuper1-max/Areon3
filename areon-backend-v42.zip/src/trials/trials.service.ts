import { BadRequestException, ForbiddenException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { PrismaService } from '../prisma.service';
import { TrialGeneratorService } from './trial-generator.service';

@Injectable()
export class TrialsService {
  private readonly logger = new Logger(TrialsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly generator: TrialGeneratorService,
  ) {}

  /**
   * Rotation is a plain scheduled DB pass, not a BullMQ queue like
   * rank-snapshot's daily job — deliberately. The reasoning that
   * justified BullMQ there (one user's slow/failing *external API*
   * call shouldn't block everyone else's job) doesn't apply here in
   * the same way: generating a cycle is pure DB reads/writes, no
   * external network call to fail or hang on. A per-user try/catch
   * loop gets the same "one failure doesn't stop the rest" property
   * without needing a queue's retry/backoff machinery for a failure
   * mode (a DB write erroring) that a queue wouldn't meaningfully
   * retry-and-succeed on anyway.
   */
  @Cron(CronExpression.EVERY_HOUR)
  async rotateExpiredCycles() {
    const expired = await this.prisma.userTrialCycle.findMany({
      where: { status: 'ACTIVE', endsAt: { lte: new Date() } },
    });
    let rotated = 0;
    for (const cycle of expired) {
      try {
        await this.generator.generateCycleForUser(cycle.userId);
        rotated += 1;
      } catch (e: any) {
        this.logger.warn(`Failed to rotate trial cycle for user=${cycle.userId}: ${e.message}`);
      }
    }
    if (expired.length > 0) this.logger.log(`Rotated ${rotated}/${expired.length} expired trial cycles`);
  }

  /** First-ever cycle for a user who has none yet — called lazily from
   * the controller on their first visit to the Trials page, not from a
   * signup hook (keeps this decoupled from the auth flow entirely). */
  async ensureActiveCycle(userId: string) {
    const existing = await this.prisma.userTrialCycle.findFirst({ where: { userId, status: 'ACTIVE' } });
    if (existing) return existing;
    const created = await this.generator.generateCycleForUser(userId);
    return created;
  }

  async getCurrentCycle(userId: string) {
    await this.ensureActiveCycle(userId);
    return this.prisma.userTrialCycle.findFirst({
      where: { userId, status: 'ACTIVE' },
      include: { trials: { include: { template: true } } },
    });
  }

  async getCycleHistory(userId: string) {
    return this.prisma.userTrialCycle.findMany({
      where: { userId, status: 'CLOSED' },
      orderBy: { cycleNumber: 'desc' },
      include: { trials: { include: { template: true } } },
    });
  }

  /**
   * The only place a trial's reward is actually granted — a real,
   * explicit user action, never automatic on completion (see
   * trial-engine's own note on this). rewardClaimed is the gate:
   * checked and set inside one transaction with the balance update and
   * the ShardTransaction, so a double-click or a retried request after
   * a dropped response can't grant it twice — the second attempt finds
   * rewardClaimed already true and throws before touching the balance.
   */
  async claimReward(userId: string, userTrialId: string) {
    const trial = await this.prisma.userTrial.findUnique({
      where: { id: userTrialId },
      include: { template: true },
    });
    if (!trial) throw new NotFoundException('Trial not found');
    if (trial.userId !== userId) throw new ForbiddenException('Not your trial');
    if (trial.status !== 'COMPLETED') throw new BadRequestException('Trial is not completed yet');
    if (trial.rewardClaimed) throw new BadRequestException('Reward already claimed');

    return this.prisma.$transaction(async (tx) => {
      // Re-read and re-check inside the transaction — closes the race
      // where two concurrent claim requests both pass the check above
      // before either has written rewardClaimed=true.
      const fresh = await tx.userTrial.findUniqueOrThrow({ where: { id: userTrialId } });
      if (fresh.rewardClaimed) throw new BadRequestException('Reward already claimed');

      const user = await tx.user.findUniqueOrThrow({ where: { id: userId } });
      const newBalance = user.shardBalance + trial.template.rewardShards;

      await tx.user.update({ where: { id: userId }, data: { shardBalance: newBalance } });
      await tx.shardTransaction.create({
        data: {
          userId,
          amount: trial.template.rewardShards,
          type: 'TRIAL_REWARD',
          reason: trial.template.title,
          relatedUserTrialId: trial.id,
          balanceAfter: newBalance,
        },
      });
      const updated = await tx.userTrial.update({
        where: { id: userTrialId },
        data: { rewardClaimed: true, rewardClaimedAt: new Date() },
      });
      return { trial: updated, newBalance };
    });
  }
}
