import { NestFactory } from '@nestjs/core';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import { AppModule } from './app.module';

// Node's JSON.stringify has no idea how to serialize a BigInt (Prisma
// returns bigint for any PostgreSQL BIGINT column, e.g. Match.matchId
// and WheelChallenge.matchId), and it throws rather than silently
// dropping the field — a real production outage found in this
// project's own logs (TypeError: Do not know how to serialize a
// BigInt), not a hypothetical. Individual call sites already convert
// theirs with .toString() where the code is aware of it, but that's
// exactly the kind of thing one new endpoint away from forgetting
// again. This is the actual fix: teach every BigInt in the process how
// to serialize itself, once, so no future endpoint can reintroduce
// this same crash by accident.
(BigInt.prototype as any).toJSON = function () {
  return this.toString();
};

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.use(cookieParser());
  app.use(
    helmet({
      // This is a JSON API, not an HTML-serving app — no page here
      // ever renders untrusted content that a CSP would be defending
      // against. The frontend (a separate service) has its own CSP,
      // tailored to what it actually loads — see its nginx.conf.
      // Every other helmet default (X-Content-Type-Options,
      // X-Frame-Options, Strict-Transport-Security, etc.) still
      // applies and is genuinely useful for an API too.
      contentSecurityPolicy: false,
    }),
  );
  app.enableCors({ origin: process.env.FRONTEND_URL, credentials: true });
  await app.listen(3000);
}
bootstrap();
