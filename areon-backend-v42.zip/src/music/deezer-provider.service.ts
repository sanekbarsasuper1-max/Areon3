import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';

export interface DeezerArtist {
  id: string;
  name: string;
  imageUrl: string | null;
  genres: string[];
}

export interface DeezerTrack {
  id: string;
  name: string;
  artist: string;
  artistId: string | null;
  albumName: string;
  imageUrl: string | null;
  durationSec: number;
  previewUrl: string | null;
  releaseYear: string | null;
}

export interface DeezerAlbum {
  id: string;
  name: string;
  artist: string;
  imageUrl: string | null;
  releaseYear: string | null;
}

/**
 * Deezer's public catalog API (api.deezer.com) — the second real
 * source tried for this feature. Spotify was ruled out first (Premium-
 * only developer accounts since February 2026), then Apple's iTunes
 * Search API was tried and found to have a genuinely erratic,
 * aggressive rate limit that made search fail constantly from a
 * shared cloud IP like Render's — a real, documented, widely-reported
 * problem with that API, not something this project's own code could
 * fix by retrying harder. Deezer needs no key for catalog/search
 * endpoints and doesn't carry that same reputation for indiscriminate
 * throttling. previewUrl is Deezer's own 30-second preview clip — CDN-
 * hosted, reliably present for the vast majority of tracks (unlike
 * Apple's, which had become inconsistent even before the rate-limit
 * problem made it moot).
 */
@Injectable()
export class DeezerProviderService {
  private readonly logger = new Logger(DeezerProviderService.name);
  private readonly baseUrl = 'https://api.deezer.com';

  async search(query: string, limit = 20): Promise<{ artists: DeezerArtist[]; tracks: DeezerTrack[]; albums: DeezerAlbum[] }> {
    const [tracksRes, artistsRes, albumsRes] = await Promise.allSettled([
      fetch(`${this.baseUrl}/search/track?q=${encodeURIComponent(query)}&limit=${limit}`),
      fetch(`${this.baseUrl}/search/artist?q=${encodeURIComponent(query)}&limit=10`),
      fetch(`${this.baseUrl}/search/album?q=${encodeURIComponent(query)}&limit=10`),
    ]);

    let rateLimited = false;
    const parse = async (settled: PromiseSettledResult<Response>) => {
      if (settled.status === 'rejected') {
        this.logger.warn(`Deezer sub-request network failure: ${settled.reason}`);
        return null;
      }
      if (settled.value.status === 429) {
        rateLimited = true;
        return null;
      }
      if (!settled.value.ok) {
        this.logger.warn(`Deezer sub-request failed: ${settled.value.status}`);
        return null;
      }
      const json = await settled.value.json();
      // Deezer returns {error: {...}} with a 200 status for some
      // failure modes (quota, bad request) rather than a proper HTTP
      // error code — checked explicitly rather than trusting .ok alone.
      if (json?.error) {
        this.logger.warn(`Deezer API error: ${JSON.stringify(json.error)}`);
        return null;
      }
      return json;
    };

    const [tracksData, artistsData, albumsData] = await Promise.all([parse(tracksRes), parse(artistsRes), parse(albumsRes)]);

    if (rateLimited && !tracksData && !artistsData && !albumsData) {
      throw new HttpException('Music search is temporarily rate-limited — try again shortly.', HttpStatus.TOO_MANY_REQUESTS);
    }

    const tracks: DeezerTrack[] = (tracksData?.data ?? []).map((t: any) => ({
      id: String(t.id),
      name: t.title,
      artist: t.artist?.name ?? 'Unknown',
      artistId: t.artist?.id ? String(t.artist.id) : null,
      albumName: t.album?.title ?? '',
      imageUrl: t.album?.cover_medium ?? t.album?.cover ?? null,
      durationSec: t.duration ?? 0,
      previewUrl: t.preview || null,
      releaseYear: null, // /search/track doesn't include release_date — only the album lookup does
    }));

    const artists: DeezerArtist[] = (artistsData?.data ?? []).map((a: any) => ({
      id: String(a.id),
      name: a.name,
      imageUrl: a.picture_medium ?? a.picture ?? null,
      genres: [],
    }));

    const albums: DeezerAlbum[] = (albumsData?.data ?? []).map((al: any) => ({
      id: String(al.id),
      name: al.title,
      artist: al.artist?.name ?? 'Unknown',
      imageUrl: al.cover_medium ?? al.cover ?? null,
      releaseYear: null,
    }));

    return { artists, tracks, albums };
  }

  /** requirement 1: clicking an artist shows their real songs. */
  async getArtistTracks(artistId: string): Promise<DeezerTrack[]> {
    const res = await fetch(`${this.baseUrl}/artist/${artistId}/top?limit=25`);
    if (!res.ok) throw new Error(`Deezer artist top tracks failed: ${res.status}`);
    const data = await res.json();
    if (data?.error) throw new Error(`Deezer API error: ${JSON.stringify(data.error)}`);
    return (data.data ?? []).map((t: any) => ({
      id: String(t.id),
      name: t.title,
      artist: t.artist?.name ?? 'Unknown',
      artistId: t.artist?.id ? String(t.artist.id) : null,
      albumName: t.album?.title ?? '',
      imageUrl: t.album?.cover_medium ?? t.album?.cover ?? null,
      durationSec: t.duration ?? 0,
      previewUrl: t.preview || null,
      releaseYear: null,
    }));
  }
}
