import { Module } from '@nestjs/common';
import { MusicController } from './music.controller';
import { MusicService } from './music.service';
import { DeezerProviderService } from './deezer-provider.service';
import { PrismaService } from '../prisma.service';

@Module({
  controllers: [MusicController],
  providers: [MusicService, DeezerProviderService, PrismaService],
})
export class MusicModule {}
