import { MatchFacts } from './coach-data-extractor';

export type CoachDepth = 'quick' | 'full' | 'coach';

export interface ResolvedNames {
  heroNames: Record<number, string>;
  itemNames: Record<string, string>; // keyed by internal item name (purchase_log's `key`)
  abilityNames: Record<number, string>; // keyed by numeric ability_id (ability_upgrades_arr's own ids)
}

export interface DraftContext {
  // From our existing Hero.countersJson — the same real, OpenDota-matchup-
  // derived data Draft Trainer's rating already uses. No new data
  // source needed for "main threats."
  yourHeroCounters: { heroId: number; winrateAgainstYou: number }[];
  enemyWeaknesses: { heroId: number; yourWinrateAgainst: number }[];
}

/**
 * The system prompt is where requirement 26's discipline actually gets
 * enforced — not by re-validating the model's output afterward, but by
 * being explicit up front about what it's allowed to do with the data
 * it's given.
 */
const SYSTEM_PROMPT = `Ты — AI Coach в Areon, платформе для Dota 2. Тебе дают СТРУКТУРИРОВАННЫЕ, уже проверенные факты о конкретном матче — не сырые данные игры, а предобработанный набор фактов.

СТРОГИЕ ПРАВИЛА:
1. Никогда не выдумывай данные, которых нет в предоставленных фактах — ни числа, ни события, ни тайминги.
2. Каждое своё заключение помечай явно:
   - "Confirmed" — если это прямо следует из данных.
   - "Likely" — если это твоя интерпретация/рекомендация на основе данных, не факт сам по себе.
3. Если для ответа на какой-то аспект не хватает данных — прямо напиши "Data unavailable", не пытайся заполнить пробел правдоподобным предположением.
4. Никогда не утверждай, что есть единственно верное решение — предлагай Recommended и Alternative с объяснением компромисса, когда уместно.
5. Учитывай, что ability_upgrades_arr и kills_log иногда содержат неточности в исходных данных OpenDota (задокументированный факт) — если вывод строится на этих полях и выглядит сомнительно, отметь это.
6. Пиши на русском, по делу, без "Great game!" и общих фраз без опоры на конкретные факты этого матча.`;

export function buildCoachPrompt(
  facts: MatchFacts,
  names: ResolvedNames,
  draft: DraftContext,
  depth: CoachDepth,
): { system: string; user: string } {
  const depthInstruction: Record<CoachDepth, string> = {
    quick: 'Дай QUICK ANALYSIS: 3-5 предложений по игре в целом, без разбора по драфтам/дракам, плюс "ONE THING TO FIX NEXT GAME".',
    full: 'Дай FULL ANALYSIS с разбором по разделам (см. формат ниже).',
    coach: 'Дай COACH MODE — максимально подробный разбор по разделам (см. формат ниже), включая каждую значимую командную драку отдельно (TARGET PRIORITY по каждой) и альтернативные варианты сборки/прокачки с объяснением компромисса.',
  };

  // requirement: the raw facts (item timing, ability order, phases,
  // teamfights) are ALREADY real, precise data — the frontend renders
  // THAT directly with real icons, not AI prose reproducing it. The
  // model's only job for full/coach is commentary attached to each
  // section, returned as JSON keyed to match what the frontend
  // already has, not one undifferentiated narrative blob.
  const formatInstruction =
    depth === 'quick'
      ? 'Ответь обычным текстом (не JSON), коротко.'
      : `Ответь ТОЛЬКО валидным JSON (без markdown-обёртки) со следующими ключами — каждый ключ это 2-5 предложений комментария к соответствующему разделу, который фронтенд покажет рядом с реальными данными (иконками предметов/способностей), НЕ переписывай сами факты текстом:
{
  "summary": "итоговая оценка игры в целом",
  "laningPhase": "комментарий к линии/ранней игре (0-10 мин)",
  "itemBuild": "комментарий к сборке и порядку покупки предметов — что было хорошо/плохо, что купить вместо",
  "abilityBuild": "комментарий к прокачке способностей — сравнение с оптимальным порядком",
  "teamfights": "комментарий к командным боям${depth === 'coach' ? ' — для COACH MODE разбери КАЖДЫЙ значимый бой отдельно с TARGET PRIORITY' : ''}",
  "midLatePhase": "комментарий к мид/лейтгейму",
  "mistakes": "ключевые ошибки",
  "goodDecisions": "что было сделано хорошо",
  "recommendations": "конкретные рекомендации на будущее"${depth === 'coach' ? ',\n  "ifIWereYourCoach": "личное послание в духе \\"если бы я был твоим тренером\\""' : ''}
}
Если для какого-то раздела реально нет данных (например teamfights недоступны), напиши в соответствующем поле "Недостаточно данных для этого раздела" — не выдумывай.`;

  const factsPayload = {
    matchId: facts.matchId,
    durationSec: facts.durationSec,
    result: facts.won ? 'WIN' : 'LOSS',
    patch: facts.patch ?? 'Data unavailable',
    yourHero: names.heroNames[facts.yourHeroId] ?? `hero_${facts.yourHeroId}`,
    yourTeam: facts.yourTeamHeroIds.map((id) => names.heroNames[id] ?? `hero_${id}`),
    enemyTeam: facts.enemyTeamHeroIds.map((id) => names.heroNames[id] ?? `hero_${id}`),
    finalStats: facts.finalStats,
    itemPurchases: facts.itemPurchases.map((p) => ({ timeSec: p.timeSec, item: names.itemNames[p.itemKey] ?? p.itemKey })),
    abilityUpgrades: facts.abilityUpgrades.map((a) => ({ level: a.level, ability: names.abilityNames[a.abilityId] ?? `ability_${a.abilityId}` })),
    teamfights: facts.teamfights === null ? 'Data unavailable — match was not parsed deeply enough for teamfight-level detail' : facts.teamfights,
    phases: facts.phases,
    draftContext: {
      mainThreatCandidates: draft.yourHeroCounters,
      favorableMatchups: draft.enemyWeaknesses,
    },
  };

  return {
    system: SYSTEM_PROMPT,
    user: `${depthInstruction[depth]}\n\n${formatInstruction}\n\nФакты матча (JSON, уже проверенные, ничего не выдумывай сверх этого):\n${JSON.stringify(factsPayload, null, 2)}`,
  };
}
