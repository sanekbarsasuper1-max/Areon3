import { BadRequestException, ForbiddenException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { OpenDotaService } from '../opendota/opendota.service';
import { extractMatchFacts } from './coach-data-extractor';
import { buildCoachPrompt, CoachDepth, DraftContext, ResolvedNames } from './coach-prompt-builder';

// Bounded polling, not an indefinite wait — a request/response HTTP
// handler blocking for minutes is a bad pattern regardless of how
// patient the client is. If parsing isn't done within this budget,
// callers get a clear "still processing" response and are expected to
// retry shortly, rather than the request hanging.
const PARSE_POLL_ATTEMPTS = 6;
const PARSE_POLL_DELAY_MS = 10_000;

// Requirement: SHORT is free; FULL and MAXIMUM cost Arium Plus
// (shardBalance) — MAXIMUM is explicitly a TEMPORARY price standing in
// for real-money payment not built yet (see the product brief this was
// built against), which is exactly why this lives as one small
// constant map rather than scattered through the service: swapping
// MAXIMUM to a real payment provider later only touches this one spot.
const DEPTH_PRICE_SHARDS: Record<CoachDepth, number> = {
  quick: 0,
  full: 300,
  coach: 500,
};

@Injectable()
export class CoachService {
  private readonly logger = new Logger(CoachService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly openDota: OpenDotaService,
  ) {}

  async generateReport(userId: string, matchRowId: string, depth: CoachDepth) {
    const match = await this.prisma.match.findUnique({ where: { id: matchRowId } });
    if (!match) throw new NotFoundException('Match not found');
    if (match.userId !== userId) throw new ForbiddenException('This is not your match');

    const cached = await this.prisma.coachReport.findUnique({
      where: { matchRowId_userId_depth: { matchRowId, userId, depth } },
    });
    if (cached) return cached;

    const parseResult = await this.ensureParsed(match.id, match.matchId);
    if (parseResult.status === 'processing') {
      return { status: 'processing' as const, message: 'Матч ещё разбирается — попробуйте через минуту.' };
    }

    const fullMatch = await this.openDota.getMatch(Number(match.matchId));
    const facts = extractMatchFacts(fullMatch, match.playerSlot, parseResult.patchLabel);

    const [names, draft] = await Promise.all([this.resolveNames(facts), this.buildDraftContext(facts)]);
    const assetIcons = await this.resolveIcons(facts);

    const { system, user } = buildCoachPrompt(facts, names, draft, depth);
    const reportBody = await this.callClaude(system, user);

    // full/coach ask the model for structured JSON commentary (see
    // buildCoachPrompt's formatInstruction) so the frontend can place
    // each comment next to the REAL data it's about — the item/ability
    // timelines themselves come straight from `facts`, never from the
    // model. quick stays plain narrative text. A model that doesn't
    // perfectly comply with the JSON format falls back to the raw text
    // as a single "summary" section rather than losing the report
    // entirely — degraded, not broken.
    const commentary: Record<string, string> | string =
      depth === 'quick'
        ? reportBody
        : (() => {
            try {
              const cleaned = reportBody.trim().replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '');
              const parsed = JSON.parse(cleaned);
              return typeof parsed === 'object' && parsed !== null ? parsed : { summary: reportBody };
            } catch {
              this.logger.warn(`Coach report for depth=${depth} wasn't valid JSON — falling back to plain narrative`);
              return { summary: reportBody };
            }
          })();

    const price = DEPTH_PRICE_SHARDS[depth];
    if (price === 0) {
      return this.prisma.coachReport.create({
        data: { matchRowId, userId, depth, reportJson: { facts, commentary, assetIcons } as any },
      });
    }

    // Payment happens HERE — after the AI call already succeeded, not
    // before — so a failed generation (API error, timeout) never
    // charges the person for a report they didn't get. The report
    // creation and the deduction land in the same transaction, so
    // there's no window where money is gone but no report exists
    // either.
    return this.prisma.$transaction(async (tx) => {
      const account = await tx.user.findUniqueOrThrow({ where: { id: userId } });
      if (account.shardBalance < price) {
        throw new BadRequestException(`Insufficient Arium Plus — this level costs ${price}, you have ${account.shardBalance}.`);
      }
      const newBalance = account.shardBalance - price;
      await tx.user.update({ where: { id: userId }, data: { shardBalance: newBalance } });
      await tx.shardTransaction.create({
        data: { userId, amount: -price, type: 'COACH_REPORT', reason: `AI Coach — ${depth} анализ`, balanceAfter: newBalance },
      });
      return tx.coachReport.create({
        data: { matchRowId, userId, depth, reportJson: { facts, commentary, assetIcons } as any },
      });
    });
  }

  /**
   * Requests a parse if the match hasn't been parsed yet, then polls a
   * bounded number of times. Genuinely fails (not "processing forever")
   * for old or private-lobby matches whose replay no longer exists.
   */
  private async ensureParsed(
    matchRowId: string,
    matchIdBigInt: bigint,
  ): Promise<{ status: 'ready'; patchLabel: string | null } | { status: 'processing' }> {
    const existing = await this.prisma.matchDetail.findUnique({ where: { matchRowId } });
    if (existing?.isParsed) return { status: 'ready', patchLabel: existing.patch };

    const matchId = Number(matchIdBigInt);
    await this.openDota.requestParse(matchId).catch((e) => {
      this.logger.warn(`Parse request failed for match ${matchId}: ${e.message}`);
    });

    for (let attempt = 0; attempt < PARSE_POLL_ATTEMPTS; attempt++) {
      await new Promise((r) => setTimeout(r, PARSE_POLL_DELAY_MS));
      const full = await this.openDota.getMatch(matchId);
      const isParsed = full.players.some((p) => p.purchase_log != null) || (full as any).teamfights != null;
      if (isParsed) {
        const patchLabel = full.patch != null ? String(full.patch) : null;
        await this.prisma.matchDetail.upsert({
          where: { matchRowId },
          create: {
            matchRowId,
            heroDamage: 0, towerDamage: 0, heroHealing: 0, lastHits: 0, denies: 0, goldT: [], xpT: [], insights: [],
            isParsed: true,
            patch: patchLabel,
            parsedAt: new Date(),
          },
          update: { isParsed: true, patch: patchLabel, parsedAt: new Date() },
        });
        return { status: 'ready', patchLabel };
      }
    }
    return { status: 'processing' };
  }

  private async resolveNames(facts: {
    yourTeamHeroIds: number[];
    enemyTeamHeroIds: number[];
    itemPurchases: { itemKey: string }[];
    abilityUpgrades: { abilityId: number }[];
  }): Promise<ResolvedNames> {
    const heroIds = [...facts.yourTeamHeroIds, ...facts.enemyTeamHeroIds];
    const itemKeys = [...new Set(facts.itemPurchases.map((p) => p.itemKey))];
    const abilityIds = [...new Set(facts.abilityUpgrades.map((a) => a.abilityId))];

    const [heroes, items, abilities] = await Promise.all([
      this.prisma.hero.findMany({ where: { id: { in: heroIds } } }),
      this.prisma.item.findMany({ where: { name: { in: itemKeys } } }),
      this.prisma.ability.findMany({ where: { id: { in: abilityIds } } }),
    ]);

    return {
      heroNames: Object.fromEntries(heroes.map((h) => [h.id, h.localizedName])),
      itemNames: Object.fromEntries(items.map((i) => [i.name, i.dname])),
      abilityNames: Object.fromEntries(abilities.map((a) => [a.id, a.dname])),
    };
  }

  /**
   * Real icon URLs for the frontend's visual skill-build/item-timeline
   * rendering (requirement: actual Dota icons, not just text) — kept
   * separate from resolveNames (which feeds the AI prompt as plain
   * text) since the model has no use for image URLs, only the
   * frontend does.
   */
  private async resolveIcons(facts: {
    yourHeroId: number;
    itemPurchases: { itemKey: string }[];
    abilityUpgrades: { abilityId: number }[];
  }) {
    const itemKeys = [...new Set(facts.itemPurchases.map((p) => p.itemKey))];
    const abilityIds = [...new Set(facts.abilityUpgrades.map((a) => a.abilityId))];

    const [hero, items, abilities] = await Promise.all([
      this.prisma.hero.findUnique({ where: { id: facts.yourHeroId } }),
      this.prisma.item.findMany({ where: { name: { in: itemKeys } } }),
      this.prisma.ability.findMany({ where: { id: { in: abilityIds } } }),
    ]);

    return {
      heroIconUrl: hero?.iconUrl ?? null,
      itemIcons: Object.fromEntries(items.map((i) => [i.name, { dname: i.dname, iconUrl: i.iconUrl }])),
      abilityIcons: Object.fromEntries(abilities.map((a) => [a.id, { dname: a.dname, iconUrl: a.iconUrl }])),
    };
  }

  /**
   * Reuses Hero.countersJson — the same real, OpenDota-matchup-derived
   * data Draft Trainer's rating already computes from. No new data
   * source, no invented "this hero is scary" judgment without a real
   * winrate behind it.
   */
  private async buildDraftContext(facts: { yourHeroId: number; enemyTeamHeroIds: number[] }): Promise<DraftContext> {
    const yourHero = await this.prisma.hero.findUnique({ where: { id: facts.yourHeroId } });
    const enemyHeroes = await this.prisma.hero.findMany({ where: { id: { in: facts.enemyTeamHeroIds } } });

    const yourHeroCounters = ((yourHero?.countersJson as any)?.weakAgainst ?? [])
      .filter((c: any) => facts.enemyTeamHeroIds.includes(c.heroId))
      .map((c: any) => ({ heroId: c.heroId, winrateAgainstYou: c.winrate }));

    const enemyWeaknesses: { heroId: number; yourWinrateAgainst: number }[] = [];
    for (const enemy of enemyHeroes) {
      const goodAgainst = (enemy.countersJson as any)?.goodAgainst ?? [];
      const match = goodAgainst.find((c: any) => c.heroId === facts.yourHeroId);
      if (match) enemyWeaknesses.push({ heroId: enemy.id, yourWinrateAgainst: 1 - match.winrate });
    }

    return { yourHeroCounters, enemyWeaknesses };
  }

  /**
   * NOT executable/tested in this sandbox — no network access to
   * actually call the Anthropic API here. Reviewed, not run, same
   * honesty flag as the BullMQ/Docker/Jamendo integrations elsewhere
   * in this project. Verify the exact current model string against
   * https://docs.claude.com before relying on this — model slugs
   * change, and this file shouldn't be the source of truth for that.
   */
  /**
   * Uses Google Gemini's free tier, not Anthropic's paid API — the
   * project owner doesn't have a billing setup for the paid API and
   * asked for a free alternative. Same prompt-building and response
   * handling as before, just a different provider's REST shape:
   * Gemini takes the system prompt as a separate systemInstruction
   * field and returns text nested under
   * candidates[0].content.parts[].text rather than a flat content
   * array.
   */
  private async callClaude(system: string, user: string): Promise<string> {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new BadRequestException('GEMINI_API_KEY is not set — AI Coach cannot generate a report without it. See FIRST_LAUNCH.md.');
    }
    const model = process.env.GEMINI_MODEL ?? 'gemini-3.6-flash';
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
    const body = JSON.stringify({
      systemInstruction: { parts: [{ text: system }] },
      contents: [{ role: 'user', parts: [{ text: user }] }],
      generationConfig: { maxOutputTokens: 4000 },
    });

    // Same transient-503 retry as Wheel of Fate's identical call — see
    // that method's comment for why.
    let lastError: Error | null = null;
    for (let attempt = 0; attempt < 2; attempt++) {
      if (attempt > 0) await new Promise((r) => setTimeout(r, 2000));
      const res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body });
      if (res.ok) {
        const data = await res.json();
        return data.candidates?.[0]?.content?.parts?.map((p: any) => p.text ?? '').join('\n') ?? '';
      }
      lastError = new Error(`Gemini API call failed: ${res.status} ${await res.text()}`);
      if (res.status !== 503) break;
    }
    throw lastError;
  }
}
