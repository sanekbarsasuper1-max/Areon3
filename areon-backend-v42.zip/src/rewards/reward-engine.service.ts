import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

/**
 * The single place ANY activity on Areon grants Site Rating and/or
 * Orion Plus — requirement 9's "Activity → Result → Reward Engine"
 * architecture, so a future new mini-game or tournament type never
 * needs its own bespoke reward-granting code, just a call to
 * grant(). Idempotent via ActivityRewardLedger's unique constraint:
 * calling this twice for the same (userId, activityType, activityId)
 * is always safe — the second call is a silent no-op, not a second
 * payout.
 */
@Injectable()
export class RewardEngineService {
  private readonly logger = new Logger(RewardEngineService.name);

  constructor(private readonly prisma: PrismaService) {}

  async grant(params: {
    userId: string;
    activityType: string;
    activityId: string;
    siteRatingDelta?: number;
    shardsDelta?: number;
    reason: string;
  }) {
    const siteRatingDelta = params.siteRatingDelta ?? 0;
    const shardsDelta = params.shardsDelta ?? 0;
    if (siteRatingDelta === 0 && shardsDelta === 0) return null;

    try {
      return await this.prisma.$transaction(async (tx) => {
        // The create() itself is the idempotency check — a second
        // call with the same (userId, activityType, activityId)
        // violates the unique constraint and throws, caught below,
        // rather than needing a separate SELECT-then-INSERT race.
        const entry = await tx.activityRewardLedger.create({
          data: {
            userId: params.userId,
            activityType: params.activityType,
            activityId: params.activityId,
            siteRatingDelta,
            shardsDelta,
            reason: params.reason,
          },
        });

        if (siteRatingDelta !== 0) {
          await tx.user.update({ where: { id: params.userId }, data: { siteRating: { increment: siteRatingDelta } } });
        }
        if (shardsDelta !== 0) {
          const user = await tx.user.findUniqueOrThrow({ where: { id: params.userId } });
          const newBalance = user.shardBalance + shardsDelta;
          await tx.user.update({ where: { id: params.userId }, data: { shardBalance: newBalance } });
          await tx.shardTransaction.create({
            data: { userId: params.userId, amount: shardsDelta, type: `REWARD_${params.activityType.toUpperCase()}`, reason: params.reason, balanceAfter: newBalance },
          });
        }
        return entry;
      });
    } catch (e: any) {
      // Prisma's unique-constraint violation code — this activity
      // already paid out, which is the expected/safe outcome of a
      // duplicate call, not an error worth logging loudly.
      if (e?.code === 'P2002') return null;
      this.logger.error(`RewardEngine.grant failed for user=${params.userId} activity=${params.activityType}/${params.activityId}: ${e instanceof Error ? e.message : String(e)}`);
      throw e;
    }
  }

  async getHistory(userId: string, limit = 50) {
    return this.prisma.activityRewardLedger.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
  }
}
