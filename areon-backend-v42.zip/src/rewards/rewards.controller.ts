import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RewardEngineService } from './reward-engine.service';

@Controller('rewards')
@UseGuards(JwtAuthGuard)
export class RewardsController {
  constructor(private readonly rewardEngine: RewardEngineService) {}

  @Get('history')
  getHistory(@Req() req: any) {
    return this.rewardEngine.getHistory(req.user.sub);
  }
}
