import { Module } from '@nestjs/common';
import { RewardEngineService } from './reward-engine.service';
import { RewardsController } from './rewards.controller';
import { PrismaService } from '../prisma.service';

@Module({
  controllers: [RewardsController],
  providers: [RewardEngineService, PrismaService],
  exports: [RewardEngineService],
})
export class RewardsModule {}
