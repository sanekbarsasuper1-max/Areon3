import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { OpenDotaService } from '../opendota/opendota.service';

// Valve serves these images via Steam's own CDN — this is the same
// asset path OpenDota, Dotabuff, and STRATZ all resolve against.
//
// `h.img` (not `h.icon`) on purpose: `icon` is the tiny square minimap
// icon, `img` is the wide hero-select-style portrait — the same one
// Dota 2's own draft screen uses. Existing databases need
// POST /admin/heroes/sync run again to pick this up; the stored URL
// doesn't change on its own just because this code did.
const STEAM_CDN = 'https://cdn.cloudflare.steamstatic.com';

@Injectable()
export class HeroesService {
  private readonly logger = new Logger(HeroesService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly openDota: OpenDotaService,
  ) {}

  /**
   * Refreshes the local hero table. Heroes only change on patch days
   * (new hero release, occasional rework), so this is safe to run
   * manually or on a weekly cron rather than per-request.
   *
   * `dataPatch`/`client` exist specifically so PatchSyncService can
   * call this SAME method — not a duplicate — inside its own
   * transaction during an automatic patch sync, tagging every row with
   * which patch it was fetched under. The manual "Синхронизировать
   * базу героев" admin button still calls this with neither argument,
   * unchanged from before.
   */
  async syncHeroes(dataPatch?: string, client?: any) {
    const db = client ?? this.prisma;
    const heroes = await this.openDota.getHeroStats();

    for (const h of heroes) {
      await db.hero.upsert({
        where: { id: h.id },
        create: {
          id: h.id,
          name: h.name,
          localizedName: h.localized_name,
          primaryAttr: h.primary_attr,
          attackType: h.attack_type,
          roles: h.roles,
          iconUrl: `${STEAM_CDN}${h.img}`,
          baseStr: h.base_str,
          baseAgi: h.base_agi,
          baseInt: h.base_int,
          strGain: h.str_gain,
          agiGain: h.agi_gain,
          intGain: h.int_gain,
          moveSpeed: h.move_speed,
          dataPatch,
        },
        update: {
          localizedName: h.localized_name,
          primaryAttr: h.primary_attr,
          attackType: h.attack_type,
          roles: h.roles,
          iconUrl: `${STEAM_CDN}${h.img}`,
          baseStr: h.base_str,
          baseAgi: h.base_agi,
          baseInt: h.base_int,
          strGain: h.str_gain,
          agiGain: h.agi_gain,
          intGain: h.int_gain,
          moveSpeed: h.move_speed,
          syncedAt: new Date(),
          ...(dataPatch ? { dataPatch } : {}),
        },
      });
    }

    this.logger.log(`Synced ${heroes.length} heroes`);
    return { synced: heroes.length };
  }

  /**
   * Computes "хорош против / слаб против" from real matchup win rates —
   * per the counters/synergies discussion, this has to be derived data,
   * not something a person curates by hand and lets rot every patch.
   *
   * Synergies ("хорошо сочетается с") are deliberately left out: there's
   * no confirmed OpenDota endpoint for ally win rate in this scaffold —
   * see the note on getHeroMatchups. Shipping a guessed synergy list
   * would be worse than shipping none.
   */
  async syncMatchups(heroId: number, minGames = 200) {
    const matchups = await this.openDota.getHeroMatchups(heroId);

    const withWinrate = matchups
      .filter((m) => m.games_played >= minGames)
      .map((m) => ({ heroId: m.hero_id, winrate: m.wins / m.games_played }))
      .sort((a, b) => b.winrate - a.winrate);

    const goodAgainst = withWinrate.slice(0, 5);
    const weakAgainst = withWinrate.slice(-5).reverse();

    await this.prisma.hero.update({
      where: { id: heroId },
      data: {
        countersJson: { goodAgainst, weakAgainst } as any,
        synergiesJson: undefined, // intentionally not populated — see above
      },
    });

    return { goodAgainst, weakAgainst };
  }

  /**
   * The bulk version — requirement discovered honestly, not
   * hypothetically: the per-hero endpoint above genuinely had no way
   * to run it across the whole roster except calling it once per
   * hero_id by hand, which is why counter-pick data was empty on a
   * fresh database (nobody had run it ~120 times). Fire-and-forget:
   * returns immediately with how many heroes are queued, and works
   * through them with a small delay between each OpenDota call rather
   * than firing all ~120 requests at once — this is exactly the "не
   * долбить API" caution used elsewhere in this project (see
   * PatchSyncService), not a new pattern invented for this method.
   */
  async syncAllMatchups(minGames = 200) {
    const heroes = await this.prisma.hero.findMany({ select: { id: true } });
    let done = 0;
    let failed = 0;

    (async () => {
      for (const h of heroes) {
        try {
          await this.syncMatchups(h.id, minGames);
          done += 1;
        } catch (e) {
          failed += 1;
          this.logger.warn(`syncAllMatchups: hero_id=${h.id} failed: ${e instanceof Error ? e.message : String(e)}`);
        }
        await new Promise((r) => setTimeout(r, 300));
      }
      this.logger.log(`syncAllMatchups finished: ${done} synced, ${failed} failed, out of ${heroes.length}`);
    })();

    return { queued: heroes.length };
  }

  async listHeroes() {
    return this.prisma.hero.findMany({ orderBy: { localizedName: 'asc' } });
  }

  async getHero(id: number) {
    return this.prisma.hero.findUnique({ where: { id } });
  }

  /**
   * Refreshes the Item reference table (id -> display name/icon).
   * Static data, safe to run rarely — same cadence as syncHeroes.
   * Needed before syncItemBuilds output means anything to a person:
   * raw item ids are meaningless without this.
   */
  async syncItems(dataPatch?: string, client?: any) {
    const db = client ?? this.prisma;
    const constants = await this.openDota.getItemConstants();
    let count = 0;

    for (const [internalName, item] of Object.entries(constants)) {
      if (!item.id) continue; // a few constant entries (e.g. "empty") have no real id
      await db.item.upsert({
        where: { id: item.id },
        create: {
          id: item.id,
          name: internalName,
          dname: item.dname ?? internalName,
          iconUrl: `${STEAM_CDN}${item.img}`,
          dataPatch,
        },
        update: {
          dname: item.dname ?? internalName,
          iconUrl: `${STEAM_CDN}${item.img}`,
          syncedAt: new Date(),
          ...(dataPatch ? { dataPatch } : {}),
        },
      });
      count += 1;
    }

    this.logger.log(`Synced ${count} items`);
    return { synced: count };
  }

  /** New — abilities had no local record/icon source before this (see the Ability model's own comment on why two OpenDota endpoints are combined). */
  async syncAbilities(client?: any) {
    const db = client ?? this.prisma;
    const [idsByAbility, constants] = await Promise.all([
      this.openDota.getAbilityIds(),
      this.openDota.getAbilityConstants(),
    ]);
    let count = 0;

    for (const [idStr, internalName] of Object.entries(idsByAbility)) {
      const id = Number(idStr);
      if (!id || !internalName) continue;
      const c = constants[internalName];
      if (!c?.img) continue; // a handful of internal/generic entries have no real icon — skip rather than store a broken URL
      await db.ability.upsert({
        where: { id },
        create: { id, name: internalName, dname: c.dname ?? internalName, iconUrl: `${STEAM_CDN}${c.img}` },
        update: { dname: c.dname ?? internalName, iconUrl: `${STEAM_CDN}${c.img}`, syncedAt: new Date() },
      });
      count += 1;
    }

    this.logger.log(`Synced ${count} abilities`);
    return { synced: count };
  }

  /**
   * Real, data-backed item recommendations — NOT filtered by "against
   * which enemy hero", since no source for that conditioning exists
   * (see the README). This is "items that correlate with winning on
   * this hero recently", full stop.
   *
   * Cost note this exists to make explicit: this is `limit` (default
   * 20) full match-detail fetches per call — one per recent match on
   * the hero — not a cheap operation like syncHeroes/syncMatchups.
   * That's exactly the "needs a real background pipeline, not a couple
   * of live calls" cost this feature was originally deferred over;
   * running it as an on-demand admin action with a small `limit` is a
   * reasonable middle ground, not a full production-scale job that
   * would want proper batching/scheduling instead.
   */
  async syncItemBuilds(heroId: number, limit = 20, minGames = 5) {
    const recentMatches = await this.openDota.getHeroRecentMatches(heroId, limit);

    const tally = new Map<number, { games: number; wins: number }>();

    for (const { match_id } of recentMatches) {
      let detail;
      try {
        detail = await this.openDota.getMatch(match_id);
      } catch {
        continue; // one bad/unparsed match shouldn't abort the whole sync
      }

      const player = detail.players.find((p) => p.hero_id === heroId);
      if (!player) continue;

      const won = player.player_slot < 128 ? detail.radiant_win : !detail.radiant_win;
      const itemIds = [player.item_0, player.item_1, player.item_2, player.item_3, player.item_4, player.item_5]
        .filter((id) => id > 0); // 0 = empty slot

      for (const itemId of itemIds) {
        const entry = tally.get(itemId) ?? { games: 0, wins: 0 };
        entry.games += 1;
        if (won) entry.wins += 1;
        tally.set(itemId, entry);
      }
    }

    const items = [...tally.entries()]
      .filter(([, v]) => v.games >= minGames)
      .map(([itemId, v]) => ({ itemId, games: v.games, wins: v.wins, winrate: v.wins / v.games }))
      .sort((a, b) => b.winrate - a.winrate)
      .slice(0, 10);

    await this.prisma.hero.update({
      where: { id: heroId },
      data: { itemBuildsJson: { items, sampledMatches: recentMatches.length } as any },
    });

    return { items, sampledMatches: recentMatches.length };
  }

  async listItems() {
    return this.prisma.item.findMany({ orderBy: { dname: 'asc' } });
  }
}
