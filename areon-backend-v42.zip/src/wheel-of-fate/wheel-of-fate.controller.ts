import { Body, Controller, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { WheelOfFateService } from './wheel-of-fate.service';

@Controller('wheel-of-fate')
@UseGuards(JwtAuthGuard)
export class WheelOfFateController {
  constructor(private readonly service: WheelOfFateService) {}

  // Most spins are cheap (cached HeroBuildConcept, no LLM call) once a
  // hero's concepts already exist — but early on, or for a
  // rarely-spun hero, this triggers a real Anthropic call. Throttled
  // less strictly than Coach (which calls the LLM on essentially every
  // request) but still bounded — audit finding CRITICAL #2.
  @Throttle({ default: { limit: 10, ttl: 300_000 } })
  @Post('spin')
  spin(@Req() req: any) {
    return this.service.spin(req.user.sub);
  }

  @Post('accept')
  accept(@Req() req: any, @Body() body: { challengeId: string }) {
    return this.service.accept(req.user.sub, body.challengeId);
  }

  @Post('reroll')
  reroll(@Req() req: any, @Body() body: { challengeId: string }) {
    return this.service.reroll(req.user.sub, body.challengeId);
  }

  @Get('active')
  active(@Req() req: any) {
    return this.service.getActive(req.user.sub);
  }

  @Get('history')
  history(@Req() req: any) {
    return this.service.getHistory(req.user.sub);
  }

  @Get('challenge/:id')
  challenge(@Req() req: any, @Param('id') id: string) {
    return this.service.getChallenge(req.user.sub, id);
  }
}
