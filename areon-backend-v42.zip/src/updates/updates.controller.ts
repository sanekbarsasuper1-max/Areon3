import { Body, Controller, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { Public } from '../auth/public.decorator';
import { VersionsService } from './versions.service';
import { SuggestionsService } from './suggestions.service';
import { SupportService } from './support.service';

@Controller()
@UseGuards(JwtAuthGuard)
export class UpdatesController {
  constructor(
    private readonly versions: VersionsService,
    private readonly suggestions: SuggestionsService,
    private readonly support: SupportService,
  ) {}

  // Public on purpose — guests should see that Areon shipped a new
  // version too (and read the changelog) without needing to log in.
  @Public()
  @Get('versions')
  listVersions() {
    return this.versions.listAll();
  }

  @Public()
  @Get('versions/current')
  getCurrentVersion() {
    return this.versions.getCurrent();
  }

  @Public()
  @Get('versions/:version')
  getVersion(@Param('version') version: string) {
    return this.versions.getByVersion(version);
  }

  @Get('suggestions')
  listSuggestions() {
    return this.suggestions.listAll();
  }

  @Get('suggestions/mine')
  listMySuggestions(@Req() req: any) {
    return this.suggestions.listMine(req.user.sub);
  }

  @Post('suggestions')
  createSuggestion(@Req() req: any, @Body() body: { title: string; description: string }) {
    return this.suggestions.create(req.user.sub, body.title, body.description);
  }

  @Get('support/tickets')
  listMyTickets(@Req() req: any) {
    return this.support.listMine(req.user.sub);
  }

  @Post('support/tickets')
  createTicket(@Req() req: any, @Body() body: { category: string; message: string }) {
    return this.support.create(req.user.sub, body.category, body.message);
  }
}
