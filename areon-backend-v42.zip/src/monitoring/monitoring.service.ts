import { Injectable, Logger } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { PrismaService } from '../prisma.service';

// A heartbeat gap bigger than this starts a NEW UserSession rather than
// extending the last one — this is what "session" actually means here
// (a continuous burst of activity), since browsers give no reliable
// close/logout signal to mark a session's real end.
const SESSION_GAP_MINUTES = 15;
// Requirement 1's three-state status, derived at read time from
// lastSeenAt — never stored as a flag that could go stale.
const ONLINE_THRESHOLD_SEC = 30;
const IDLE_THRESHOLD_SEC = 300; // 5 minutes
// Requirement 6: bounded retention so these tables don't grow forever.
const ACTIVITY_RETENTION_DAYS = 90;
const SESSION_RETENTION_DAYS = 90;

@Injectable()
export class MonitoringService {
  private readonly logger = new Logger(MonitoringService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Called from the same heartbeat endpoint that already drives Online
   * status — this just adds "which session is this" and "which page"
   * on top of the existing lastSeenAt update, rather than a second
   * polling mechanism.
   */
  async recordHeartbeat(userId: string, page: string | undefined, userAgent: string | undefined) {
    const last = await this.prisma.userSession.findFirst({
      where: { userId },
      orderBy: { lastActivityAt: 'desc' },
    });

    const gapMs = last ? Date.now() - last.lastActivityAt.getTime() : Infinity;
    const isNewSession = !last || gapMs > SESSION_GAP_MINUTES * 60_000;

    if (isNewSession) {
      await this.prisma.userSession.create({
        data: { userId, userAgent, pageViews: page ? 1 : 0 },
      });
    } else {
      await this.prisma.userSession.update({
        where: { id: last.id },
        data: {
          lastActivityAt: new Date(),
          // Only bump pageViews when the reported page actually
          // changed from what it was — a heartbeat on the same page
          // the user's been sitting on isn't a new page view.
          pageViews: page && page !== (await this.currentPageFor(userId)) ? last.pageViews + 1 : last.pageViews,
        },
      });
    }

    await this.prisma.user.update({
      where: { id: userId },
      data: { lastSeenAt: new Date(), ...(page ? { currentPage: page } : {}) },
    });
  }

  private async currentPageFor(userId: string): Promise<string | null> {
    const user = await this.prisma.user.findUnique({ where: { id: userId }, select: { currentPage: true } });
    return user?.currentPage ?? null;
  }

  /**
   * The one place every "significant event" in the app gets recorded
   * from — deliberately a short, explicit call site list (login, draft
   * start/complete, Wheel spin/resolve, match sync, trial complete),
   * not a generic request-logging middleware that would catch
   * everything indiscriminately (requirement 6's own warning against
   * that).
   */
  async log(userId: string, type: string, page?: string, metadata?: Record<string, unknown>) {
    await this.prisma.activityEvent.create({
      data: { userId, type, page, metadata: metadata as any },
    }).catch((e) => {
      // Never let an analytics write break the actual feature it's
      // attached to.
      this.logger.warn(`Failed to log activity event type=${type}: ${e instanceof Error ? e.message : String(e)}`);
    });
  }

  private statusFor(lastSeenAt: Date | null): 'online' | 'idle' | 'offline' {
    if (!lastSeenAt) return 'offline';
    const secondsAgo = (Date.now() - lastSeenAt.getTime()) / 1000;
    if (secondsAgo <= ONLINE_THRESHOLD_SEC) return 'online';
    if (secondsAgo <= IDLE_THRESHOLD_SEC) return 'idle';
    return 'offline';
  }

  async getOnlineNow() {
    const cutoff = new Date(Date.now() - IDLE_THRESHOLD_SEC * 1000);
    const users = await this.prisma.user.findMany({
      where: { lastSeenAt: { gte: cutoff } },
      select: { id: true, personaName: true, avatarFull: true, lastSeenAt: true, currentPage: true },
      orderBy: { lastSeenAt: 'desc' },
    });
    return users.map((u) => ({ ...u, status: this.statusFor(u.lastSeenAt) }));
  }

  async getVisits(range: { from: Date; to: Date }) {
    const sessions = await this.prisma.userSession.findMany({
      where: { startedAt: { gte: range.from, lte: range.to } },
      include: { user: { select: { personaName: true, avatarFull: true, steamId64: true } } },
      orderBy: { startedAt: 'desc' },
      take: 200,
    });
    return sessions.map((s) => ({
      ...s,
      durationSec: Math.round((s.lastActivityAt.getTime() - s.startedAt.getTime()) / 1000),
    }));
  }

  async getActivity(filter: { userId?: string; type?: string }) {
    return this.prisma.activityEvent.findMany({
      where: { userId: filter.userId, type: filter.type },
      include: { user: { select: { personaName: true, avatarFull: true } } },
      orderBy: { createdAt: 'desc' },
      take: 200,
    });
  }

  async getUserDetail(userId: string) {
    const user = await this.prisma.user.findUniqueOrThrow({
      where: { id: userId },
      select: { id: true, personaName: true, avatarFull: true, steamId64: true, createdAt: true, lastSeenAt: true, currentPage: true },
    });
    const [sessions, recentActivity] = await Promise.all([
      this.prisma.userSession.findMany({ where: { userId }, orderBy: { startedAt: 'desc' }, take: 20 }),
      this.prisma.activityEvent.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, take: 50 }),
    ]);
    const totalTimeSec = sessions.reduce((sum, s) => sum + Math.round((s.lastActivityAt.getTime() - s.startedAt.getTime()) / 1000), 0);
    return {
      user: { ...user, status: this.statusFor(user.lastSeenAt) },
      totalSessions: await this.prisma.userSession.count({ where: { userId } }),
      totalTimeSec,
      sessions,
      recentActivity,
    };
  }

  async getOverview() {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const last24h = new Date(Date.now() - 24 * 60 * 60 * 1000);

    const [onlineNow, usersToday, newUsersToday, sessionsToday, activeLast24h] = await Promise.all([
      this.getOnlineNow(),
      this.prisma.userSession.findMany({ where: { startedAt: { gte: startOfToday } }, select: { userId: true }, distinct: ['userId'] }),
      this.prisma.user.count({ where: { createdAt: { gte: startOfToday } } }),
      this.prisma.userSession.findMany({ where: { startedAt: { gte: startOfToday } } }),
      this.prisma.user.count({ where: { lastSeenAt: { gte: last24h } } }),
    ]);

    const avgSessionSec =
      sessionsToday.length > 0
        ? Math.round(
            sessionsToday.reduce((sum, s) => sum + (s.lastActivityAt.getTime() - s.startedAt.getTime()) / 1000, 0) / sessionsToday.length,
          )
        : 0;

    return {
      onlineNow: onlineNow.length,
      usersToday: usersToday.length,
      newUsersToday,
      sessionsToday: sessionsToday.length,
      avgSessionSec,
      activeLast24h,
    };
  }

  // Requirement 6: bounded retention, checked once a day rather than
  // on every request.
  @Cron('0 4 * * *')
  async cleanupOldData() {
    const activityCutoff = new Date(Date.now() - ACTIVITY_RETENTION_DAYS * 24 * 60 * 60 * 1000);
    const sessionCutoff = new Date(Date.now() - SESSION_RETENTION_DAYS * 24 * 60 * 60 * 1000);

    const [deletedActivity, deletedSessions] = await Promise.all([
      this.prisma.activityEvent.deleteMany({ where: { createdAt: { lt: activityCutoff } } }),
      this.prisma.userSession.deleteMany({ where: { lastActivityAt: { lt: sessionCutoff } } }),
    ]);
    this.logger.log(`Monitoring cleanup: removed ${deletedActivity.count} old activity events, ${deletedSessions.count} old sessions`);
  }
}
