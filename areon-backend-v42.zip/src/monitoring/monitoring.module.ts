import { Module } from '@nestjs/common';
import { MonitoringService } from './monitoring.service';
import { PrismaService } from '../prisma.service';

@Module({
  providers: [MonitoringService, PrismaService],
  exports: [MonitoringService],
})
export class MonitoringModule {}
