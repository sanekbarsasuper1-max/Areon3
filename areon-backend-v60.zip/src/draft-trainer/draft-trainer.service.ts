import { BadRequestException, ForbiddenException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { OpenDotaService } from '../opendota/opendota.service';
import { DraftGateway } from './draft.gateway';
import { MonitoringService } from '../monitoring/monitoring.service';
import { DraftTournamentsService } from '../draft-tournaments/draft-tournaments.service';
import { RewardEngineService } from '../rewards/reward-engine.service';

export type DraftSide = 'FIRST_PICK' | 'SECOND_PICK';
export type DraftAction = 'ban' | 'pick';

export interface DraftStep {
  step: number; // 1-indexed, matches the product doc's "STEP 13 / 24"
  side: DraftSide;
  action: DraftAction;
  timeLimitSec: number;
}

export interface DraftEvent extends DraftStep {
  heroId: number | null; // null only for a timed-out ban (skipped, nobody banned)
  timedOut: boolean;
  // How much of the acting side's reserve pool this specific action
  // consumed (0 for anything that finished within the main per-action
  // allowance). Stored per-action specifically so admin undo can refund
  // exactly this much, rather than the earlier version of this file
  // which only kept a running total and couldn't roll one action back
  // precisely.
  reserveSpent: number;
  // Requirement 12: "почему выбран именно этот вариант" shown in
  // plain language after the draft, not the model's internal scoring
  // numbers — set only for actions pickBotHero/pickBotBan actually
  // made (undefined for every human action, and for a timed-out skip).
  botReason?: string;
}

/**
 * ============================================================================
 * CAPTAIN'S MODE DRAFT RULES - config, not hardcoded UI branches (per the
 * doc's requirement 5). Sides are logical (FIRST_PICK / SECOND_PICK), never
 * Radiant/Dire directly - DraftSession.radiantSide is the only mapping
 * applied at render/report time, never baked in here.
 *
 * CONFIRMED against official Valve patch notes (dota2.com/patches/7.40,
 * mirrored by Liquipedia's Version 7.40 page):
 *   "Changed order of the first and the third ban phases.
 *    First Ban Phase: OLD First-Second-Second-First-Second-Second-First
 *                      NEW First-First-Second-Second-First-Second-Second
 *    Third Ban Phase: OLD First-Second-Second-First
 *                      NEW First-Second-First-Second"
 * Patch 7.40 (Dec 2025) changed ONLY the intra-phase order of ban phases
 * 1 and 3 — it did not change the ban COUNTS (still 7 and 4), and nothing
 * in the official notes touches the pick phases. No later patch (7.40b/c,
 * 7.41 and its point releases) has been found changing this further as of
 * this writing — 7.40c's only CM-relevant change was adding a new hero
 * (Largo) to the CM pool, not a draft-order change.
 *
 * Also confirmed (Liquipedia's Game Modes page): ban-phase TOTALS 7/3/4
 * split 3-2-2 (first pick) vs 4-1-2 (second pick), pick-phase totals 2/6/2
 * split 1-3-1 for both sides, 24 actions total, 15s per ban in the first
 * ban phase, 30s for every other action, 130s total reserve time per side,
 * and timeout behavior (ban timeout = skipped, pick timeout = random hero).
 *
 * STILL NOT independently confirmed: the exact intra-phase order of ban
 * phase 2 and all three pick phases — no official patch note or wiki table
 * was found spelling those out turn-by-turn, only the totals above. Those
 * remain a reasonable, symmetric reconstruction, clearly marked as such
 * below — not verified against an official source the way phases 1 and 3
 * now are.
 * ============================================================================
 */
const BAN_PHASE_1_TIME = 15;
const OTHER_TIME = 30;

function phase(
  steps: { side: DraftSide; action: DraftAction }[],
  timeLimitSec: number,
): { side: DraftSide; action: DraftAction; timeLimitSec: number }[] {
  return steps.map((s) => ({ ...s, timeLimitSec }));
}

const F: DraftSide = 'FIRST_PICK';
const S: DraftSide = 'SECOND_PICK';
const ban = (side: DraftSide) => ({ side, action: 'ban' as DraftAction });
const pick = (side: DraftSide) => ({ side, action: 'pick' as DraftAction });

const RAW_SEQUENCE = [
  // Ban phase 1 - 7 total (F:3, S:4) - order per official 7.40 patch note.
  ...phase([ban(F), ban(F), ban(S), ban(S), ban(F), ban(S), ban(S)], BAN_PHASE_1_TIME),
  // Pick phase 1 - 1 each. NOT independently confirmed intra-order.
  ...phase([pick(F), pick(S)], OTHER_TIME),
  // Ban phase 2 - 3 total (F:2, S:1). NOT independently confirmed intra-order.
  ...phase([ban(S), ban(F), ban(F)], OTHER_TIME),
  // Pick phase 2 - 3 each. NOT independently confirmed intra-order.
  ...phase([pick(S), pick(F), pick(F), pick(S), pick(S), pick(F)], OTHER_TIME),
  // Ban phase 3 - 4 total (F:2, S:2) - order per official 7.40 patch note.
  ...phase([ban(F), ban(S), ban(F), ban(S)], OTHER_TIME),
  // Pick phase 3 - 1 each. NOT independently confirmed intra-order.
  ...phase([pick(S), pick(F)], OTHER_TIME),
];

export function buildCaptainsModeSequence(): DraftStep[] {
  return RAW_SEQUENCE.map((s, i) => ({ ...s, step: i + 1 }));
}

@Injectable()
export class DraftTrainerService {
  private readonly logger = new Logger(DraftTrainerService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly openDota: OpenDotaService,
    private readonly draftGateway: DraftGateway,
    private readonly monitoring: MonitoringService,
    private readonly draftTournaments: DraftTournamentsService,
    private readonly rewardEngine: RewardEngineService,
  ) {}

  /**
   * `radiantSide` is a coin flip (or explicit choice) independent of turn
   * order — FIRST_PICK always acts first structurally, but that says
   * nothing about who's Radiant. This one field is what makes "Radiant
   * First Pick", "Radiant Second Pick", "Dire First Pick" and "Dire
   * Second Pick" all representable, per the product requirement.
   *
   * Solo only — 'self' mode, the creator plays both sides. Playing
   * against a specific person goes through inviteFriend(); playing
   * against whoever's next in the queue goes through searchMatch().
   */
  async createFreeDraft(userId: string, options?: { radiantSide?: DraftSide }) {
    const radiantSide = options?.radiantSide ?? (Math.random() < 0.5 ? 'FIRST_PICK' : 'SECOND_PICK');

    return this.prisma.draftSession.create({
      data: {
        createdByUserId: userId,
        mode: 'free',
        opponentType: 'self',
        sequence: buildCaptainsModeSequence() as any,
        actions: [] as any,
        status: 'in_progress',
        radiantSide,
        currentStepStartedAt: new Date(),
        rulesVersion: 'cm-7.40-ban-phase-1-3-reorder',
      },
    });
  }

  /**
   * Starts a session against the heuristic bot. `botSide` defaults to a
   * coin flip if not given. The bot resolves its own turns synchronously
   * inside this call and inside performAction/performTimeout — the
   * session returned to the frontend is always already sitting at the
   * human's next turn (or completed), never mid-bot-turn, so there's
   * nothing for the client to poll for.
   *
   * See scheduleBotTurn() for exactly what the bot does — it's a fixed
   * heuristic (random bans, counter-pick-scored picks using already-
   * synced Hero.countersJson data), not a trained model. Calling it
   * "AI" in the UI is the product's chosen label, not a claim about the
   * underlying technique.
   */
  async createAiDraft(userId: string, options?: { radiantSide?: DraftSide; botSide?: DraftSide }) {
    const radiantSide = options?.radiantSide ?? (Math.random() < 0.5 ? 'FIRST_PICK' : 'SECOND_PICK');
    const aiSide = options?.botSide ?? (Math.random() < 0.5 ? 'FIRST_PICK' : 'SECOND_PICK');

    const session = await this.prisma.draftSession.create({
      data: {
        createdByUserId: userId,
        mode: 'free',
        opponentType: 'ai',
        aiSide,
        sequence: buildCaptainsModeSequence() as any,
        actions: [] as any,
        status: 'in_progress',
        radiantSide,
        currentStepStartedAt: new Date(),
        rulesVersion: 'cm-7.40-ban-phase-1-3-reorder',
      },
    });

    this.scheduleBotTurn(session.id);
    return session;
  }

  /**
   * Both players are already known (assigned by the bracket) — no
   * invite/accept step like inviteFriend(), the match itself is the
   * invitation. Either of the two assigned players can call this to
   * start it; whoever does becomes createdByUserId, but that has no
   * gameplay significance here (unlike 'self'/'friend' mode) since
   * both sides are already fixed by playerAId/playerBId.
   */
  async createTournamentMatchDraft(tournamentMatchId: string, playerAId: string, playerBId: string) {
    const radiantSide: DraftSide = Math.random() < 0.5 ? 'FIRST_PICK' : 'SECOND_PICK';
    return this.prisma.draftSession.create({
      data: {
        createdByUserId: playerAId,
        participantSecondUserId: playerBId,
        mode: 'free',
        opponentType: 'tournament',
        tournamentMatchId,
        sequence: buildCaptainsModeSequence() as any,
        actions: [] as any,
        status: 'in_progress',
        radiantSide,
        currentStepStartedAt: new Date(),
        rulesVersion: 'cm-7.40-ban-phase-1-3-reorder',
      },
    });
  }

  /** Either assigned player can call this once the match is 'ready' — see DraftTournamentsService for what that means. */
  async startTournamentMatch(tournamentMatchId: string, userId: string) {
    const match = await this.draftTournaments.getMatch(tournamentMatchId);
    if (match.status !== 'ready') {
      throw new BadRequestException(`This match is not ready to start (status: ${match.status})`);
    }
    if (userId !== match.playerAId && userId !== match.playerBId) {
      throw new ForbiddenException('You are not a player in this match');
    }
    if (match.draftSessionId) {
      return this.prisma.draftSession.findUnique({ where: { id: match.draftSessionId } });
    }
    const session = await this.createTournamentMatchDraft(tournamentMatchId, match.playerAId!, match.playerBId!);
    await this.draftTournaments.markInProgress(tournamentMatchId, session.id);
    return session;
  }

  /**
   * Sends an on-site invite to a specific user — no link to share, the
   * invited person just sees it appear next time they check
   * `listPendingInvites`. Deliberately only offered against users the
   * `/players/online` picker already surfaced (i.e. active in the last
   * minute) — inviting someone who isn't even online would just create
   * a lobby nobody ever sees.
   */
  async inviteFriend(userId: string, invitedUserId: string, radiantSide?: DraftSide) {
    if (invitedUserId === userId) {
      throw new BadRequestException("You can't invite yourself");
    }
    const invitedUser = await this.prisma.user.findUnique({ where: { id: invitedUserId } });
    if (!invitedUser) throw new NotFoundException('That user does not exist');

    const resolvedRadiantSide = radiantSide ?? (Math.random() < 0.5 ? 'FIRST_PICK' : 'SECOND_PICK');

    return this.prisma.draftSession.create({
      data: {
        createdByUserId: userId,
        mode: 'free',
        opponentType: 'friend',
        invitedUserId,
        sequence: buildCaptainsModeSequence() as any,
        actions: [] as any,
        status: 'waiting_for_opponent',
        radiantSide: resolvedRadiantSide,
        currentStepStartedAt: new Date(),
        rulesVersion: 'cm-7.40-ban-phase-1-3-reorder',
      },
    });
  }

  async listPendingInvites(userId: string) {
    return this.prisma.draftSession.findMany({
      where: { invitedUserId: userId, status: 'waiting_for_opponent' },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Accepts a pending invite (opponentType 'friend') or claims an open
   * matchmaking seat (opponentType 'matchmaking', called internally by
   * searchMatch — see there for why matchmaking mostly doesn't reach
   * this method directly). Starts the clock fresh at the moment of
   * joining, not at lobby/invite creation.
   */
  async joinFriendDraft(sessionId: string, userId: string) {
    const session = await this.getSession(sessionId);

    if (session.opponentType !== 'friend' && session.opponentType !== 'matchmaking') {
      throw new BadRequestException('This session cannot be joined');
    }
    if (session.status !== 'waiting_for_opponent') {
      throw new BadRequestException('This lobby is not waiting for an opponent');
    }
    if (session.createdByUserId === userId) {
      throw new BadRequestException("You can't join your own lobby as the opponent");
    }
    if (session.opponentType === 'friend' && session.invitedUserId && session.invitedUserId !== userId) {
      throw new ForbiddenException('This invite was not addressed to you');
    }
    if (session.participantSecondUserId) {
      throw new BadRequestException('This lobby already has an opponent');
    }

    const updated = await this.prisma.draftSession.update({
      where: { id: sessionId },
      data: {
        participantSecondUserId: userId,
        status: 'in_progress',
        currentStepStartedAt: new Date(),
      },
    });

    // The creator has been sitting in the waiting room possibly for a
    // while — this is what tells their screen an opponent just showed
    // up, without waiting on a poll interval.
    this.draftGateway.emitUpdate(sessionId, updated);
    return updated;
  }

  /**
   * Matchmaking queue: if someone else is already waiting, join them
   * immediately; otherwise become the one waiting. The DB row itself
   * IS the queue — no separate in-memory or ticket table.
   *
   * KNOWN SIMPLIFICATION: the "find an existing waiter, else create
   * one" check isn't wrapped in a strict row lock, so two people
   * searching in the exact same instant could theoretically both end
   * up creating a fresh waiting session instead of matching each
   * other. They'd each just end up waiting for the next searcher
   * (self-correcting on the following poll), not stuck — a real
   * production queue would want proper locking to close even that
   * narrow window, but it's a low-stakes race for a training tool.
   */
  async searchMatch(userId: string) {
    const existingSearch = await this.prisma.draftSession.findFirst({
      where: { createdByUserId: userId, opponentType: 'matchmaking', status: 'waiting_for_opponent' },
    });
    if (existingSearch) return existingSearch;

    const waitingOpponent = await this.prisma.draftSession.findFirst({
      where: {
        opponentType: 'matchmaking',
        status: 'waiting_for_opponent',
        createdByUserId: { not: userId },
      },
      orderBy: { createdAt: 'asc' },
    });

    if (waitingOpponent) {
      return this.joinFriendDraft(waitingOpponent.id, userId);
    }

    const radiantSide: DraftSide = Math.random() < 0.5 ? 'FIRST_PICK' : 'SECOND_PICK';
    return this.prisma.draftSession.create({
      data: {
        createdByUserId: userId,
        mode: 'free',
        opponentType: 'matchmaking',
        sequence: buildCaptainsModeSequence() as any,
        actions: [] as any,
        status: 'waiting_for_opponent',
        radiantSide,
        currentStepStartedAt: new Date(),
        rulesVersion: 'cm-7.40-ban-phase-1-3-reorder',
      },
    });
  }

  /** Leaves the matchmaking queue / withdraws a not-yet-accepted invite. */
  async cancelWaiting(sessionId: string, userId: string) {
    const session = await this.getSession(sessionId);
    if (session.createdByUserId !== userId) {
      throw new ForbiddenException('Only the creator can cancel this');
    }
    if (session.status !== 'waiting_for_opponent') {
      throw new BadRequestException('This session is not waiting — nothing to cancel');
    }
    return this.prisma.draftSession.update({
      where: { id: sessionId },
      data: { status: 'cancelled' },
    });
  }

  async listMine(userId: string) {
    return this.prisma.draftSession.findMany({
      where: { OR: [{ createdByUserId: userId }, { participantSecondUserId: userId }] },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getSession(id: string) {
    const session = await this.prisma.draftSession.findUnique({ where: { id } });
    if (!session) throw new NotFoundException('Draft session not found');
    return session;
  }

  /**
   * The public-facing read used by the controller's GET route — unlike
   * the bare getSession() above (used internally by methods that do
   * their own authorization afterward, e.g. checking who's allowed to
   * act), this enforces who's allowed to even *view* the session.
   *
   * Completed drafts are viewable by any logged-in Areon user — that's
   * the whole point of Share Draft, a finished draft's outcome is
   * already locked in, nothing to protect. IN-PROGRESS drafts are
   * restricted to their two real participants (or an admin spectating)
   * — the actual gap worth closing is a stranger peeking at a *live*
   * friend/matchmaking draft, which could matter competitively; a
   * finished one can't be un-fairly influenced by being looked at.
   */
  async getSessionForViewer(id: string, userId: string) {
    const session = await this.getSession(id);
    if (session.status === 'completed') return session;

    const isParticipant = session.createdByUserId === userId || session.participantSecondUserId === userId;
    if (isParticipant) return session;

    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (user?.isAdmin) return session;

    throw new ForbiddenException(
      'This draft is still in progress — only its participants or an admin can view it',
    );
  }

  /**
   * Every 'free'-mode draft currently in progress or waiting — for the
   * admin panel's "watch any game" list. Not scoped to the requesting
   * admin's own games at all, on purpose.
   */
  async adminListActiveSessions() {
    return this.prisma.draftSession.findMany({
      where: { mode: 'free', status: { in: ['waiting_for_opponent', 'in_progress'] } },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Admin-only, and only this — there is no player-facing undo. Pops
   * the last action off the session and reopens it for that step to be
   * replayed, refunding exactly the reserve time that action consumed
   * (tracked per-action via DraftEvent.reserveSpent) rather than
   * leaving it permanently spent.
   */
  async adminUndo(sessionId: string) {
    const session = await this.getSession(sessionId);
    const actions = session.actions as unknown as DraftEvent[];
    if (actions.length === 0) {
      throw new BadRequestException('Nothing to undo — no actions taken yet');
    }

    const undoneAction = actions[actions.length - 1];
    const newActions = actions.slice(0, -1);
    const isFirst = undoneAction.side === 'FIRST_PICK';
    const refund = undoneAction.reserveSpent ?? 0;

    const updated = await this.prisma.draftSession.update({
      where: { id: sessionId },
      data: {
        actions: newActions as any,
        status: 'in_progress',
        currentStepStartedAt: new Date(),
        ...(isFirst
          ? { reserveFirstSec: session.reserveFirstSec + refund }
          : { reserveSecondSec: session.reserveSecondSec + refund }),
      },
    });

    this.draftGateway.emitUpdate(sessionId, updated);
    return updated;
  }

  async performAction(sessionId: string, userId: string, heroId: number) {
    const session = await this.getSession(sessionId);
    const sequence = session.sequence as unknown as DraftStep[];
    const actions = session.actions as unknown as DraftEvent[];
    const nextStep = sequence[actions.length];
    this.assertMutable(session, userId, nextStep, { requireTurnOwner: true });

    const hero = await this.prisma.hero.findUnique({ where: { id: heroId } });
    if (!hero) throw new BadRequestException('Unknown hero');
    if (!hero.captainsModeAvailable) {
      throw new BadRequestException(`${hero.localizedName} is not available in Captain's Mode`);
    }

    const usedHeroIds = new Set(actions.filter((a) => a.heroId != null).map((a) => a.heroId));
    if (usedHeroIds.has(heroId)) {
      throw new BadRequestException('That hero is already picked or banned');
    }

    // A manual action can still land after the main per-action timer ran
    // out, as long as the side hadn't fully burned through its reserve
    // yet — that overflow needs to come out of the reserve pool, same as
    // it would in the real client, or the next step would get a full
    // fresh allowance for free.
    const elapsedSec = (Date.now() - session.currentStepStartedAt.getTime()) / 1000;
    return this.appendAction(session, nextStep, { heroId, timedOut: false }, elapsedSec).then((s) => {
      this.scheduleBotTurn(s.id);
      return s;
    });
  }

  /**
   * Called by the client when its local countdown (main timer, then
   * reserve) hits zero. Re-checks elapsed time AND reserve server-side
   * against currentStepStartedAt rather than trusting the client
   * outright - a client clock can't force a timeout to finalize early.
   *
   * Per the confirmed mechanic: the main per-action timer does not carry
   * over; once it's spent, the side automatically starts drawing down
   * its 130s reserve pool instead. Only once BOTH are exhausted does the
   * forced outcome (skipped ban / random pick) actually happen — before
   * that, this just rejects and the client keeps counting down locally
   * using the reserve value already in the session.
   */
  async performTimeout(sessionId: string, userId: string) {
    const session = await this.getSession(sessionId);
    this.assertMutable(session, userId);

    const sequence = session.sequence as unknown as DraftStep[];
    const actions = session.actions as unknown as DraftEvent[];
    const nextStep = sequence[actions.length];

    const elapsedSec = (Date.now() - session.currentStepStartedAt.getTime()) / 1000;
    const overflowSec = elapsedSec - nextStep.timeLimitSec;
    const currentReserve = nextStep.side === 'FIRST_PICK' ? session.reserveFirstSec : session.reserveSecondSec;

    if (overflowSec < currentReserve) {
      throw new BadRequestException(
        'Main time is up but reserve time is not exhausted yet — the client should keep counting down using reserve, not call timeout',
      );
    }

    if (nextStep.action === 'ban') {
      // Per the confirmed rule: a ban timeout skips the ban entirely.
      return this.appendAction(session, nextStep, { heroId: null, timedOut: true }, elapsedSec).then((s) => {
        this.scheduleBotTurn(s.id);
        return s;
      });
    }

    // Pick timeout: auto-assign a random available, CM-eligible hero.
    const usedHeroIds = new Set(actions.filter((a) => a.heroId != null).map((a) => a.heroId));
    const candidates = await this.prisma.hero.findMany({
      where: { captainsModeAvailable: true, id: { notIn: [...usedHeroIds] as number[] } },
    });
    if (candidates.length === 0) {
      throw new BadRequestException('No available heroes left to auto-pick - hero database may be empty/unsynced');
    }
    const randomHero = candidates[Math.floor(Math.random() * candidates.length)];
    return this.appendAction(session, nextStep, { heroId: randomHero.id, timedOut: true }, elapsedSec).then((s) => {
      this.scheduleBotTurn(s.id);
      return s;
    });
  }

  /**
   * Runs the bot's turn(s) until it's the human's turn again, the
   * session completes, or the session isn't actually an AI game.
   * Bot actions are timestamped as instant (elapsedSec 0) — the bot
   * doesn't have a reaction-time concept, so no reserve gets deducted
   * for its moves.
   */
  /**
   * Requirement: no more instant/synchronous bot moves — this used to
   * resolve every consecutive bot turn in the same request that
   * triggered it (a while-loop calling pickBotHero → appendAction back
   * to back with no gap), which is exactly why bot bans/picks looked
   * instantaneous no matter what the frontend's own timer displayed.
   * This now only ever schedules ONE bot turn: computes a randomized
   * "thinking" delay, waits it out with a real setTimeout (not
   * something the frontend can shortcut), THEN runs the exact same
   * scoring logic pickBotHero always used, appends the result, and
   * pushes it live over the existing draft.gateway socket — the same
   * channel two-human sessions already use, so 'ai' mode sessions
   * just need to stay connected to it (see App usage) rather than
   * needing a second live-update mechanism built for bots specifically.
   * If the sequence has another bot turn immediately after (does not
   * happen in a normal alternating Captain's Mode sequence, but the
   * recursion is here in case a rules variant ever produces one), this
   * schedules that one too once the first finishes — never a second
   * synchronous loop.
   */
  private async scheduleBotTurn(sessionId: string) {
    const session = await this.getSession(sessionId);
    if (session.opponentType !== 'ai' || session.status !== 'in_progress') return;

    const sequence = session.sequence as unknown as DraftStep[];
    const actions = session.actions as unknown as DraftEvent[];
    const nextStep = sequence[actions.length];
    if (!nextStep || nextStep.side !== session.aiSide) return;

    const delayMs = this.botThinkingDelayMs(nextStep, actions.length);

    setTimeout(async () => {
      try {
        // Re-fetch — the delay was real time passing, not a blocking
        // hold on this data; an admin action (undo, force-timeout)
        // could have changed things while the bot was "thinking".
        const fresh = await this.getSession(sessionId);
        if (fresh.status !== 'in_progress') return;
        const freshSequence = fresh.sequence as unknown as DraftStep[];
        const freshActions = fresh.actions as unknown as DraftEvent[];
        const freshStep = freshSequence[freshActions.length];
        if (!freshStep || freshStep.side !== fresh.aiSide) return; // no longer the bot's turn to act on

        const { id: heroId, reason: botReason } = await this.pickBotHero(fresh, freshStep);
        const updated = await this.appendAction(fresh, freshStep, { heroId, timedOut: false, botReason }, 0);
        this.draftGateway.emitUpdate(sessionId, updated);
        this.scheduleBotTurn(sessionId); // in case another bot turn immediately follows
      } catch (e: any) {
        this.logger.error(`Bot turn failed for session=${sessionId}: ${e instanceof Error ? e.message : String(e)}`);
      }
    }, delayMs);
  }

  /**
   * 5–15s, varied rather than a fixed number so it doesn't read as an
   * obvious artificial pause — a ban with no picks on board yet is
   * scored on one simple signal (see pickBotBan's own comment) and
   * gets the short end; a pick made later in the draft, weighing role
   * need against real counter/risk data across a bigger candidate
   * pool, gets the long end. This governs wall-clock delay only — the
   * decision itself always runs the same scoring logic in
   * pickBotHero/pickBotBan regardless of which bucket it landed in.
   */
  private botThinkingDelayMs(step: DraftStep, actionsSoFar: number): number {
    const isEarlyBan = step.action === 'ban' && actionsSoFar < 2;
    const isLateComplexPick = step.action === 'pick' && actionsSoFar >= 6;
    const [minSec, maxSec] = isEarlyBan ? [5, 7] : isLateComplexPick ? [10, 15] : [7, 10];
    return (minSec + Math.random() * (maxSec - minSec)) * 1000;
  }

  /**
   * Fixed heuristic, not a trained model:
   *  - BAN: uniformly random among available Captain's-Mode-eligible
   *    heroes. No attempt to model "which heroes are strong" — that
   *    would need pick/win-rate data this scaffold doesn't store yet.
   *  - PICK: scores each available hero by how many of the human's
   *    already-picked heroes appear in that hero's `countersJson.goodAgainst`
   *    list (real per-matchup win-rate data from OpenDota, synced via
   *    HeroesService.syncMatchups — see the hero-database README notes).
   *    Highest score wins, ties broken randomly. If the human hasn't
   *    picked anything yet, or none of the candidates have synced
   *    matchup data, this degrades to a random pick — not a silent
   *    wrong answer, just an honest "no signal available yet".
   */
  /**
   * Redesigned per the product brief: no longer pure "counter the last
   * enemy pick" — the bot now tracks which of its own role categories
   * are still open and weighs role need alongside counter data, so a
   * five-pick side ends up looking like an actual team instead of five
   * independent counter-picks. Deliberately does NOT invent an "ally
   * synergy" score — no real per-hero-pair synergy data exists in this
   * project (see computeDraftRating's own honest note on this same
   * limitation) — role-fit is the real, available substitute for "does
   * this pick build toward a coherent team".
   */
  private async pickBotHero(
    session: { actions: any; aiSide: string | null },
    step: DraftStep,
  ): Promise<{ id: number; reason: string }> {
    const actions = session.actions as unknown as DraftEvent[];
    const usedHeroIds = [...new Set(actions.filter((a) => a.heroId != null).map((a) => a.heroId!))];

    const candidates = await this.prisma.hero.findMany({
      where: { captainsModeAvailable: true, id: { notIn: usedHeroIds } },
    });
    if (candidates.length === 0) {
      throw new BadRequestException('No available heroes left for the bot — hero database may be empty/unsynced');
    }

    const myPickedIds = actions.filter((a) => a.action === 'pick' && a.side === session.aiSide && a.heroId != null).map((a) => a.heroId!);
    const enemyPickedIds = actions.filter((a) => a.action === 'pick' && a.side !== session.aiSide && a.heroId != null).map((a) => a.heroId!);

    if (step.action === 'ban') {
      return this.pickBotBan(candidates, myPickedIds, enemyPickedIds);
    }

    // Role coverage the bot's own lineup still needs — same five
    // categories computeDraftRating scores a finished draft on, so the
    // live pick logic and the post-draft explanation agree with each
    // other instead of being two disconnected systems.
    const ROLE_CATEGORIES = ['Carry', 'Support', 'Disabler', 'Durable', 'Nuker'];
    const myHeroes = myPickedIds.length > 0 ? await this.prisma.hero.findMany({ where: { id: { in: myPickedIds } } }) : [];
    const coveredRoles = new Set(myHeroes.flatMap((h) => h.roles.filter((r) => ROLE_CATEGORIES.includes(r))));
    const missingRoles = ROLE_CATEGORIES.filter((r) => !coveredRoles.has(r));

    const isTrueFirstPick = myPickedIds.length === 0 && enemyPickedIds.length === 0;

    // Requirement 7: dynamic weighting by draft stage — early on
    // (roughly the first third of the sequence) flexibility and role
    // breadth matter more than reacting to specific enemy picks, since
    // there's little to react to yet and an early pick locks in
    // structure for the rest of the draft; late in the draft, the
    // opposite: concrete counter data against the now-mostly-revealed
    // enemy lineup matters far more than staying flexible. `actions`
    // is this session's real running total, not an estimate.
    const draftStage = actions.length < 6 ? 'early' : actions.length >= 14 ? 'late' : 'mid';
    const roleWeight = draftStage === 'early' ? 4 : draftStage === 'late' ? 2 : 3;
    const counterWeight = draftStage === 'early' ? 1.2 : draftStage === 'late' ? 3 : 2;
    const versatilityWeight = draftStage === 'early' ? 3 : 1;

    // Same real gaps the post-draft 10-category scoring checks for
    // (see scoreComposition's teamfight/control/damage blocks) — the
    // bot uses the identical signals while it's still picking, not a
    // separate disconnected heuristic, per the brief's explicit
    // request to share one model between live decisions and the
    // after-the-fact report.
    const hasInitiator = myHeroes.some((h) => h.roles.includes('Initiator'));
    const hasDisabler = myHeroes.some((h) => h.roles.includes('Disabler'));
    const hasNuker = myHeroes.some((h) => h.roles.includes('Nuker'));
    const hasPhysicalCore = myHeroes.some((h) => (h.primaryAttr === 'agi' || h.primaryAttr === 'str') && h.roles.includes('Carry'));

    const scored: { id: number; score: number; roleFit: number; counterScore: number; counterRisk: number; versatility: number; gapFill: number; gapLabels: string[] }[] = [];

    for (const c of candidates) {
      const counters = c.countersJson as unknown as { goodAgainst?: { heroId: number }[]; weakAgainst?: { heroId: number }[] } | null;

      // How many of the bot's still-open role slots this hero fills —
      // the core of "build a team", not just react to the last pick.
      const roleFit = missingRoles.length === 0 ? 0 : c.roles.filter((r) => missingRoles.includes(r)).length;

      // Real per-matchup data: how good this pick is against what the
      // enemy has shown, and how exposed it already is to what the
      // enemy has shown (counters the enemy holds against it).
      const counterScore = counters?.goodAgainst?.filter((g) => enemyPickedIds.includes(g.heroId)).length ?? 0;
      const counterRisk = counters?.weakAgainst?.filter((w) => enemyPickedIds.includes(w.heroId)).length ?? 0;

      // First pick of the whole draft: nothing to counter yet, so lean
      // on role breadth (a hero tagged for more of the five categories
      // is a safer foundation to plan the rest of the team around) —
      // real data (the hero's own tagged roles), not an invented
      // "meta strength" score.
      const versatility = isTrueFirstPick ? c.roles.filter((r) => ROLE_CATEGORIES.includes(r)).length : 0;

      // Fills a genuine structural gap (no initiator/control/magic
      // damage/physical core yet) — worth a real bonus, same weight
      // class as role-fit, since these are exactly the gaps the
      // post-draft report would otherwise flag as weaknesses.
      let gapFill = 0;
      const gapLabels: string[] = [];
      if (!hasInitiator && c.roles.includes('Initiator')) { gapFill += 1; gapLabels.push('добавляет инициацию, которой не было'); }
      if (!hasDisabler && c.roles.includes('Disabler')) { gapFill += 1; gapLabels.push('добавляет контроль, которого не было'); }
      if (!hasNuker && c.roles.includes('Nuker')) { gapFill += 1; gapLabels.push('добавляет магический бурст'); }
      if (!hasPhysicalCore && (c.primaryAttr === 'agi' || c.primaryAttr === 'str') && c.roles.includes('Carry')) { gapFill += 1; gapLabels.push('закрывает физического керри'); }

      const score = roleFit * roleWeight + counterScore * counterWeight - counterRisk * (counterWeight * 0.75) + versatility * versatilityWeight + gapFill * 2;
      scored.push({ id: c.id, score, roleFit, counterScore, counterRisk, versatility, gapFill, gapLabels });
    }
    const maxScore = Math.max(...scored.map((s) => s.score));
    // Requirement 11: "не случайный любой герой, а один из нескольких
    // действительно сильных вариантов" — a small tolerance band
    // around the true best (not just an exact tie) is what makes the
    // bot's picks vary run to run without ever picking something
    // actually weak; 1.5 points is roughly "one extra role-fit or
    // counter-score hit", a real margin, not a coin flip across the
    // whole candidate pool.
    const NEAR_EQUAL_TOLERANCE = 1.5;
    const nearBest = scored.filter((s) => maxScore - s.score <= NEAR_EQUAL_TOLERANCE);
    const chosen = nearBest[Math.floor(Math.random() * nearBest.length)];

    const reasonParts: string[] = [];
    if (chosen.roleFit > 0) reasonParts.push(`закрывает ${chosen.roleFit} недостающую роль(и)`);
    if (chosen.counterScore > 0) reasonParts.push(`контрит ${chosen.counterScore} героя(ев) соперника`);
    if (chosen.gapLabels.length > 0) reasonParts.push(...chosen.gapLabels);
    if (chosen.versatility > 0) reasonParts.push('универсален для первого пика драфта');
    if (chosen.counterRisk > 0) reasonParts.push(`но статистически слаб против ${chosen.counterRisk} героя(ев) соперника`);
    const reason = reasonParts.length > 0 ? reasonParts.join(', ') : 'наиболее сбалансированный доступный вариант';

    return { id: chosen.id, reason };
  }

  /**
   * Ban logic: if the bot has picks on the board already, prioritize
   * banning whichever remaining hero would counter its OWN lineup the
   * hardest (a defensive ban, using the same real weakAgainst/
   * goodAgainst data as picks — this candidate's goodAgainst list
   * pointing at a hero we already have is a direct signal it's
   * dangerous to us specifically, not a generic "strong hero" guess).
   * Before the bot has any picks yet, there is no "our lineup" to
   * defend and no invented popularity score to rank on, so this stays
   * an honest random choice among the legal candidates rather than
   * pretending to know which heroes are generically strongest.
   */
  private pickBotBan(
    candidates: { id: number; countersJson: unknown }[],
    myPickedIds: number[],
    _enemyPickedIds: number[],
  ): { id: number; reason: string } {
    if (myPickedIds.length === 0) {
      // No lineup to defend yet, but "fully random" was the real
      // cause of early bans looking arbitrary — most Captain's Mode
      // bans happen before any picks, so this path covers most of
      // what a person actually watches. The honest signal available
      // without a lineup: how broadly dangerous this hero is (the
      // size of its own synced goodAgainst list) — a hero that
      // counters many things is a reasonable generic threat to take
      // off the board early, the same instinct real drafters use for
      // "ban the flexible/strong hero" before anyone's shown intent.
      let bestScore = -1;
      let best: number[] = [];
      for (const c of candidates) {
        const counters = c.countersJson as { goodAgainst?: { heroId: number }[] } | null;
        const breadth = counters?.goodAgainst?.length ?? 0;
        if (breadth > bestScore) {
          bestScore = breadth;
          best = [c.id];
        } else if (breadth === bestScore) {
          best.push(c.id);
        }
      }
      // Every candidate had zero synced matchup data (a genuinely
      // unsynced hero table) — the only case where this is still an
      // honest random pick rather than pretending to have a signal.
      if (bestScore <= 0) {
        const id = candidates[Math.floor(Math.random() * candidates.length)].id;
        return { id, reason: 'нет синхронизированных данных по контрпикам — выбор без явного сигнала' };
      }
      const id = best[Math.floor(Math.random() * best.length)];
      return { id, reason: `статистически опасен против широкого круга героев (${bestScore} синхронизированных контрпиков)` };
    }

    let bestScore = -1;
    let best: number[] = [];
    for (const c of candidates) {
      const counters = c.countersJson as { goodAgainst?: { heroId: number }[] } | null;
      const threatToUs = counters?.goodAgainst?.filter((g) => myPickedIds.includes(g.heroId)).length ?? 0;
      if (threatToUs > bestScore) {
        bestScore = threatToUs;
        best = [c.id];
      } else if (threatToUs === bestScore) {
        best.push(c.id);
      }
    }
    const id = best[Math.floor(Math.random() * best.length)];
    return { id, reason: bestScore > 0 ? `статистически хорошо играет против нашего текущего состава (${bestScore} угрозы)` : 'наименее рискованный доступный бан' };
  }

  /**
   * Resolves who's allowed to act for a given logical side. 'self' mode
   * keeps the original behaviour (creator controls both sides). 'ai'
   * mode returns null for the bot's side — nobody human ever owns it.
   * 'friend'/'matchmaking' split control across the two real
   * participants.
   */
  private participantForSide(
    session: { opponentType: string; createdByUserId: string; participantSecondUserId: string | null; aiSide?: string | null },
    side: DraftSide,
  ): string | null {
    if (session.opponentType === 'ai') {
      return side === session.aiSide ? null : session.createdByUserId;
    }
    const isTwoPlayerMode = session.opponentType === 'friend' || session.opponentType === 'matchmaking';
    if (!isTwoPlayerMode) return session.createdByUserId;
    return side === 'FIRST_PICK' ? session.createdByUserId : session.participantSecondUserId;
  }

  /**
   * `requireTurnOwner`: performAction needs the caller to be the exact
   * side whose turn it is. performTimeout does not — the whole point of
   * calling timeout is usually to report that the OTHER participant let
   * their clock run out, so it only needs to check that the caller is
   * one of the two real participants in this session at all.
   */
  private assertMutable(
    session: {
      createdByUserId: string;
      participantSecondUserId: string | null;
      opponentType: string;
      status: string;
      mode: string;
    },
    userId: string,
    nextStep?: DraftStep,
    options?: { requireTurnOwner?: boolean },
  ) {
    if (session.mode !== 'free') throw new BadRequestException('Only free-draft sessions accept actions');
    if (session.status === 'waiting_for_opponent') {
      throw new BadRequestException('This lobby is still waiting for an opponent to join');
    }
    if (session.status !== 'in_progress') throw new BadRequestException('This draft is already finished');

    const isParticipant = userId === session.createdByUserId || userId === session.participantSecondUserId;
    if (!isParticipant) throw new ForbiddenException('Not a participant in this draft session');

    if (options?.requireTurnOwner && nextStep) {
      const turnUser = this.participantForSide(session, nextStep.side);
      if (turnUser !== userId) throw new ForbiddenException('Not your turn');
    }
  }

  private async appendAction(
    session: {
      id: string;
      sequence: any;
      actions: any;
      reserveFirstSec: number;
      reserveSecondSec: number;
    },
    step: DraftStep,
    outcome: { heroId: number | null; timedOut: boolean; botReason?: string },
    elapsedSec: number,
  ) {
    const sequence = session.sequence as unknown as DraftStep[];
    const actions = session.actions as unknown as DraftEvent[];

    // Deduct any overflow beyond the main per-action allowance from that
    // side's reserve pool, floored at 0. On a genuine forced timeout this
    // drains it to exactly 0 (by construction, since performTimeout only
    // gets here once overflow >= currentReserve); on a manual action that
    // just ran a little long, it's a partial deduction.
    const overflowSec = Math.max(0, elapsedSec - step.timeLimitSec);
    const isFirst = step.side === 'FIRST_PICK';
    const reserveBefore = isFirst ? session.reserveFirstSec : session.reserveSecondSec;
    const reserveAfter = Math.max(0, Math.round(reserveBefore - overflowSec));
    // The actual amount deducted, which can be less than overflowSec if
    // the side didn't have that much reserve left to give (reserveAfter
    // floors at 0 rather than going negative) — this exact number, not
    // overflowSec, is what a later undo needs to hand back.
    const reserveSpent = reserveBefore - reserveAfter;

    const newActions = [...actions, { ...step, ...outcome, reserveSpent }];
    const isComplete = newActions.length === sequence.length;

    const updated = await this.prisma.draftSession.update({
      where: { id: session.id },
      data: {
        actions: newActions as any,
        status: isComplete ? 'completed' : 'in_progress',
        currentStepStartedAt: new Date(),
        ...(isFirst ? { reserveFirstSec: reserveAfter } : { reserveSecondSec: reserveAfter }),
      },
    });

    this.draftGateway.emitUpdate(session.id, updated);
    if (isComplete) {
      this.monitoring.log(updated.createdByUserId, 'draft_completed', '/draft-trainer', { sessionId: updated.id, mode: updated.mode }).catch(() => {});

      // Site Rating participation — every real participant, every mode
      // (even solo self/ai practice counts as real activity on the
      // platform, just at the flat participation rate; only the
      // 2-player win/loss bonus below distinguishes a real opponent
      // match).
      this.rewardEngine.grant({
        userId: updated.createdByUserId, activityType: 'draft', activityId: updated.id,
        siteRatingDelta: 5, reason: 'Завершённый драфт',
      }).catch(() => {});
      if (updated.participantSecondUserId) {
        this.rewardEngine.grant({
          userId: updated.participantSecondUserId, activityType: 'draft', activityId: updated.id,
          siteRatingDelta: 5, reason: 'Завершённый драфт',
        }).catch(() => {});
      }

      if (updated.tournamentMatchId) {
        await this.resolveTournamentMatchIfLinked(updated);
      } else {
        await this.applyDraftRatingIfEligible(updated);
      }
    }
    return updated;
  }

  /**
   * Requirement 10's Elo-style Drafter Rating. Only fires for a real
   * two-player match (friend/matchmaking) — 'self' and 'ai' sessions
   * have no genuine opponent to exchange rating with, and tournament
   * matches are handled by resolveTournamentMatchIfLinked instead (a
   * bracket win/loss, not an Elo exchange, for now). Winner is the
   * same composition-quality heuristic used everywhere else in this
   * file — see that method's own note on this being a real, disclosed
   * product tradeoff rather than an oversight.
   */
  private async applyDraftRatingIfEligible(session: { id: string; mode: string; opponentType: string; radiantSide: string; createdByUserId: string; participantSecondUserId: string | null }) {
    const isTwoPlayer = session.opponentType === 'friend' || session.opponentType === 'matchmaking';
    if (!isTwoPlayer || !session.participantSecondUserId) return;

    const rating = await this.computeDraftRating(session.id);
    const radiantUserId = session.radiantSide === 'FIRST_PICK' ? session.createdByUserId : session.participantSecondUserId;
    const direUserId = session.radiantSide === 'FIRST_PICK' ? session.participantSecondUserId : session.createdByUserId;
    const radiantWon = rating.estimatedOutcome.strongerSide === 'radiant';
    const winnerId = radiantWon ? radiantUserId : direUserId;
    const loserId = radiantWon ? direUserId : radiantUserId;

    const [winner, loser] = await Promise.all([
      this.prisma.user.findUniqueOrThrow({ where: { id: winnerId } }),
      this.prisma.user.findUniqueOrThrow({ where: { id: loserId } }),
    ]);

    // Standard Elo, K=32 — a conventional, widely-used constant for a
    // ladder this size, not tuned against anything specific to Areon.
    const K = 32;
    const expectedWinner = 1 / (1 + Math.pow(10, (loser.draftRating - winner.draftRating) / 400));
    const winnerChange = Math.round(K * (1 - expectedWinner));
    const loserChange = -winnerChange;

    await this.prisma.$transaction([
      this.prisma.user.update({ where: { id: winnerId }, data: { draftRating: { increment: winnerChange } } }),
      this.prisma.user.update({ where: { id: loserId }, data: { draftRating: { increment: loserChange } } }),
      this.prisma.draftRatingHistoryEntry.create({
        data: {
          userId: winnerId, sessionId: session.id, opponentId: loserId, won: true,
          oldRating: winner.draftRating, change: winnerChange, newRating: winner.draftRating + winnerChange,
          radiantScore: rating.radiant.total, direScore: rating.dire.total,
        },
      }),
      this.prisma.draftRatingHistoryEntry.create({
        data: {
          userId: loserId, sessionId: session.id, opponentId: winnerId, won: false,
          oldRating: loser.draftRating, change: loserChange, newRating: loser.draftRating + loserChange,
          radiantScore: rating.radiant.total, direScore: rating.dire.total,
        },
      }),
    ]);

    // Site Rating win/loss bonus, on top of the flat participation
    // grant already given at raw completion — participation and
    // result are two separate grants (requirement 3), not one merged
    // number.
    this.rewardEngine.grant({
      userId: winnerId, activityType: 'draft_result', activityId: session.id,
      siteRatingDelta: 15, reason: 'Победа в драфте',
    }).catch(() => {});
    this.rewardEngine.grant({
      userId: loserId, activityType: 'draft_result', activityId: session.id,
      siteRatingDelta: 2, reason: 'Поражение в драфте',
    }).catch(() => {});
  }

  /**
   * The one and only place a Draft Tournament match's winner is
   * decided — by the same composition-quality heuristic
   * computeDraftRating already produces for the casual "estimated
   * outcome" banner, now actually used to eliminate a player. That
   * tradeoff (approximate metric, real elimination) was an explicit
   * product decision, not an oversight — see the product brief this
   * was built against. Ties broken toward Radiant rather than
   * randomly: exceedingly rare with real composition scores, and a
   * fixed tiebreak is easier to explain than a coin flip would be.
   */
  private async resolveTournamentMatchIfLinked(session: { id: string; tournamentMatchId: string | null; radiantSide: string; createdByUserId: string; participantSecondUserId: string | null }) {
    if (!session.tournamentMatchId) return;
    const rating = await this.computeDraftRating(session.id);
    const radiantUserId = session.radiantSide === 'FIRST_PICK' ? session.createdByUserId : session.participantSecondUserId;
    const direUserId = session.radiantSide === 'FIRST_PICK' ? session.participantSecondUserId : session.createdByUserId;
    const winnerId = rating.radiant.total >= rating.dire.total ? radiantUserId : direUserId;
    if (!winnerId) return; // shouldn't happen for a tournament match (both players always assigned)
    await this.draftTournaments.resolveMatch(session.tournamentMatchId, winnerId, false);
  }

  async listProMatches() {
    return this.openDota.getProMatches();
  }

  /**
   * ============================================================================
   * DRAFT RATING — deterministic composition heuristics, NOT a win-probability
   * prediction. This scores structural properties of a finished draft
   * (role coverage, attribute spread, counter-awareness), not "who's going
   * to win" — that would need real match outcome data trained against
   * thousands of games, which this scaffold doesn't have. Three
   * components, each out of a fixed weight, summing to 100:
   *
   *  - Role coverage (40 pts): does the 5-hero lineup cover the five
   *    OpenDota-tagged roles that matter most for a functional team
   *    (Carry, Support, Disabler, Durable, Nuker)? Missing categories
   *    just lower this component — it's not a claim that every team
   *    needs exactly one of each, just a rough completeness check.
   *  - Attribute diversity (20 pts): how many distinct primary
   *    attributes (str/agi/int/universal) appear among the 5 picks.
   *    A team stacked on one attribute is more vulnerable to a single
   *    counter-strategy (e.g. all-intelligence low-HP lineups dying to
   *    burst) — a real but rough signal, not a hard rule.
   *  - Counter-awareness (40 pts): of the picks made after at least one
   *    enemy hero was already visible, what fraction appear in that
   *    hero's own `countersJson.goodAgainst` list against an enemy pick
   *    already on the board? Reuses the exact same real per-matchup
   *    data the AI bot uses to pick — see pickBotHero. Picks made
   *    before the enemy had shown anyone aren't counted against this
   *    score at all (there was nothing to counter yet).
   * ============================================================================
   */
  /**
   * Requirement 6: after the last pick, each side assigns their 5
   * heroes to positions before the final analysis unlocks. Validated
   * server-side — exactly this side's 5 picked heroes, each getting a
   * distinct position 1-5 — so a malformed or partial submission can't
   * silently corrupt what the results screen reads back.
   */
  async setPositions(sessionId: string, userId: string, positions: Record<number, number>) {
    const session = await this.getSession(sessionId);
    const actions = session.actions as unknown as DraftEvent[];
    // Solo practice (self/ai) has no real second participant — the
    // frontend treats Radiant as "my side" there regardless of pick
    // order (see DraftSessionPage's own mySide comment), and this had
    // fallen out of sync with it: this endpoint was still deriving
    // side purely from createdByUserId/participantSecondUserId, which
    // is FIRST_PICK for every self/ai session regardless of which one
    // is actually Radiant. Whenever radiantSide happened to be
    // SECOND_PICK (randomized at session creation, so roughly half
    // the time), the 5 hero ids the frontend sent (Radiant's picks)
    // never matched this endpoint's expected side (First Pick's
    // picks) — rejected as "not this side's picks", which is exactly
    // what made "Завершить драфт" appear broken.
    const side: DraftSide | null =
      session.opponentType === 'self' || session.opponentType === 'ai'
        ? (session.radiantSide as DraftSide)
        : userId === session.createdByUserId ? 'FIRST_PICK'
        : userId === session.participantSecondUserId ? 'SECOND_PICK' : null;
    if (!side) throw new ForbiddenException('You are not a participant in this draft');

    const pickedIds = actions.filter((a) => a.action === 'pick' && a.side === side && a.heroId != null).map((a) => a.heroId!);
    const heroIds = Object.keys(positions).map(Number);
    const posValues = Object.values(positions);

    if (heroIds.length !== 5 || new Set(posValues).size !== 5 || posValues.some((p) => p < 1 || p > 5)) {
      throw new BadRequestException('Positions must assign exactly 5 distinct positions (1-5) to exactly 5 heroes');
    }
    if (heroIds.some((h) => !pickedIds.includes(h)) || pickedIds.some((h) => !heroIds.includes(h))) {
      throw new BadRequestException('Positions must cover exactly this side\'s 5 picked heroes, no others');
    }

    const isRadiant = side === session.radiantSide;
    return this.prisma.draftSession.update({
      where: { id: sessionId },
      data: isRadiant ? { radiantPositions: positions as any } : { direPositions: positions as any },
    });
  }

  /** Requirement 11: lets the results screen show "your rating changed by X" for a specific session, once resolved. */
  async getMyRatingChangeForSession(sessionId: string, userId: string) {
    return this.prisma.draftRatingHistoryEntry.findFirst({ where: { sessionId, userId } });
  }

  async computeDraftRating(sessionId: string) {
    const session = await this.getSession(sessionId);
    // Deliberately available before completion too — this is what
    // powers the live "team composition so far" comparison the active
    // drafting screen shows after every pick, not just the post-draft
    // results screen. Only real requirement is at least one pick to
    // compare.
    if ((session.actions as unknown as DraftEvent[]).filter((a) => a.action === 'pick').length === 0) {
      throw new BadRequestException('Rating needs at least one pick on the board to compare');
    }

    const actions = session.actions as unknown as DraftEvent[];
    const radiantSide = session.radiantSide as DraftSide;
    const direSide: DraftSide = radiantSide === 'FIRST_PICK' ? 'SECOND_PICK' : 'FIRST_PICK';

    const [radiant, dire] = await Promise.all([
      this.scoreComposition(actions, radiantSide),
      this.scoreComposition(actions, direSide),
    ]);

    const [radiantTags, direTags] = await Promise.all([
      this.roleTagBreakdown(actions, radiantSide),
      this.roleTagBreakdown(actions, direSide),
    ]);

    const [radiantPositions, direPositions] = await Promise.all([
      this.assignPositions(actions, radiantSide),
      this.assignPositions(actions, direSide),
    ]);

    // Cross-team counter pairs — computed once, then shown from each
    // side's point of view. Only reports a pair when the picked hero
    // actually has synced countersJson (see hero-database README) —
    // heroes nobody ran syncMatchups on simply won't show up here,
    // which the frontend surfaces as "нет данных", not silence-as-zero.
    const counterPairs = await this.findCounterPairs(actions, radiantSide, direSide);

    // Synergy pairs (requirement 8) — real role-tag rules, computed
    // per side separately since the visualization shows each team's
    // own internal synergy, not cross-team pairs (that's what
    // counterPairs above already covers).
    const radiantPickedIds = actions.filter((a) => a.action === 'pick' && a.side === radiantSide && a.heroId != null).map((a) => a.heroId!);
    const direPickedIds = actions.filter((a) => a.action === 'pick' && a.side === direSide && a.heroId != null).map((a) => a.heroId!);
    const [radiantHeroesFull, direHeroesFull] = await Promise.all([
      radiantPickedIds.length > 1 ? this.prisma.hero.findMany({ where: { id: { in: radiantPickedIds } } }) : [],
      direPickedIds.length > 1 ? this.prisma.hero.findMany({ where: { id: { in: direPickedIds } } }) : [],
    ]);
    const synergy = {
      radiant: this.computeSynergyPairs(radiantHeroesFull),
      dire: this.computeSynergyPairs(direHeroesFull),
    };

    // Full 10-pair set for the Synergy Pentagon (requirement 9) — the
    // capped list above is for the "why" prose, this is every edge the
    // diagram needs to draw, "neutral" pairs included.
    const synergyFull = {
      radiant: this.computeAllSynergyPairs(radiantHeroesFull),
      dire: this.computeAllSynergyPairs(direHeroesFull),
    };

    // Lane matchups (requirement 7) — same position slot, both sides,
    // compared using the same real countersJson data findCounterPairs
    // already relies on. "hasData: false" when the picked hero simply
    // hasn't had matchups synced — never silently treated as "even".
    const laneMatchups = radiantPositions.map((rp) => {
      const ep = direPositions.find((p) => p.position === rp.position);
      if (!ep) return null;
      const myHero = radiantHeroesFull.find((h) => h.id === rp.heroId);
      const counters = myHero?.countersJson as { goodAgainst?: { heroId: number }[]; weakAgainst?: { heroId: number }[] } | null;
      const hasData = counters?.goodAgainst != null || counters?.weakAgainst != null;
      const favorsRadiant = counters?.goodAgainst?.some((g) => g.heroId === ep.heroId) ?? false;
      const favorsDire = counters?.weakAgainst?.some((w) => w.heroId === ep.heroId) ?? false;
      return {
        position: rp.position,
        label: rp.label,
        radiantHeroId: rp.heroId,
        direHeroId: ep.heroId,
        hasData,
        favors: !hasData ? null : favorsRadiant ? 'radiant' : favorsDire ? 'dire' : 'even',
      };
    }).filter((m): m is NonNullable<typeof m> => m != null);

    // A simulated estimate, not a real match outcome — Draft Trainer
    // has no actual game played after the draft to determine a real
    // winner from (see the honest limitation note on synergies above).
    // Framed explicitly as "estimate" everywhere it surfaces, and
    // deliberately does NOT touch the player's real Areon rating —
    // that's earned from real matches, not from out-scoring a bot's
    // heuristic composition check.
    const scoreDiff = radiant.total - dire.total;
    const estimatedOutcome = {
      isEstimate: true,
      strongerSide: scoreDiff >= 0 ? 'radiant' : 'dire' as 'radiant' | 'dire',
      scoreDiff,
    };

    return {
      radiant,
      dire,
      counterPairs,
      comparison: { radiant: radiantTags, dire: direTags },
      positions: { radiant: radiantPositions, dire: direPositions, isEstimate: true },
      synergy,
      synergyFull,
      laneMatchups,
      estimatedOutcome,
      // Not implemented: item
      // recommendations (the data exists in principle via
      // /heroes/{id}/matches + per-match item slots, but computing it
      // needs a real background aggregation pipeline this scaffold
      // doesn't have; not something to fake with a handful of live
      // calls per draft completion).
      notes: {
        synergiesAvailable: true,
        itemRecommendationsAvailable: false,
      },
    };
  }

  /**
   * For every (my pick, enemy pick) pair, checks both directions using
   * each hero's own `countersJson.goodAgainst` list — real per-matchup
   * win rates from OpenDota, same data the bot and the rating score
   * use. A pair only appears if at least one direction has data.
   */
  private async findCounterPairs(actions: DraftEvent[], radiantSide: DraftSide, direSide: DraftSide) {
    // Deduplicated defensively — a hero should only ever appear once
    // per side's picks, but this is the actual fix for "Windranger
    // контрит Viper" showing twice: if `actions` ever contains a
    // repeated pick entry for the same hero (a retried request, an
    // admin correction, anything upstream), the nested loop below
    // would evaluate that hero's pairing more than once without this.
    const radiantPicks = [...new Set(actions.filter((a) => a.action === 'pick' && a.side === radiantSide && a.heroId != null).map((a) => a.heroId!))];
    const direPicks = [...new Set(actions.filter((a) => a.action === 'pick' && a.side === direSide && a.heroId != null).map((a) => a.heroId!))];
    const allIds = [...radiantPicks, ...direPicks];
    const heroes = await this.prisma.hero.findMany({ where: { id: { in: allIds } } });
    const byId = new Map(heroes.map((h) => [h.id, h]));

    type Pair = { radiantHeroId: number; direHeroId: number; favors: 'radiant' | 'dire' };
    const pairs: Pair[] = [];
    const seen = new Set<string>();

    for (const rId of radiantPicks) {
      for (const dId of direPicks) {
        const rHero = byId.get(rId);
        const dHero = byId.get(dId);
        const rGoodAgainstD = (rHero?.countersJson as any)?.goodAgainst?.some((g: any) => g.heroId === dId);
        const dGoodAgainstR = (dHero?.countersJson as any)?.goodAgainst?.some((g: any) => g.heroId === rId);
        // Second guard, belt-and-suspenders: even with deduplicated
        // input arrays above, this key check is what actually
        // guarantees the OUTPUT list itself can never repeat the same
        // (who, whom, direction) triple, which is what was actually
        // visible on screen.
        if (rGoodAgainstD && seen.add(`${rId}>${dId}>radiant`)) pairs.push({ radiantHeroId: rId, direHeroId: dId, favors: 'radiant' });
        if (dGoodAgainstR && seen.add(`${rId}>${dId}>dire`)) pairs.push({ radiantHeroId: rId, direHeroId: dId, favors: 'dire' });
      }
    }
    return pairs;
  }

  /**
   * Radiant-vs-Dire comparison (requirement 13). Counts of real
   * OpenDota role tags already on Hero.roles — the closest honest
   * proxy available for "how much initiation/control/damage/etc this
   * lineup has" without inventing a composite score. Explicitly
   * labeled by tag name wherever this surfaces on the frontend, not
   * hidden behind an unexplained percentage.
   */
  /**
   * Requirement 8's synergy visualization. There is no real per-hero-
   * pair synergy dataset available anywhere in this project (see
   * scoreComposition's own note on that same limitation) — this is
   * NOT randomly generated or invented per pair. It's a small, fixed
   * set of well-established drafting principles (initiation feeding a
   * follow-up nuke, control setting up burst, two heroes contesting
   * the same scarce farm-dependent role) applied to each pair's real
   * OpenDota role tags. Capped at 3 pairs total so the diagram stays
   * readable, per the brief's own "не перегружать" instruction.
   */
  private computeSynergyPairs(heroes: { id: number; localizedName: string; roles: string[] }[]) {
    const all = this.computeAllSynergyPairs(heroes);
    const positives = all.filter((p) => p.tone === 'positive').slice(0, 2);
    const negatives = all.filter((p) => p.tone === 'negative').slice(0, 1);
    return [...positives, ...negatives];
  }

  /**
   * Every pair among the given heroes (all C(5,2)=10 for a full
   * lineup), including 'neutral' ones — the capped, list-friendly
   * version above only wants the few pairs actually worth calling out
   * in prose; the Synergy Pentagon (requirement 9) needs a line drawn
   * between every vertex, so a pair matching no rule still needs an
   * explicit (gray, "no strong signal either way") entry rather than
   * silently missing from the diagram.
   */
  private computeAllSynergyPairs(heroes: { id: number; localizedName: string; roles: string[] }[]) {
    const POSITIVE_RULES: { pair: [string, string]; reason: string }[] = [
      { pair: ['Initiator', 'Nuker'], reason: 'Инициация с последующим бурст-уроном' },
      { pair: ['Initiator', 'Disabler'], reason: 'Инициация с продолженным контролем' },
      { pair: ['Disabler', 'Nuker'], reason: 'Контроль открывает окно для урона' },
      { pair: ['Durable', 'Initiator'], reason: 'Живучий герой может безопасно входить в бой первым' },
    ];

    const pairs: { heroAId: number; heroBId: number; tone: 'positive' | 'negative' | 'neutral'; reason: string }[] = [];

    for (let i = 0; i < heroes.length; i++) {
      for (let j = i + 1; j < heroes.length; j++) {
        const a = heroes[i];
        const b = heroes[j];
        let matched = false;
        for (const rule of POSITIVE_RULES) {
          const aHasFirst = a.roles.includes(rule.pair[0]) && b.roles.includes(rule.pair[1]);
          const bHasFirst = b.roles.includes(rule.pair[0]) && a.roles.includes(rule.pair[1]);
          if (aHasFirst || bHasFirst) {
            pairs.push({ heroAId: a.id, heroBId: b.id, tone: 'positive', reason: rule.reason });
            matched = true;
            break;
          }
        }
        if (matched) continue;
        // Farm conflict: two heroes both leaning on the Carry tag with
        // neither tagged as a Support to enable the other — a real,
        // well-known drafting problem, not a per-hero invented score.
        if (a.roles.includes('Carry') && b.roles.includes('Carry') && !a.roles.includes('Support') && !b.roles.includes('Support')) {
          pairs.push({ heroAId: a.id, heroBId: b.id, tone: 'negative', reason: 'Оба героя претендуют на фарм и роль основного керри' });
          continue;
        }
        // Nobody wants to start the fight: both lean on getting away
        // (Escape) with neither able to actually open one (Initiator)
        // — a real, common drafting gap, not the mirror image of the
        // farm-conflict rule above by coincidence; it's the same
        // "two heroes want the same job, nobody covers the other one"
        // pattern applied to engage instead of farm priority.
        if (a.roles.includes('Escape') && b.roles.includes('Escape') && !a.roles.includes('Initiator') && !b.roles.includes('Initiator')) {
          pairs.push({ heroAId: a.id, heroBId: b.id, tone: 'negative', reason: 'Оба героя ориентированы на побег из боя, а не на его начало — некому инициировать' });
          continue;
        }
        // Two support-tagged heroes neither of whom brings real damage
        // or control — redundant utility without covering the gap it
        // creates elsewhere in the lineup.
        if (a.roles.includes('Support') && b.roles.includes('Support') && !a.roles.includes('Nuker') && !b.roles.includes('Nuker') && !a.roles.includes('Disabler') && !b.roles.includes('Disabler')) {
          pairs.push({ heroAId: a.id, heroBId: b.id, tone: 'negative', reason: 'Оба героя — чистая поддержка без урона и контроля, состав рискует остаться без завершения боя' });
          continue;
        }
        pairs.push({ heroAId: a.id, heroBId: b.id, tone: 'neutral', reason: 'Нет выраженного сигнала ни в одну сторону по доступным данным' });
      }
    }
    return pairs;
  }

  private async roleTagBreakdown(actions: DraftEvent[], side: DraftSide) {
    const pickedIds = actions.filter((a) => a.action === 'pick' && a.side === side && a.heroId != null).map((a) => a.heroId!);
    const heroes = pickedIds.length > 0 ? await this.prisma.hero.findMany({ where: { id: { in: pickedIds } } }) : [];
    const count = (tag: string) => heroes.filter((h) => h.roles.includes(tag)).length;
    return {
      initiation: count('Initiator'),
      control: count('Disabler'),
      damage: count('Nuker'),
      survivability: count('Durable'),
      push: count('Pusher'),
      mobility: count('Escape'),
    };
  }

  /**
   * Requirement 7's "most likely position" per hero. OpenDota's role
   * tags aren't a strict 1-5 slot system (a hero can be tagged both
   * Carry and Support), so this is a heuristic, not a fact — labeled
   * as such wherever it's shown. Greedy assignment: for each of the 5
   * slots in priority order, pick whichever still-unassigned hero on
   * this side best matches that slot's defining role tag; a hero with
   * no matching tag at all is assigned to whatever slot is left over,
   * since a five-pick side always needs five positions filled.
   */
  private async assignPositions(actions: DraftEvent[], side: DraftSide) {
    const pickedIds = actions.filter((a) => a.action === 'pick' && a.side === side && a.heroId != null).map((a) => a.heroId!);
    if (pickedIds.length === 0) return [];
    const heroes = await this.prisma.hero.findMany({ where: { id: { in: pickedIds } } });

    // Priority order matters here: Carry and Mid are usually the most
    // visually/statistically obvious roles (Carry tag, or a hero with
    // no Support tag at all defaulting toward Mid), so they're claimed
    // first, leaving Offlane/Support/Hard Support to sort out what's
    // left — the same order a human drafter would usually reason in.
    const SLOTS: { position: number; label: string; tag: string }[] = [
      { position: 1, label: 'Carry', tag: 'Carry' },
      { position: 2, label: 'Mid', tag: 'Nuker' },
      { position: 3, label: 'Offlane', tag: 'Durable' },
      { position: 4, label: 'Support', tag: 'Support' },
      { position: 5, label: 'Hard Support', tag: 'Disabler' },
    ];

    const remaining = [...heroes];
    const assigned: { position: number; label: string; heroId: number }[] = [];

    for (const slot of SLOTS) {
      const idx = remaining.findIndex((h) => h.roles.includes(slot.tag));
      const hero = idx >= 0 ? remaining.splice(idx, 1)[0] : remaining.shift();
      if (hero) assigned.push({ position: slot.position, label: slot.label, heroId: hero.id });
    }
    return assigned;
  }

  private async scoreComposition(actions: DraftEvent[], side: DraftSide) {
    const ROLE_CATEGORIES = ['Carry', 'Support', 'Disabler', 'Durable', 'Nuker'];
    const ROLE_HINTS: Record<string, string> = {
      Carry: 'слабый скейлинг в позднюю игру',
      Support: 'проблемы с хилом/контролем на линиях',
      Disabler: 'нечем обездвижить вражеских кор-героев в решающий момент',
      Durable: 'команда может не выдерживать размены в файтах',
      Nuker: 'мало бурст-урона, чтобы быстро снять цель',
    };

    const myPicks = actions.filter((a) => a.action === 'pick' && a.side === side && a.heroId != null);
    const enemyPicks = actions.filter((a) => a.action === 'pick' && a.side !== side && a.heroId != null);
    const heroIds = myPicks.map((p) => p.heroId!);
    const enemyHeroIds = enemyPicks.map((p) => p.heroId!);
    const heroes = await this.prisma.hero.findMany({ where: { id: { in: heroIds } } });
    const enemyHeroes = await this.prisma.hero.findMany({ where: { id: { in: enemyHeroIds } } });
    const heroesById = new Map(heroes.map((h) => [h.id, h]));

    // Role coverage
    const rolesPresent = new Set<string>();
    for (const h of heroes) (h.roles ?? []).forEach((r) => rolesPresent.add(r));
    const coveredCategories = ROLE_CATEGORIES.filter((r) => rolesPresent.has(r));
    const missingRoles = ROLE_CATEGORIES.filter((r) => !rolesPresent.has(r));
    const roleCoverage = Math.round((coveredCategories.length / ROLE_CATEGORIES.length) * 15);

    // Attribute diversity
    const attrs = new Set(heroes.map((h) => h.primaryAttr));
    const attributeDiversity = Math.round((Math.min(attrs.size, 4) / 4) * 8);

    // Counter-awareness — same scoring as the bot's pick heuristic,
    // applied retroactively to what was actually picked.
    let eligiblePicks = 0;
    let counterAwarePicks = 0;
    // Per-pick detail (requirement: show WHICH heroes, not just a
    // count) — who countered whom, and separately, which of MY picks
    // turned out to be the one getting countered by something the
    // enemy already had on board (this doubles as "risky pick"
    // material for the recommendations block).
    const counterDetails: { myHeroId: number; enemyHeroId: number }[] = [];
    const riskyPicks: { myHeroId: number; enemyHeroId: number }[] = [];
    for (const action of actions) {
      if (action.action !== 'pick' || action.side !== side || action.heroId == null) continue;

      const enemyPickedBefore = actions
        .slice(0, actions.indexOf(action))
        .filter((a) => a.action === 'pick' && a.side !== side && a.heroId != null)
        .map((a) => a.heroId!);
      if (enemyPickedBefore.length === 0) continue; // nothing to counter yet

      eligiblePicks += 1;
      const hero = heroesById.get(action.heroId);
      const counters = hero?.countersJson as unknown as { goodAgainst?: { heroId: number }[]; weakAgainst?: { heroId: number }[] } | null;
      const counteredEnemies = counters?.goodAgainst?.filter((g) => enemyPickedBefore.includes(g.heroId)) ?? [];
      if (counteredEnemies.length > 0) {
        counterAwarePicks += 1;
        for (const c of counteredEnemies) counterDetails.push({ myHeroId: action.heroId, enemyHeroId: c.heroId });
      }
      const weakAgainstEnemies = counters?.weakAgainst?.filter((w) => enemyPickedBefore.includes(w.heroId)) ?? [];
      for (const w of weakAgainstEnemies) riskyPicks.push({ myHeroId: action.heroId, enemyHeroId: w.heroId });
    }
    const counterAwareness =
      eligiblePicks > 0 ? Math.round((counterAwarePicks / eligiblePicks) * 15) : 0;
    const counterAwareRatio = eligiblePicks > 0 ? counterAwarePicks / eligiblePicks : null;

    // Requirement: 5 scoring categories, not 3 — these two were
    // already computed elsewhere in this file for the results-screen
    // visuals (Synergy Pentagon, lane matchup cards) but never
    // actually folded into the total score itself, which is exactly
    // what left it at 3 components (role coverage, attribute
    // diversity, counter-awareness) instead of 5.

    // Internal synergy — same rule set as the Synergy Pentagon
    // (computeAllSynergyPairs), scored here rather than just drawn:
    // each positive pair earns points, each negative one costs points,
    // scaled by how many of the 10 possible pairs among 5 heroes
    // actually fired a rule (most come back "neutral", which is
    // expected and not penalized).
    const synergyPairs = heroes.length >= 2 ? this.computeAllSynergyPairs(heroes) : [];
    const positivePairs = synergyPairs.filter((p) => p.tone === 'positive').length;
    const negativePairs = synergyPairs.filter((p) => p.tone === 'negative').length;
    const synergyScore = Math.max(0, Math.min(12, 6 + positivePairs * 2 - negativePairs * 3));

    // Lane matchup — the same position-assignment heuristic used for
    // the results screen's "Your Position N vs Enemy Position N"
    // cards, scored by how many of your assigned lanes have a synced
    // counter-advantage over whoever's assigned to the same position
    // on the enemy side. Same "no data = excluded, not penalized"
    // rule as counter-awareness above — only lanes where BOTH heroes
    // have synced countersJson data count toward eligiblePositions.
    const myPositions = await this.assignPositions(actions, side);
    const enemyPositions = enemyHeroes.length > 0 ? await this.assignPositions(actions, side === 'FIRST_PICK' ? 'SECOND_PICK' : 'FIRST_PICK') : [];
    let eligiblePositions = 0;
    let favorablePositions = 0;
    for (const mp of myPositions) {
      const ep = enemyPositions.find((p) => p.position === mp.position);
      if (!ep) continue;
      const myHero = heroesById.get(mp.heroId);
      const counters = myHero?.countersJson as unknown as { goodAgainst?: { heroId: number }[]; badAgainst?: { heroId: number }[] } | null;
      if (!counters?.goodAgainst && !counters?.badAgainst) continue; // this hero has no synced matchup data at all
      eligiblePositions += 1;
      if (counters.goodAgainst?.some((g) => g.heroId === ep.heroId)) favorablePositions += 1;
    }
    const laneMatchupScore = eligiblePositions > 0 ? Math.round((favorablePositions / eligiblePositions) * 10) : 0;
    const laneMatchupRatio = eligiblePositions > 0 ? favorablePositions / eligiblePositions : null;

    // Five new categories (requirement: 10 total, not 5) — every one
    // derived from Hero.roles tags actually synced from OpenDota
    // (Carry, Escape, Nuker, Initiator, Durable, Disabler, Jungler,
    // Support, Pusher — Valve's own canonical set, not invented
    // labels) plus primaryAttr, never a fabricated per-hero "meta
    // strength" number. Each yields both a score and its own
    // explanation sentences, same as the original five.
    const hasRole = (role: string) => heroes.some((h) => h.roles.includes(role));
    const countRole = (role: string) => heroes.filter((h) => h.roles.includes(role)).length;

    // TEAMFIGHT (12): initiation + mass control + durable frontline +
    // burst follow-up are the four real ingredients of a 5v5 a
    // drafter actually plans around.
    let teamfightScore = 0;
    const teamfightNotes: string[] = [];
    if (hasRole('Initiator')) { teamfightScore += 4; teamfightNotes.push('Есть герой для инициации боя.'); }
    else teamfightNotes.push('Нет выраженного инициатора — сложно навязать бой на своих условиях.');
    const disablerCount = countRole('Disabler');
    if (disablerCount >= 2) { teamfightScore += 4; teamfightNotes.push(`${disablerCount} героя(ев) с контролем — массовый контроль реален.`); }
    else if (disablerCount === 1) { teamfightScore += 2; teamfightNotes.push('Один источник контроля — бой держится на одном каст-окне.'); }
    else teamfightNotes.push('Контроля почти нет — тяжело удержать врага в бою.');
    if (hasRole('Durable')) { teamfightScore += 2; teamfightNotes.push('Есть герой, способный держать удар на передней линии.'); }
    if (hasRole('Nuker') && disablerCount >= 1) { teamfightScore += 2; teamfightNotes.push('Контроль + бурст-урон дают реальный follow-up после инициации.'); }
    teamfightScore = Math.min(12, teamfightScore);

    // DAMAGE PROFILE (8): reward having BOTH a physical (right-click,
    // proxied by Agility/Strength carries) and a magical (Nuker-
    // tagged) damage source — a one-dimensional damage profile is a
    // real, well-known drafting weakness (easy to itemize against).
    let damageScore = 0;
    const damageNotes: string[] = [];
    const hasPhysicalCore = heroes.some((h) => (h.primaryAttr === 'agi' || h.primaryAttr === 'str') && h.roles.includes('Carry'));
    const nukerCount = countRole('Nuker');
    if (hasPhysicalCore) { damageScore += 4; damageNotes.push('Есть физический керри для стабильного правого клика в лейтгейме.'); }
    else damageNotes.push('Нет выраженного физического керри — урон в лейтгейме под вопросом.');
    if (nukerCount >= 1) { damageScore += 4; damageNotes.push(`${nukerCount} героя(ев) с магическим бурстом — есть альтернативный источник урона.`); }
    else damageNotes.push('Нет магического бурста — весь урон зависит от предметов и авто-атак.');
    if (hasPhysicalCore && nukerCount >= 1) damageNotes.push('Смешанный профиль урона — сложнее закупиться против него одним типом защиты.');
    damageScore = Math.min(8, damageScore);

    // CONTROL & INITIATION (10) — a more granular version of the
    // teamfight signal above, scored on its own since "having control"
    // and "using it to win fights" are related but distinct questions
    // a drafter asks separately.
    let controlScore = 0;
    const controlNotes: string[] = [];
    if (disablerCount >= 2) { controlScore += 6; controlNotes.push('Несколько источников контроля — можно чейнить обездвиживание.'); }
    else if (disablerCount === 1) { controlScore += 3; controlNotes.push('Один источник контроля в составе.'); }
    else controlNotes.push('Контроля нет вообще — мобильных героев соперника нечем поймать.');
    if (hasRole('Initiator')) { controlScore += 4; controlNotes.push('Инициатор может начать бой первым, а не реагировать на чужую инициацию.'); }
    controlScore = Math.min(10, controlScore);

    // SCALING (5): a coherent game plan across phases — too many pure
    // Carry-tagged heroes with nothing else is a real, common draft
    // mistake ("5 late-game heroes, no early presence"), not an
    // invented penalty.
    let scalingScore = 0;
    const scalingNotes: string[] = [];
    const carryCount = countRole('Carry');
    const earlyPresence = countRole('Nuker') + countRole('Initiator') + countRole('Disabler');
    if (carryCount >= 1 && carryCount <= 2) { scalingScore += 3; scalingNotes.push(`${carryCount} чётких керри — понятный вин-кондишн в лейтгейме.`); }
    else if (carryCount >= 3) { scalingNotes.push('Слишком много героев тянут в лейтгейм одновременно — фарм будет делиться.'); }
    else scalingNotes.push('Нет выраженного керри — неясно, кто закрывает игру в лейте.');
    if (earlyPresence >= 2) { scalingScore += 2; scalingNotes.push('Достаточно героев с ранним impact — можно давить, пока керри фармит.'); }
    scalingScore = Math.min(5, scalingScore);

    // OBJECTIVES & TEMPO (5): push/map-control presence — Pusher and
    // Jungler tags are OpenDota's own real signals for exactly this.
    let objectivesScore = 0;
    const objectivesNotes: string[] = [];
    if (hasRole('Pusher')) { objectivesScore += 3; objectivesNotes.push('Есть герой с давлением на строения — можно закрывать игру через темп, а не только через бои.'); }
    else objectivesNotes.push('Нет выраженного пушера — давление на карту будет держаться только на драках.');
    if (hasRole('Jungler') || hasRole('Escape')) { objectivesScore += 2; objectivesNotes.push('Есть гибкость по карте (фарм вне линии или быстрый отход) для контроля темпа.'); }
    objectivesScore = Math.min(5, objectivesScore);

    // "Кого стоило забанить лучше" — among every hero nobody used
    // (banned or picked) this game, which one has the strongest synced
    // matchup against THIS side's final picks? Only meaningful for
    // heroes that have had syncMatchups run on them — most won't, so
    // this frequently comes back null, which the frontend shows as
    // "недостаточно данных", not a false "nobody was dangerous".
    const usedIds = new Set(actions.filter((a) => a.heroId != null).map((a) => a.heroId));
    const unusedHeroes = await this.prisma.hero.findMany({
      where: { captainsModeAvailable: true, id: { notIn: [...usedIds] as number[] } },
    });
    let mostDangerousUnbanned: { heroId: number; score: number } | null = null;
    const dangerousUnbanned: { heroId: number; score: number }[] = [];
    for (const h of unusedHeroes) {
      const counters = h.countersJson as unknown as { goodAgainst?: { heroId: number }[] } | null;
      const score = counters?.goodAgainst?.filter((g) => heroIds.includes(g.heroId)).length ?? 0;
      if (score > 0) {
        dangerousUnbanned.push({ heroId: h.id, score });
        if (!mostDangerousUnbanned || score > mostDangerousUnbanned.score) {
          mostDangerousUnbanned = { heroId: h.id, score };
        }
      }
    }
    dangerousUnbanned.sort((a, b) => b.score - a.score);
    const topDangerousUnbanned = dangerousUnbanned.slice(0, 3);

    // Plain-language reasons, grouped by category so the frontend can
    // show each explanation directly under the category it explains
    // (requirement 7: "что именно оценивается... почему начислены
    // очки") rather than one undifferentiated list a reader has to
    // match up themselves.
    const explanations: {
      roles: string[]; attributes: string[]; counters: string[]; synergy: string[]; lanes: string[];
      teamfight: string[]; damage: string[]; control: string[]; scaling: string[]; objectives: string[];
    } = { roles: [], attributes: [], counters: [], synergy: [], lanes: [], teamfight: teamfightNotes, damage: damageNotes, control: controlNotes, scaling: scalingNotes, objectives: objectivesNotes };

    if (missingRoles.length > 0) {
      explanations.roles.push(`Не хватает ролей: ${missingRoles.join(', ')} — ${missingRoles.map((r) => ROLE_HINTS[r]).join('; ')}.`);
    } else {
      explanations.roles.push('Все пять ключевых ролей закрыты хотя бы одним героем — состав структурно полный.');
    }
    if (coveredCategories.length > 0) {
      explanations.roles.push(`Закрытые роли: ${coveredCategories.join(', ')}.`);
    }

    if (attrs.size <= 2) {
      explanations.attributes.push(`Состав сосредоточен на ${attrs.size} атрибуте(ах) (${[...attrs].join('/')}) — уязвим к одной стратегии контригры (например, магический бурст против интеллекта или физический — против ловкости).`);
    } else {
      explanations.attributes.push(`Атрибуты распределены между ${attrs.size} категориями (${[...attrs].join('/')}) — сложнее контрить одним типом урона.`);
    }

    if (counterDetails.length > 0) {
      for (const c of counterDetails) {
        explanations.counters.push(`${heroesById.get(c.myHeroId)?.localizedName ?? c.myHeroId} контрит ${c.enemyHeroId} — пик учитывал уже открытого героя соперника.`);
      }
    } else if (eligiblePicks > 0) {
      explanations.counters.push('Ни один поздний пик не использовал синхронизированное преимущество над уже открытыми героями соперника.');
    } else {
      explanations.counters.push('Недостаточно синхронизированных данных по контрпикам, чтобы оценить эту категорию.');
    }
    if (riskyPicks.length > 0) {
      for (const r of riskyPicks) {
        explanations.counters.push(`⚠ ${heroesById.get(r.myHeroId)?.localizedName ?? r.myHeroId} статистически слаб против ${r.enemyHeroId} — рискованный пик против этого соперника.`);
      }
    }

    if (synergyPairs.length > 0) {
      for (const p of synergyPairs.filter((p) => p.tone !== 'neutral')) {
        const nameA = heroesById.get(p.heroAId)?.localizedName ?? p.heroAId;
        const nameB = heroesById.get(p.heroBId)?.localizedName ?? p.heroBId;
        explanations.synergy.push(`${p.tone === 'positive' ? '✓' : '✗'} ${nameA} ↔ ${nameB} — ${p.reason}.`);
      }
      if (explanations.synergy.length === 0) {
        explanations.synergy.push('Значимых связок (ни сильных, ни конфликтующих) по доступным тегам ролей не найдено — состав нейтрален по внутренней синергии.');
      }
    }

    if (laneMatchupRatio == null) {
      explanations.lanes.push('Недостаточно синхронизированных данных по линиям, чтобы оценить эту категорию.');
    } else {
      for (const mp of myPositions) {
        const ep = enemyPositions.find((p) => p.position === mp.position);
        if (!ep) continue;
        const myHero = heroesById.get(mp.heroId);
        const counters = myHero?.countersJson as unknown as { goodAgainst?: { heroId: number }[]; badAgainst?: { heroId: number }[] } | null;
        if (!counters?.goodAgainst && !counters?.badAgainst) continue;
        const favors = counters.goodAgainst?.some((g) => g.heroId === ep.heroId);
        explanations.lanes.push(
          `${mp.label}: ${myHero?.localizedName ?? mp.heroId} против ${ep.heroId} — ${favors ? 'выгодный матчап по линии' : 'нейтральный или невыгодный матчап по линии'}.`,
        );
      }
      if (laneMatchupRatio < 0.4) {
        explanations.lanes.push('По расчётной расстановке несколько ваших линий структурно проигрывают своим визави — стоит пересмотреть, кто на какой позиции.');
      }
    }

    // Kept for anything still reading the old flat shape — a superset
    // built from the same categorized sentences above, not a second
    // independent source of truth.
    const reasons: string[] = [...explanations.roles, ...explanations.attributes, ...explanations.counters, ...explanations.synergy, ...explanations.lanes, ...teamfightNotes, ...damageNotes, ...controlNotes, ...scalingNotes, ...objectivesNotes];

    // Alternative-pick suggestion (requirement 9's "Alternative pick:
    // Hero X instead of Hero Y") — for each risky pick above, look for
    // an unused hero sharing at least one role tag (so the suggestion
    // stays a plausible same-job swap, not a random hero) that
    // actually counters the same enemy hero the risky pick was weak
    // against.
    const alternativePicks: { insteadOfHeroId: number; suggestedHeroId: number; vsEnemyHeroId: number }[] = [];
    for (const r of riskyPicks) {
      const myHero = heroesById.get(r.myHeroId);
      if (!myHero) continue;
      const candidate = unusedHeroes.find((h) => {
        if (h.id === r.myHeroId) return false;
        const sharesRole = h.roles.some((role) => myHero.roles.includes(role));
        const counters = h.countersJson as unknown as { goodAgainst?: { heroId: number }[] } | null;
        return sharesRole && counters?.goodAgainst?.some((g) => g.heroId === r.enemyHeroId);
      });
      if (candidate) alternativePicks.push({ insteadOfHeroId: r.myHeroId, suggestedHeroId: candidate.id, vsEnemyHeroId: r.enemyHeroId });
    }

    return {
      total: roleCoverage + attributeDiversity + counterAwareness + synergyScore + laneMatchupScore + teamfightScore + damageScore + controlScore + scalingScore + objectivesScore,
      roleCoverage,
      attributeDiversity,
      counterAwareness,
      synergyScore,
      laneMatchupScore,
      teamfightScore,
      damageScore,
      controlScore,
      scalingScore,
      objectivesScore,
      synergyPositivePairs: positivePairs,
      synergyNegativePairs: negativePairs,
      laneMatchupEligiblePositions: eligiblePositions,
      laneMatchupRatio,
      coveredRoles: coveredCategories,
      missingRoles,
      distinctAttributes: attrs.size,
      counterAwareEligiblePicks: eligiblePicks,
      // Null (not 0) when there was no opportunity to counter-pick at
      // all, so the frontend can show "n/a" instead of implying a bad
      // score for something structurally impossible to earn.
      counterAwareRatio,
      mostDangerousUnbanned,
      dangerousUnbanned: topDangerousUnbanned,
      counterDetails,
      riskyPicks,
      alternativePicks,
      explanations,
      reasons,
    };
  }

  /**
   * Imports a real pro match's draft as a read-only, already-completed
   * session - "study a real draft", not "practice your own". Only works
   * for Captain's Mode matches; anything without a `picks_bans` array
   * (All Pick, Turbo, etc.) will fail here rather than fabricate one.
   */
  async startProReplay(userId: string, matchId: number) {
    const match = await this.openDota.getMatch(matchId);
    if (!match.picks_bans || match.picks_bans.length === 0) {
      throw new NotFoundException(
        `Match ${matchId} has no picks_bans data - likely not a Captain's Mode game`,
      );
    }

    const sorted = [...match.picks_bans].sort((a, b) => a.order - b.order);
    // Convention for replay display only: team 0 (Radiant) is labeled
    // FIRST_PICK, team 1 (Dire) SECOND_PICK — real Radiant/Dire is known
    // directly from OpenDota here, no guessing needed for this mode.
    const events: DraftEvent[] = sorted.map((pb, i) => ({
      step: i + 1,
      side: pb.team === 0 ? 'FIRST_PICK' : 'SECOND_PICK',
      action: pb.is_pick ? 'pick' : 'ban',
      heroId: pb.hero_id,
      timedOut: false,
      timeLimitSec: 0,
      reserveSpent: 0,
    }));

    return this.prisma.draftSession.create({
      data: {
        createdByUserId: userId,
        mode: 'pro_replay',
        sequence: events.map(({ step, side, action, timeLimitSec }) => ({ step, side, action, timeLimitSec })) as any,
        actions: events as any,
        status: 'completed',
        radiantSide: 'FIRST_PICK',
        sourceProMatchId: BigInt(matchId),
      },
    });
  }
}
